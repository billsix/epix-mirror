/*
 * lengths.c: Scaling and length conversion
 *
 * There are three types of coordinates/length in ePiX:
 *   (1) Cartesian (the user interface)
 *   (2) LaTeX picture coordinates (unitlength, the output)
 *   (3) File-independent true unit (pt, used for visual formatting)
 *
 * Cartesian coordinates live in [x_min, x_max] x [y_min, y_max], the 
 * "bounding box". Latex picture coordinates live in the "picture box"
 * [0, h_size] x [0, v_size]. The functions hscale and vscale handle
 * Cartesian to picture coordinate conversion; h_unscale and v_unscale
 * are the inverse functions.
 * 
 * The user specifies objects' locations in Cartesian coordinates, which
 * facilitates the design of portable, mathematically accurate figures. 
 * There is also a facility for offsetting labels by amounts in true pt;
 * This eases the visual placement of labels, and helps to make the figure 
 * portable: A change of bounding box re-positions the label's basepoint
 * globally, while the offset (which is scale-independent) adjusts the
 * label from its new basepoint.
 *
 * True-coordinate changes are handled by scale (which converts true pt
 * to (user-specified) LaTeX picture units and its inverse, unscale. In
 * summary, "scale" functions convert *to* picture coordinates, "unscale"
 * functions convert *from* picture coordinates. These functions know about 
 * the following LaTeX dimensions: "cm", "in", "mm", "pc", and "pt"
 *
 * 
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.6.5
 * Last Change: August 22, 2001
 */

#include <stdlib.h>
#include "epix.h"

short int scale_warning=0;

/* Number of pic_units per unitlength */
extern double pic_size; 
/* "cm", "in", "mm", "pc", or "pt" */
extern char *pic_unit; 

/* Cartesian dimensions */
extern double x_min, x_max, y_min, y_max;
extern double x_size, y_size;

/* LaTeX dimensions */
extern double h_size, v_size;


/*
 * About truncation and numerical accuracy of output:
 *
 * Functions that convert Cartesian to picture units truncate output
 * as of version 0.6.5, to avoid printing %e-type expressions in
 * output.  This means that h_unscale is no longer the inverse of
 * h_scale to machine precision, though it is quite close, and will
 * not cause problems for reasonable LaTeX unitlength. ("reasonable"
 * meaning "truncation in h_scale is unnoticeable":) Similar remarks
 * hold for h_stretch, but currently h_unstretch is only provided for
 * completeness, and in any case the difference between (say)
 * h_unstretch(hscale(x)) and x is no more than (10^-4)*unitlength.
 */

/* Cartesian to unitlength for points */
double h_scale(double x_posn)
{
  return truncate((x_posn - x_min)*h_size/x_size);
}
double v_scale(double y_posn)
{
  return truncate((y_posn - y_min)*v_size/y_size);
}

/* unitlength to Cartesian */
double h_unscale(double h_posn)
{
  return x_min + h_posn*x_size/h_size;
}
double v_unscale(double v_posn)
{
  return y_min + v_posn*y_size/v_size;
}

/* Cartesian to unitlength for direction vectors */
double h_stretch(double x)
{
  return truncate(x*h_size/x_size);
}
double v_stretch(double y)
{
  return truncate(y*v_size/y_size);
}

/* unitlength to Cartesian for direction vectors */
double h_unstretch(double u)
{
  return u*x_size/h_size;
}
double v_unstretch(double v)
{
  return v*y_size/v_size;
}

/*
 * true pts to unitlength
 */
double scale(double true)
{
  if (! strcmp((char *)pic_unit,"cm"))
    return (true/pic_size)*(2.54/72.27);

  else if (! strcmp((char *)pic_unit,"in"))
    return (true/pic_size)*(1.0/72.27);

  else if (! strcmp((char *)pic_unit,"mm"))
    return (true/pic_size)*(25.4/72.27);

  else if (! strcmp((char *)pic_unit,"pc"))
    return (true/pic_size)*(1.0/12.0);

  else if (! strcmp((char *)pic_unit,"pt"))
    return (true/pic_size);

  /* Invalid unit length and no warning printed yet */
  else if (scale_warning == 0) 
    {
      scale_warning = 1;
      
      printf("%%%% ePiX WARNING: Unrecognized units \"%s\"! ", pic_unit);
      printf("Scaling may be incorrect.\n");
      printf("%%%%   Valid units are ");
      printf("\"cm\", \"in\", \"mm\", \"pc\", and \"pt\".\n");
      printf("%%%%   Please check the preamble of your source file.\n");
      printf("%%%%\n");
      return true/pic_size;
    }

  /* Warning issued already; try our best to comply... */
  else
    return true/pic_size;
}

/*
 * unitlength to true pts
 */
double unscale(double latex_coord)
{
  if (! strcmp((char *)pic_unit,"cm"))
    return (latex_coord*pic_size)*(72.27/2.54);

  else if (! strcmp((char *)pic_unit,"in"))
    return (latex_coord*pic_size)*(72.27);

  else if (! strcmp((char *)pic_unit,"mm"))
    return (latex_coord*pic_size)*(72.27/25.4);

  else if (! strcmp((char *)pic_unit,"pc"))
    return (latex_coord*pic_size)*(12.0);

  else if (! strcmp((char *)pic_unit,"pt"))
    return (latex_coord*pic_size);

  /* Invalid unit length and no warning printed yet */
  else if (scale_warning == 0) 
    {
      scale_warning = 1;
      
      printf("%%%% ePiX WARNING: Unrecognized units \"%s\"! ", pic_unit);
      printf("Scaling may be incorrect.\n");
      printf("%%%%   Valid units are ");
      printf("\"cm\", \"in\", \"mm\", \"pc\", and \"pt\".\n");
      printf("%%%%   Please check the preamble of your source file.\n");
      printf("%%%%\n");
      return latex_coord*pic_size;
    }

  /* Warning issued already; try our best to comply... */
  else
    return latex_coord*pic_size;
}


