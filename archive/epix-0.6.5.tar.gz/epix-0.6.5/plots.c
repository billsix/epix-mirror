/*
 * plots.c: Plots and parametric plots of user-defined functions
 *
 * Includes functions for plotting derivatives and integrals.  The
 * algorithms are simple-minded: finite difference centered at t for
 * derivatives, the trapezoid method for integrals, Euler's method for
 * solutions of ODEs.
 *
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.6.5
 * Last Change: August 22, 2001
 */

#include "epix.h"

extern double x_min, x_max, y_min, y_max;
extern double h_size, v_size;

/* 
 * Increment for Newton quotient, integral; must be defined in
 * each function that uses it, usually in terms of the picture
 * size, e.g.,  dh = (x_max - x_min)/(num_pts*ITERATIONS)
 */
static double dt; 

extern int lines_printed; // Counter for controlling output length

void comment_plot(char *type)
{
  printf("\n%%%% %s:", type);  
}

/* Functions for adaptive plotting */

/* Classical Newtonian increment */
static double delta(double f(double), double t, double dt)
{
  return (*f)(t + dt) - (*f)(t);
}

static double arclength(double f1(double), double f2(double),
			double t_min, double t_max, int n)
{
  int i = 0;
  double sum = 0;
  double dt = (t_max - t_min)/(n*ITERATIONS);

  for (i=0; i < n*ITERATIONS; ++i)
    sum += hypot(delta(*f1, t_min + i*dt, dt), delta(*f2, t_min + i*dt, dt));

  return sum;
}

void draw_adapt_plot(double f1(double), double f2(double),
		     double t_min, double t_max, int n, const int path_style)
{
  int i = 0;
  double sum = 0;
  int pt_count = 0;
  double dt = (t_max - t_min)/(n*ITERATIONS);
  double step = (1.0/n)*arclength(*f1, *f2, t_min, t_max, n);
  int step_count = 0;

  start_path(path_style); // pt_count already = 1
  printf("(%g,%g)", h_scale((*f1)(t_min)), v_scale((*f2)(t_min)));

  for (i=0; i <= n*ITERATIONS; ++i)
    {
    sum += hypot(delta(*f1, t_min + i*dt, dt), delta(*f2, t_min + i*dt, dt));
      ++step_count;

      if (step <= sum || ITERATIONS <= step_count) {
	line_break(pt_count++, n*ITERATIONS, path_style);
	  printf("(%g,%g)", 
		 h_scale((*f1)(t_min + i*dt)), 
		 v_scale((*f2)(t_min + i*dt)));
	  sum -= step;
	  step_count = 0;
      }
    }
}
	
void adplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("adplot");
  draw_adapt_plot(*id, *f, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void dashadplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("dashadplot");
  draw_adapt_plot(*id, *f, t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void dotadplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("dotadplot");
  draw_adapt_plot(*id, *f, t_min, t_max, num_pts, DOT);
  end_stanza();
}

void boldadplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("boldadplot");
  bold();
  draw_adapt_plot(*id, *f, t_min, t_max, num_pts, BOLD);
  end_bold();
  end_stanza();
}

void draw_plot(double plot_f(double), double t_min, double t_max, 
	       int num_pts, const int path_style)
{
  int i;
  double t;

  start_path(path_style);
  for (i=0; i <= num_pts; ++i)
    {
      t = t_min + i*(t_max - t_min)/num_pts;

      printf("(%g,%g)", h_scale(t), v_scale((*plot_f)(t)));
      line_break(i, num_pts, path_style);
    }
}

void plot(double plot_f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("plot");
  draw_plot((*plot_f), t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void dashplot(double plot_f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("dashplot");
  draw_plot((*plot_f), t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void dotplot(double plot_f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("dotplot");
  draw_plot((*plot_f), t_min, t_max, num_pts, DOTTED);
  end_stanza();
}

void boldplot(double plot_f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("boldplot");

  bold();
  draw_plot((*plot_f), t_min, t_max, num_pts, BOLD);
  endbold();
  end_stanza();
}

void draw_paramplot(double plot_h(double), double plot_v(double), \
	  double t_min, double t_max, int num_pts, const int path_style)
{
  int i;
  double t;

  start_path(path_style);
  for (i=0; i <= num_pts; ++i)
    {
      t = t_min + i*(t_max - t_min)/num_pts;

      printf("(%g,%g)", h_scale((*plot_h)(t)), v_scale((*plot_v)(t)));
      line_break(i, num_pts, path_style);
    }
}

void paramplot(double plot_h(double), double plot_v(double), \
	       double t_min, double t_max, int num_pts)
{
  comment_plot("paramplot");
  draw_paramplot((*plot_h), (*plot_v), t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void dashparamplot(double plot_h(double), double plot_v(double), \
		   double t_min, double t_max, int num_pts)
{
  comment_plot("dashparamplot");
  draw_paramplot((*plot_h), (*plot_v), t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void dotparamplot(double plot_h(double), double plot_v(double), \
		  double t_min, double t_max, int num_pts)
{
  comment_plot("dotparamplot");
  draw_paramplot((*plot_h), (*plot_v), t_min, t_max, num_pts, DOTTED);
  end_stanza();
}

void boldparamplot(double plot_h(double), double plot_v(double), \
		   double t_min, double t_max, int num_pts)
{
  comment_plot("boldparamplot");
  bold();
  draw_paramplot((*plot_h), (*plot_v), t_min, t_max, num_pts, BOLD);
  endbold();
  end_stanza();
}

/*
 * Angles measured in revolutions (2\pi radians)
 */

void draw_polarplot(double plot_r(double), double t_min, \
		    double t_max, int num_pts, const int path_style)
{
  int i;
  double t;
  double rho;

  start_path(path_style);
  for (i=0; i <= num_pts; ++i)
    {
      t = 2*M_PI*(t_min + i*(t_max - t_min)/num_pts);

      rho=(*plot_r)(t);
      printf("(%g,%g)", h_scale(rho*cos(t)), v_scale(rho*sin(t)));
      line_break(i, num_pts, path_style);
  }
}

void polarplot(double plot_r(double), double t_min, double t_max, int num_pts)
{
  comment_plot("polarplot");
  draw_polarplot((*plot_r), t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void dashpolarplot(double plot_r(double), double t_min, \
		   double t_max, int num_pts)
{
  comment_plot("dashpolarplot");
  draw_polarplot((*plot_r), t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void dotpolarplot(double plot_r(double), double t_min, \
		  double t_max, int num_pts)
{
  comment_plot("dotpolarplot");
  draw_polarplot((*plot_r), t_min, t_max, num_pts, DOTTED);
  end_stanza();
}

void boldpolarplot(double plot_r(double), double t_min, \
		   double t_max, int num_pts)
{
  comment_plot("boldpolarplot");
  bold();
  draw_polarplot((*plot_r), t_min, t_max, num_pts, BOLD);
  endbold();
  end_stanza();
}

/* Plotting functions that truncate plots at bounding box */

/*
 * edge-seek
 *
 * Approximates point where plot goes outside global bounding box.
 * Algorithm: Start at point known to be inside, take small steps
 * towards outside point, stop when point goes outside.
 */
struct pair edge_seek(double t, double f(double), double step)
{
  struct pair temp;

  while (x_min <= t && t <= x_max && y_min <= (*f)(t) && (*f)(t) <= y_max)
    {
      temp.x1 = t;
      temp.x2 = (*f)(t);
      t += (SEEK_SIZE)*step; 
    }
  return temp;
}

/*
 * clipplot and its variants plot a curve by keeping track of the
 * state (in/out of bounding region) of pairs of adjacent points. The
 * <previous> point is initially outside the bounding region. 
 * Subsequently, if (previous, current) = 
 * (out, in)  --> Start new path segment (seek back to find edge)
 * (in, in)   --> Continue existing path
 * (in, out)  --> End current path segment (seek forward to find edge)
 * (out, out) --> Print nothing, test next point
 */

void draw_clipplot(double f(double), double t_min, double t_max, 
		   int num_pts, const int path_style)
{
  struct pair curr, prev;
  int current=1, previous=0; /* In/out of bounding box */
  int i;
  int pt_count=0; /* Points printed in path segment, to format output */
  int pr_flag=0; /* Whether any points have been printed */
  double t, step = (t_max - t_min)/num_pts;
  
  for (i=0; i <= num_pts; ++i)
    {
      t = t_min + i*step;
      curr = P(t, (*f)(t));

      if (x_min <= curr.x1 && curr.x1 <= x_max && \
	  y_min <= curr.x2 && curr.x2 <= y_max)
	current=1;
      else
	current=0;
      
      /*
       * Four cases: Previous is in/out, current is in/out.
       */
      
      /* Start new path component */
      if (current == 1 && previous == 0)
	{
	  if (t == t_min) // print first point
	    {
	      start_path(path_style);
	      printf("(%g,%g)", h_scale(curr.x1), v_scale(curr.x2) );
	      pt_count = 1;
	    }
	  else // print 2 points: seek-back and current
	    {
	      if (pr_flag == 0)
		start_path(path_style);

	      else
		{
		  printf("\n%%%%"); // New sub-stanza
		  start_path(path_style);
		}

	      printf("(%g,%g)(%g,%g)",
		     /* Seek back to edge of bounding box */
		     h_scale((edge_seek(t, (*f), -(1.0)*step)).x1), \
		     v_scale((edge_seek(t, (*f), -(1.0)*step)).x2), \
		     h_scale(curr.x1), v_scale(curr.x2) );
	      pt_count=2;
	    }
	  pr_flag=1;
	  previous=1;
	  prev=curr;
	}
      
      /* Continue path */
      else if (current == 1 && previous == 1)
	{
	  line_break(pt_count - 1, num_pts, path_style);
	  printf("(%g,%g)", h_scale(curr.x1), v_scale(curr.x2));
	  previous=1;
	  prev=curr;
	  
	  ++pt_count;
	}
      
      /* End current path */
      else if (current == 0 && previous == 1)
	{
	  line_break(pt_count - 1, num_pts, path_style);
	  printf("(%g,%g)", \
		 /* 
		  * Magic number (0.01): Skip back 1+e path steps, then
		  * seek forward. Acceptably handles the case in which
		  * previous + seek_step is outside the bounding box.
		  */
		 h_scale((edge_seek(t - (1+(0.01)*SEEK_SIZE)*step, \
				    (*f), step)).x1), \
		 v_scale((edge_seek(t - (1+(0.01)*SEEK_SIZE)*step, \
				    (*f), step)).x2) );
	  previous=0;
	  prev=curr;
	  pt_count=0;
	}
      
      /* (current == 0 && previous == 0), keep searching... */
      else 
	{
	  previous=0;
	  prev=curr;
	}
    }
}

void clipplot(double f(double), double t_min, double t_max, int num_pts)
{
  printf("\n%%%% clipplot:");  
  draw_clipplot(*f, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void dashclipplot(double f(double), double t_min, double t_max, int num_pts)
{
  printf("\n%%%% dashclipplot:");  
  draw_clipplot(*f, t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void dotclipplot(double f(double), double t_min, double t_max, int num_pts)
{
  printf("\n%%%% dotclipplot:");  
  draw_clipplot(*f, t_min, t_max, num_pts, DOTTED);
  end_stanza();
}

void boldclipplot(double f(double), double t_min, double t_max, int num_pts)
{
  printf("\n%%%% boldclipplot:");  
  bold();
  draw_clipplot(*f, t_min, t_max, num_pts, BOLD);
  endbold();
  end_stanza();
}

/* Data plotting from file */

/*
 * Input file consists of lines containing two double-precision
 * floating point numbers separated by whitespace. Lines starting
 * with '%' are discarded, as are lines not matching the format
 * string "%g %g \n".
 */
void marker(struct pair p, const int mark_type)
{
  switch(mark_type) {
  case SPOT:   
    printf("\n\\put(%g,%g){\\circle*{%g}}\t%%%% (%g,%g)",
	 h_scale(p.x1), v_scale(p.x2), scale(DIAM), p.x1, p.x2);
    break;
  case RING:   
    printf("\n\\put(%g,%g){\\circle{%g}}\t%%%% (%g,%g)",
	 h_scale(p.x1), v_scale(p.x2), scale(DIAM), p.x1, p.x2);
    break;
  case DOT:   
    printf("\n\\put(%g,%g){\\circle*{%g}}\t%%%% (%g,%g)",
	 h_scale(p.x1), v_scale(p.x2), scale(0.5*DIAM), p.x1, p.x2);
    break;
  case DDOT:   
    printf("\n\\put(%g,%g){\\circle*{%g}}\t%%%% (%g,%g)",
	 h_scale(p.x1), v_scale(p.x2), scale(0.25*DIAM), p.x1, p.x2);
    break;
  case PLUS:   
    printf("\n%%%% + at (%.2f,%.2f):", p.x1, p.x2);
    printf("\n\\put(%g,%g){\\kern -0.25pt \\rule[-2pt]{0.5pt}{4pt}}",
	   h_scale(p.x1), v_scale(p.x2));
    printf("\n\\put(%g,%g){\\kern -2pt \\rule[-0.25pt]{4pt}{0.5pt}}",
	   h_scale(p.x1), v_scale(p.x2));
    break;
  case BOX:   
    /* Magic number 4pt */
    printf("\n\\put(%g,%g){\\kern 2pt \\rule[-2pt]{4pt}{4pt}}",
	   h_scale(p.x1), v_scale(p.x2));
    break;
  case BBOX:   
    /* Magic number 2pt */
    printf("\n\\put(%g,%g){\\kern 1pt \\rule[-1pt]{2pt}{2pt}}",
	   h_scale(p.x1), v_scale(p.x2));
    break;
  default: 
    break;
  }
}

void data_plot(const char *data, const int mark_type)
{
  double x, y;
  FILE *input;
  char line[FILE_WIDTH+1];
  int lineno = 0;

  input = fopen(data, "r");

  if (input != NULL) { // No error opening data file
    printf("\n%%%% data_plot: File %s \n%%%%", data);

    while (fgets(line, FILE_WIDTH, input) != NULL) {
      ++lineno;
      if (line[0] == '%') // '%' starts comment line
	;

      else if (sscanf(line, "%lg %lg", &x, &y) == 2)
	marker(P(x, y), mark_type);

      else 
	{
	  printf("\n%%%% Ignoring line %d of file %s", lineno, data);
	  ++lines_printed;
	}
    } // while()
    fclose(input);
  } // if()
  
  else 
    printf("\n%%%% Couldn't open file %s", data);
  
  end_stanza();
}
  
/* Calculus plots: derivatives and definite integrals */

/* Difference quotient of f at t */
static double deriv(double f(double), double t, double dt)
{
  return ((*f)(t + 0.5*dt) - (*f)(t - 0.5*dt))/dt;
}

static double integrand(double f(double), double t, double dt)
{
  return (0.5)*((*f)(t) + (*f)(t + dt))*dt; /* Trapezoid formula */
}

/* Print list of ordered pairs */
void draw_deriv(double f(double), double a, double b, 
		int num_pts, const int path_style)
{
  /*
   * Algorithm: Partition into intervals of length dt=(b-a)/N;
   *  Evaluate f'(t) for t=a, a+0.5*dt, ..., b-0.5*dt, b.
   */
  double t = a;
  int i=1;

  dt = (b-a)/(num_pts*ITERATIONS);

  start_path(path_style);

  /* f'(a) */
  printf("(%g,%g)", h_scale(t), v_scale(((*f)(t + dt) - (*f)(t))/dt));
  t += 0.5*dt;

  for (i=1; i <= num_pts; ++i)
    {
      printf("(%g,%g)", h_scale(t), v_scale(deriv((*f), t, dt)) );
      line_break(i, num_pts, path_style);
      t += dt*ITERATIONS;
    }
  /* f'(b) */
  t += 0.5*dt;
  printf("(%g,%g)", h_scale(t), v_scale(((*f)(t) - (*f)(t - dt))/dt));
}

void plot_deriv(double f(double t), double a, double b, int num_pts)
{
  comment_plot("plot_deriv");
  draw_deriv((*f), a, b, num_pts, PLAIN);
  end_stanza();
}

void dashplot_deriv(double f(double t), double a, double b, int num_pts)
{
  comment_plot("dashplot_deriv");
  draw_deriv((*f), a, b, num_pts, DASHED);
  end_stanza();
}

void dotplot_deriv(double f(double t), double a, double b, int num_pts)
{
  comment_plot("dotplot_deriv");
  draw_deriv((*f), a, b, num_pts, DOTTED);
  end_stanza();
}

void boldplot_deriv(double f(double t), double a, double b, int num_pts)
{
  comment_plot("boldplot_deriv");
  bold();
  draw_deriv((*f), a, b, num_pts, BOLD);
  endbold();
  end_stanza();
}

/* Tangent field along parametrized path */
void tan_field(double f1(double), double f2(double), double t_min, \
	       double t_max, double num_pts)
{
  double t=t_min;
  double dt=(t_max - t_min)/(num_pts*ITERATIONS);
  int i;

  comment_plot("tan_field");

  for (i=0; i <= num_pts; ++i, t+=ITERATIONS*dt)
    {
      draw_arrow(P((*f1)(t), (*f2)(t)), // basepoint
		 add_pair(P((*f1)(t), (*f2)(t)), //basepoint
			  /* plus tangent vector */
			 mult_s(ITERATIONS, P((*f1)(t+dt/2)-(*f1)(t-dt/2), \
					      (*f2)(t+dt/2)-(*f2)(t-dt/2)))),
		 PLAIN);
      if (i < num_pts )
	printf("\n%%%%");
    }
  end_stanza();
}

void boldtan_field(double f1(double), double f2(double), double t_min, \
	       double t_max, double num_pts)
{
  double t=t_min;
  double dt=(t_max - t_min)/(num_pts*ITERATIONS);
  int i;

  comment_plot("boldtan_field");

  for (i=0; i <= num_pts; ++i, t+=ITERATIONS*dt)
    {
      draw_boldarrow(P((*f1)(t), (*f2)(t)), // basepoint
		     add_pair(P((*f1)(t), (*f2)(t)), //basepoint
			      /* plus tangent vector */
			 mult_s(ITERATIONS, P((*f1)(t+dt/2)-(*f1)(t-dt/2), \
					      (*f2)(t+dt/2)-(*f2)(t-dt/2)))));
      if (i < num_pts )
	printf("\n%%%%");
    }
  end_stanza();
}

/* Print raw path */
void draw_int(double f(double), double a, double b, 
	      int num_pts, const int path_style)
{
  /*
   * Integrand is 0.5*(f(t) + f(t+dt))*dt
   */
  double t = a, sum = 0; 
  int i, pt_count=0;
  dt = (b-a)/(num_pts*ITERATIONS);

  start_path(path_style);
  for (i=0; i <= num_pts*ITERATIONS; ++i)
    {
      if (i%ITERATIONS == 0)
	{
	  printf("(%g,%g)", h_scale(t), v_scale(sum) );
	  ++pt_count;
	  line_break(pt_count, num_pts, path_style);
	}
      sum += integrand(f, t, dt);
      t += dt;
    }
}

void plot_int(double f(double), double a, double b, int num_pts)
{
  comment_plot("plot_int");
  draw_int((*f), a, b, num_pts, PLAIN);
  end_stanza();
}

void dashplot_int(double f(double), double a, double b, int num_pts)
{
  comment_plot("dashplot_int");
  draw_int((*f), a, b, num_pts, DASHED);
  end_stanza();
}

void dotplot_int(double f(double), double a, double b, int num_pts)
{
  comment_plot("dotplot_int");
  draw_int((*f), a, b, num_pts, DOTTED);
  end_stanza();
}

void boldplot_int(double f(double), double a, double b, int num_pts)
{
  comment_plot("plot_int");
  bold();
  draw_int((*f), a, b, num_pts, BOLD);
  endbold();
  end_stanza();
}

/* ODE plots -- slope, dart, and vector fields, solutions of ODEs */

void draw_slope_field(double f1(double, double), double f2(double, double),
		      struct pair p, struct pair q, int n1, int n2)
{
  double x1;
  double x2;
  double dx1 = (q.x1 - p.x1)/n1;
  double dx2 = (q.x2 - p.x2)/n2;
  double len_pict;
  double minimum;

  int i1, i2;
  struct pair base; // basepoint
  struct pair vect; // displacement vector

  for (i1 = 0; i1 <= n1; ++i1)
    {
      x1 = p.x1 + i1*dx1;
      for (i2 = 0; i2 <= n2; ++i2)
      {
	x2 = p.x2 + i2*dx2;
	base = P(x1, x2);

	vect = P((*f1)(x1, x2), (*f2)(x1, x2));
	if (truncate(raw_len(vect)) == 0)
	  {
	    // Formerly a 2pt \circle*, which broke color handling
	    printf("\n\\put(%g,%g)", h_scale(x1), v_scale(x2));
	    printf("{\\kern -0.25pt \\rule[-0.25pt]{0.5pt}{0.5pt}}");
	  }
	else {
	  len_pict = hypot(h_stretch(vect.x1), v_stretch(vect.x2));
	  // Magic number 0.4: Slope segment length 80% of shorter grid length
	  minimum = (h_size/n1 > v_size/n2) ? 0.4*v_size/n2 : 0.4*h_size/n1;
	  vect = mult_s(scale(minimum)/len_pict, vect);
	  draw_line(diff_pair(base,vect), add_pair(base,vect), 1, PLAIN);
	}
      }
    }
}

void slope_field(double f1(double, double), double f2(double, double),
		 struct pair p, struct pair q, int n1, int n2)
{
  comment_plot("slope_field");
  draw_slope_field(*f1, *f2, p, q, n1, n2);
  end_stanza();
}

void boldslope_field(double f1(double, double), double f2(double, double),
		 struct pair p, struct pair q, int n1, int n2)
{
  comment_plot("boldslope_field");
  bold();
  draw_slope_field(*f1, *f2, p, q, n1, n2);
  endbold();
  end_stanza();
}

void draw_dart_field(double f1(double, double), double f2(double, double),
		     struct pair p, struct pair q, int n1, int n2)
{
  double x1;
  double x2;
  double dx1 = (q.x1 - p.x1)/n1;
  double dx2 = (q.x2 - p.x2)/n2;
  double len_pict;
  double minimum;

  int i1, i2;
  struct pair base; // basepoint
  struct pair vect; // displacement vector

  for (i1 = 0; i1 <= n1; ++i1)
    {
      x1 = p.x1 + i1*dx1;
      for (i2 = 0; i2 <= n2; ++i2)
      {
	x2 = p.x2 + i2*dx2;
	base = P(x1, x2);

	vect = P((*f1)(x1, x2), (*f2)(x1, x2));
	if (truncate(raw_len(vect)) == 0)
	  {
	    // Formerly a 2pt \circle*, which broke color handling
	    printf("\n\\put(%g,%g)", h_scale(x1), v_scale(x2));
	    printf("{\\kern -0.25pt \\rule[-0.25pt]{0.5pt}{0.5pt}}");
	  }
	else {
	  len_pict = hypot(h_stretch(vect.x1), v_stretch(vect.x2));
	  // Magic number 0.4: Slope segment length 80% of shorter grid length
	  minimum = (h_size/n1 > v_size/n2) ? 0.4*v_size/n2 : 0.4*h_size/n1;
	  vect = mult_s(scale(minimum)/len_pict, vect);
	  draw_dart(diff_pair(base,vect), add_pair(base,vect), PLAIN);
	}
      }
    }
}

void dart_field(double f1(double, double), double f2(double, double),
		struct pair p, struct pair q, int n1, int n2)
{
  comment_plot("dart_field");
  draw_dart_field(*f1, *f2, p, q, n1, n2);
  end_stanza();
}

void bolddart_field(double f1(double, double), double f2(double, double),
		    struct pair p, struct pair q, int n1, int n2)
{
  comment_plot("bolddart_field");
  bold();
  draw_dart_field(*f1, *f2, p, q, n1, n2);
  endbold();
  end_stanza();
}

void draw_vector_field(double f1(double, double), double f2(double, double),
		      struct pair p, struct pair q, int n1, int n2,
		       const int path_style)
{
  double x1;
  double x2;
  double dx1 = (q.x1 - p.x1)/n1;
  double dx2 = (q.x2 - p.x2)/n2;

  int i1, i2;
  struct pair base; // basepoint
  struct pair vect; // displacement vector

  for (i1 = 0; i1 <= n1; ++i1)
    {
      x1 = p.x1 + i1*dx1;
      for (i2 = 0; i2 <= n2; ++i2)
      {
	x2 = p.x2 + i2*dx2;
	base = P(x1, x2);

	vect = P((*f1)(x1, x2), (*f2)(x1, x2));
	if (true_len(vect) == 0)
	  dot(P(x1,x2)); // Draw "dot" for zero vector
	else if (path_style == BOLD)
	  draw_boldarrow(base, add_pair(base,vect));
	else
	  draw_arrow(base, add_pair(base,vect), path_style);
      }
    }
}

void vector_field(double f1(double, double), double f2(double, double),
		  struct pair p, struct pair q, int n1, int n2)
{
  comment_plot("vector_field");
  draw_vector_field(*f1, *f2, p, q, n1, n2, PLAIN);
  end_stanza();
}

void boldvector_field(double f1(double, double), double f2(double, double),
		      struct pair p, struct pair q, int n1, int n2)
{
  comment_plot("boldvector_field");
  bold();
  draw_vector_field(*f1, *f2, p, q, n1, n2, BOLD);
  endbold();
  end_stanza();
}

void draw_ode_plot(double f1(double, double), double f2(double, double),
		   struct pair start, double t_max, int num_pts, 
		   const int path_style)
{
  int i=0;
  int pt_count = 0;
  struct pair curr = start;

  if (x_min <= curr.x1 && curr.x1 <= x_max &&
      y_min <= curr.x2 && curr.x2 <= y_max)
    start_path(path_style);
  else
    printf("\n%%%% Initial point outside bounding box");

  while(x_min <= curr.x1 && curr.x1 <= x_max &&
	y_min <= curr.x2 && curr.x2 <= y_max &&
	i <= num_pts*ITERATIONS)
    {
      if (i%ITERATIONS == 0)
	{
	  printf("(%g,%g)", h_scale(curr.x1), v_scale(curr.x2));
	  ++pt_count;
	  line_break(pt_count, num_pts, path_style);
	}

      ++i;

      /* Euler's method */
      curr.x1 += (*f1)(curr.x1, curr.x2)*t_max/(num_pts*ITERATIONS);
      curr.x2 += (*f2)(curr.x1, curr.x2)*t_max/(num_pts*ITERATIONS);
    }
  
  printf("(%g,%g)", h_scale(curr.x1), v_scale(curr.x2));
}

void ode_plot(double f1(double, double), double f2(double, double),
	      struct pair start, double t_max, int num_pts)
{
  comment_plot("ode_plot");
  draw_ode_plot(*f1, *f2, start, t_max, num_pts, PLAIN);
  end_stanza();
}

void dashode_plot(double f1(double, double), double f2(double, double),
		  struct pair start, double t_max, int num_pts)
{
  comment_plot("dashode_plot");
  draw_ode_plot(*f1, *f2, start, t_max, num_pts, DASHED);
  end_stanza();
}

void dotode_plot(double f1(double, double), double f2(double, double),
		 struct pair start, double t_max, int num_pts)
{
  comment_plot("dotode_plot");
  draw_ode_plot(*f1, *f2, start, t_max, num_pts, DOTTED);
  end_stanza();
}

void boldode_plot(double f1(double, double), double f2(double, double),
		  struct pair start, double t_max, int num_pts)
{
  comment_plot("boldode_plot");
  bold();
  draw_ode_plot(*f1, *f2, start, t_max, num_pts, BOLD);
  endbold();
  end_stanza();
}

