/* 
 * ePiX: A lightweight runtime program to generate mathematically 
 * accurate LaTeX eepic files from user-friendly C source files. 
 *
 * ePiX is distributed under the terms of the GNU GPL. You may copy,
 * modify, and distribute this program freely as long as this copyleft
 * notice remains intact IN ITS ENTIRETY. This program comes with
 * ABSOLUTELY NO WARRANTY OF ANY KIND, INCLUDING ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Feedback about this program (bug reports, suggestions for features,
 * etc.) is welcome. If you find this program useful, please consider
 * making a contribution to the Free Software Foundation; see
 * http://www.fsf.org
 *
 * Andrew D. Hwang                      <ahwang@mathcs.holycross.edu>
 *
 * Version: 0.6.5
 * Last Change: August 22, 2001 
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "epix.h"

const char *version="0.6.5";

/* 
 * <Size> and <offset> of picture in PICTURE coordinates. Sizes 
 * define space in document alotted by LaTeX. Offsets shift the
 * origin from the CENTER of the picture; positive offsets shift
 * RIGHT and UP (contrast LaTeX behavior).
 */
extern double h_size, v_size, h_offset, v_offset;

/*
 * Bounding box of picture in CARTESIAN coordinates.
 * Output is scaled so that Cartesian bounding box exactly
 * fills picture box (see h_scale, v_scale).
 */
extern double x_min, x_max, y_min, y_max;
/* Cartesian width and height of bounding box */
extern double x_size, y_size;

/*
 * Picture length units
 *
 * <pic_unit> is one of the following valid LaTeX length units: 
 *    cm, in, mm, pc, or pt.
 * <pic_size> is a double that (with pic_unit) specifies unitlength
 */
extern double pic_size; // e.g., 1
extern char *pic_unit;  // e.g., "pt" 

/*
 * Output control; count line_breaks, terminate with fatal error if
 * more than 20000 are printed. 
 */
int lines_printed = 0;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                 Non-Printing Functions                *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* 
 * Upper bound on truncation prevents %e-type output; not strictly a
 * magic number, since the bound is built into C.
 */
double truncate(double t)
{
  if (fabs(t) < 0.0001) // 10^-4
    t=0;

  return t;
}

/* Ordered pairs and operations */

struct pair P(double x1, double x2)
{
  struct pair temp;

  temp.x1 = x1;
  temp.x2 = x2;
  return temp;
} 

struct pair cis(double t)
{
  struct pair temp;

  temp.x1 = cos(t);
  temp.x2 = sin(t);
  return temp;
} 
  

/* Vector operations */
struct pair add_pair(struct pair p1, struct pair p2)
{
  p1.x1 += p2.x1;
  p1.x2 += p2.x2;
  return p1;
}

struct pair diff_pair(struct pair p1, struct pair p2)
{
  struct pair temp;

  temp.x1 = p1.x1 - p2.x1;
  temp.x2 = p1.x2 - p2.x2;
  return temp;
}

/* Scalar multiplication */
struct pair mult_s(double c, struct pair p)
{
  p.x1 *= c;
  p.x2 *= c;

  return p;
}

/* Complex product */
struct pair mult_pair(struct pair p1, struct pair p2)
{
  struct pair temp;

  temp.x1 = p1.x1*p2.x1 - p1.x2*p2.x2; // ac - bd
  temp.x2 = p1.x1*p2.x2 + p1.x2*p2.x1; // ad + bc
  return temp;
}

/* 1/4-rotation (mult by i) */
struct pair J(struct pair p)
{
  struct pair temp;

  temp.x1 = -p.x2;
  temp.x2 =  p.x1;
  return temp;
}

/* Pythagorean length of pair */
double raw_len(struct pair p)
{
  return hypot(p.x1, p.x2);
}

/* True length of pair given in picture coordinates */
double true_len(struct pair p)
{
  return unscale(raw_len(p));
}

/* Scale vector in picture units to 1 true pt length */
struct pair normalize(struct pair p)
{
  if ( true_len(p) > 0) // return (0,0) if p = (0,0)
    p = mult_s( 1/true_len(p), p );

  return p;
}

/* Cartesian pair to picture units pair */
struct pair cart_to_pict(struct pair p)
{
  struct pair temp = { h_scale(p.x1), v_scale(p.x2) };
  return temp;
}


/* Functions for declaring variables */
void bounding_box(struct pair p1, struct pair p2)
{
  if (p1.x1 < p2.x1)
    {
      x_min = p1.x1;
      x_max = p2.x1;
    }

  else if (p1.x1 > p2.x1)
    {
      x_min = p2.x1;
      x_max = p1.x1;
    }
  else
    {
      fprintf(stderr, "Error: Bounding box has width zero!\n");
      exit(1);
    }

  if (p1.x2 < p2.x2)
    {
      y_min = p1.x2;
      y_max = p2.x2;
    }

  else if (p1.x2 > p2.x2)
    {
      y_min = p2.x2;
      y_max = p1.x2;
    }
  else
    {
      fprintf(stderr, "Error: Bounding box has height zero!\n");
      exit(1);
    }
}

void picture(struct pair sizes)
{
  h_size = sizes.x1;
  v_size = sizes.x2;
}

void offset(struct pair shift)
{
  h_offset = shift.x1;
  v_offset = shift.x2;
}

void unitlength(const char *units)
{
  pic_size = strtod(units, &pic_unit);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                 Sectioning Functions                  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Begin picture */
void begin(void)
{
  x_size = x_max - x_min;
  y_size = y_max - y_min;

  printf("%%%% File generated by ePiX-%s", version);
  printf("\n%%%%");
  printf("\n%%%%   Cartesian bounding box: [%g,%g] x [%g,%g]",
	 x_min, x_max, y_min, y_max);
  printf("\n%%%%   Actual size: %g%s x %g%s",
	 h_size*pic_size, pic_unit, v_size*pic_size, pic_unit);
  printf("\n%%%%   Figure offset: %s by %g%s, %s by %g%s",
        (h_offset >= 0) ? "right" : "left", fabs(h_offset)*pic_size, pic_unit, 
        (v_offset >= 0) ? "up"    : "down", fabs(v_offset)*pic_size, pic_unit);
  printf("\n%%%%");
  printf("\n\\setlength{\\unitlength}{%g%s}", pic_size, pic_unit);
  printf("\n\\begin{picture}(%g,%g)(%g,%g)", \
	 h_size, v_size, -h_offset, -v_offset);
  end_stanza();
}
/* End picture */
void end(void)
{
  printf("\n\\end{picture}\n");
}

/* Path style declarations */
void start_path(const int path_style)
{
  printf("\n");

  if (path_style == PLAIN)
    printf("\\path");

  else if (path_style == DASHED)
    printf("\\dashline{%.1f}", scale(DASH_LENGTH));

  else if (path_style == DOTTED)
    printf("\\dottedline{%.1f}", scale(DOT_SEP));

  else if (path_style == BOLD)
    printf("\\path");

  else
    printf("\\path");
}

void bold(void)
{
  printf("\n{\\thicklines");
}
void endbold(void)
{
  printf("\n}%%");
}
void end_bold(void)
{
  printf("\n}%%");
}

/* Colors */
void red(void)
{
  printf("\n\\begin{red}%%");
}
void end_red(void)
{
  printf("\n\\end{red}%%");
}

void blue(void)
{
  printf("\n\\begin{blue}%%");
}
void end_blue(void)
{
  printf("\n\\end{blue}%%");
}

void green(void)
{
  printf("\n\\begin{green}%%");
}
void end_green(void)
{
  printf("\n\\end{green}%%");
}

void cyan(void)
{
  printf("\n\\begin{cyan}%%");
}
void end_cyan(void)
{
  printf("\n\\end{cyan}%%");
}

void magenta(void)
{
  printf("\n\\begin{magenta}%%");
}
void end_magenta(void)
{
  printf("\n\\end{magenta}%%");
}

void yellow(void)
{
  printf("\n\\begin{yellow}%%");
}
void end_yellow(void)
{
  printf("\n\\end{yellow}%%");
}

/* Obsolete path declarations */
void path(void)
{
  printf("\\path");
}
void dashed(void)
{
  printf("\\dashline{%.1f}", scale(DASH_LENGTH));
}
void dotted(void)
{
  printf("\\dottedline{%.1f}", scale(DOT_SEP));
}

/* Fill closed path */
void fill(void)
{
  printf("\\blacken");
}
/* End current stanza of .eepic file */
void end_stanza(void)
{
  int i=0;
  /* Stanza separator of width FILE_WIDTH */
  printf("\n%%%%\n%%%%");
  for (i=0; i<= FILE_WIDTH - 4; ++i)
    printf("-");
  printf("%%%%");

  output();
}

void fatal_error(void)
{
  int i;
  printf("\n%%%%\n");
  for (i=0; i <= FILE_WIDTH; ++i)
    printf("%%");

  printf("\n%%%%      ");
  printf("That's more than %d lines. I suspect an error...", MAX_LINES);
  printf("     %%%%\n");

  for (i=0; i <= FILE_WIDTH; ++i)
    printf("%%");
  end();
  exit(1);
}

void output(void)
{
  if (lines_printed > MAX_LINES)
    fatal_error();
}

void line_break(int i, int num_pts, int path_style)
{
  // Print only 3 points on first line of dashed/dotted path
  if (path_style == DASHED || path_style == DOTTED)
    ++i;
  
  if ((i+1) % PAIRS_PER_LINE == 0 && i < num_pts)
    {
      printf("\n  ");
      ++lines_printed;
      output();
    }
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                    Picture objects                    *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 * label -- put string constant <label_text> 
 * at Cartesian position <pair> offset by <vect> true points.
 */
void label(struct pair base, struct pair offset, char *label_text)
{
  printf("\n%%%% label: \"%s\" at (%g, %g)\n%%%%", \
	 label_text, base.x1, base.x2);
  printf("\n\\put(%g,%g){%s}", \
	 h_scale(base.x1)+scale(offset.x1), \
	 v_scale(base.x2)+scale(offset.x2), label_text);
  end_stanza();
}

/*
 * mask -- filled white rectangle to mask out part of a figure
 * prior to label placement. Parameters designed to match those
 * of labels; <base> is the Cartesian location, <offset> is the
 * offset in true pt, <size> is the size of the box in true pt.
 */
void mask(struct pair base, struct pair offset, struct pair size)
{
  double a = base.x1 + h_unstretch(scale(offset.x1));
  double b = base.x2 + v_unstretch(scale(offset.x2));
  double c = base.x1 + h_unstretch(scale(offset.x1 + size.x1));
  double d = base.x2 + v_unstretch(scale(offset.x2 + size.x2));

  printf("\n%%%% mask: %g pt x %g pt at (%g, %g)\n%%%%", \
	 size.x1, size.x2, base.x1, base.x2);
  printf("\n\\whiten");
  draw_rect(P(a,b), P(c,d), PLAIN);
  end_stanza();
}

/*
 * Empty and filled LaTeX circles of diameter DIAM true pt
 */

void comment_circ(char *type, double h_posn, double v_posn)
{
  printf("\n%%%% %s: center (%.2f,%.2f)\n%%%%", \
	 type, h_posn, v_posn);
}

void circ(struct pair p) // filled white circ 4 pt in diameter
{
  comment_circ("circ", p.x1, p.x2);

  printf("\n\\whiten");
  printf("\n\\put(%g,%g){\\circle{%g}}",
	 h_scale(p.x1), v_scale(p.x2), scale(DIAM));
  end_stanza();
}  
void ring(struct pair p, double r) // unfilled circ of specified diam
{
  comment_circ("ring", p.x1, p.x2);

  printf("\n\\put(%g,%g){\\circle{%g}}",
	 h_scale(p.x1), v_scale(p.x2), scale(r*DIAM/4));
  end_stanza();
}  
void spot(struct pair p)
{
  comment_circ("spot", p.x1, p.x2);

  printf("\n\\put(%g,%g){\\circle*{%g}}",
	 h_scale(p.x1), v_scale(p.x2), scale(DIAM));
  end_stanza();
}  
void dot(struct pair p)
{
  comment_circ("dot", p.x1, p.x2);

  printf("\n\\put(%g,%g){\\circle*{%g}}",
	 h_scale(p.x1), v_scale(p.x2), scale(0.5*DIAM));
  end_stanza();
}  
void ddot(struct pair p)
{
  comment_circ("ddot", p.x1, p.x2);

  printf("\n\\put(%g,%g){\\circle*{%g}}",
	 h_scale(p.x1), v_scale(p.x2), scale(0.25*DIAM));
}

/* Axis ticks */
void h_axis_tick(double h_posn, double v_posn)
{
  printf("\n\\put(%g,%g){\\kern -0.25pt \\rule[-2pt]{0.5pt}{4pt}}", \
	 h_scale(h_posn), v_scale(v_posn));
}

void v_axis_tick(double h_posn, double v_posn)
{
  printf("\n\\put(%g,%g){\\kern -2pt \\rule[-0.25pt]{4pt}{0.5pt}}", \
	 h_scale(h_posn), v_scale(v_posn));
}

/* 
 * Coordinate axes, specified by initial and final points, and number
 *  of steps. h/v_axis are identical except for style of tick marks.
 */
void h_axis(struct pair tail, struct pair head, int n)
{
  int i=0;
  struct pair step = diff_pair(head, tail); 

  printf("\n%%%% h_axis: (%.2f,%.2f) to (%.2f,%.2f), %d steps",
	 tail.x1, tail.x2, head.x1, head.x2, n);

  start_path(PLAIN);
  printf("(%g,%g)(%g,%g)", h_scale(tail.x1), v_scale(tail.x2), \
	 h_scale(head.x1), v_scale(head.x2));

  printf("\n%%%% tick marks:");
  for (i=0; i<= n; ++i)
    {
      h_axis_tick(tail.x1 + i*step.x1/n, tail.x2 + i*step.x2/n);
      ++lines_printed;
    }  
  end_stanza();
}
  
void v_axis(struct pair tail, struct pair head, int n)
{
  int i=0;
  struct pair step = diff_pair(head, tail);

  printf("\n%%%% v_axis: (%.2f,%.2f) to (%.2f,%.2f), %d steps",
	 tail.x1, tail.x2, head.x1, head.x2, n);

  start_path(PLAIN);
  printf("(%g,%g)(%g,%g)", h_scale(tail.x1), v_scale(tail.x2), \
	 h_scale(head.x1), v_scale(head.x2));

  printf("\n%%%% tick marks:");
  for (i=0; i<= n; ++i)
    {
      v_axis_tick(tail.x1 + i*step.x1/n, tail.x2 + i*step.x2/n);
      ++lines_printed;
    }
  end_stanza();
}

/* n1 x n2 Cartesian grid */
void draw_grid(struct pair p1, struct pair p2, \
	       int n1, int n2, const int path_style)
{
  int i;
  printf("\n%%%%   Vertical lines");
  for (i=0; i<=n1; ++i)
    {
      draw_line(P(p1.x1 + i*(p2.x1 - p1.x1)/n1, p1.x2), \
		P(p1.x1 + i*(p2.x1 - p1.x1)/n1, p2.x2), n2, path_style);
      ++lines_printed;
    }

  printf("\n%%%%   Horizontal lines");
  for (i=0; i<=n2; ++i)
    {
      draw_line(P(p1.x1, p1.x2 + i*(p2.x2 - p1.x2)/n2), \
		P(p2.x1, p1.x2 + i*(p2.x2 - p1.x2)/n2), n1, path_style);
      ++lines_printed;
    }
}

void grid(struct pair p1, struct pair p2, int n1, int n2)
{
  printf("\n%%%% grid:");
  draw_grid(p1, p2, n1, n2, PLAIN);
  end_stanza();
}

void dashgrid(struct pair p1, struct pair p2, int n1, int n2)
{
  n1 = (int) n1;
  n2 = (int) n2;

  printf("\n%%%% dashgrid:");
  draw_grid(p1, p2, n1, n2, DASHED);
  end_stanza();
}

void dotgrid(struct pair p1, struct pair p2, int n1, int n2)
{
  printf("\n%%%% dotgrid:");
  draw_grid(p1, p2, n1, n2, DOTTED);
  end_stanza();
}

void boldgrid(struct pair p1, struct pair p2, int n1, int n2)
{
  printf("\n%%%% boldgrid:");
  bold();
  draw_grid(p1, p2, n1, n2, BOLD);
  endbold();
  end_stanza();
}

/* Polar grid with n1 rings and n2 sectors */
void draw_polar_grid(double radius, int n1, int n2, const int path_style)
{
  int i=0;

  printf("\n%%%%   rings\n%%%%"); 
  for (i=1; i <= n1; ++i) 
    {
      if (path_style == PLAIN || path_style == BOLD)
	draw_native_ellipse(P(0,0), P(i*radius/n1,i*radius/n1));
      
      else
	draw_ellipse(P(0,0), P(i*radius/n1,i*radius/n1), path_style);

      ++lines_printed;
    }

  printf("\n%%%%   radii\n%%%%");  
  for (i=0; i < n2; ++i)
    {
      double x = radius*cos(2*M_PI*i/n2);
      double y = radius*sin(2*M_PI*i/n2);

      draw_line(P(0,0), P(x, y), 2*n1, path_style);
      if (i<n2-1)
	printf("\n%%%%");

      ++lines_printed;
    }
}

void polar_grid(double radius, int n1, int n2)
{
  printf("\n%%%% polar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  draw_polar_grid(radius, n1, n2, PLAIN);
  end_stanza();
}

void dashpolar_grid(double radius, int n1, int n2)
{
  printf("\n%%%% dashpolar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  draw_polar_grid(radius, n1, n2, DASHED);
  end_stanza();
}

void dotpolar_grid(double radius, int n1, int n2)
{
  printf("\n%%%% dotpolar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  draw_polar_grid(radius, n1, n2, DOTTED);
  end_stanza();
}

void boldpolar_grid(double radius, int n1, int n2)
{
  printf("\n%%%% boldpolar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  bold();
  draw_polar_grid(radius, n1, n2, BOLD);
  endbold();
  end_stanza();
}

/* 
 * As of Version 0.4, h_axis_labels and v_axis_labels (which generate
 * their labels automatically from Cartesian coordinates) are preferred
 * for horizontal and vertical axes, but axis_floats and axis_integers
 * have conceivable uses, such as labelling a diagonal axis meant to
 * represent perspective.
 *
 * axis_floats -- Prints axis labels as floats
 *
 * Labels' reference points start at <tail> and step by <step> for
 * n steps. Label values start at <start> and end at <finish>
 */  
void axis_floats(struct pair tail, struct pair step, \
		 int n, double start, double finish)
{
  int i=0;
  /* 
   * If some (but not all) labels require negative signs, spacing is
   * facilitated by giving every non-negative label an invisible "-".
   */
  int neg_flag=0;
  if (start*finish < 0)
    neg_flag=1;

  printf("\n%%%% axis_floats:");

  for (i=0; i<= n; ++i)
    {
      printf("\n");

      if (neg_flag && start+i*(finish-start)/n >= 0)
	printf("\\put(%g,%g){$\\phantom{-}%g$}", \
	       h_scale(tail.x1 + i*step.x1), \
	       v_scale(tail.x2 + i*step.x2), \
	       start+i*(finish-start)/n);
      else
	printf("\\put(%g,%g){$%g$}", \
	       h_scale(tail.x1 + i*step.x1), \
	       v_scale(tail.x2 + i*step.x2), \
	       start+i*(finish-start)/n);
    }
  end_stanza();
}
  
/* 
 * axis_integers -- Same as axis_floats, but labels are integers.
 */  
void axis_integers(struct pair tail, struct pair step, \
		   int n, int start, int finish)
{
  int i=0;
  int neg_flag=0;
  if (start*finish < 0)
    neg_flag=1;

  printf("\n%%%% axis_integers:");

  for (i=0; i<= n; ++i)
    {
      printf("\n");

      if (neg_flag && start+i*(finish-start)/n >= 0)
	printf("\\put(%g,%g){$\\phantom{-}%d$}", \
	       h_scale(tail.x1 + i*step.x1), \
	       v_scale(tail.x2 + i*step.x2), \
	       start+i*(finish-start)/n);
      else
	printf("\\put(%g,%g){$%d$}", \
	       h_scale(tail.x1 + i*step.x1), \
	       v_scale(tail.x2 + i*step.x2), \
	       start+i*(finish-start)/n);
    }
  end_stanza();
}

/*
 * h_axis_labels: Draws n+1 equally-spaced axis labels between 
 *    <tail> and <head>. Automatically generates label values from
 *    Cartesian coordinates, and has true-distance offsets.
 */

void h_axis_labels(struct pair tail, struct pair head, \
		   int n, struct pair offset)
{
  int i=0;
  int neg_flag=0;
  if (head.x1*tail.x1 < 0)
    neg_flag=1;

  printf("\n%%%% h_axis_labels:");

  for (i=0; i<= n; ++i)
    {
      printf("\n");

      if (neg_flag && tail.x1 + i*(head.x1 - tail.x1)/n >= 0)
	printf("\\put(%g,%g){$\\phantom{-}%g$}", \
	       h_scale(tail.x1 + i*(head.x1-tail.x1)/n) + scale(offset.x1), \
	       v_scale(tail.x2 + i*(head.x2-tail.x2)/n) + scale(offset.x2), \
	       tail.x1 + i*(head.x1 - tail.x1)/n);

      else
	printf("\\put(%g,%g){$%g$}", \
	       h_scale(tail.x1 + i*(head.x1-tail.x1)/n) + scale(offset.x1), \
	       v_scale(tail.x2 + i*(head.x2-tail.x2)/n) + scale(offset.x2), \
	       tail.x1 + i*(head.x1-tail.x1)/n);
    }
  end_stanza();
}

void v_axis_labels(struct pair tail, struct pair head, \
		   int n, struct pair offset)
{
  int i=0;
  int neg_flag=0;
  if (head.x2*tail.x2 < 0)
    neg_flag=1;

  printf("\n%%%% v_axis_labels:");

  for (i=0; i<= n; ++i)
    {
      printf("\n");

      if (neg_flag && tail.x2 + i*(head.x2 - tail.x2)/n >= 0)
	printf("\\put(%g,%g){$\\phantom{-}%g$}", \
	       h_scale(tail.x1 + i*(head.x1-tail.x1)/n) + scale(offset.x1), \
	       v_scale(tail.x2 + i*(head.x2-tail.x2)/n) + scale(offset.x2), \
	       tail.x2 + i*(head.x2 - tail.x2)/n);

      else
	printf("\\put(%g,%g){$%g$}", \
	       h_scale(tail.x1 + i*(head.x1-tail.x1)/n) + scale(offset.x1), \
	       v_scale(tail.x2 + i*(head.x2-tail.x2)/n) + scale(offset.x2), \
	       tail.x2 + i*(head.x2-tail.x2)/n);
    }
  end_stanza();
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *             Simple geometric objects                  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Lines */
void draw_line(struct pair tail, struct pair head, int n, const int path_style)
{
  int i;
  struct pair pt = tail;

  start_path(path_style);

  /* Ensure at least two points printed */
  n = abs(n);
  if (n<1)
    n=1;

  for (i=0; i<=n; ++i)
    {
      printf("(%g,%g)", h_scale(pt.x1), v_scale(pt.x2));
      pt.x1 += (head.x1 - tail.x1)/n;
      pt.x2 += (head.x2 - tail.x2)/n;

      line_break(i,n, path_style);
    }
}

void comment_line(char *type, struct pair tail, struct pair head)
{
  printf("\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	 type, tail.x1, tail.x2, head.x1, head.x2);
}

void line(struct pair tail, struct pair head)
{
  comment_line("line", tail, head);
  draw_line(tail, head, 1, PLAIN);
  end_stanza();
}

void dashline(struct pair tail, struct pair head)
{
  comment_line("dashline", tail, head);
  draw_line(tail, head, 1, DASHED);					      
  end_stanza();
}

void dotline(struct pair tail, struct pair head)
{
  comment_line("dotline", tail, head);
  draw_line(tail, head, 1, DOTTED);
  end_stanza();
}

void boldline(struct pair tail, struct pair head)
{
  comment_line("boldline", tail, head);
  bold();
  draw_line(tail, head, 1, BOLD);
  endbold();
  end_stanza();
}

/* Triangles */
void draw_triangle(struct pair p1, struct pair p2, struct pair p3,
		   const int path_style)
{
  start_path(path_style);

  printf("(%g,%g)(%g,%g)(%g,%g)(%g,%g)", \
	 h_scale(p1.x1), v_scale(p1.x2), h_scale(p2.x1), v_scale(p2.x2), \
	 h_scale(p3.x1), v_scale(p3.x2), h_scale(p1.x1), v_scale(p1.x2));
}

void comment_triangle(char *type, 
		      struct pair p1, struct pair p2, struct pair p3)
{
  printf("\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	 type, p1.x1, p1.x2, p2.x1, p2.x2, p3.x1, p3.x2);
}

void triangle(struct pair p1, struct pair p2, struct pair p3)
{
  comment_triangle("triangle", p1, p2, p3);
  draw_triangle(p1, p2, p3, PLAIN);
  end_stanza();
}

void dashtriangle(struct pair p1, struct pair p2, struct pair p3)
{
  comment_triangle("dashtriangle", p1, p2, p3);
  draw_triangle(p1, p2, p3, DASHED);
  end_stanza();
}

void dottriangle(struct pair p1, struct pair p2, struct pair p3)
{
  comment_triangle("dottriangle", p1, p2, p3);
  draw_triangle(p1, p2, p3, DOTTED);
  end_stanza();
}

void boldtriangle(struct pair p1, struct pair p2, struct pair p3)
{
  comment_triangle("boldtriangle", p1, p2, p3);
  bold();
  draw_triangle(p1, p2, p3, BOLD);
  endbold();
  end_stanza();
}

/* 
 * If (a,b) and (c,d) are opposite corners of a rectangle, then
 * the corners -- in order -- are (a,b), (a,d), (c,d), and (c,b).
 */
void draw_rect(struct pair p1, struct pair p2, const int path_style) 
{
  start_path(path_style);
  printf("(%g,%g)(%g,%g)",
	 h_scale(p1.x1), v_scale(p1.x2), h_scale(p1.x1), v_scale(p2.x2) );
  printf("\n  (%g,%g)(%g,%g)(%g,%g)", \
	 h_scale(p2.x1), v_scale(p2.x2), h_scale(p2.x1), v_scale(p1.x2), \
	 h_scale(p1.x1), v_scale(p1.x2));
}

void comment_rect(char *type, struct pair p1, struct pair p2)
{
  printf("\n%%%% %s: corners (%.2f, %.2f) and (%.2f, %.2f)\n%%%%", \
	 type, p1.x1, p1.x2, p2.x1, p2.x2);
}

void rect(struct pair p1, struct pair p2)
{
  comment_rect("rect", p1, p2);
  draw_rect(p1, p2, PLAIN);
  end_stanza();
}

void dashrect(struct pair p1, struct pair p2)
{
  comment_rect("dashrect", p1, p2);
  draw_rect(p1, p2, DASHED);
  end_stanza();
}

void dotrect(struct pair p1, struct pair p2)
{
  comment_rect("dotrect", p1, p2);
  draw_rect(p1, p2, DOTTED);
  end_stanza();
}

void boldrect(struct pair p1, struct pair p2)
{
  comment_rect("rect", p1, p2);
  bold();
  draw_rect(p1, p2, BOLD);
  endbold();
  end_stanza();
}

void swatch(struct pair p1, struct pair p2)
{
  comment_rect("swatch", p1, p2);
  printf("\n\\shade");
  draw_rect(p1, p2, PLAIN);
  end_stanza();
}

void boldswatch(struct pair p1, struct pair p2)
{
  comment_rect("boldswatch", p1, p2);
  bold();
  printf("\\shade");
  draw_rect(p1, p2, BOLD);
  endbold();
  end_stanza();
}

/* 
 * Arrows joining two specified <pair>s. An arrow consists of a head
 * and a shaft; the head is 2*width true points wide, and width*ratio
 * true points long, while the shaft is long enough to join the <tail>
 * to <new_head> (see below). If the <tail> is inside the arrowhead,
 * the shaft is not drawn. 
 *
 * Because drawing the head and shaft involve separate complications, 
 * they are split into separate functions. The algorithm is:
 *
 * (1) Find Cartesian direction vector from <tail> to <head>, and
 *    convert to picture coords.
 *
 * (2) If shaft is too short, put base of arrowhead at <base>. Precisely,
 *    determine the true pt length of the direction vector, normalize
 *    it, and move width*ratio true points toward <tail> from <head>.
 *    If this backtracks across <tail>, do not draw the shaft; otherwise,
 *    retract the head appropriately, to <new_head>. Draw the shaft.
 *    Stop snickering...
 *
 * (3) Compute the three vertices of the arrowhead; they are two true pt
 *    to either side of <new_head>, and width*ratio true pt along the
 *    unit vector from <new_head> to <head>, i.e., at <head> provided
 *    the arrow is not so short that <tail> lies inside the arrowhead.
 *    To get perpendicular offsets, the rotation operator J is applied
 *    to the true unit vector.
 *
 * As with other polygon objects, draw_arrowhead and draw_shaft print
 * only lists of coordinate pairs, not line styles, etc. draw_arrow is the
 * user analogue of draw_rect (e.g.); it draws the requisite paths and
 * nothing else. This division of labor  allows the pieces to be used in
 * other functions, e.g., plots of tangent vectors to a parametrized curve.
 *
 * A certain amount of mental resistance was required not to use the term
 * "flint" instead of "arrowhead".
 */
void draw_arrowhead(struct pair tail, struct pair head, double width)
{
  //  double width=ARROWHEAD_WIDTH;
  double ratio=ARROWHEAD_RATIO;

  /*
   * Vertices of arrowhead:
   *
   *                       <tip1>
   * <cart_to_pict(tail)>  <new_head>    <tip3>
   *                       <tip2>
   */
  struct pair tip1, tip2, tip3; 

  /* Head/tail of shaft in picture coordinates */
  struct pair new_head;
  /* Picture coords direction vector from <tail> to <head> */
  struct pair dir = { h_stretch(head.x1 - tail.x1),
		      v_stretch(head.x2 - tail.x2) };
  /* Picture coords unit vector parallel to direction vector */
  struct pair unit_dir = normalize(dir);

  if ( width*ratio < true_len(dir) ) // <tail> outside arrowhead
    {
      new_head = add_pair(cart_to_pict(head), mult_s(-width*ratio, unit_dir));
      tip3 = cart_to_pict(head);
    }

  else // <tail> inside arrowhead
    {
      new_head = cart_to_pict(tail);
      tip3 = add_pair(new_head, mult_s(width*ratio, unit_dir));
    }

  tip1 = add_pair(new_head, mult_s( width, J(unit_dir)));
  tip2 = add_pair(new_head, mult_s(-width, J(unit_dir)));

  /* N.B. Coordinates already converted from Cartesian */
  printf("(%.2f,%.2f)(%.2f,%.2f)(%.2f,%.2f)(%.2f,%.2f)", \
	 tip1.x1, tip1.x2, tip2.x1, tip2.x2, 
	 tip3.x1, tip3.x2, tip1.x1, tip1.x2 );
}

void draw_shaft(struct pair tail, struct pair head, double width)
{
  //  double width=ARROWHEAD_WIDTH;
  double ratio=ARROWHEAD_RATIO;

  /* Head/tail of shaft in picture coordinates */
  struct pair new_head;
  /* Picture coords direction vector from <tail> to <head> */
  struct pair dir = { (head.x1 - tail.x1)*h_size/x_size, \
		      (head.x2 - tail.x2)*v_size/y_size };
  /* Picture coords unit vector parallel to direction vector */
  struct pair unit_dir = normalize(dir);

  if ( width*ratio < true_len(dir) ) // <tail> outside arrowhead
    {
      new_head = add_pair(cart_to_pict(head), mult_s(-width*ratio, unit_dir));
      printf("(%g,%g)(%g,%g)", \
	     h_scale(tail.x1), v_scale(tail.x2), new_head.x1, new_head.x2);
    }
}

void draw_arrow(struct pair tail, struct pair head, const int path_style)
{
  double width=ARROWHEAD_WIDTH;
  double ratio=ARROWHEAD_RATIO;
  struct pair dir = { (head.x1 - tail.x1)*h_size/x_size, \
		      (head.x2 - tail.x2)*v_size/y_size };

  if ( width*ratio < true_len(dir) )
    {
      if (path_style == DOTTED)
	bold();
      start_path(path_style);
      draw_shaft(tail, head, width);
      if (path_style == DOTTED)
	endbold();
    }
  start_path(PLAIN);
  draw_arrowhead(tail, head, width);
}

void draw_boldarrow(struct pair tail, struct pair head)
{
  double width=ARROWHEAD_WIDTH;
  double ratio=ARROWHEAD_RATIO;
  struct pair dir = { (head.x1 - tail.x1)*h_size/x_size, \
		      (head.x2 - tail.x2)*v_size/y_size };

  if ( width*ratio < true_len(dir) )
    {
      bold();
      start_path(BOLD);
      draw_shaft(tail, head, width);
      endbold();
    }
  printf("\n");
  fill();
  start_path(PLAIN);
  draw_arrowhead(tail, head, width);
}

void arrow(struct pair tail, struct pair head)
{
  comment_line("arrow", tail, head);
  draw_arrow(tail, head, PLAIN);
  end_stanza();
}

void dasharrow(struct pair tail, struct pair head)
{
  comment_line("dasharrow", tail, head);
  draw_arrow(tail, head, DASHED);
  end_stanza();
}

void dotarrow(struct pair tail, struct pair head)
{
  comment_line("dotarrow", tail, head);
   draw_arrow(tail, head, DOTTED);
   end_stanza();
}

void boldarrow(struct pair tail, struct pair head)
{
  comment_line("boldarrow", tail, head);
  draw_boldarrow(tail, head);
  end_stanza();
}

/* Small arrows: "dart"s. Same as arrows with head half size */
void draw_dart(struct pair tail, struct pair head, const int path_style)
{
  double width=0.5*ARROWHEAD_WIDTH;
  double ratio=ARROWHEAD_RATIO;
  struct pair dir = { (head.x1 - tail.x1)*h_size/x_size, \
		      (head.x2 - tail.x2)*v_size/y_size };

  if ( width*ratio < true_len(dir) )
    {
      if (path_style == DOTTED)
	bold();
      start_path(path_style);
      draw_shaft(tail, head, width);
      if (path_style == DOTTED)
	endbold();
    }
  start_path(PLAIN);
  draw_arrowhead(tail, head, width);
}

void draw_bolddart(struct pair tail, struct pair head)
{
  double width=0.5*ARROWHEAD_WIDTH;
  double ratio=ARROWHEAD_RATIO;
  struct pair dir = { (head.x1 - tail.x1)*h_size/x_size, \
		      (head.x2 - tail.x2)*v_size/y_size };

  if ( width*ratio < true_len(dir) )
    {
      bold();
      start_path(BOLD);
      draw_shaft(tail, head, width);
      endbold();
    }
  printf("\n");
  fill();
  start_path(PLAIN);
  draw_arrowhead(tail, head, width);
}

void dart(struct pair tail, struct pair head)
{
  comment_line("dart", tail, head);
  draw_dart(tail, head, PLAIN);
  end_stanza();
}

void dashdart(struct pair tail, struct pair head)
{
  comment_line("dashdart", tail, head);
  draw_dart(tail, head, DASHED);
  end_stanza();
}

void dotdart(struct pair tail, struct pair head)
{
  comment_line("dotdart", tail, head);
   draw_dart(tail, head, DOTTED);
   end_stanza();
}

void bolddart(struct pair tail, struct pair head)
{
  comment_line("bolddart", tail, head);
  draw_bolddart(tail, head);
  end_stanza();
}
