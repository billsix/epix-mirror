/* 
 * arcana.c
 *
 * Functions not likely to be of general interest.
 *
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.6.5
 * Last Change: August 22, 2001
 */

#include "epix.h"

/* 
 * Number of iterations per point printed; also used to determine
 * increment in Newton quotient.
 */
#define ITERATIONS 1000 

static double dt;

extern double x_min, x_max, y_min, y_max;
extern double h_size, v_size;

/* Difference quotient of f at t */
static double deriv(double f(double), double t, double dt)
{
  return ((*f)(t + 0.5*dt) - (*f)(t - 0.5*dt))/dt;
}

/* Convert a momentum profile to a geometric profile */

void draw_profile(double f(double), double a, double b, 
		  int num_pts, const int path_style)
{
  double x=x_min;
  double t=a;
  int i=0, pt_count=0;

  dt = (b-a)/(num_pts*ITERATIONS);

  start_path(path_style);
  printf("(%g,%g)", h_scale(x), v_scale(sqrt((*f)(t))) );
  ++pt_count;
  t += 0.5*dt;
  x += dt*sqrt((4-deriv((*f), t, dt)*deriv((*f), t, dt))/(4*((*f)(t))));

  while (0 <= (*f)(t) && (*f)(t) <= y_max && x <= x_max \
	 && fabs(deriv((*f), t, dt)) <= 2 )
    {
      if ( i%ITERATIONS == 0 )
	{
	  printf("(%g,%g)", h_scale(x), v_scale(sqrt((*f)(t))) );
	  ++pt_count;
	  line_break(pt_count, num_pts, path_style);
	}

      x += dt*sqrt((4-deriv((*f), t, dt)*deriv((*f), t, dt))/(4*((*f)(t))));
      t += dt;
      ++i;
    }
  
  /* Next point printed is slightly wrong; x incremented, t not */
  printf("(%g,%g)", h_scale(x), v_scale(sqrt((*f)(t - dt))) );
}

void plot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("plot_profile");
  draw_profile((*f), a, b, num_pts, PLAIN);
  end_stanza();
}

void dashplot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("dashplot_profile");
  draw_profile((*f), a, b, num_pts, DASHED);
  end_stanza();
}

void dotplot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("dotplot_profile");
  draw_profile((*f), a, b, num_pts, DOTTED);
  end_stanza();
}

void boldplot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("boldplot_profile");
  bold();
  draw_profile((*f), a, b, num_pts, BOLD);
  endbold();
  end_stanza();
}

