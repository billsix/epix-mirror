/* sample7.c, August 16, 2001
 *
 * Polar plotting; polar angles are measured in revolutions, not
 * radians or degrees.
 */

#include "epix.h"

double plot_r(double t)
{
  return exp(-t/4);
}

main() {

  bounding_box(P(-1, -0.5), P(1,1));
  picture(P(200, 150));
  unitlength("1.2pt");

  begin();

  // Coordinate axes
  h_axis(P(x_min,0), P(x_max,0), 8);
  v_axis(P(0,y_min), P(0,1), 6); // y-axis extends out of bounding box

  /* 
   * Note that while the locations of axis labels are given in Cartesian
   * coordinates (from which the actual labels are determined), the offset
   * is given in true points.
   */
  h_axis_labels(P(x_min,0), P(x_max,0), 2, P(-6, -14));
  label(P(0,y_max), P(4, -4), "$1$");

  // Graph label
  label(P(0.5, 0.75), P(0,0), "$r=e^{-\\theta/4}$");

  // spiral
  polarplot((*plot_r), 0, 3, 180);

  end();
}
