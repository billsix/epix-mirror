/* 
 * sample10.c -- Upper and lower sums for the integral of log.
 *
 * August 21, 2001
 */

#include "epix.h"

#define N 8.0 // Number of rectangles

#define f log // gather references to integrand

main() {
  int i;
  double dx;

  picture(P(320, 180));
  bounding_box(P(1,0), P(9,2.5));
  unitlength("0.01in");

  begin();

  dx = x_size/N;

  h_axis(P(x_min, y_min), P(x_max, y_min), x_size);
  v_axis(P(x_min, y_min), P(x_min, y_max), 2*y_size);

  h_axis_labels(P(x_min, 0), P(x_max, 0), x_size, P(-4, -12));
  v_axis_labels(P(1,0), P(1,2), 2, P(-10, -2));

  label(P(x_max, f(x_max)), P(2,2), "$y=\\ln x$");

  boldplot(f, x_min, x_max, 40);

  for(i=0; i < N; ++i)
    {
      double ai=x_min + i*dx;
      double bi=x_min + (i+1)*dx;

      red();
      line(P(bi, 0), P(bi, f(bi)));
      line(P(ai, f(ai)), P(bi, f(ai)));
      end_red();

      blue();
      bold();
      line(P(ai, f(ai)), P(ai, f(bi)));
      line(P(ai, f(bi)), P(bi, f(bi)));
      end_bold();
      end_blue();
    }

  end();
}

