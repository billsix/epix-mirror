/* sample5.c, August 16, 2001 
 *
 * Axes with ticks, graphs of user-supplied functions
 */

#include "epix.h"

double f(double t)
{
  return 2*t*(1-t)*(1-t);
}

double g(double t)
{
  return 2*t*(1-t);
}

main() {

  bounding_box(P(-0.5, -0.25), P(1.5, 1));
  picture(P(320, 160));
  unitlength("1pt");

  begin();

  h_axis(P(-0.25, 0), P(1.5, 0), 14);
  v_axis(P(0,0), P(0,0.75), 6);

  h_axis_labels(P(0,0), P(1.5,0), 3, P(-4, -14));
  v_axis_labels(P(0, 0.25), P(0,0.75), 2, P(-30, -2));

  label(P(0.875, 0.75), P(0,0), "$\\varphi_1(\\tau)=2\\tau(1-\\tau)^2$");
  label(P(0.125, 0.6), P(0,0), "$\\varphi_2(\\tau)=2\\tau(1-\\tau)$");

  /* Graph of \varphi(\tau)=2\tau(1-\tau)^2 */
  plot((*f), -0.025, 1.55, 40);
  dashplot((*g), 0, 1.125, 40);

  end();
}

