/* 
 * sample16.c -- The Koch curve. This is an ad hoc example of how
 * to use C together with ePiX, not an "elementary" ePiX example.
 *
 * August 22, 2001
 */

#include "epix.h"

#define MAX 256 // Paths printed in chunks of 256 points

void koch(struct pair p, struct pair q, int depth)
{
  int length = 1+(int)pow(4, depth); // number of points plotted
  int direction[length]; // int array containing step information
  int i, j, k;
  int seed[4] = {0, 1, -1, 0}; // directions to recurse
  int pt_count = 0;

  struct pair location; // coordinates of current point
  struct pair step_vector; // direction to move

  location.x1 = p.x1;
  location.x2 = p.x2;

  for(i=0; i<length; ++i) // initialize direction[]
    direction[i]=0;

  /* 
   * direction[] starts out [0, 1, -1, 0, ..., 0] (4^depth entries)
   * then take repeated "Kronecker sum" with seed = [0, 1, -1, 0]
   */

  for(i=0; i<4; ++i)
    direction[i]=seed[i];

  for(i=1; i<depth; ++i) // recursively fill direction array
    {
      for(j=0; j < pow(4,i); ++j)
	{
	  for(k=3; 0 < k; --k) // needn't do k=0 if seed[0] = 0...
	    direction[k*(int)pow(4,i) + j] = direction[j] + seed[k];
	}
    }

  start_path(PLAIN);

  for(i=0; i<length; ++i)
    {
      printf("(%.4f,%.4f)", h_scale(location.x1), v_scale(location.x2));
      ++pt_count;
      
      // cis(x) = P(cos(x), sin(x))
      step_vector=mult_pair(cis(M_PI*direction[i]/3.0), 
			    add_pair(q, mult_s(-1,p)));

      location.x1 += step_vector.x1/pow(3,depth);
      location.x2 += step_vector.x2/pow(3,depth);

      if (pt_count != MAX+1)
	line_break(pt_count, MAX, PLAIN);
      else // time to start a new path segment
	{
	  printf("(%.4f,%.4f)", h_scale(location.x1), v_scale(location.x2));
	  if (i != length - 1)
	    {
	      printf("\n%%%%");
	      start_path(PLAIN);	
	    }  
	  pt_count = 0;
	}
    }
  end_stanza();
}

main() {
  double y = sqrt(3)/2;

  bounding_box(P(0,0), P(1, 1.25));
  picture(P(300, 375));
  unitlength("1pt");

  begin();   

  koch(P(0, y), P(1, y), 5);
  koch(P(0.5, y - sqrt(3)/2), P(0, y), 5);
  koch(P(1, y), P(0.5, y - sqrt(3)/2), 5);

  end();
}
