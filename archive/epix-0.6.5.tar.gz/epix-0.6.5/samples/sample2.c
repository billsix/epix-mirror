/* sample2.c, August 16, 2001 
 * 
 * Solid, dashed, bold, and/or rotated half-ellipses, arrows
 */

#include "epix.h"

main() {

  bounding_box(P(-1, -1), P(1,1));
  picture(P(160, 160));
  offset(P(0, -10));

  unitlength("1pt");

  begin();

  ellipse(P(0,0), P(1,1));
  
  /* Center, radius, rotation angle in degrees */
  boldellipse_half(P(0,0), P(1/sqrt(3),1), -90);
  dashellipse_half(P(0,0), P(1/sqrt(3),1), 90);

  boldellipse_half(P(0,0), P(1/sqrt(3), 1), 150);
  dashellipse_half(P(0,0), P(1/sqrt(3), 1), -30);

  red();
  boldellipse_half(P(0,0), P(1/sqrt(3), 1), 30); 
  dashellipse_half(P(0,0), P(1/sqrt(3), 1), 210);
  end_red();

  arrow(P(0,0), P(0,1.2));
  boldarrow(P(0,0), P(-0.6*sqrt(3), -0.6));

  arrow(P(0,0), P(0.6*sqrt(3), -0.6));

  end();
}
