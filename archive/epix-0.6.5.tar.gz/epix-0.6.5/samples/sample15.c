/* 
 * sample15.c -- Animation frames (rolling wheel)
 *
 * August 21, 2001
 */

#include "epix.h"

double f1(double t)
{
  return t - sin(t);
}
double g1(double t)
{
  return -cos(t);
}

double f2(double t)
{
  return t - (2.0/3.0)*sin(t);
}
double g2(double t)
{
  return -(2.0/3.0)*cos(t);
}

double f3(double t)
{
  return t - (1.0/3.0)*sin(t);
}
double g3(double t)
{
  return -(1.0/3.0)*cos(t);
}


main() {
  /* Variable declarations/assignments first */
  int i;
  double dt = 5*M_PI/11;
  double t = 0;

  /* Global size assignments */
  picture(P(420, 120));
  offset(P(-120,0));

  bounding_box(P(0,-1), P(7,1));
  unitlength("0.005in");

  for(i=0; i < 7; ++i)
    {
      t += dt;
      begin(); // Entire picture inside loop body

      line(P(x_min - 2, y_min), P(x_max + 6, y_min)); // the ground
      
      ellipse(P(t,0), P(1,1)); // the wheel
      
      dot(P(f1(t), g1(t))); // the points
      dot(P(f2(t), g2(t)));
      dot(P(f3(t), g3(t)));
      
      /* and the paths they trace */
      bold();
      green();
      line(P(t,0), P(f1(t), g1(t)));
      end_green();

      red();
      paramplot(f1, g1, 0, t, (int) ceil(1+10*t));
      end_red();
      
      magenta();
      paramplot(f2, g2, 0, t, (int) ceil(1+10*t));
      end_magenta();

      blue();
      paramplot(f3, g3, 0, t, (int) ceil(1+10*t));
      end_blue();

      cyan();
      line(P(0,0), P(t,0));
      end_cyan();
      end_bold();

      end();
    
      /* figure separator and vertical space */
      printf("\n\\vspace*{3ex}\n%%%%");
    }
}

