/* 
 * sample14.c -- Tangent vector field plots along a curve
 *
 * August 16, 2001
 */

#include "epix.h"

double f1(double t)
{
  return sin(3*M_PI*t+0.5);
}
double f2(double t)
{
  return sin(4*M_PI*t+0.5);
}

main() {

  bounding_box(P(-1,-1), P(1,1));
  picture(P(330, 330));
  unitlength("0.01in");

  begin();

  grid(P(x_min,y_min), P(x_max,y_max), 4*(x_max-x_min), 4*(y_max-y_min));

  h_axis_labels(P(x_min, 0), P(x_max, 0), 2*(x_max - x_min), P(-20, 5));
  v_axis_labels(P(0, y_min), P(0, y_max), 2*(y_max - y_min), P(-20, 5));

  tan_field(*f1, *f2, 0, 2, 150);

  end();
}

