/* sample8.c, August 16, 2001 */

#include "epix.h"

double plot_h(double t)
{
  return 1.6*cos(M_PI*t)-0.6*cos(5*M_PI*t);
}

double plot_v(double t)
{
  return 1.6*sin(M_PI*t)+0.6*sin(5*M_PI*t);
}

main() {
  bounding_box(P(-2,-2), P(2,2));
  picture(P(150, 150));
  unitlength("1.2pt");

  begin();

  grid(P(x_min,y_min), P(x_max,y_max), 6,6);

  green();
  bold();
  dashellipse(P(0,0),P(2,2));

  dashellipse(P(1.6,0), P(0.4, 0.4));
  end_bold();
  end_green();

  ellipse(P(1.6,0), P(0.6,0.6));

  boldparamplot((*plot_h), (*plot_v), 0, 2, 180);

  end();
}
