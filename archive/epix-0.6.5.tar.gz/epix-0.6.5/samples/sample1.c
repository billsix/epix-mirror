/* sample1.c, August 16, 2001
 * 
 * Rectangles and circular arcs
 */

#include "epix.h"

main() {
  double a = sqrt(5);

  bounding_box(P(0,0), P((1+a)/2, (1+a)/3));

  picture(P(270, 180));

  unitlength("0.0125in");

  begin();

  boldrect(P(0,0), P((1+a)/2, 1));

  line(P(1,0), P(1,1));
  dashline(P(0.5,0), P(0.5,1));
  line(P(0.5,0), P(1,1));

  arc(P(0.5,0), a/2, 0, atan(2));

  end();
}

