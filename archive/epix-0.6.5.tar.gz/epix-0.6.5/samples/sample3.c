/* sample3.c, August 16, 2001 
 * 
 * Circular arcs and arrows; use of variables makes the figure
 * easy to modify.
 */

#include "epix.h"

double a=M_PI, b=1;

main() 
{
  double R=4.5; // outer radius
  double r=0.5; // inner radius
  double D=0.25;// half-width of slit

  bounding_box(P(-5, -5), P(5,5));
  picture(P(160, 160));
  unitlength("0.35mm");

  begin();

  boldarrow(P(0,0), P(1.5*x_max,0));
  spot(P(0,0)); // Origin

  // Circular arcs
  arc(P(0,0), R, asin(D/R), 2*M_PI-asin(D/R));
  arc(P(0,0), r, asin(D/r), 2*M_PI-asin(D/r));

  // Slit
  line(P(r*cos(asin(D/r)), D), P(R*cos(asin(D/R)), D));
  line(P(r*cos(asin(D/r)), -D), P(R*cos(asin(D/R)), -D));

  // Arrows
  arrow(P(R/4, r), P(3*R/4, r));
  arrow(P(3*R/4, -r), P(R/4, -r));

  arc_arrow(P(0,0), 0.9*R, a-b, a+b);

  label(P(R,D), P(2,4), "$R\\to\\infty$");
  label(P(-R/2,r), P(0,0), "$\\delta\\to0$");
  label(P(R*sqrt(2)/2, R*sqrt(2)/2), P(2,4), "$\\gamma$");

  end();
}
