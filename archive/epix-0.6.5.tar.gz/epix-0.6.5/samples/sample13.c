/* 
 * sample13.c -- Tangent vector field plots along a curve
 */

#include "epix.h"

double f0(double t)
{
  return 0;
}
double f1(double t)
{
  return t;
}
double f2(double t)
{
  return 2-t*t/8;
}

main() {
  unitlength("0.01in");
  bounding_box(P(0,0), P(4,2));
  picture(P(360, 180));

  begin();

  h_axis(P(x_min,0), P(x_max,0), 8);
  v_axis(P(0,y_min), P(0,y_max), 4);

  //  h_axis_labels(P(x_min, 0), P(x_max, 0), (x_max - x_min), P(-10, 5));
  //  v_axis_labels(P(0, y_min), P(0, y_max), (y_max - y_min), P(-10, 5));

  dashparamplot(*f1, *f2, x_min, x_max, 20);

  boldtan_field(*f1, *f2, x_min, 0.75*x_max, 3);
  boldtan_field(*f0, *f2, 0.01, 0.75*x_max, 3);

  end();
}

