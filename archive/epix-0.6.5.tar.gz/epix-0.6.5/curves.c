/*
 * curves.c: Ellipses, circular arcs, splines
 *
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.6.5
 * Last Change: August 22, 2001
 */

#include "epix.h"

extern double x_min, x_max, y_min, y_max;
extern double h_size, v_size;

/* 
 * Ellipses and half-ellipses 
 */

/* eepic.sty has an \ellipse function; native_ellipse() accesses it */
void draw_native_ellipse(struct pair center, struct pair radius)
{
  printf("\n\\put(%g,%g){\\ellipse{%g}{%g}}", \
	 h_scale(center.x1), v_scale(center.x2), \
	 h_stretch(2*radius.x1), v_stretch(2*radius.x2));
}

void native_ellipse(struct pair center, struct pair radius)
{
  comment_ellipse("native_ellipse", center, radius);
  draw_native_ellipse(center, radius);
  end_stanza();
}

/* All other curves generate their own data */

void draw_ellipse(struct pair center, struct pair radius, const int path_style)
{
  int i;

  start_path(path_style);
  for (i=0; i <= 2*NUM_PTS; ++i) {
    printf("(%g,%g)", \
	   h_scale(center.x1 + radius.x1*cos(M_PI*i/NUM_PTS)),
	   v_scale(center.x2 + radius.x2*sin(M_PI*i/NUM_PTS)) );

    line_break(i, 2*NUM_PTS, path_style);
  }
}  

void comment_ellipse(char *type, struct pair center, struct pair radius)
{
  printf("\n%%%% %s: center (%.2f, %.2f), radius (%.2f, %.2f)\n%%%%", \
	 type, center.x1, center.x2, radius.x1, radius.x2);
}

void ellipse(struct pair center, struct pair radius)
{
  comment_ellipse("ellipse", center, radius);
  draw_ellipse(center, radius, PLAIN);
  end_stanza();
}

void dashellipse(struct pair center, struct pair radius)
{
  comment_ellipse("dashellipse", center, radius);
  draw_ellipse(center, radius, DASHED);
  end_stanza();
}

void dotellipse(struct pair center, struct pair radius)
{
  comment_ellipse("dotellipse", center, radius);
  draw_ellipse(center, radius, DOTTED);
  end_stanza();
}

void boldellipse(struct pair center, struct pair radius)
{
  comment_ellipse("boldellipse", center, radius);
  bold();
  draw_ellipse(center, radius, BOLD);
  endbold();
  end_stanza();
}

/* 
 * draw_half_ellipse -- draws a *top* half_ellipse with center <center>, 
 *   semi-axes <radius>, NUM_PTS+1 points, and translated (in parameter) 
 *   by <phase> (measured in degrees).
 */
void draw_half_ellipse(struct pair center, struct pair radius, 
		       double phase, const int path_style)
{
  int i;
  start_path(path_style);
  for (i=0; i <= NUM_PTS; ++i) {
    printf("(%g,%g)",
	   h_scale(center.x1 
		   + radius.x1*cos(M_PI*(i+phase*NUM_PTS/180)/NUM_PTS)),
	   v_scale(center.x2 
		   + radius.x2*sin(M_PI*(i+phase*NUM_PTS/180)/NUM_PTS)) );

    line_break(i, NUM_PTS, path_style);
  }
}  

/* Plain half-ellipses */
void ellipse_top(struct pair center, struct pair radius)
{
  comment_ellipse("ellipse_top", center, radius);
  draw_half_ellipse(center, radius, 0, PLAIN);
  end_stanza();
}

void ellipse_bottom(struct pair center, struct pair radius)
{
  comment_ellipse("ellipse_bottom", center, radius);
  draw_half_ellipse(center, radius, 180, PLAIN);
  end_stanza();
}

void ellipse_left(struct pair center, struct pair radius)
{
  comment_ellipse("ellipse_left", center, radius);
  draw_half_ellipse(center, radius, 90, PLAIN);
  end_stanza();
}

void ellipse_right(struct pair center, struct pair radius)
{
  comment_ellipse("ellipse_right", center, radius);
  draw_half_ellipse(center, radius, -90, PLAIN);
  end_stanza();
}

/* Dashed half-ellipses */
void dashellipse_top(struct pair center, struct pair radius)
{
  comment_ellipse("dashellipse_top", center, radius);
  draw_half_ellipse(center, radius, 0, DASHED);
  end_stanza();
}

void dashellipse_bottom(struct pair center, struct pair radius)
{
  comment_ellipse("dashellipse_bottom", center, radius);
  draw_half_ellipse(center, radius, 180, DASHED);
  end_stanza();
}

void dashellipse_left(struct pair center, struct pair radius)
{
  comment_ellipse("dashellipse_left", center, radius);
  draw_half_ellipse(center, radius, 90, DASHED);
  end_stanza();
}

void dashellipse_right(struct pair center, struct pair radius)
{
  comment_ellipse("dashellipse_right", center, radius);
  draw_half_ellipse(center, radius, -90, DASHED);
  end_stanza();
}

/* Dotted half-ellipses */
void dotellipse_top(struct pair center, struct pair radius)
{
  comment_ellipse("dotellipse_top", center, radius);
  draw_half_ellipse(center, radius, 0, DOTTED);
  end_stanza();
}

void dotellipse_bottom(struct pair center, struct pair radius)
{
  comment_ellipse("dotellipse_bottom", center, radius);
  draw_half_ellipse(center, radius, 180, DOTTED);
  end_stanza();
}

void dotellipse_left(struct pair center, struct pair radius)
{
  comment_ellipse("dotellipse_left", center, radius);
  draw_half_ellipse(center, radius, 90, DOTTED);
  end_stanza();
}

void dotellipse_right(struct pair center, struct pair radius)
{
  comment_ellipse("dotellipse_right", center, radius);
  draw_half_ellipse(center, radius, -90, DOTTED);
  end_stanza();
}

/* Bold half-ellipses */
void boldellipse_top(struct pair center, struct pair radius)
{
  comment_ellipse("boldellipse_top", center, radius);
  bold();
  draw_half_ellipse(center, radius, 0, BOLD);
  endbold();
  end_stanza();
}

void boldellipse_bottom(struct pair center, struct pair radius)
{
  comment_ellipse("boldellipse_bottom", center, radius);
  bold();
  draw_half_ellipse(center, radius, 180, BOLD);
  endbold();
  end_stanza();
}

void boldellipse_left(struct pair center, struct pair radius)
{
  comment_ellipse("boldellipse_left", center, radius);
  bold();
  draw_half_ellipse(center, radius, 90, BOLD);
  endbold();
  end_stanza();
}

void boldellipse_right(struct pair center, struct pair radius)
{
  comment_ellipse("boldellipse_right", center, radius);
  bold();
  draw_half_ellipse(center, radius, -90, BOLD);
  endbold();
  end_stanza();
}

/* Rotated half_ellipses */
void comment_rotate_ellipse(char *type, struct pair center, \
			    struct pair radius, double angle)
{
  printf("\n%%%% %s: center (%.2f, %.2f), radius (%.2f, %.2f),",\
	 type, center.x1, center.x2, radius.x1, radius.x2);
  printf("\n%%%%   rotated %.1f degrees\n%%%%", angle);
}

/*
 * draw_ellipse_half -- right ellipse rotated counterclockwise by <angle>
 */
void rotate_half_ellipse(struct pair center, struct pair radius, 
			 double angle, const int path_style)
{
  int i = 0;
  double t = -M_PI_2;
  double dt = M_PI/NUM_PTS;

  start_path(path_style);
  for (i=0; i <= NUM_PTS; ++i, t += dt) {

    printf("(%g,%g)", \
	   h_scale(center.x1 + radius.x1*cos(t)*cos(M_PI*angle/180.0) \
		  - radius.x2*sin(t)*sin(M_PI*angle/180.0)), \
	   v_scale(center.x2 + radius.x1*cos(t)*sin(M_PI*angle/180.0) \
		  + radius.x2*sin(t)*cos(M_PI*angle/180.0)) );
    
    line_break(i, NUM_PTS, path_style);
  }
}

void ellipse_half(struct pair center, struct pair radius, double angle)
{
  comment_rotate_ellipse("ellipse_half", center, radius, angle);
  rotate_half_ellipse(center, radius, angle, PLAIN);
  end_stanza();
}

void dashellipse_half(struct pair center, struct pair radius, double angle)
{
  comment_rotate_ellipse("dashellipse_half", center, radius, angle);
  rotate_half_ellipse(center, radius, angle, DASHED);
  end_stanza();
}

void dotellipse_half(struct pair center, struct pair radius, double angle)
{
  comment_rotate_ellipse("dotellipse_half", center, radius, angle);
  rotate_half_ellipse(center, radius, angle, DOTTED);
  end_stanza();
}

void boldellipse_half(struct pair center, struct pair radius, double angle)
{
  comment_rotate_ellipse("boldellipse_half", center, radius, angle);
  bold();
  rotate_half_ellipse(center, radius, angle, BOLD);
  endbold();
  end_stanza();
}

/* 
 * Objects containing circular arcs 
 */

/* Circular arc spanning arbitrary angle */
void comment_arc(char *type, struct pair center, \
		 double radius, double start, double finish)
{
  printf("\n%%%% %s:\n%%%%   center (%.2f,%.2f), radius %.2f, ",\
	 type, center.x1, center.x2, radius);
  printf("from %.2f to %.2f radians \n%%%%", start, finish);
}

/* 
 * draw_proper_arc is called iff start/finish angles are sensible.
 * Angles are measured in radians, hence may be generated readily
 * by the standard C math functions.
 */

static double arc_scale(double r)
{
  /* Approx. number of true pts per radian */
  return unscale(h_stretch(r) + v_stretch(r))/2.0;
}

void draw_proper_arc(struct pair center, double r, 
		     double start, double finish, const int path_style)
{
  double angle = finish - start; 
  int i; 

  /* 
   * Number of points plotted is nearly proportional to radius and
   * angle subtended for large circles, but is no smaller than 20
   * points per circle for small circles. Hybrid of two failed attempts:
   *
   * int num_pts=(int) ceil(fabs(NUM_PTS*angle));
   * 
   * ceil(fabs(angle)*unscale(h_scale(r)+v_scale(r))/(2.0*DASH_LENGTH));
   */
  int num_pts=(int) ceil(fabs(0.5*(angle/M_PI)*(NUM_PTS + arc_scale(r)/DASH_LENGTH)));

  if (num_pts < 2)
    num_pts=2;

  start_path(path_style);
  for (i=0; i <= num_pts; ++i) {
    printf("(%g,%g)", \
	   h_scale(center.x1 + r*cos((start+i*angle/num_pts))),
	   v_scale(center.x2 + r*sin((start+i*angle/num_pts))));

    line_break(i, num_pts, path_style);
  }
}

void draw_arc(struct pair center, double r, 
	      double start, double finish, const int path_style)
{
  if (fabs(finish-start) >= 2*M_PI) // One full turn or more
    draw_ellipse(center, P(r, r), path_style);

  else if (0 < finish - start)
    draw_proper_arc(center, r, start, finish, path_style);
    
  else if (0 > finish - start)
    draw_proper_arc(center, r, finish, start, path_style);

  else // start == finish
    printf("\n%%%%   Null arc...?");
}

void arc(struct pair center, double r, double start, double finish)
{
  comment_arc("arc", center, r, start, finish);
  draw_arc(center, r, start, finish, PLAIN);
  end_stanza();
}

void dasharc(struct pair center, double r, double start, double finish)
{
  comment_arc("dasharc", center, r, start, finish);
  draw_arc(center, r, start, finish, DASHED);
  end_stanza();
}

void dotarc(struct pair center, double r, double start, double finish)
{
  comment_arc("dotarc", center, r, start, finish);
  draw_arc(center, r, start, finish, DOTTED);
  end_stanza();
}

void boldarc(struct pair center, double r, double start, double finish)
{
  comment_arc("boldarc", center, r, start, finish);
  bold();
  draw_arc(center, r, start, finish, BOLD);
  endbold();
  end_stanza();
}

/* Angle subtended by arrowhead at Cartesian distance r */

static double subtended(double r)
{
  return 2*ARROWHEAD_WIDTH*ARROWHEAD_RATIO/unscale(h_stretch(r)+v_stretch(r));
}

void draw_arc_arrow(struct pair center, double r, 
		    double start, double finish, const int path_style)
{
  struct pair base, dir, tip;

  if (fabs(start - finish) <= subtended(r))
    printf("\n%%%%   Arc shorter than arrowhead; not printed");
  
  else {
    if (start < finish)
      finish -= subtended(r);
    else
      finish += subtended(r);
    
    /* Terminal point of arc */
    base = add_pair(center, mult_s(r, cis(finish)));
    /* Unit (1 true pt) vector tangent to arc at <base> */
    dir.x1 = h_stretch(cos(finish));
    dir.x2 = v_stretch(sin(finish));
    dir = J(normalize(dir));
    /* Reverse direction if necessary */
    if (start > finish)
      dir = mult_s(-1, dir);
    
    /* Magic number 0.01 */
    tip = add_pair(base, mult_s(0.01, dir));
    
    draw_arc(center, r, start, finish, path_style);
    
    //  start_path(PLAIN);
    draw_arrow(base, tip, PLAIN);
  }
}

void arc_arrow(struct pair center, double r, double start, double finish)
{
  comment_arc("arc_arrow", center, r, start, finish);
  draw_arc_arrow(center, r, start, finish, PLAIN);
  end_stanza();
}

void dasharc_arrow(struct pair center, double r, double start, double finish)
{
  comment_arc("dasharc_arrow", center, r, start, finish);
  draw_arc_arrow(center, r, start, finish, DASHED);
  end_stanza();
}

void dotarc_arrow(struct pair center, double r, double start, double finish)
{
  comment_arc("dotarc_arrow", center, r, start, finish);
  draw_arc_arrow(center, r, start, finish, DOTTED);
  end_stanza();
}

void boldarc_arrow(struct pair center, double r, double start, double finish)
{
  comment_arc("boldarc_arrow", center, r, start, finish);
  bold();
  draw_arc_arrow(center, r, start, finish, BOLD);
  endbold();
  end_stanza();
}

/* Hyperbolic lines and triangles */

void draw_hyperbolic_line(struct pair tail, struct pair head, 
			  const int path_style)
{
  double x;
  double a = tail.x1, b = tail.x2, c = head.x1, d = head.x2;
  int i, n;

  if (b < 0 || d < 0)
    printf("\n%%%% Error: One or both points not in upper half-plane");

  /*
   * Position of center of circle is numerically unstable near a=c.
   */
  else if ( truncate(fabs(a - c)) == 0 ) {

    n = (int) ceil(unscale(v_scale(M_PI*fabs(d - b))/20.0));
    if (n < 1)
      n=1; // print at least 2 points

    start_path(path_style);
    for (i=0; i <= n; ++i) 
      {
	printf("(%g,%g)", h_scale(a), v_scale(b + i*(d - b)/n));
	line_break(i, n, path_style);
      }
  }    

  else {
    x = (0.5)*(hypot(c, d) - hypot(a, b))/(c-a); // center of circle

    draw_arc(P(x,0), hypot(c-x, d), 
	     atan2(d, c-x), atan2(b, a-x), path_style);
  }
}

void hyperbolic_line(struct pair tail, struct pair head)
{
  comment_line("hyperbolic_line", tail, head);
  draw_hyperbolic_line(tail, head, PLAIN);
  end_stanza();
}

void dashhyperbolic_line(struct pair tail, struct pair head)
{
  comment_line("dashhyperbolic_line", tail, head);
  draw_hyperbolic_line(tail, head, DASHED);
  end_stanza();
}

void dothyperbolic_line(struct pair tail, struct pair head)
{
  comment_line("dothyperbolic_line", tail, head);
  draw_hyperbolic_line(tail, head, DOTTED);
  end_stanza();
}

void boldhyperbolic_line(struct pair tail, struct pair head)
{
  comment_line("boldhyperbolic_line", tail, head);
  bold();
  draw_hyperbolic_line(tail, head, BOLD);
  endbold();
  end_stanza();
}

/* 
 * Splines 
 */

void comment_quad_spline(char *type, struct pair p1,
			 struct pair p2, struct pair p3)
{
  printf("\n%%%% %s: control points", type);
  printf("\n%%%%   (%.2f, %.2f), (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	 p1.x1, p1.x2, p2.x1, p2.x2, p3.x1, p3.x2);
}
void comment_cubic_spline(char *type, struct pair p1, struct pair p2,
			  struct pair p3, struct pair p4)
{
  printf("\n%%%% %s: control points", type);
  printf("\n%%%%   (%.2f, %.2f), (%.2f, %.2f), (%.2f, %.2f), (%.2f, %.2f)",
	 p1.x1, p1.x2, p2.x1, p2.x2, p3.x1, p3.x2, p4.x1, p4.x2);
  printf("\n%%%%");
}

void draw_quad_spline(struct pair p1, struct pair p2, struct pair p3,
		      const int path_style)
{
  int i=0;
  double t=0;
  double dt = 1.0/NUM_PTS;

  if (path_style == DOTTED)
    for (i=0; i <= NUM_PTS; ++i) {
      double x = t*t*p1.x1 + 2*t*(1-t)*p2.x1 + (1-t)*(1-t)*p3.x1;
      double y = t*t*p1.x2 + 2*t*(1-t)*p2.x2 + (1-t)*(1-t)*p3.x2;
      
      ddot(P(x,y));
      t += dt;
    }
  
  else
    {
      start_path(path_style);

      for (i=0; i <= NUM_PTS; ++i) {
	printf("(%g,%g)", \
	       h_scale(t*t*p1.x1 + 2*t*(1-t)*p2.x1 + (1-t)*(1-t)*p3.x1),
	       v_scale(t*t*p1.x2 + 2*t*(1-t)*p2.x2 + (1-t)*(1-t)*p3.x2));
	t += dt;
	line_break(i, NUM_PTS, path_style);
      }
    }
}

void draw_cubic_spline(struct pair p1, struct pair p2,
		       struct pair p3, struct pair p4, const int path_style)
{
  int i=0;
  double t = 0;
  double dt = 1.0/NUM_PTS; 

  start_path(path_style);

  for (i=0; i <= NUM_PTS; ++i) {
    printf("(%g,%g)", \
	   h_scale( pow(t,3)*p1.x1 + 3*t*t*(1-t)*p2.x1 \
		   + 3*t*(1-t)*(1-t)*p3.x1 + pow(1-t,3)*p4.x1), \
	   v_scale( pow(t,3)*p1.x2 + 3*t*t*(1-t)*p2.x2 \
		   + 3*t*(1-t)*(1-t)*p3.x2 + pow(1-t,3)*p4.x2));
    t += dt;
    line_break(i, NUM_PTS, path_style);
  }
}

void quad_spline(struct pair p1, struct pair p2, struct pair p3)
{
  comment_quad_spline("quad_spline", p1, p2, p3);
  draw_quad_spline(p1, p2, p3, PLAIN);
  end_stanza();
}

void dashquad_spline(struct pair p1, struct pair p2, struct pair p3)
{
  comment_quad_spline("dashquad_spline", p1, p2, p3);
  draw_quad_spline(p1, p2, p3, DASHED);
  end_stanza();
}

void dotquad_spline(struct pair p1, struct pair p2, struct pair p3)
{
  comment_quad_spline("dotquad_spline", p1, p2, p3);
  draw_quad_spline(p1, p2, p3, DOTTED);
  end_stanza();
}

void boldquad_spline(struct pair p1, struct pair p2, struct pair p3)
{
  comment_quad_spline("boldquad_spline", p1, p2, p3);
  bold();
  draw_quad_spline(p1, p2, p3, BOLD);
  endbold();
  end_stanza();
}

void cubic_spline(struct pair p1, struct pair p2, \
		  struct pair p3, struct pair p4)
{
  comment_cubic_spline("cubic_spline", p1, p2, p3, p4);
  draw_cubic_spline(p1, p2, p3, p4, PLAIN);
  end_stanza();
}

void dashcubic_spline(struct pair p1, struct pair p2, \
		      struct pair p3, struct pair p4)
{
  comment_cubic_spline("dashcubic_spline", p1, p2, p3, p4);
  draw_cubic_spline(p1, p2, p3, p4, DASHED);
  end_stanza();
}

void dotcubic_spline(struct pair p1, struct pair p2, \
		     struct pair p3, struct pair p4)
{
  comment_cubic_spline("dotcubic_spline", p1, p2, p3, p4);
  draw_cubic_spline(p1, p2, p3, p4, DOTTED);
  end_stanza();
}

void boldcubic_spline(struct pair p1, struct pair p2, \
		      struct pair p3, struct pair p4)
{
  comment_cubic_spline("boldcubic_spline", p1, p2, p3, p4);
  bold();
  draw_cubic_spline(p1, p2, p3, p4, BOLD);
  endbold();
  end_stanza();
}

/* Planar knot diagram primitives */

void comment_twist(char *type, struct pair p1, struct pair p4)
{
  printf("\n%%%% %s: control points", type);
  printf("\n%%%%   (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	 p1.x1, p1.x2, p4.x1, p4.x2);
}

void draw_under_strand(struct pair p3, struct pair p6,
		       struct pair p5, struct pair p2, const int path_style)
{
  int i=0;
  double t = 0;
  double dt = 1.0/NUM_PTS; 

  // Draw two half-splines with given control points
  start_path(path_style);
  for (i=0; i < NUM_PTS/2 - 1; ++i) {
    printf("(%g,%g)", \
	   h_scale( pow(t,3)*p3.x1 + 3*t*t*(1-t)*p6.x1 \
		   + 3*t*(1-t)*(1-t)*p5.x1 + pow(1-t,3)*p2.x1), \
	   v_scale( pow(t,3)*p3.x2 + 3*t*t*(1-t)*p6.x2 \
		   + 3*t*(1-t)*(1-t)*p5.x2 + pow(1-t,3)*p2.x2));
    t += dt;
    line_break(i, NUM_PTS/2, path_style);
  }

  t=1; // Start at end of path, step backward
  start_path(path_style);
  for (i=0; i < NUM_PTS/2 - 1; ++i) {
    printf("(%g,%g)", \
	   h_scale( pow(t,3)*p3.x1 + 3*t*t*(1-t)*p6.x1 \
		   + 3*t*(1-t)*(1-t)*p5.x1 + pow(1-t,3)*p2.x1), \
	   v_scale( pow(t,3)*p3.x2 + 3*t*t*(1-t)*p6.x2 \
		   + 3*t*(1-t)*(1-t)*p5.x2 + pow(1-t,3)*p2.x2));
    t -= dt;
    line_break(i, NUM_PTS/2, path_style);
  }
}

void draw_p_twist(struct pair p1, struct pair p4, const int path_style)
{
  struct pair p2, p3, p5, p6;
  // Set up control points in an H
  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      p2.x1 = p1.x1; // <p2>     <p4>
      p2.x2 = p4.x2; // <p5>     <p6>
      p3.x1 = p4.x1; // <p1>     <p3>
      p3.x2 = p1.x2;

      p5.x1 = p1.x1;
      p6.x1 = p4.x1;
      p5.x2 = p6.x2 = (0.5)*(p1.x2 + p4.x2);
    }

  else
    {
      p2.x1 = p4.x1; // <p1> <p5> <p2>
      p2.x2 = p1.x2; // 
      p3.x1 = p1.x1; // <p3> <p6> <p4>
      p3.x2 = p4.x2;

      p5.x2 = p1.x2;
      p6.x2 = p4.x2;
      p5.x1 = p6.x1 = (0.5)*(p1.x1 + p4.x1);
    }
  
  // Over strand
  draw_cubic_spline(p1, p5, p6, p4, path_style);
  draw_under_strand(p3, p6, p5, p2, path_style);
}

void draw_n_twist(struct pair p1, struct pair p4, const int path_style)
{
  struct pair p2, p3, p5, p6;
  // Set up control points in an H -- same as draw_p_twist
  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      p2.x1 = p1.x1; // <p2>     <p4>
      p2.x2 = p4.x2; // <p5>     <p6>
      p3.x1 = p4.x1; // <p1>     <p3>
      p3.x2 = p1.x2;

      p5.x1 = p1.x1;
      p6.x1 = p4.x1;
      p5.x2 = p6.x2 = (0.5)*(p1.x2 + p4.x2);
    }

  else
    {
      p2.x1 = p4.x1; // <p1> <p5> <p2>
      p2.x2 = p1.x2; // 
      p3.x1 = p1.x1; // <p3> <p6> <p4>
      p3.x2 = p4.x2;

      p5.x2 = p1.x2;
      p6.x2 = p4.x2;
      p5.x1 = p6.x1 = (0.5)*(p1.x1 + p4.x1);
    }
  
  // Over strand -- control points reversed from draw_p_twist
  draw_cubic_spline(p3, p6, p5, p2, path_style);
  draw_under_strand(p1, p5, p6, p4, path_style);
}

void p_twist(struct pair p1, struct pair p4)
{
  comment_twist("p_twist", p1, p4);
  draw_p_twist(p1, p4, PLAIN);
  end_stanza();
}

void boldp_twist(struct pair p1, struct pair p4)
{
  comment_twist("boldp_twist", p1, p4);
  bold();
  draw_p_twist(p1, p4, BOLD);
  endbold();
  end_stanza();
}

void n_twist(struct pair p1, struct pair p4)
{
  comment_twist("n_twist", p1, p4);
  draw_n_twist(p1, p4, PLAIN);
  end_stanza();
}

void boldn_twist(struct pair p1, struct pair p4)
{
  comment_twist("boldn_twist", p1, p4);
  bold();
  draw_n_twist(p1, p4, BOLD);
  endbold();
  end_stanza();
}

void twists(struct pair p1, struct pair p4, int n)
{
  double a;
  double b;
  double c;
  double d;

  int i;

  printf("\n%%%% twists(%d), (%.2f,%.2f) to (%.2f,%.2f)", 
	 n, p1.x1, p1.x2, p4.x1, p4.x2);

  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      a = p1.x1;
      b = p1.x2;
      c = p4.x1;
      d = p4.x2;
      
      if (n < 0) {
	n = -n;
	for (i=0; i < n; ++i)
	  draw_n_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n), PLAIN);
      }

      else
	for (i=0; i < n; ++i)
	  draw_p_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n), PLAIN);
    }

  else
    {
      a = p1.x2;
      b = p1.x1;
      c = p4.x2;
      d = p4.x1;

      if (n < 0) {
	n = -n;
	for (i=0; i < n; ++i)
	  draw_n_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c), PLAIN);
      }

      else
	for (i=0; i < n; ++i)
	  draw_p_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c), PLAIN);
    }
  end_stanza();
}

void boldtwists(struct pair p1, struct pair p4, int n)
{
  double a;
  double b;
  double c;
  double d;

  int i;

  printf("\n%%%% boldtwists(%d), (%.2f,%.2f) to (%.2f,%.2f)", 
	 n, p1.x1, p1.x2, p4.x1, p4.x2);

  bold();
  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      a = p1.x1;
      b = p1.x2;
      c = p4.x1;
      d = p4.x2;
      
      if (n < 0) {
	n = -n;
	for (i=0; i < n; ++i)
	  draw_n_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n), PLAIN);
      }

      else
	for (i=0; i < n; ++i)
	  draw_p_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n), PLAIN);
    }

  else
    {
      a = p1.x2;
      b = p1.x1;
      c = p4.x2;
      d = p4.x1;

      if (n < 0) {
	n = -n;
	for (i=0; i < n; ++i)
	  draw_n_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c), PLAIN);
      }

      else
	for (i=0; i < n; ++i)
	  draw_p_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c), PLAIN);
    }
  endbold();
  end_stanza();
}
