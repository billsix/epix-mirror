/*
 * ePiX default preamble
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 */

double pic_size=1;
const char *pic_unit="pt";
