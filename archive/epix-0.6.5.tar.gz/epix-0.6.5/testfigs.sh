#!/bin/sh
#
# testfigs.sh -- shell script to test ePiX before installation
# 
# August 6, 2001  Andrew D. Hwang  ahwang@mathcs.holycross.edu
#
CC="gcc"
CFLAGS=""

ePiX() {
# Mimic run of epix on sample file, using newly-compiled library
FILEROOT=${1%%".c"}

$CC $CFLAGS $1 -o $FILEROOT.exe -I.. -L. -lm -lepixtest 

if [ -x "$FILEROOT.exe" ] 
then ./$FILEROOT.exe > $FILEROOT.eepic
fi

if [ -f "$FILEROOT.eepic" ] 
then echo -n "."
    rm -f $FILEROOT.exe
    return 0;
else 
    echo "failed, exiting"
    rm -f $FILEROOT.exe libepixtest.a 2>/dev/null
    exit 1;
fi
}

## Script proper starts here ##

if [ -d samples ] 
then cd ./samples
else echo Directory \"samples\" does not exist, exiting
    exit 1;
fi

# Now we're in samples
cp -p ../libepix.a libepixtest.a

echo -n "Creating .eepic files  "
for i in $(ls sample*.c) ; do ePiX $i ; done
echo " done"

# Clean test library
rm -f libepixtest.a

echo; echo "Testing laps..."

../laps sample.tex 1>/dev/null

if [ -f "sample.ps" ] 
then echo; echo "ePiX test: success"
    mv -f sample.dvi  sample.ps ..
    rm -f sample.log sample*.eepic
else echo; echo "failed"; exit 1;
fi

echo "You may now preview sample.dvi or sample.ps"

cd ..

exit 0;

