#!/bin/sh
#
# update_figs.sh -- converts ePiX-0.6.4 and earlier files to 0.6.5
#   by stripping out the "const " declaration of *pic_unit and (most)
#   dereferences ("*") in plot commands.
#
# August 19, 2001, Andrew D. Hwang   ahwang@mathcs.holycross.edu
#

echo -n "This operation is potentially destructive. Create backup? [y/n] "
read ANSWER

case "$ANSWER" in

    y|Y|yes|Yes)

    tar -cf - *.c | gzip -9 > update_figs.tar.gz
    echo "Wrote all \".c\" files in this directory to update_figs.tar.gz"
    ;;

    *)
    ;;

esac

echo -n "Converting files "
for i in $(ls *.c)
do
    FILEROOT=${i%%".c"}
    mv $FILEROOT.c $FILEROOT.tmp
    sed 's/^const //g 
	s/x_size()/x_size/g
	s/y_size()/y_size/g
	s/plot(\*/plot(/g
	s/\, \*/\, /g' $FILEROOT.tmp > $FILEROOT.c
    rm -f $FILEROOT.tmp
    echo -n "."
done 

echo " done"

exit 0

