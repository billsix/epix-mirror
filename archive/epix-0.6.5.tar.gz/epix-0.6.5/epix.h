/*
 * Header file for ePiX
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.6.5
 * Last Change: August 22, 2001
 *
 */

#ifndef EPIX
#define EPIX

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* 
 * To find magic numbers in source code, do
 *
 *             grep "Magic number" *.c
 */

/* Tweakable constants  */

#define NUM_PTS 40 /* Number of points in half-ellipses, splines */
#define FILE_WIDTH 70 /* Width of output file, in characters */
#define PAIRS_PER_LINE 4 /* Number of pairs per line in output file */
#define DIAM 4 /* Diameter of circles and spots in true pt */
#define ARROWHEAD_WIDTH 2.0 /* Half-width of arrowheads in true pt */
#define ARROWHEAD_RATIO 5.5 /* Aspect ratio of arrowheads */

#define MAX_LINES 20000 /* Fatal error if this many lines printed */

/* 
 * Determines accuracy of truncation in clipplot et. al.
 * smaller -> better accuracy, longer run
 */
#define SEEK_SIZE 0.01 

/*
 * In calculus plotting, determines the size of the increment dt
 * and the number of increments per point printed
 * larger -> better accuracy, longer run
 */
#define ITERATIONS 1000 

/* Dash length/dot separation in true pt */
#define DASH_LENGTH 5.0
#define DOT_SEP 5.0
enum path_style {PLAIN, DASHED, DOTTED, BOLD};

/* Data plot markers */
enum mark_type {SPOT, RING, DOT, DDOT, PLUS, BOX, BBOX};

/* The standard variables */
double x_min, x_max, y_min, y_max, x_size, y_size;
double h_size, v_size;
double h_offset, v_offset; // no offset by default

double pic_size; 
char *pic_unit;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *               Coordinate conversion -- lengths.c              *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

// Cartesian to picture for points
double h_scale(double); 
double v_scale(double);
// picture to Cartesian for points
double h_unscale(double);
double v_unscale(double);
// Cartesian to picture for direction vectors
double h_stretch(double); 
double v_stretch(double);
// picture to Cartesian for direction vectors
double h_unstretch(double); 
double v_unstretch(double);

// true pt to picture
double scale(double);  
// and back
double unscale(double);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *      Simple functions, picture objects, polygons -- epix.c    *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* 
 * Ordered pairs and operations 
 */
struct pair {
  double x1;
  double x2;
};

/* If less than 0.0001, set to zero */
double truncate(double);

/* Create a pair */
struct pair P(double, double); 
struct pair cis(double); // t -> [cos(t), sin(t)]

/* Vector operations on pairs */
struct pair add_pair(struct pair, struct pair);
struct pair diff_pair(struct pair, struct pair);
struct pair mult_s(double, struct pair);

/* Complex Multiplication */
struct pair mult_pair(struct pair, struct pair);
/* Multiplication by i */
struct pair J(struct pair);

double raw_len(struct pair); // Pythagorean length of pair

/* Length of pair given in picture coords */
double true_len(struct pair); // length in true pt
struct pair normalize(struct pair); // parallel true pt unit vector

/* Coordinate conversion */
struct pair cart_to_pict(struct pair);


/* Variable assignment */
void bounding_box(struct pair, struct pair);
void picture(struct pair);
void offset(struct pair);

/* Delimiters, line styles, output file formatting */

void begin(void);
void end(void);  

void start_path(const int);

/* Misc Styles and output formatting */
void bold(void);
void endbold(void);
void end_bold(void);

void red(void);
void end_red(void);
void blue(void);
void end_blue(void);
void green(void);
void end_green(void);
void cyan(void);
void end_cyan(void);
void magenta(void);
void end_magenta(void);
void yellow(void);
void end_yellow(void);

void fill(void);
void end_stanza(void);

void output(void);
void fatal_error(void);
void line_break(int, int, int);

/* Obsolete path style declarations */
void path(void);
void dashed(void);
void dotted(void);

/* 
 * Picture objects 
 */

void circ(struct pair);
void ring(struct pair, double);
void spot(struct pair);
void dot(struct pair);
void ddot(struct pair);

/* Axes, labels, and decorations */
void h_axis_tick(double, double);
void v_axis_tick(double, double);

/*
 * Axes specified by starting point, direction vector, and multiple.
 * Tick marks of specified type are drawn every <vector>.
 */
void h_axis(struct pair, struct pair, int);
void v_axis(struct pair, struct pair, int);

void draw_grid(struct pair, struct pair, int, int, const int);
void grid(struct pair, struct pair, int, int);
void dashgrid(struct pair, struct pair, int, int);
void dotgrid(struct pair, struct pair, int, int);
void boldgrid(struct pair, struct pair, int, int);

void draw_polar_grid(double, int, int, const int);
void polar_grid(double, int, int);
void dashpolar_grid(double, int, int);
void dotpolar_grid(double, int, int);
void boldpolar_grid(double, int, int);

/*
 * Old-style axis labels
 */
void axis_floats(struct pair, struct pair, int, double, double);
void axis_integers(struct pair, struct pair, int, int, int);
/*
 * h/v_axis_labels: Generate axis labels given endpoints and number
 *    of labels; the offset translates labels in true points for
 *    visual ease of placement. Positioning of labels with signs
 *    is handled more attractively than in Version 0.2.
 */
void h_axis_labels(struct pair, struct pair, int, struct pair);
void v_axis_labels(struct pair, struct pair, int, struct pair);

/* Cartesian position and true offset of label <char> */
void label(struct pair, struct pair, char *);
void mask(struct pair, struct pair, struct pair);

/* Polygons */
void draw_line(struct pair, struct pair, int, const int); 
void comment_line(char *, struct pair, struct pair);

void line(struct pair, struct pair);     
void dashline(struct pair, struct pair); 
void dotline(struct pair, struct pair); 
void boldline(struct pair, struct pair); 

void draw_triangle(struct pair, struct pair, struct pair, const int); 
void comment_triangle(char *, struct pair, struct pair, struct pair);

void triangle(struct pair, struct pair, struct pair);
void dashtriangle(struct pair, struct pair, struct pair);
void dottriangle(struct pair, struct pair, struct pair);
void boldtriangle(struct pair, struct pair, struct pair);

void draw_rect(struct pair, struct pair, const int); /* opposite corners */
void comment_rect(char *, struct pair, struct pair);

void rect(struct pair, struct pair);
void dashrect(struct pair, struct pair); 
void dotrect(struct pair, struct pair); 
void boldrect(struct pair, struct pair); 
void swatch(struct pair, struct pair);
void boldswatch(struct pair, struct pair);

void draw_arrowhead(struct pair, struct pair, double);
void draw_shaft(struct pair, struct pair, double);
void draw_arrow(struct pair, struct pair, const int);
void draw_boldarrow(struct pair, struct pair);
void arrow(struct pair, struct pair);
void dasharrow(struct pair, struct pair);
void dotarrow(struct pair, struct pair);
void boldarrow(struct pair, struct pair);

void draw_dart(struct pair, struct pair, const int);
void draw_bolddart(struct pair, struct pair);
void dart(struct pair, struct pair);
void dashdart(struct pair, struct pair);
void dotdart(struct pair, struct pair);
void bolddart(struct pair, struct pair);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *  Ellipses, half-ellipses, circular arcs, splines -- curves.c  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Ellipses */

/* Point-plotting and comment functions */
void draw_native_ellipse(struct pair, struct pair);
void draw_ellipse(struct pair, struct pair, const int); 
void draw_half_ellipse(struct pair, struct pair, double, const int);
void rotate_half_ellipse(struct pair, struct pair, double, const int);
void comment_ellipse(char *, struct pair, struct pair);
void comment_rotate_ellipse(char *, struct pair, struct pair, double);

/* Stanza-creating whole ellipse functions */
void native_ellipse(struct pair, struct pair);

void ellipse(struct pair, struct pair);
void dashellipse(struct pair, struct pair); 
void dotellipse(struct pair, struct pair); 
void boldellipse(struct pair, struct pair); 

/* Stanza-creating standard half-ellipse functions */
void ellipse_left(struct pair, struct pair);
void ellipse_right(struct pair, struct pair);
void ellipse_top(struct pair, struct pair);
void ellipse_bottom(struct pair, struct pair);

void dashellipse_left(struct pair, struct pair);
void dashellipse_right(struct pair, struct pair);
void dashellipse_top(struct pair, struct pair);
void dashellipse_bottom(struct pair, struct pair);

void dotellipse_left(struct pair, struct pair);
void dotellipse_right(struct pair, struct pair);
void dotellipse_top(struct pair, struct pair);
void dotellipse_bottom(struct pair, struct pair);

void boldellipse_left(struct pair, struct pair);
void boldellipse_right(struct pair, struct pair);
void boldellipse_top(struct pair, struct pair);
void boldellipse_bottom(struct pair, struct pair);

/* Right half ellipse rotated through <double> revolutions */
void ellipse_half(struct pair, struct pair, double);
void dashellipse_half(struct pair, struct pair, double);
void dotellipse_half(struct pair, struct pair, double);
void boldellipse_half(struct pair, struct pair, double);

/* Circular arcs */
void comment_arc(char *, struct pair, double, double, double);
void draw_proper_arc(struct pair, double, double, double, const int);
void draw_arc(struct pair, double, double, double, const int);
void arc(struct pair, double, double, double);
void dasharc(struct pair, double, double, double);
void dotarc(struct pair, double, double, double);
void boldarc(struct pair, double, double, double);

void draw_arc_arrow(struct pair, double, double, double, const int);

void arc_arrow(struct pair, double, double, double);
void dasharc_arrow(struct pair, double, double, double);
void dotarc_arrow(struct pair, double, double, double);
void boldarc_arrow(struct pair, double, double, double);

/* Hyperbolic lines */
void draw_hyperbolic_line(struct pair, struct pair, const int);
void hyperbolic_line(struct pair, struct pair);
void dashhyperbolic_line(struct pair, struct pair);
void dothyperbolic_line(struct pair, struct pair);
void boldhyperbolic_line(struct pair, struct pair);

/* Splines */
void comment_quad_spline(char *, struct pair, struct pair, struct pair);
void comment_cubic_spline(char *, struct pair, struct pair, \
			  struct pair, struct pair);
void draw_quad_spline(struct pair, struct pair, struct pair, const int);
void draw_cubic_spline(struct pair, struct pair, struct pair, struct pair,
		       const int);

void quad_spline(struct pair, struct pair, struct pair);
void dashquad_spline(struct pair, struct pair, struct pair);
void dotquad_spline(struct pair, struct pair, struct pair);
void boldquad_spline(struct pair, struct pair, struct pair);

void cubic_spline(struct pair, struct pair, struct pair, struct pair);
void dashcubic_spline(struct pair, struct pair, struct pair, struct pair);
void dotcubic_spline(struct pair, struct pair, struct pair, struct pair);
void boldcubic_spline(struct pair, struct pair, struct pair, struct pair);

/* Knot diagram primitives */
void comment_twist(char *, struct pair, struct pair);
void draw_p_twist(struct pair, struct pair, const int);
void draw_n_twist(struct pair, struct pair, const int);
void p_twist(struct pair, struct pair);
void boldp_twist(struct pair, struct pair);
void n_twist(struct pair, struct pair);
void boldn_twist(struct pair, struct pair);
void twists(struct pair, struct pair, int);
void boldtwists(struct pair, struct pair, int);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *          Plots of user-specified functions -- plots.c         *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Adaptive plotting */
void draw_adapt_plot(double f1(double), double f2(double),
		     double, double, int, const int);
void adplot(double f(double), double, double, int);
void dashadplot(double f(double), double, double, int);
void dotadplot(double f(double), double, double, int);
void boldadplot(double f(double), double, double, int);


/* Graph y=f(t), bounds on t, and number of points to plot. */
void comment_plot(char *);
void draw_plot(double (*f)(double), double, double, int, const int);

void plot(double (*f)(double), double, double, int);
void dashplot(double (*f)(double), double, double, int);
void dotplot(double (*f)(double), double, double, int);
void boldplot(double (*f)(double), double, double, int);

/* Parametric plot [x(t), y(t)] */
void draw_paramplot(double (*x)(double), double (*y)(double), \
	       double, double, int, const int);
void paramplot(double (*x)(double), double (*y)(double), \
	       double, double, int);
void dashparamplot(double (*x)(double), double (*y)(double), \
	       double, double, int);
void dotparamplot(double (*x)(double), double (*y)(double), \
	       double, double, int);
void boldparamplot(double (*x)(double), double (*y)(double), \
	       double, double, int);

/* Polar plot r=r(t) */
void draw_polarplot(double (*r)(double), double, double, int, const int);
void polarplot(double (*r)(double), double, double, int);
void dashpolarplot(double (*r)(double), double, double, int);
void dotpolarplot(double (*r)(double), double, double, int);
void boldpolarplot(double (*r)(double), double, double, int);

/* Truncated plotting */
struct pair edge_seek(double, double f(double), double);
void draw_clipplot(double (*f)(double), double, double, int, const int);
void clipplot(double (*f)(double), double, double, int);
void dashclipplot(double (*f)(double), double, double, int);
void dotclipplot(double (*f)(double), double, double, int);
void boldclipplot(double (*f)(double), double, double, int);

/* Data plotting from file */
void marker(struct pair, const int);
void data_plot(const char *, const int);

/* Derivatives and integrals */

// double deriv(double f(double), double, double);
void draw_deriv(double f(double), double, double, int, const int);

void plot_deriv(double f(double t), double, double, int);
void dashplot_deriv(double f(double t), double, double, int);
void dotplot_deriv(double f(double t), double, double, int);
void boldplot_deriv(double f(double t), double, double, int);

void tan_field(double f1(double), double f2(double), double, double, double);
void boldtan_field(double f1(double), double f2(double), double, double, double);

// double integrand(double f(double), double, double);
void draw_int(double f(double), double, double, int, const int);

void plot_int(double f(double), double, double, int);
void dashplot_int(double f(double), double, double, int);
void dotplot_int(double f(double), double, double, int);
void boldplot_int(double f(double), double, double, int);

/* Slope, dart, and vector fields */
void draw_slope_field(double f1(double, double), double f2(double, double),
		      struct pair, struct pair, int, int);
void slope_field(double f1(double, double), double f2(double, double),
		      struct pair, struct pair, int, int);
void boldslope_field(double f1(double, double), double f2(double, double),
		      struct pair, struct pair, int, int);

void draw_dart_field(double f1(double, double), double f2(double, double),
		     struct pair, struct pair, int, int);
void dart_field(double f1(double, double), double f2(double, double),
		struct pair, struct pair, int, int);
void bolddart_field(double f1(double, double), double f2(double, double),
		    struct pair, struct pair, int, int);

void draw_vector_field(double f1(double, double), double f2(double, double),
		       struct pair, struct pair, int, int, const int);
void vector_field(double f1(double, double), double f2(double, double),
		       struct pair, struct pair, int, int);
void boldvector_field(double f1(double, double), double f2(double, double),
		       struct pair, struct pair, int, int);

/* ODE plotting */
void draw_ode_plot(double f1(double, double), double f2(double, double),
		   struct pair, double, int, const int);
void ode_plot(double f1(double, double), double f2(double, double),
	      struct pair, double, int);
void dashode_plot(double f1(double, double), double f2(double, double),
		  struct pair, double, int);
void dotode_plot(double f1(double, double), double f2(double, double),
		 struct pair, double, int);
void boldode_plot(double f1(double, double), double f2(double, double),
		  struct pair, double, int);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                         functions.c                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

double id(double);
double sinx(double);
double sgn(double);
double recip(double);
double cb(double);

int abs(int);
int gcd(int, int);

double inf(double f(double), double, double);
double sup(double f(double), double, double);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                          arcana.c                             *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Implementation of the momentum construction */
void draw_profile(double f(double), double, double, int, const int);
void plot_profile(double f(double), double, double, int);

#endif /* EPIX */
