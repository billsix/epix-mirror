/*
 * functions.h
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.7.x
 * Last Change: May 29, 2002
 *
 */

#ifndef _EPIX_FUNCTIONS
#define _EPIX_FUNCTIONS

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                         functions.c                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

double
id (double);

double
proj1 (double, double);

double
proj2 (double, double);

double
sinx (double);

double
sgn (double);

double
recip (double);

double
cb (double);

int 
abs (int);

int 
gcd (int, int);

double
inf (double f(double), double, double);

double
sup (double f(double), double, double);

#endif /* _EPIX_FUNCTIONS */
