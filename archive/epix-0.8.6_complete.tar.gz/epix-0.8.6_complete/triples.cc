/* 
 * triples.cc -- Ordered triples and operations
 *
 * Andrew D. Hwang                      <ahwang@mathcs.holycross.edu>
 *
 * Version: 0.8.6rc6
 * Last Change: July 28, 2002
 */

#define _EPIX_COMPILE

#include "triples.h"

extern double viewpt1, viewpt2, viewpt3;

/* Member functions */

// constructor
triple::triple(double init1, double init2, double init3)
{
  x1 = init1;
  x2 = init2;
  x3 = init3;
}

// copy
triple::triple(const triple& old)
{
  x1 = old.x1;
  x2 = old.x2;
  x3 = old.x3;
}

// increment operators
triple& triple::operator += (const triple& oper)
{
  x1 += oper.x1;
  x2 += oper.x2;
  x3 += oper.x3;
  
  return (*this);
}

triple& triple::operator -= (const triple& oper)
{
  x1 -= oper.x1;
  x2 -= oper.x2;
  x3 -= oper.x3;
  
  return (*this);
}

triple& triple::operator *= (const double& c)
{
  x1 *= c;
  x2 *= c;
  x3 *= c;
  
  return (*this);
}

/* triple creation */

triple P(double x1, double x2, double x3)
{
  return triple(x1, x2, x3);
} 

// equality
int operator == (const triple& u, const triple& v)
{
  return ((u.x1 == v.x1) && (u.x2 == v.x2) && (u.x3 == v.x3) );
}

// negation
triple operator - (const triple& u)
{
  return P(-u.x1, -u.x2, -u.x3);
}
  
// addition
triple operator + (const triple& u, const triple& v)
{
  return P(u.x1 + v.x1, u.x2 + v.x2, u.x3 + v.x3);
}

triple operator - (const triple& u, const triple& v)
{
  return P(u.x1 - v.x1, u.x2 - v.x2, u.x3 - v.x3);
}

// cross product
triple operator * (const triple& u, const triple& v)
{
  return P(u.x2 * v.x3 - u.x3 * v.x2,
	   u.x3 * v.x1 - u.x1 * v.x3,
	   u.x1 * v.x2 - u.x2 * v.x1);
}

// scalar multiplication
triple operator * (const double& c, const triple& v)
{
  return P(c*(v.x1), c*(v.x2), c*(v.x3));
}

// dot product
double operator | (const triple& u, const triple& v)
{
  return u.x1*v.x1 + u.x2*v.x2 + u.x3*v.x3;
}

// componentwise product (a,b,c)&(x,y,z)=(ax,by,cz)
triple operator & (const triple& u, const triple& v)
{
  return P(u.x1*v.x1, u.x2*v.x2, u.x3*v.x3);
}

/* 
   rotate a triple by <angle> degrees about a coordinate axis
   triple rot1(const double& angle, const triple& v)
   {  
   double c = cos(M_PI*angle/180);
   double s = sin(M_PI*angle/180);
   return P(v.x1, c*v.x2 - s*v.x3, s*v.x2 + c*v.x3);
   }
   triple rot2(const double& angle, const triple& v)
   {
   double c = cos(M_PI*angle/180);
   double s = sin(M_PI*angle/180);
   return P(c*v.x3 - s*v.x1, v.x2, s*v.x3 + c*v.x1);
   }
   triple rot3(const double& angle, const triple& v)
   {
   double c = cos(M_PI*angle/180);
   double s = sin(M_PI*angle/180);
   return P(c*v.x1 - s*v.x2, s*v.x1 + c*v.x2, v.x3);
   }
*/
/* rotate <viewpt> by <angle> degrees about a coordinate axis */
void rot1(const double& angle)
{  
  double c = cos(M_PI*angle/180);
  double s = sin(M_PI*angle/180);
  viewpt2 = c*viewpt2 - s*viewpt3;
  viewpt3 = c*viewpt3 + s*viewpt2;
}

void rot2(const double& angle)
{
  double c = cos(M_PI*angle/180);
  double s = sin(M_PI*angle/180);
  viewpt1 = c*viewpt3 - s*viewpt1;
  viewpt3 = c*viewpt1 + s*viewpt3;
}

void rot3(const double& angle)
{
  double c = cos(M_PI*angle/180);
  double s = sin(M_PI*angle/180);
  viewpt1 = c*viewpt1 - s*viewpt2;
  viewpt2 = c*viewpt2 + s*viewpt1;
}

