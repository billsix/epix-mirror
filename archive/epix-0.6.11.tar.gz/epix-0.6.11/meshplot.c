/* 
 * meshplot.c -- Rudimentary mesh plotting, not suitable for "production"
 *
 * Andrew D. Hwang                      <ahwang@mathcs.holycross.edu>
 *
 * Version: 0.6.8
 * Last Change: February 2, 2002 (March 5)
 */

#include "epix.h"

static void 
quad(struct pair, struct pair, struct pair, struct pair);

/* Basic mesh unit is a white-filled quadrilateral */
static void 
quad(struct pair p1, struct pair p2, struct pair p3, struct pair p4)
{
  fprintf (stdout, "\n\\whiten\\path(%g,%g)(%g,%g)(%g,%g)(%g,%g)(%g,%g)",
	   h_scale(p1.x1),v_scale(p1.x2),
	   h_scale(p2.x1),v_scale(p2.x2),
	   h_scale(p3.x1),v_scale(p3.x2),
	   h_scale(p4.x1),v_scale(p4.x2),
	   h_scale(p1.x1),v_scale(p1.x2));
}

/* 
 * Draw quads from back to front, utilizing PostScript layering
 * of superimposed objects to hide lines.
 */
void 
meshplot(double f(double u, double v), struct pair p1, struct pair p2,
	 int u_num, int v_num)
{
  int i=0, j=0;
  double u, v;
  double u_min=p1.x1;
  double u_max=p2.x1;
  double v_min=p1.x2;
  double v_max=p2.x2;

  double du = (u_max - u_min)/u_num;
  double dv = (v_max - v_min)/v_num;

  fprintf (stdout, "\n%%%% meshplot:");
  
  for (i=0; i< u_num; ++i)
    {
      for (j=0; j< v_num; ++j)
	{
	  u = u_min + i*du;
	  v = v_min + j*dv;
	  quad(V(u, v, f(u, v)), V(u+du, v, f(u+du, v)),
	       V(u+du, v+dv, f(u+du, v+dv)), V(u, v+dv, f(u, v+dv)));
	}
    }
  end_stanza();
}

