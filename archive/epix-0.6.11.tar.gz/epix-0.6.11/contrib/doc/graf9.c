#include <epix/epix.h>
#include <epix/epix_ext.h>

main() 
{
  bounding_box(P(-4,-3),P(4,2)); // [-4,4] x [-3,2]
  picture(P(12, 7.5));           // picture is 12 x 7.5 units

  unitlength("5mm");

  /* Start picture */
  begin();

  /* hatched polygon */
  hatch_polygon(45, 0.2, 6, P(-2,-3),P(-3,1),P(1,0),P(2,3),P(4,-2),P(-1,-1));

  /* End picture */
  end();
}
