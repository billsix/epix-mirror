#include <epix/epix.h>
#include <epix/epix_ext.h>

double f(double x)
{
  return 4.5-(x-3)*(x-3)/2;
}

main() 
{
  struct CartesianStyle cs;

  bounding_box(P(-1,-2), P(7,6)); // [-1,7] x [-2,6]
  picture(P(12,12));              // picture is 12 x 12 units
  unitlength("5mm");

  /* Begin picture */
  begin();

  /* Coordinate system */
  initCartesianStruct(&cs);
  cs.ylabpos = LEFT;
  cartesianCoord(cs);

  /* Graphs */
  hatch_area(150,0.2,f,sin,0,5.5,100);

  /* End picture */
  end();
}
