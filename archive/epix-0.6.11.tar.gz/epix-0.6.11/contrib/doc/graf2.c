#include <epix/epix.h>
#include <epix/epix_ext.h>

main() 
{
  struct CartesianStyle cs;

  bounding_box(P(-3,-2), P(5,6));
  picture(P(12, 12));

  unitlength("5mm");

  begin();

  initCartesianStruct(&cs);
  cs.xn = 6;
  cs.x1 = -2;
  cs.yn = 6;
  cs.y1 = -1;
  cartesianCoord(cs);

  end();
}

