#include <epix/epix.h>
#include <epix/epix_ext.h>

static char* ylabels[] =
  {"22","23","24","25",NULL};

main() 
{
  struct CartesianStyle cs;

  bounding_box(P(-1,19), P(7,27));
  picture(P(12, 12));

  unitlength("5mm");

  begin();

  initCartesianStruct(&cs);
  cs.y0= 20;
  cs.xn = 6;
  cs.yn = 5;
  cs.y1 = 22;
  cs.ylabels = ylabels;
  cs.ybroken = 1;
  cartesianCoord(cs);

  end();
}



