/* slopefield.c -- March 29, 2002
 *
 * Slope field and ode plotting
 */

#include <epix.h>

double f1(double s, double t)
{
  return 0.1*s - t/(0.01+s*s+t*t);
}
double f2(double s, double t)
{
  return 0.025*t + s/(0.01+s*s+t*t);
}

main() {
  int i=0;

  unitlength("1pt");
  bounding_box(P(-2, -2), P(4,3));
  picture(P(234, 195));
  offset(P(100, -30));

  begin();

  dart_field(f1, f2, P(x_min, y_min), P(x_max, y_max), 4*x_size, 4*y_size);

  magenta();
  boldode_plot(f1, f2, P(0.9,0), 20, 200);
  end_magenta();

  blue();
  boldode_plot(f1, f2, P(0.95,0), 20, 200);
  end_blue();

  green();
  boldode_plot(f1, f2, P(0.975,0), 20, 200);
  end_green();

  red();
  boldode_plot(f1, f2, P(1,0), 20, 200);
  end_red();

  end();
}

