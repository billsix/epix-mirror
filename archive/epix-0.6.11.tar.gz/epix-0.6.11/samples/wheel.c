/* 
 * wheel.c -- Animation frames (rolling wheel)
 *
 * March 29, 2002
 */

#include <epix.h>

double f1(double t, double r)
{
  return t - r*sin(t);
}
double f2(double t, double r)
{
  return -r*cos(t);
}

double r1=2.0/3.0;
double r2=1.0/3.0;

main() 
{
  int i;
  double dt = 5*M_PI/11;
  double t = 0;

  picture(P(420, 120));
  bounding_box(P(0,-1), P(7,1));
  unitlength("0.005in");
  offset(P(-120,0));

  for(i=0; i < 9; ++i)
    {
      t += dt;
      begin(); // Entire picture inside loop body

      line(P(x_min - 2, y_min), P(x_max + 6, y_min)); // the ground
      
      ellipse(P(t,0), P(1,1)); // the wheel
      
      dot(P(f1(t,  1), f2(t,  1))); // the points
      dot(P(f1(t, r1), f2(t, r1)));
      dot(P(f1(t, r2), f2(t, r2)));
      
      /* the paths they trace */
      bold();
      red();
      sliceplot2(f1, f2, 0, t, 1, (int) ceil(1+10*t));
      end_red();
      
      magenta();
      sliceplot2(f1, f2, 0, t, r1, (int) ceil(1+10*t));
      end_magenta();

      blue();
      sliceplot2(f1, f2, 0, t, r2, (int) ceil(1+10*t));
      end_blue();

      cyan();
      line(P(0,0), P(t,0));
      end_cyan();

      /* and the spoke */
      green();
      line(P(t,0), P(f1(t,1), f2(t,1)));
      end_green();
      end_bold();

      end();
    
      /* figure separator and vertical space */
      printf("\n\\vspace*{3ex}\n%%%%");
    }
}

