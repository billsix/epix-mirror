/* multiplot.c, March 28, 2002
 *
 * Plotting curve families
 */

#include "../epix.h"

double f1(double s, double t)
{
  return exp(M_PI_2*t)*cos(M_PI_2*(s+t));
}
double f2(double s, double t)
{
  return exp(M_PI_2*t)*sin(M_PI_2*(s+t));
}

double g1(double s, double t)
{
  return exp(M_PI_2*t)*cos(M_PI_2*(s+t));
}
double g2(double s, double t)
{
  return -exp(M_PI_2*t)*sin(M_PI_2*(s+t));
}

main() 
{
  unitlength("1pt");
  bounding_box(P(-3,-3), P(3,3));
  picture(P(300,300));

  begin();

  red();
  boldmultiplot1(f1, f2, P(0,-2), P(4,1), Net(12,12), 60);
  end_red();

  blue();
  boldmultiplot1(g1, g2, P(0,-2), P(4,1), Net(12,12), 60);
  end_blue();

  end();
}

