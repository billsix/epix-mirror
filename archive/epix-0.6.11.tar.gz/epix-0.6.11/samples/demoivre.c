/* demoivre.c -- July 22, 2001 */

#include <epix.h>

main()
{
  int i, n=24;
  struct pair pow={1,0};
  struct pair z = {1.0, M_PI/n};

  bounding_box(P(-1.5,0), P(1,1.25));
  picture(P(200,100));
  unitlength("1pt");
  offset(P(75,0));

  begin();
  
  for(i=0; i<n; ++i)
    {
      line(P(0,0), mult_pair(z, pow));
      line(pow, mult_pair(z, pow));

      pow=mult_pair(z, pow);
    }
  red();
  triangle(P(0, 0), P(1, 0), P(1, z.x2));
  end_red();
  label(P(1, z.x2), P(2, -4), "$\\alpha=1+\\frac{i\\pi}{n}$");

  label(pow, P(-14,-4), "$\\alpha^n$");

  end();
}

