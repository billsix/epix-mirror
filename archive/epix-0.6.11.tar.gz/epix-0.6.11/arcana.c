/* 
 * arcana.c
 *
 * Functions not likely to be of general interest:
 *   plot_profile -- Implementation of the momentum construction
 *   std_F -- Routine for visualizing linear maps of the plane
 *
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.6.10
 * Last Change: March 23, 2002
 */

#include "epix.h"

/* 
 * Number of iterations per point printed; also used to determine
 * increment in Newton quotient.
 */
#define ITERATIONS 1000 

static double dt;

extern double x_min, x_max, y_min, y_max;
extern double h_size, v_size;

/* Difference quotient of f at t */
static double 
deriv(double f(double), double t, double dt)
{
  return (f(t + 0.5*dt) - f(t - 0.5*dt))/dt;
}

/* Convert a momentum profile to a geometric profile */

void 
draw_profile(double f(double), double a, double b, 
		  int num_pts, const int path_style)
{
  double x=x_min;
  double t=a;
  int i=0, pt_count=0;

  dt = (b-a)/(num_pts*ITERATIONS);

  start_path(path_style);
  fprintf(stdout, "(%g,%g)", h_scale(x), v_scale(sqrt((*f)(t))) );
  ++pt_count;
  t += 0.5*dt;
  x += dt*sqrt((4-deriv(f, t, dt)*deriv(f, t, dt))/(4*f(t)));

  while (0 <= f(t) && f(t) <= y_max && x <= x_max
	 && fabs(deriv(f, t, dt)) <= 2 && pt_count <= num_pts)
    {
      if ( i%ITERATIONS == 0 )
	{
	  fprintf(stdout, "(%g,%g)", h_scale(x), v_scale(sqrt(f(t))) );
	  ++pt_count;
	  line_break(pt_count, num_pts, path_style);
	}

      x += dt*sqrt((4-deriv(f, t, dt)*deriv(f, t, dt))/(4*f(t)));
      t += dt;
      ++i;
    }
  
  /* Next point printed is slightly wrong; x incremented, t not */
  fprintf(stdout, "(%g,%g)", h_scale(x), v_scale(sqrt(f(t - dt))) );
}

void 
plot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("plot_profile");
  draw_profile(f, a, b, num_pts, PLAIN);
  end_stanza();
}

void 
dashplot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("dashplot_profile");
  draw_profile(f, a, b, num_pts, DASHED);
  end_stanza();
}

void 
dotplot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("dotplot_profile");
  draw_profile(f, a, b, num_pts, DOTTED);
  end_stanza();
}

void 
boldplot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("boldplot_profile");
  bold();
  draw_profile(f, a, b, num_pts, BOLD);
  endbold();
  end_stanza();
}

/* Plane linear transformations */

// 2x2 matrix multiplication [a1 a2][in] = [out]
struct pair 
transf(struct pair a1, struct pair a2, struct pair in)
{
  struct pair out;

  out.x1 = a1.x1*in.x1 + a2.x1*in.x2;
  out.x2 = a1.x2*in.x1 + a2.x2*in.x2;

  return out;
}

struct pair 
reflect(double theta, struct pair in)
{
  double a = cos(2*theta);
  double b = sin(2*theta);
  struct pair out;

  /*
   * Columns of reflection matrix are P(a,b), P(b,-a)
   */
  out=transf(P(a,b), P(b,-a), in);

  return out; 
}

void 
std_F(struct pair a1, struct pair a2)
{
  struct pair p1, p2, p3, p4, p5, p6, p7, p8, p9, p10;
  struct pair q1, q2, q3, q4, q5, q6, q7, q8, q9, q10;
  struct pair c1, c2, c3, c4;

  double r=1.0/6.0;

  // Vertices of standard F
  p1 = P(r,   0.75*r);
  p2 = P(2*r, 0.75*r);
  p3 = P(2*r, 2.25*r);
  p4 = P(4*r, 2.25*r);
  p5 = P(4*r, 3.25*r);
  p6 = P(2*r, 3.25*r);
  p7 = P(2*r, 4.25*r);
  p8 = P(5*r, 4.25*r);
  p9 = P(5*r, 5.25*r);
  p10= P(r,   5.25*r);

  // Vertices of transformed F
  q1 = transf(a1, a2, p1);
  q2 = transf(a1, a2, p2);
  q3 = transf(a1, a2, p3);
  q4 = transf(a1, a2, p4);
  q5 = transf(a1, a2, p5);
  q6 = transf(a1, a2, p6);
  q7 = transf(a1, a2, p7);
  q8 = transf(a1, a2, p8);
  q9 = transf(a1, a2, p9);
  q10= transf(a1, a2, p10);

  // Vertices of parallelogram
  c1 = transf(a1, a2, P(0,0));
  c2 = transf(a1, a2, P(1,0));
  c3 = transf(a1, a2, P(1,1));
  c4 = transf(a1, a2, P(0,1));

  fprintf (stdout, "\n%%%% Standard F: (%g,%g), (%g,%g)", 
	   a1.x1, a1.x2, a2.x1, a2.x2);
  fprintf (stdout, "\n%%%%");

  // Boundary of parallelogram
  fprintf (stdout, "\n\\path(%g,%g)(%g,%g)(%g,%g)(%g,%g)(%g,%g)",
	   h_scale(c1.x1), v_scale(c1.x2),
	   h_scale(c2.x1), v_scale(c2.x2),
	   h_scale(c3.x1), v_scale(c3.x2),
	   h_scale(c4.x1), v_scale(c4.x2),
	   h_scale(c1.x1), v_scale(c1.x2));

  dot(P(0,0));

  // The actual F
  fprintf (stdout, "\n\\blacken\\path");
  fprintf (stdout, "(%g,%g)(%g,%g)(%g,%g)\n  (%g,%g)(%g,%g)(%g,%g)(%g,%g)\n  (%g,%g)(%g,%g)(%g,%g)(%g,%g)",
	   h_scale(q1.x1), v_scale(q1.x2), h_scale(q2.x1), v_scale(q2.x2),
	   h_scale(q3.x1), v_scale(q3.x2), h_scale(q4.x1), v_scale(q4.x2),
	   h_scale(q5.x1), v_scale(q5.x2), h_scale(q6.x1), v_scale(q6.x2),
	   h_scale(q7.x1), v_scale(q7.x2), h_scale(q8.x1), v_scale(q8.x2),
	   h_scale(q9.x1), v_scale(q9.x2), h_scale(q10.x1), v_scale(q10.x2),
	   h_scale(q1.x1), v_scale(q1.x2));

  end_stanza();
}
