/*
 * plots.c: Plots and parametric plots of user-defined functions
 *
 * Includes functions for plotting derivatives and integrals.  The
 * algorithms are simple-minded: finite difference centered at t for
 * derivatives, the trapezoid method for integrals, Euler's method for
 * solutions of ODEs.
 *
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.5
 * Last Change: July 6, 2002
 */

#define _EPIX_COMPILE
#include "plots.h"
#include "objects.h"

/* 
 * Increment for Newton quotient, integral; must be defined in
 * each function that uses it, usually in terms of the picture
 * size, e.g.,  dh = (x_max - x_min)/(num_pts*ITERATIONS)
 */
static double dt; 

extern int lines_printed; // Counter for controlling output length

void
comment_plot(char *type)
{
  fprintf(stdout, "\n%%%% %s:", type);  
}

/* Functions for adaptive plotting */

/* Classical Newtonian increment */
static double delta(double f(double), double t, double dt)
{
  return f(t + dt) - f(t);
}

static double arclength(double f1(double), double f2(double),
			double t_min, double t_max, int n)
{
  int i = 0;
  double sum = 0;
  double dt = (t_max - t_min)/(n*ITERATIONS);

  for (i=0; i < n*ITERATIONS; ++i)
    sum += hypot(delta(f1, t_min + i*dt, dt), delta(f2, t_min + i*dt, dt));

  return sum;
}

static pair 
plot_pt(double f1(double), double f2(double), double t)
{
  return pair(f1(t), f2(t));
}

/*  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *\
 *                      Adaptive plotting                          *
\*  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  */
void
draw_adapt_plot(double f1(double), double f2(double),
		double t_min, double t_max, int n, const int path_style)
{
  int i = 0;
  double sum = 0;
  int pt_count = 0;
  double dt = (t_max - t_min)/(n*ITERATIONS);
  double step = (1.0/n)*arclength(f1, f2, t_min, t_max, n);
  int step_count = 0;

  start_path(path_style); // pt_count already = 1
  print(plot_pt(f1, f2, t_min));

  for (i=0; i <= n*ITERATIONS; ++i)
    {
      sum += hypot(delta(f1, t_min + i*dt, dt), delta(f2, t_min + i*dt, dt));
      ++step_count;

      if (step <= sum || ITERATIONS <= step_count) 
	{
	  line_break(pt_count++, n*ITERATIONS, path_style);
	  print(plot_pt(f1, f2, t_min + i*dt));

	  sum -= step;
	  step_count = 0;
	}
    }
}
	
void
adplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("adplot");
  draw_adapt_plot(id, f, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void
dashadplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("dashadplot");
  draw_adapt_plot(id, f, t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void
dotadplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("dotadplot");
  draw_adapt_plot(id, f, t_min, t_max, num_pts, DOT);
  end_stanza();
}

void
boldadplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("boldadplot");
  bold;
  draw_adapt_plot(id, f, t_min, t_max, num_pts, BOLD);
  end_bold;
  end_stanza();
}

/*  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *\
 *                    Ordinary graph plotting                      *
\*  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  */
void
draw_plot(double f(double), double t_min, double t_max, 
	  int num_pts, const int path_style)
{
  int i;
  double t;

  start_path(path_style);
  for (i=0; i <= num_pts; ++i)
    {
      t = t_min + i*(t_max - t_min)/num_pts;
      print(plot_pt(id, f, t));

      line_break(i, num_pts, path_style);
    }
}

void
plot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("plot");
  draw_plot(f, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void
dashplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("dashplot");
  draw_plot(f, t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void
dotplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("dotplot");
  draw_plot(f, t_min, t_max, num_pts, DOTTED);
  end_stanza();
}

void
boldplot(double f(double), double t_min, double t_max, int num_pts)
{
  comment_plot("boldplot");

  bold;
  draw_plot(f, t_min, t_max, num_pts, BOLD);
  endbold;
  end_stanza();
}

/*  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *\
 *                 Planar parametric plotting                      *
\*  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  */

void
draw_plot(double f1(double), double f2(double),
	  double t_min, double t_max, int num_pts, const int path_style)
{
  int i;
  double t;

  start_path(path_style);
  for (i=0; i <= num_pts; ++i)
    {
      t = t_min + i*(t_max - t_min)/num_pts;
      print(plot_pt(f1, f2, t));

      line_break(i, num_pts, path_style);
    }
}

void
plot(double f1(double), double f2(double), 
     double t_min, double t_max, int num_pts)
{
  comment_plot("plot");
  draw_plot(f1, f2, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void
dashplot(double f1(double), double f2(double),
	 double t_min, double t_max, int num_pts)
{
  comment_plot("dashplot");
  draw_plot(f1, f2, t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void
dotplot(double f1(double), double f2(double),
	double t_min, double t_max, int num_pts)
{
  comment_plot("dotplot");
  draw_plot(f1, f2, t_min, t_max, num_pts, DOTTED);
  end_stanza();
}

void
boldplot(double f1(double), double f2(double),
	 double t_min, double t_max, int num_pts)
{
  comment_plot("boldplot");
  bold;
  draw_plot(f1, f2, t_min, t_max, num_pts, BOLD);
  endbold;
  end_stanza();
}

/*  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *\
 *                    Space curve plotting                         *
\*  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  *  */

void
draw_plot(double u1(double), double u2(double), double u3(double),
	  double t_min, double t_max, int num_pts, const int path_style)
{
  double a1 = viewpt1;
  double a2 = viewpt2;
  double len_sq = a1*a1 + a2*a2;

  double t;
  double dt = (t_max - t_min)/num_pts;

  if (truncate (len_sq) == 0)
    {
      fprintf (stdout, "\n%%%% plot3d: Vertical projection vector");
      draw_plot(u1, u2, t_min, t_max, num_pts, path_style);
    }
  else
    {
      start_path(path_style);
      for (int i=0; i <= num_pts; ++i)
	{
	  t = t_min + i*dt;
	  print(V(u1(t), u2(t), u3(t)));

	  line_break(i, num_pts, path_style);
	}
    }
}
    
void
plot(double u1(double), double u2(double), double u3(double),
     double t_min, double t_max, int num_pts)
{
  comment_plot("plot3d");
  draw_plot(u1, u2, u3, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void
dashplot(double u1(double), double u2(double), double u3(double),
	 double t_min, double t_max, int num_pts)
{
  comment_plot("dashplot3d");
  draw_plot(u1, u2, u3, t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void
dotplot(double u1(double), double u2(double), double u3(double),
	double t_min, double t_max, int num_pts)
{
  comment_plot("dotplot3d");
  draw_plot(u1, u2, u3, t_min, t_max, num_pts, DOTTED);
  end_stanza();
}

void
boldplot(double u1(double), double u2(double), double u3(double),
	 double t_min, double t_max, int num_pts)
{
  comment_plot("boldplot3d");
  bold;
  draw_plot(u1, u2, u3, t_min, t_max, num_pts, BOLD);
  end_bold;
  end_stanza();
}

/*
 * Angles measured in revolutions (2\pi radians)
 */

void
draw_polarplot(double r(double), double t_min,
	       double t_max, int num_pts, const int path_style)
{
  double t;
  double dt = 2*M_PI*(t_max - t_min)/num_pts;
  double t0 = 2*M_PI*t_min;

  start_path(path_style);
  for (int i=0; i <= num_pts; ++i)
    {
      t = t0 + i*dt;
      print(polar(r(t), t));

      line_break(i, num_pts, path_style);
  }
}

void
polarplot(double r(double), double t_min, double t_max, int num_pts)
{
  comment_plot("polarplot");
  draw_polarplot(r, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void
dashpolarplot(double r(double), double t_min,
	      double t_max, int num_pts)
{
  comment_plot("dashpolarplot");
  draw_polarplot(r, t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void
dotpolarplot(double r(double), double t_min,
	     double t_max, int num_pts)
{
  comment_plot("dotpolarplot");
  draw_polarplot(r, t_min, t_max, num_pts, DOTTED);
  end_stanza();
}

void
boldpolarplot(double r(double), double t_min,
	      double t_max, int num_pts)
{
  comment_plot("boldpolarplot");
  bold;
  draw_polarplot(r, t_min, t_max, num_pts, BOLD);
  endbold;
  end_stanza();
}

/* 
 * plot one curve in a family:
 * sliceplot1: t -> [f1(s0,t), f2(s0,t)]
 * sliceplot2: s -> [f1(s,t0), f2(s,t0)]
 */
void
draw_sliceplot1(double f1(double, double), double f2(double, double), 
		double t_min, double t_max, double s0, int num_pts,
		const int path_style)
{
  double t;
  double dt = (t_max - t_min)/num_pts;

  start_path(path_style);
  for (int i=0; i <= num_pts; ++i)
    {
      t = t_min + i*dt;
      print(P(f1(s0,t), f2(s0,t)));

      line_break(i, num_pts, path_style);
    }
}

void
draw_sliceplot2(double f1(double, double), double f2(double, double), 
		double s_min, double s_max, double t0, int num_pts,
		const int path_style)
{
  double s;
  double ds = (s_max - s_min)/num_pts;

  start_path(path_style);
  for (int i=0; i <= num_pts; ++i)
    {
      s = s_min + i*ds;
      print(P(f1(s,t0), f2(s,t0)));

      line_break(i, num_pts, path_style);
    }
}

void
sliceplot1 (double f1(double, double), double f2(double, double), 
	    double t_min, double t_max, double s0, int num_pts)
{
  comment_plot("sliceplot1");
  draw_sliceplot1(f1, f2, t_min, t_max, s0, num_pts, PLAIN);
  end_stanza();
}
void
sliceplot2 (double f1(double, double), double f2(double, double), 
	    double s_min, double s_max, double t0, int num_pts)
{
  comment_plot("sliceplot2");
  draw_sliceplot2(f1, f2, s_min, s_max, t0, num_pts, PLAIN);
  end_stanza();
}

void
dashsliceplot1 (double f1(double, double), double f2(double, double), 
		double t_min, double t_max, double s0, int num_pts)
{
  comment_plot("dashsliceplot1");
  draw_sliceplot1(f1, f2, t_min, t_max, s0, num_pts, DASHED);
  end_stanza();
}
void
dashsliceplot2 (double f1(double, double), double f2(double, double), 
		double s_min, double s_max, double t0, int num_pts)
{
  comment_plot("dashsliceplot2");
  draw_sliceplot2(f1, f2, s_min, s_max, t0, num_pts, DASHED);
  end_stanza();
}

void
dotsliceplot1 (double f1(double, double), double f2(double, double), 
	       double t_min, double t_max, double s0, int num_pts)
{
  comment_plot("dotsliceplot1");
  draw_sliceplot1(f1, f2, t_min, t_max, s0, num_pts, DOTTED);
  end_stanza();
}
void
dotsliceplot2 (double f1(double, double), double f2(double, double), 
	       double s_min, double s_max, double t0, int num_pts)
{
  comment_plot("dotsliceplot2");
  draw_sliceplot2(f1, f2, s_min, s_max, t0, num_pts, DOTTED);
  end_stanza();
}

void
boldsliceplot1 (double f1(double, double), double f2(double, double), 
		double t_min, double t_max, double s0, int num_pts)
{
  comment_plot("boldsliceplot1");
  bold;
  draw_sliceplot1(f1, f2, t_min, t_max, s0, num_pts, BOLD);
  end_bold;
  end_stanza();
}
void
boldsliceplot2 (double f1(double, double), double f2(double, double), 
		double s_min, double s_max, double t0, int num_pts)
{
  comment_plot("boldsliceplot2");
  bold;
  draw_sliceplot2(f1, f2, s_min, s_max, t0, num_pts, BOLD);
  end_bold;
  end_stanza();
}

static void
draw_multiplot1 (double f1(double, double), double f2(double, double), 
		 pair lowleft, pair upright, struct mesh netsize,
		 int num_pts, const int path_style)
{
  int i, N1 = netsize.n1;
  double s;

  double s_min=lowleft.x1;
  double s_max=upright.x1;
  double ds = (s_max - s_min)/N1;

  double t_min=lowleft.x2;
  double t_max=upright.x2;
  
  comment_plot("multiplot1");
  if (path_style == BOLD)
    bold;

  for (i=0; i <= N1; ++i)
    {
      s = s_min + i*ds;
      draw_sliceplot1(f1, f2, t_min, t_max, s, num_pts, path_style);
      if (i < N1)
	fprintf (stdout, "\n%%%%");
    }
  if (path_style == BOLD)
    end_bold;

  end_stanza();
}
static void
draw_multiplot2 (double f1(double, double), double f2(double, double), 
		 pair lowleft, pair upright, struct mesh netsize,
		 int num_pts, const int path_style)
{
  int i, N2 = netsize.n2;
  double t;

  double s_min=lowleft.x1;
  double s_max=upright.x1;
  double t_min=lowleft.x2;
  double t_max=upright.x2;
  double dt = (t_max - t_min)/N2;

  comment_plot("multiplot2");
  if (path_style == BOLD)
    bold;

  for (i=0; i <= N2; ++i)
    {
      t = t_min + i*dt;
      draw_sliceplot2(f1, f2, s_min, s_max, t, num_pts, path_style);
      if (i < N2)
	fprintf (stdout, "\n%%%%");
    }
  if (path_style == BOLD)
    end_bold;

  end_stanza();
}

void
multiplot1 (double f1(double, double), double f2(double, double), 
	    pair lowleft, pair upright, struct mesh netsize,
	    int num_pts)
{
  draw_multiplot1 (f1, f2, lowleft, upright, netsize, num_pts, PLAIN);
}
void
multiplot2 (double f1(double, double), double f2(double, double), 
	    pair lowleft, pair upright, struct mesh netsize,
	    int num_pts)
{
  draw_multiplot2 (f1, f2, lowleft, upright, netsize, num_pts, PLAIN);
}

void
dashmultiplot1 (double f1(double, double), double f2(double, double), 
		pair lowleft, pair upright, struct mesh netsize,
		int num_pts)
{
  draw_multiplot1 (f1, f2, lowleft, upright, netsize, num_pts, DASHED);
}
void
dashmultiplot2 (double f1(double, double), double f2(double, double), 
		pair lowleft, pair upright, struct mesh netsize,
		int num_pts)
{
  draw_multiplot2 (f1, f2, lowleft, upright, netsize, num_pts, DASHED);
}

void
dotmultiplot1 (double f1(double, double), double f2(double, double), 
	       pair lowleft, pair upright, struct mesh netsize,
	       int num_pts)
{
  draw_multiplot1 (f1, f2, lowleft, upright, netsize, num_pts, DOTTED);
}
void
dotmultiplot2 (double f1(double, double), double f2(double, double), 
	       pair lowleft, pair upright, struct mesh netsize,
	       int num_pts)
{
  draw_multiplot2 (f1, f2, lowleft, upright, netsize, num_pts, DOTTED);
}

void
boldmultiplot1 (double f1(double, double), double f2(double, double), 
		pair lowleft, pair upright, struct mesh netsize,
		int num_pts)
{
  draw_multiplot1 (f1, f2, lowleft, upright, netsize, num_pts, BOLD);
}
void
boldmultiplot2 (double f1(double, double), double f2(double, double), 
		pair lowleft, pair upright, struct mesh netsize,
		int num_pts)
{
  draw_multiplot2 (f1, f2, lowleft, upright, netsize, num_pts, BOLD);
}


/* Plotting functions that truncate plots at bounding box */

/*
 * edge-seek
 *
 * Approximates point where plot goes outside global bounding box.
 * Algorithm: Start at point known to be inside, take small steps
 * towards outside point, stop when point goes outside.
 */
static
pair edge_seek(double f1(double), double f2(double), double f3(double),
	       double t, double step)
{
  pair temp = V(f1(t), f2(t), f3(t));

  while (x_min <= temp.x1 && temp.x1 <= x_max && 
	 y_min <= temp.x2 && temp.x2 <= y_max)
    {
      t += (SEEK_SIZE)*step; 
      temp = V(f1(t), f2(t), f3(t));
    }

  return temp; // pair(f1(t), f2(t));
}

/* the zero function */
static double zero(double t)
{
  return 0;
}

/*
 * clipplot and its variants plot a curve by keeping track of the
 * state (in/out of bounding region) of pairs of adjacent points. The
 * <previous> point is initially outside the bounding region. 
 * Subsequently, if (previous, current) = 
 * (out, in)  --> Start new path segment (seek back to find edge)
 * (in, in)   --> Continue existing path
 * (in, out)  --> End current path segment (seek forward to find edge)
 * (out, out) --> Print nothing, test next point
 *
 * 
 */

void
draw_clipplot(double f1(double), double f2(double), double f3(double),
	      double t_min, double t_max, int num_pts, const int path_style)
{
  pair curr, prev;
  int current=1, previous=0; /* In/out of bounding box */
  int i;
  int pt_count=0; /* Points printed in path segment, to format output */
  int pr_flag=0; /* Whether any points have been printed */
  double t = 0;
  double step = (t_max - t_min)/num_pts;
  
  for (i=0; i <= num_pts; ++i)
    {
      t = t_min + i*step;
      curr = V(f1(t), f2(t), f3(t));

      if (x_min <= curr.x1 && curr.x1 <= x_max && \
	  y_min <= curr.x2 && curr.x2 <= y_max)
	current=1;
      else
	current=0;
      
      /*
       * Four cases: Previous is in/out, current is in/out.
       */
      
      /* Start new path component */
      if (current == 1 && previous == 0)
	{
	  if (t == t_min) // print first point
	    {
	      start_path(path_style);
	      print(curr);
	      pt_count = 1;
	    }
	  else // print 2 points: seek-back and current
	    {
	      if (pr_flag == 0)
		start_path(path_style);

	      else
		{
		  fprintf(stdout, "\n%%%%"); // New sub-stanza
		  start_path(path_style);
		}

	      /* Seek back to edge of bounding box */
	      print(edge_seek(f1, f2, f3, t, -step));
	      print(curr);
	      pt_count=2;
	    }
	  pr_flag=1;
	  previous=1;
	  prev=curr;
	}
      
      /* Continue path */
      else if (current == 1 && previous == 1)
	{
	  line_break(pt_count - 1, num_pts, path_style);
	  print(curr);
	  previous=1;
	  prev=curr;
	  
	  ++pt_count;
	}
      
      /* End current path */
      else if (current == 0 && previous == 1)
	{
	  line_break(pt_count - 1, num_pts, path_style);
	  /* 
	   * Magic number (0.01): Skip back 1+e path steps, then
	   * seek forward. Acceptably handles the case in which
	   * previous + seek_step is outside the bounding box.
	   */
	  print(edge_seek(f1, f2, f3, t - (1+(0.01)*SEEK_SIZE)*step, step));
	  previous=0;
	  prev=curr;
	  pt_count=0;
	}
      
      /* (current == 0 && previous == 0), keep searching... */
      else 
	{
	  previous=0;
	  prev=curr;
	}
    }
}

/* Ordinary plot of function of one variable */
void
clipplot(double f(double), double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% clipplot:");  
  draw_clipplot(id, f, zero, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}
void
dashclipplot(double f(double), double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% dashclipplot:");  
  draw_clipplot(id, f, zero, t_min, t_max, num_pts, DASHED);
  end_stanza();
}
void
dotclipplot(double f(double), double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% dotclipplot:");  
  draw_clipplot(id, f, zero, t_min, t_max, num_pts, DOTTED);
  end_stanza();
}
void
boldclipplot(double f(double), double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% boldclipplot:");  
  bold;
  draw_clipplot(id, f, zero, t_min, t_max, num_pts, BOLD);
  endbold;
  end_stanza();
}

/* Parametric plane curves */

void
clipplot(double f1(double), double f2(double), 
	 double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% clipplot:");  
  draw_clipplot(f1, f2, zero, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}

void
dashclipplot(double f1(double), double f2(double), 
	     double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% dashclipplot:");  
  draw_clipplot(f1, f2, zero, t_min, t_max, num_pts, DASHED);
  end_stanza();
}

void
dotclipplot(double f1(double), double f2(double), 
	    double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% dotclipplot:");  
  draw_clipplot(f1, f2, zero, t_min, t_max, num_pts, DOTTED);
  end_stanza();
}

void
boldclipplot(double f1(double), double f2(double), 
	     double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% boldclipplot:");  
  bold;
  draw_clipplot(f1, f2, zero, t_min, t_max, num_pts, BOLD);
  end_bold;
  end_stanza();
}

/* Parametric space curves */
void
clipplot(double f1(double), double f2(double), double f3(double),
	 double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% clipplot3d:");  
  draw_clipplot(f1, f2, f3, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}
void
dashclipplot(double f1(double), double f2(double), double f3(double),
	     double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% dashclipplot3d:");  
  draw_clipplot(f1, f2, f3, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}
void
dotclipplot(double f1(double), double f2(double), double f3(double),
	    double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% dotclipplot3d:");  
  draw_clipplot(f1, f2, f3, t_min, t_max, num_pts, PLAIN);
  end_stanza();
}
void
boldclipplot(double f1(double), double f2(double), double f3(double),
	     double t_min, double t_max, int num_pts)
{
  fprintf(stdout, "\n%%%% boldclipplot3d:");  
  bold;
  draw_clipplot(f1, f2, f3, t_min, t_max, num_pts, PLAIN);
  end_bold;
  end_stanza();
}

/* Data plotting from file */

/*
 * Input file consists of lines containing two double-precision
 * floating point numbers separated by whitespace. Lines starting
 * with '%' are discarded, as are lines not matching the format
 * string "%g %g \n".
 */
void
data_plot(const char *data, const int mark_type)
{
  double x, y;
  FILE *input;
  char line[FILE_WIDTH+1];
  int lineno = 0;
  int pt_count = 0; // Number of points printed in PATH
  int lines = 0;    // Printable lines found in data file

  input = fopen(data, "r");

  if (input != NULL) { // No error opening data file
    fprintf(stdout, "\n%%%% data_plot: File %s \n%%%%", data);

    if (mark_type == PATH)
      {
	// Count lines in input file for line breaking of output
	while (fgets(line, FILE_WIDTH, input) != NULL) {
	  if (line[0] == '%')
	    ;
	  else if (sscanf(line, "%lg %lg", &x, &y) == 2) 
	    ++lines;
	}
	rewind(input);

	start_path (PLAIN);
      }
    
    while (fgets(line, FILE_WIDTH, input) != NULL) {
      ++lineno;
      if (line[0] == '%') // '%' starts comment line
	;

      else if (sscanf(line, "%lg %lg", &x, &y) == 2) 
	{
	  marker(P(x, y), mark_type);
	  if (mark_type == PATH)
	    {
	      ++pt_count;
	      line_break(pt_count, lines, PLAIN);
	    }
	}

      else 
	{
	  fprintf(stdout, "\n%%%% Ignoring line %d of file %s", lineno, data);
	  ++lines_printed;
	}
    } // while()
    fclose(input);
  } // if()
  
  else 
    fprintf(stdout, "\n%%%% Couldn't open file %s", data);
  
  end_stanza();
}
  
/* Calculus plots: derivatives and definite integrals */

/* Difference quotient of f at t */
static double deriv(double f(double), double t, double dt)
{
  return (f(t + 0.5*dt) - f(t - 0.5*dt))/dt;
}

static double integrand(double f(double), double t, double dt)
{
  return (0.5)*(f(t) + f(t + dt))*dt; /* Trapezoid formula */
}

/* Print list of ordered pairs */
void
draw_deriv(double f(double), double a, double b, 
	   int num_pts, const int path_style)
{
  /*
   * Algorithm: Partition into intervals of length dt=(b-a)/N;
   *  Evaluate f'(t) for t=a, a+0.5*dt, ..., b-0.5*dt, b.
   */
  double t = a;
  int i=1;

  dt = (b-a)/(num_pts*ITERATIONS);

  start_path(path_style);

  /* f'(a) */
  print(P(t, delta(f, t, dt)/dt));
  //  fprintf(stdout, "(%g,%g)", h_scale(t), v_scale((f(t + dt) - f(t))/dt));
  t += 0.5*dt;

  for (i=1; i <= num_pts; ++i)
    {
      print(P(t, deriv(f, t, dt)));
      line_break(i, num_pts, path_style);
      t += dt*ITERATIONS;
    }
  /* f'(b) */
  t += 0.5*dt;
  print(P(t, deriv(f, t - 0.5*dt, dt)));
  //  fprintf(stdout, "(%g,%g)", h_scale(t), v_scale((f(t) - f(t - dt))/dt));
}

void
plot_deriv(double f(double t), double a, double b, int num_pts)
{
  comment_plot("plot_deriv");
  draw_deriv(f, a, b, num_pts, PLAIN);
  end_stanza();
}

void
dashplot_deriv(double f(double t), double a, double b, int num_pts)
{
  comment_plot("dashplot_deriv");
  draw_deriv(f, a, b, num_pts, DASHED);
  end_stanza();
}

void
dotplot_deriv(double f(double t), double a, double b, int num_pts)
{
  comment_plot("dotplot_deriv");
  draw_deriv(f, a, b, num_pts, DOTTED);
  end_stanza();
}

void
boldplot_deriv(double f(double t), double a, double b, int num_pts)
{
  comment_plot("boldplot_deriv");
  bold;
  draw_deriv(f, a, b, num_pts, BOLD);
  endbold;
  end_stanza();
}

/* Tangent field along parametrized path */
void
tan_field(double f1(double), double f2(double), double t_min, \
	       double t_max, double num_pts)
{
  double t=t_min;
  double dt=(t_max - t_min)/(num_pts*ITERATIONS);
  double delta_t=(t_max - t_min)/num_pts;
  int i;

  comment_plot("tan_field");

  for (i=0; i <= num_pts; ++i, t+=ITERATIONS*dt)
    {
      draw_arrow(plot_pt(f1, f2, t), plot_pt(f1, f2, t)
		 + delta_t * P(deriv(f1, t, dt), deriv(f2, t, dt)), PLAIN);
      //f1(t+dt/2)-f1(t-dt/2), f2(t+dt/2)-f2(t-dt/2)))),

      if (i < num_pts )
	fprintf(stdout, "\n%%%%");
    }
  end_stanza();
}

void
boldtan_field(double f1(double), double f2(double), double t_min, \
	       double t_max, double num_pts)
{
  double t=t_min;
  double dt=(t_max - t_min)/(num_pts*ITERATIONS);
  double delta_t=(t_max - t_min)/num_pts;
  int i;

  comment_plot("boldtan_field");

  for (i=0; i <= num_pts; ++i, t+=ITERATIONS*dt)
    {
      draw_boldarrow(plot_pt(f1, f2, t), 
	plot_pt(f1, f2, t) + delta_t*P(deriv(f1, t, dt), deriv(f2, t, dt)));

      /*
	draw_boldarrow(P(f1(t), f2(t)), // basepoint
	add_pair(P(f1(t), f2(t)), //basepoint
	// plus tangent vector
	mult_s(ITERATIONS, P(f1(t+dt/2)-f1(t-dt/2), \
	f2(t+dt/2)-f2(t-dt/2)))));
      */
      if (i < num_pts )
	fprintf(stdout, "\n%%%%");
    }
  end_stanza();
}

/* Print raw path */
void
draw_int(double f(double), double a, double b, 
	 int num_pts, const int path_style)
{
  /*
   * Integrand is 0.5*(f(t) + f(t+dt))*dt
   */
  double t = a, sum = 0; 
  int i, pt_count=0;
  dt = (b-a)/(num_pts*ITERATIONS);

  start_path(path_style);
  for (i=0; i <= num_pts*ITERATIONS; ++i)
    {
      if (i%ITERATIONS == 0)
	{
	  print(pair(t, sum));
	  ++pt_count;
	  line_break(pt_count, num_pts, path_style);
	}
      sum += integrand(f, t, dt);
      t += dt;
    }
}

void
plot_int(double f(double), double a, double b, int num_pts)
{
  comment_plot("plot_int");
  draw_int(f, a, b, num_pts, PLAIN);
  end_stanza();
}

void
dashplot_int(double f(double), double a, double b, int num_pts)
{
  comment_plot("dashplot_int");
  draw_int(f, a, b, num_pts, DASHED);
  end_stanza();
}

void
dotplot_int(double f(double), double a, double b, int num_pts)
{
  comment_plot("dotplot_int");
  draw_int(f, a, b, num_pts, DOTTED);
  end_stanza();
}

void
boldplot_int(double f(double), double a, double b, int num_pts)
{
  comment_plot("plot_int");
  bold;
  draw_int(f, a, b, num_pts, BOLD);
  endbold;
  end_stanza();
}

/* ODE plots -- slope, dart, and vector fields, solutions of ODEs */

static void
draw_field(double f1(double, double), double f2(double, double),
	   pair p, pair q, int n1, int n2,
	   const int field_type, const int path_style)
{
  /*
   * p = lower left corner, q = upper right corner, (n1, n2) = grid size
   */
  double x1;
  double x2;
  double dx1 = (q.x1 - p.x1)/n1;
  double dx2 = (q.x2 - p.x2)/n2;
  double len_pict; // vector length in LaTeX units
  double minimum; // 40% of shorter grid length in Cartesian

  int i1, i2;
  pair base; // basepoint
  pair vect; // displacement vector

  for (i1 = 0; i1 <= n1; ++i1)
    {
      x1 = p.x1 + i1*dx1;
      for (i2 = 0; i2 <= n2; ++i2)
      {
	x2 = p.x2 + i2*dx2;
	base = P(x1, x2);

	vect = P(f1(x1, x2), f2(x1, x2));

	// Plotting the zero vector
	if (truncate(raw_len(vect)) == 0)
	  {
	    // Formerly a 2pt \circle*, which broke color handling
	    fprintf(stdout, "\n\\put");
	    print(base);
	    fprintf(stdout, "{\\kern -0.25pt \\rule[-0.25pt]{0.5pt}{0.5pt}}");
	  }
	// VECTOR fields plotted to scale
	else if (field_type == VECTOR)
	  {
	    if (path_style == BOLD)
	      draw_boldarrow(base, base + vect);
	    else
	      draw_arrow(base, base + vect, path_style);
	  }

	else // DART or ARROW fields scaled to constant length
	  {
	    pair temp = c2s(vect);
	    pair dX = c2s(pair(dx1, dx2));
	    len_pict = raw_len(temp);
	    // Magic number 0.4: Segment length 80% of shorter grid length
	    minimum = (dX.x1 > dX.x2) ? 0.4*dX.x2 : 0.4*dX.x1;
	    vect *= (minimum/len_pict);
	    
	    if (field_type == SLOPE)
	      draw_line(base - vect, base + vect, 1, 0, PLAIN);
	    else if (field_type == DART)
	      draw_dart(base - vect, base + vect, PLAIN);
	    else // unknown type...
	      ;	    
	  }
      }
    }
}

void
draw_slope_field(double f1(double, double), double f2(double, double),
		 pair p, pair q, int n1, int n2)
{
  draw_field(f1, f2, p, q, n1, n2, SLOPE, PLAIN);
}
void
draw_dart_field(double f1(double, double), double f2(double, double),
		pair p, pair q, int n1, int n2)
{
  draw_field(f1, f2, p, q, n1, n2, DART, PLAIN);
}
void
draw_vector_field(double f1(double, double), double f2(double, double),
		  pair p, pair q, int n1, int n2, const int path_style)
{
  draw_field(f1, f2, p, q, n1, n2, VECTOR, path_style);
}

void
slope_field(double f1(double, double), double f2(double, double),
	    pair p, pair q, int n1, int n2)
{
  comment_plot("slope_field");
  draw_slope_field(f1, f2, p, q, n1, n2);
  end_stanza();
}

void
boldslope_field(double f1(double, double), double f2(double, double),
		pair p, pair q, int n1, int n2)
{
  comment_plot("boldslope_field");
  bold;
  draw_slope_field(f1, f2, p, q, n1, n2);
  endbold;
  end_stanza();
}

void
dart_field(double f1(double, double), double f2(double, double),
	   pair p, pair q, int n1, int n2)
{
  comment_plot("dart_field");
  draw_dart_field(f1, f2, p, q, n1, n2);
  end_stanza();
}

void
bolddart_field(double f1(double, double), double f2(double, double),
	       pair p, pair q, int n1, int n2)
{
  comment_plot("bolddart_field");
  bold;
  draw_dart_field(f1, f2, p, q, n1, n2);
  endbold;
  end_stanza();
}

void
vector_field(double f1(double, double), double f2(double, double),
	     pair p, pair q, int n1, int n2)
{
  comment_plot("vector_field");
  draw_vector_field(f1, f2, p, q, n1, n2, PLAIN);
  end_stanza();
}

void
boldvector_field(double f1(double, double), double f2(double, double),
		 pair p, pair q, int n1, int n2)
{
  comment_plot("boldvector_field");
  bold;
  draw_vector_field(f1, f2, p, q, n1, n2, BOLD);
  endbold;
  end_stanza();
}

void
draw_ode_plot(double f1(double, double), double f2(double, double),
	      pair start, double t_max, int num_pts, 
	      const int path_style)
{
  int i=0;
  int pt_count = 0;
  pair curr = start;

  if (x_min <= curr.x1 && curr.x1 <= x_max &&
      y_min <= curr.x2 && curr.x2 <= y_max)
    start_path(path_style);
  else
    fprintf(stdout, "\n%%%% Initial point outside bounding box");

  while(x_min <= curr.x1 && curr.x1 <= x_max &&
	y_min <= curr.x2 && curr.x2 <= y_max &&
	i <= num_pts*ITERATIONS)
    {
      if (i%ITERATIONS == 0)
	{
	  print(curr);
	  ++pt_count;
	  line_break(pt_count, num_pts, path_style);
	}

      ++i;

      /* Euler's method */
      curr += (t_max/(num_pts*ITERATIONS)) 
	* pair(f1(curr.x1, curr.x2), f2(curr.x1, curr.x2));
    }
  
  print(curr);
}

void
ode_plot(double f1(double, double), double f2(double, double),
	 pair start, double t_max, int num_pts)
{
  comment_plot("ode_plot");
  draw_ode_plot(f1, f2, start, t_max, num_pts, PLAIN);
  end_stanza();
}

void
dashode_plot(double f1(double, double), double f2(double, double),
	     pair start, double t_max, int num_pts)
{
  comment_plot("dashode_plot");
  draw_ode_plot(f1, f2, start, t_max, num_pts, DASHED);
  end_stanza();
}

void
dotode_plot(double f1(double, double), double f2(double, double),
	    pair start, double t_max, int num_pts)
{
  comment_plot("dotode_plot");
  draw_ode_plot(f1, f2, start, t_max, num_pts, DOTTED);
  end_stanza();
}

void
boldode_plot(double f1(double, double), double f2(double, double),
	     pair start, double t_max, int num_pts)
{
  comment_plot("boldode_plot");
  bold;
  draw_ode_plot(f1, f2, start, t_max, num_pts, BOLD);
  endbold;
  end_stanza();
}



