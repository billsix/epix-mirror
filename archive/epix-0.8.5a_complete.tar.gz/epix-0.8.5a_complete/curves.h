/*
 * curves.h -- Ellipses, arcs, splines
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.5
 * Last Change: July 6, 2002
 *
 */

#ifndef _EPIX_CURVES
#define _EPIX_CURVES

#ifdef _EPIX_COMPILE
#include "objects.h"
#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *  Ellipses, half-ellipses, circular arcs, splines -- curves.c  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Ellipses */

/* Point-plotting functions */
void draw_ellipse (pair, pair, const int); 
void draw_half_ellipse (pair, pair, double, const int);
void rotate_half_ellipse (pair, pair, double, const int);

/* Stanza-creating whole ellipse functions */
void ellipse (pair, pair);
void dashellipse (pair, pair); 
void dotellipse (pair, pair); 
void boldellipse (pair, pair); 

/* Stanza-creating standard half-ellipse functions */
void ellipse_left (pair, pair);
void ellipse_right (pair, pair);
void ellipse_top (pair, pair);
void ellipse_bottom (pair, pair);

void dashellipse_left (pair, pair);
void dashellipse_right (pair, pair);
void dashellipse_top (pair, pair);
void dashellipse_bottom (pair, pair);

void dotellipse_left (pair, pair);
void dotellipse_right (pair, pair);
void dotellipse_top (pair, pair);
void dotellipse_bottom (pair, pair);

void boldellipse_left (pair, pair);
void boldellipse_right (pair, pair);
void boldellipse_top (pair, pair);
void boldellipse_bottom (pair, pair);

/* Right half ellipse rotated through <double> revolutions */
void ellipse_half (pair, pair, double);
void dashellipse_half (pair, pair, double);
void dotellipse_half (pair, pair, double);
void boldellipse_half (pair, pair, double);

/* Circular arcs */

void draw_proper_arc (pair, double, double, double, const int);
void draw_arc (pair, double, double, double, const int);

void arc (pair, double, double, double);
void dasharc (pair, double, double, double);
void dotarc (pair, double, double, double);
void boldarc (pair, double, double, double);

void draw_arc_arrow (pair, double, double, double, const int);
void arc_arrow (pair, double, double, double);
void dasharc_arrow (pair, double, double, double);
void dotarc_arrow (pair, double, double, double);
void boldarc_arrow (pair, double, double, double);

/* Hyperbolic lines */
void draw_hyperbolic_line (pair, pair, const int);

void hyperbolic_line (pair, pair);
void dashhyperbolic_line (pair, pair);
void dothyperbolic_line (pair, pair);
void boldhyperbolic_line (pair, pair);

pair poincare_klein (pair);
pair klein_poincare (pair);

void draw_disk_line (pair, pair, const int);
void disk_line (pair, pair);
void dashdisk_line (pair, pair);
void dotdisk_line (pair, pair);
void bolddisk_line (pair, pair);

/* Splines */

void draw_spline (pair, pair, pair, const int);
void draw_spline (pair, pair, pair, pair, const int);

/* Quadratc */
void spline (pair, pair, pair);
void dashspline (pair, pair, pair);
void dotspline (pair, pair, pair);
void boldspline (pair, pair, pair);

/* Cubic */
void spline (pair, pair, pair, pair);
void dashspline (pair, pair, pair, pair);
void dotspline (pair, pair, pair, pair);
void boldspline (pair, pair, pair, pair);

/* Knot diagram primitives */

// void draw_p_twist (pair, pair, const int);
// void draw_n_twist (pair, pair, const int);

void p_twist (pair, pair);

void boldp_twist (pair, pair);

void n_twist (pair, pair);

void boldn_twist (pair, pair);

void twists (pair, pair, int);

void boldtwists (pair, pair, int);

#endif /* _EPIX_CURVES */
