/* 
 * triples.h -- ePiX triple:: class and mathematical operators
 *
 * Andrew D. Hwang                      <ahwang@mathcs.holycross.edu>
 *
 * Version: 0.8.5
 * Last Change: July 5, 2002
 */

#ifndef _EPIX_TRIPLES
#define _EPIX_TRIPLES

#ifdef _EPIX_COMPILE
#define _INCLUDE // Used to flag declaration of size variables
#include "pairs.h"
#endif

class triple 
{
 public:
  double x1;
  double x2;
  double x3;

  // void constructor
  triple(void) {}

  // Cartesian constructor
  triple(double x1, double x2, double x3);

  // copy
  triple(const triple& old);

  // destructor
  ~triple() {}

  // increment operators
  triple& operator += (const triple&);
  triple& operator -= (const triple&);
  triple& operator *= (const double&);

  // complex multiplication and division
  triple& operator *= (const triple&);
  triple& operator /= (const triple&);
};

/* triple creation */
triple P(double, double, double); 

// spherical constructor
#define sph(r, t, phi) P(r*cos(t)*cos(phi), r*sin(t)*cos(phi), r*sin(phi))

const triple E_1 = P(1,0,0);
const triple E_2 = P(0,1,0);
const triple E_3 = P(0,0,1);

int  operator == (const triple&, const triple&);
triple operator - (const triple&);
triple operator + (const triple&, const triple&);
triple operator - (const triple&, const triple&);

// cross product
triple operator * (const triple&, const triple&);

// scalar multiplication
triple operator * (const double&, const triple&);

// dot product
double operator |(const triple&, const triple&);
// componentwise product (a,b,c)&(x,y,z) = (ax,by,cz)
triple operator &(const triple&, const triple&);

triple rot1(const double& angle, const triple& v);
triple rot2(const double& angle, const triple& v);
triple rot3(const double& angle, const triple& v);

#endif /* _EPIX_TRIPLES */
