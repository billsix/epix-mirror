/* levelset.c -- level sets */
#include "epix.h"
#define MAX 3

double f1(double t, double r)
{
  return r*sinh(t);
}
double g1(double t, double r)
{
  return r*cosh(t);
}

main()
{
  int i;

  bounding_box(P(-(MAX),-(MAX)), P((MAX), (MAX)));
  unitlength("0.625in");
  picture(P(4,4));
  offset(P(3,-1));

  begin();

  rgb(0.5,0.5,1);
  boldline(P(x_min, y_min), P(x_max, y_max));
  boldline(P(x_min, y_max), P(x_max, y_min));

  for (i=1; i <= (MAX)*(MAX); ++i) 
    {
      double t0 = acosh((MAX)/sqrt(i));
      double D = i*i/pow(MAX, 4); //((MAX)*(MAX));

      //      rgb(0.5*(1-D), 0.8*D, 1-D);
      rgb(0.5+0.75*D, 0.5-0.25*D, 1-D);
      boldsliceplot2(f1, g1, -t0, t0,  sqrt(i), 40);
      boldsliceplot2(f1, g1, -t0, t0, -sqrt(i), 40);

      rgb(0.5-0.5*D, 0.5+0.25*D, 1-0.25*D);
      boldsliceplot2(g1, f1, -t0, t0,  sqrt(i), 40);
      boldsliceplot2(g1, f1, -t0, t0, -sqrt(i), 40);
  }

  red;
  rect(P(x_min, y_min), P(x_max, y_max));
  end(); 
}

