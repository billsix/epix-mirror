/* orthant.c, March 28, 2002  */
#include "epix.h"

main() 
{
  double aspect=1/sqrt(3);
  double len=1.2;

  bounding_box(P(-1, -1), P(1,1));
  picture(P(160, 160));
  unitlength("1pt");

  offset(P(100, -50));

  begin();

  ellipse(P(0,0), P(1,1));
  
  /* Center, radius, rotation angle in degrees */
  red;
  boldellipse_half(P(0,0), P(aspect, 1),  30); 
  dashellipse_half(P(0,0), P(aspect, 1), 210);

  black;
  boldellipse_half(P(0,0), P(aspect, 1),  -90);
  dashellipse_half(P(0,0), P(aspect, 1),   90);

  boldellipse_half(P(0,0), P(aspect, 1), 150);
  dashellipse_half(P(0,0), P(aspect, 1), -30);

  arrow(P(0,0), polar(len,  M_PI_2));
  arrow(P(0,0), polar(len, -M_PI/6));
  boldarrow(P(0,0), polar(len, 7*M_PI/6));

  end();
}
