/* golden_rect.c, March 28, 2002 */
#include "epix.h"

main() 
{
  double tau = (1+sqrt(5))/2;

  bounding_box(P(0,0), P(tau,1));
  picture(P(100*(1+tau), 100*tau));
  unitlength("0.0125in");

  offset(P(120,-80));

  begin();

  line(P(1,0), P(1,1));
  dashline(P(0.5,0), P(0.5,1));
  line(P(0.5,0), P(1,1));

  arc(P(0.5,0), tau-0.5, 0, atan(2));
  boldrect(P(0,0), P(tau, 1));

  end();
}

