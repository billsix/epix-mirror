/*
 * legacy.h
 *
 * This header contains C macros for epix functions whose 
 * use is deprecated.
 *
 * Version 0.8.5
 *
 * Last change: July 6, 2002
 */

#include "pairs.h"

/* Pair operations */
#define add_pair(p1, p2) (p1)+(p2)
#define diff_pair(p1, p2) (p1)-(p2)
#define mult_s(c, p2) (c)*(p2)      /* Scalar multiplication */
#define mult_pair(p1, p2) (p1)*(p2) /* Complex product */

/* Old color handling: revert color to black */
#define end_red       fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")
#define end_green     fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")
#define end_blue      fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")

#define end_cyan      fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")
#define end_magenta   fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")
#define end_yellow    fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")

/* Splines */
#define draw_quad_spline(p1, p2, p3, STYLE) draw_spline((p1), (p2), (p3), (SYTLE))
#define draw_cubic_spline(p1, p2, p3, p4, STYLE) draw_spline((p1), (p2), (p3), (p4), (SYTLE))

#define quad_spline(p1, p2, p3)     spline((p1), (p2), (p3))
#define dashquad_spline(p1, p2, p3) dashspline((p1), (p2), (p3))
#define dotquad_spline(p1, p2, p3)  dotspline((p1), (p2), (p3))
#define boldquad_spline(p1, p2, p3) boldspline((p1), (p2), (p3))

#define cubic_spline(p1, p2, p3, p4)     spline((p1), (p2), (p3), (p4))
#define dashcubic_spline(p1, p2, p3, p4) dashspline((p1), (p2), (p3), (p4))
#define dotcubic_spline(p1, p2, p3, p4)  dotspline((p1), (p2), (p3), (p4))
#define boldcubic_spline(p1, p2, p3, p4) boldspline((p1), (p2), (p3), (p4))

/* plot */
/* Parametric plane curves */
#define paramplot(f1, f2, a, b, n)     plot(f1, f2, (a), (b), (n))
#define dashparamplot(f1, f2, a, b, n) dashplot(f1, f2, (a), (b), (n))
#define dotparamplot(f1, f2, a, b, n)  dotplot(f1, f2, (a), (b), (n))
#define boldparamplot(f1, f2, a, b, n) boldplot(f1, f2, (a), (b), (n))

/* Parametric space curves */
#define plot3d(u1, u2, u3, a, b, n)     plot(u1,  u2, u3, (a), (b), (n))
#define dashplot3d(u1, u2, u3, a, b, n) dashplot(u1,  u2, u3, (a), (b), (n))
#define dotplot3d(u1, u2, u3, a, b, n)  dotplot(u1,  u2, u3, (a), (b), (n))
#define boldplot3d(u1, u2, u3, a, b, n) boldplot(u1,  u2, u3, (a), (b), (n))

/* clipplot */
/* Clipped parametric plane curves */
#define clipparamplot(f1, f2, a, b, n)     clipplot(f1, f2, (a), (b), (n))
#define dashclipparamplot(f1, f2, a, b, n) dashclipplot(f1, f2, (a), (b), (n))
#define dotclipparamplot(f1, f2, a, b, n)  dotclipplot(f1, f2, (a), (b), (n))
#define boldclipparamplot(f1, f2, a, b, n) boldclipplot(f1, f2, (a), (b), (n))

/* Clipped parametric space curves */
#define clipplot3d(f1,f2,f3,a,b,n)     clipplot(f1,f2,f3,(a),(b),(n))
#define dashclipplot3d(f1,f2,f3,a,b,n) dashclipplot(f1,f2,f3,(a),(b),(n))
#define dotclipplot3d(f1,f2,f3,a,b,n)  dotclipplot(f1,f2,f3,(a),(b),(n))
#define boldclipplot3d(f1,f2,f3,a,b,n) boldclipplot(f1,f2,f3,(a),(b),(n))

