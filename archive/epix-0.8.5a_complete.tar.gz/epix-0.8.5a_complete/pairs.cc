/* 
 * pairs.cc -- Ordered pairs and operations
 *
 * Andrew D. Hwang                      <ahwang@mathcs.holycross.edu>
 *
 * Version: 0.8.5
 * Last Change: July 5, 2002
 */

#define _EPIX_COMPILE

#include "pairs.h"

extern double viewpt1, viewpt2, viewpt3;

/* Member functions */

// constructor
pair::pair(double init1, double init2)
{
  x1 = init1;
  x2 = init2;
}

// copy
pair::pair(const pair& old)
{
  x1 = old.x1;
  x2 = old.x2;
}

// increment operators
pair& pair::operator += (const pair& oper)
{
  x1 += oper.x1;
  x2 += oper.x2;
  
  return (*this);
}

pair& pair::operator -= (const pair& oper)
{
  x1 -= oper.x1;
  x2 -= oper.x2;
  
  return (*this);
}

pair& pair::operator *= (const double& c)
{
  x1 *= c;
  x2 *= c;
  
  return (*this);
}

// complex multiplication and division
pair& pair::operator *= (const pair& oper)
{
  double temp = x1;
  x1 = temp * oper.x1 - x2 * oper.x2;
  x2 = temp * oper.x2 + x2 * oper.x1;
  
  return (*this);
}
pair& pair::operator /= (const pair& oper)
{
  double denom = hypot(oper.x1, oper.x2);

  double temp = x1;
  x1 = (temp * oper.x1 + x2 * oper.x2)/denom;
  x2 = (x2 * oper.x1 - temp * oper.x2)/denom;
  
  return (*this);
}

/* pair creation */

pair P(double x1, double x2)
{
  return pair(x1, x2);
} 

// equality
int operator == (const pair& u, const pair& v)
{
  return ((u.x1 == v.x1) && (u.x2 == v.x2) );
}

// negation
pair operator - (const pair& u)
{
  return P(-u.x1, -u.x2);
}
  
// addition
pair operator + (const pair& u, const pair& v)
{
  return P(u.x1 + v.x1, u.x2 + v.x2);
}

pair operator - (const pair& u, const pair& v)
{
  return P(u.x1 - v.x1, u.x2 - v.x2);
}

// scalar multiplication
pair operator * (const double& c, const pair& v)
{
  return P(c*(v.x1), c*(v.x2));
}

/* 1/4-rotation (mult by i) */
pair J(pair p)
{
  return P(-p.x2, p.x1);
}

// complex product
pair operator * (const pair& u, const pair& v)
{
  return P(u.x1*v.x1 - u.x2*v.x2, u.x2*v.x1 + u.x1*v.x2);
}

// complex quotient
pair operator / (const pair& u, const pair& v)
{
  double denom = hypot(v.x1, v.x2);
  
  if (denom < 0.0001) // cf. truncate
    fprintf (stderr, "Error: complex division by 0\n");

  return (1.0/denom)*P(u.x1*v.x1 + u.x2*v.x2, u.x2*v.x1 - u.x1*v.x2);
}

// dot product
double operator | (const pair& u, const pair& v)
{
  return u.x1*v.x1 + u.x2*v.x2;
}

// componentwise product (a,b)&(x,y)=(ax,by)
pair operator & (const pair& u, const pair& v)
{
  return P(u.x1*v.x1, u.x2*v.x2);
}

struct mesh Net (int N1, int N2) 
{
  struct mesh temp;
  
  temp.n1 = N1;
  temp.n2 = N2;
  
  return temp;
};
  
/* 
 * Projects (x1, x2, x3) to <pair> according to <viewpoint>. 
 */

#include "lengths.h"

pair V(double x1, double x2, double x3)
{
  double a1 = viewpt1;
  double a2 = viewpt2;
  double a3 = viewpt3;

  double len1, len2;
  double len_sq = a1*a1 + a2*a2;

  if (truncate (len_sq) == 0) // <viewpoint> is (0, 0, a3)
    return P(x1, x2);

  else
    {
      len1 = 1/sqrt(len_sq + a3*a3);
      len2 = 1/sqrt(len_sq);

      return P(len2*(-a2*x1 + a1*x2),
	       len1*len2*(-a1*a3*x1 - a2*a3*x2 + len_sq*x3));
    }
} 

