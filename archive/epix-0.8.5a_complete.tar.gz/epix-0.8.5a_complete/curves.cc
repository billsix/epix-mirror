/*
 * curves.c: Ellipses, circular arcs, splines
 *
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.5
 * Last Change: July 6, 2002
 */

#define _EPIX_COMPILE
#include "curves.h"

/* 
 * Ellipses and half-ellipses 
 */

static void 
comment_ellipse(char *type, pair center, pair radius)
{
  fprintf(stdout, "\n%%%% %s: center (%.2f, %.2f), radius (%.2f, %.2f)\n%%%%",
	  type, center.x1, center.x2, radius.x1, radius.x2);
}

void 
draw_ellipse(pair center, pair radius, const int path_style)
{
  int i;
  pair current;

  start_path(path_style);
  for (i=0; i <= 2*NUM_PTS; ++i) 
    {
      current = center + (radius&cis(M_PI*i/NUM_PTS));
      print(current);

      line_break(i, 2*NUM_PTS, path_style);
    }
}  

void
ellipse(pair center, pair radius)
{
  comment_ellipse("ellipse", center, radius);
  draw_ellipse(center, radius, PLAIN);
  end_stanza();
}

void 
dashellipse(pair center, pair radius)
{
  comment_ellipse("dashellipse", center, radius);
  draw_ellipse(center, radius, DASHED);
  end_stanza();
}

void 
dotellipse(pair center, pair radius)
{
  comment_ellipse("dotellipse", center, radius);
  draw_ellipse(center, radius, DOTTED);
  end_stanza();
}

void 
boldellipse(pair center, pair radius)
{
  comment_ellipse("boldellipse", center, radius);
  bold;
  draw_ellipse(center, radius, BOLD);
  endbold;
  end_stanza();
}

/* 
 * draw_half_ellipse -- draws a *top* half_ellipse with center <center>, 
 *   semi-axes <radius>, NUM_PTS+1 points, and translated (in parameter) 
 *   by <phase> (measured in degrees).
 */
void 
draw_half_ellipse(pair center, pair radius, double phase, const int path_style)
{
  int i;
  pair current;

  start_path(path_style);
  for (i=0; i <= NUM_PTS; ++i) 
    {
      current = center + (radius&cis(M_PI*(i*1.0/NUM_PTS + phase/180)));
      print(current);

      line_break(i, NUM_PTS, path_style);
    }
}  

/* Plain half-ellipses */
void 
ellipse_top(pair center, pair radius)
{
  comment_ellipse("ellipse_top", center, radius);
  draw_half_ellipse(center, radius, 0, PLAIN);
  end_stanza();
}

void 
ellipse_bottom(pair center, pair radius)
{
  comment_ellipse("ellipse_bottom", center, radius);
  draw_half_ellipse(center, radius, 180, PLAIN);
  end_stanza();
}

void 
ellipse_left(pair center, pair radius)
{
  comment_ellipse("ellipse_left", center, radius);
  draw_half_ellipse(center, radius, 90, PLAIN);
  end_stanza();
}

void 
ellipse_right(pair center, pair radius)
{
  comment_ellipse("ellipse_right", center, radius);
  draw_half_ellipse(center, radius, -90, PLAIN);
  end_stanza();
}

/* Dashed half-ellipses */
void 
dashellipse_top(pair center, pair radius)
{
  comment_ellipse("dashellipse_top", center, radius);
  draw_half_ellipse(center, radius, 0, DASHED);
  end_stanza();
}

void 
dashellipse_bottom(pair center, pair radius)
{
  comment_ellipse("dashellipse_bottom", center, radius);
  draw_half_ellipse(center, radius, 180, DASHED);
  end_stanza();
}

void 
dashellipse_left(pair center, pair radius)
{
  comment_ellipse("dashellipse_left", center, radius);
  draw_half_ellipse(center, radius, 90, DASHED);
  end_stanza();
}

void 
dashellipse_right(pair center, pair radius)
{
  comment_ellipse("dashellipse_right", center, radius);
  draw_half_ellipse(center, radius, -90, DASHED);
  end_stanza();
}

/* Dotted half-ellipses */
void 
dotellipse_top(pair center, pair radius)
{
  comment_ellipse("dotellipse_top", center, radius);
  draw_half_ellipse(center, radius, 0, DOTTED);
  end_stanza();
}

void 
dotellipse_bottom(pair center, pair radius)
{
  comment_ellipse("dotellipse_bottom", center, radius);
  draw_half_ellipse(center, radius, 180, DOTTED);
  end_stanza();
}

void 
dotellipse_left(pair center, pair radius)
{
  comment_ellipse("dotellipse_left", center, radius);
  draw_half_ellipse(center, radius, 90, DOTTED);
  end_stanza();
}

void 
dotellipse_right(pair center, pair radius)
{
  comment_ellipse("dotellipse_right", center, radius);
  draw_half_ellipse(center, radius, -90, DOTTED);
  end_stanza();
}

/* Bold half-ellipses */
void 
boldellipse_top(pair center, pair radius)
{
  comment_ellipse("boldellipse_top", center, radius);
  bold;
  draw_half_ellipse(center, radius, 0, BOLD);
  endbold;
  end_stanza();
}

void 
boldellipse_bottom(pair center, pair radius)
{
  comment_ellipse("boldellipse_bottom", center, radius);
  bold;
  draw_half_ellipse(center, radius, 180, BOLD);
  endbold;
  end_stanza();
}

void 
boldellipse_left(pair center, pair radius)
{
  comment_ellipse("boldellipse_left", center, radius);
  bold;
  draw_half_ellipse(center, radius, 90, BOLD);
  endbold;
  end_stanza();
}

void 
boldellipse_right(pair center, pair radius)
{
  comment_ellipse("boldellipse_right", center, radius);
  bold;
  draw_half_ellipse(center, radius, -90, BOLD);
  endbold;
  end_stanza();
}

/* Rotated half_ellipses */
static void 
comment_rotate_ellipse(char *type, pair center, pair radius, double angle)
{
  fprintf(stdout, "\n%%%% %s: center (%.2f, %.2f), radius (%.2f, %.2f),",
	  type, center.x1, center.x2, radius.x1, radius.x2);
  fprintf(stdout, "\n%%%%   rotated %.1f degrees\n%%%%", angle);
}

/*
 * draw_ellipse_half -- right ellipse rotated counterclockwise by <angle>
 */
void 
rotate_half_ellipse(pair center, pair radius, 
		    double angle, const int path_style)
{
  int i = 0;
  double t;
  pair current;
  pair rotate = cis(M_PI*angle/180.0);

  //  double dt = M_PI/NUM_PTS;

  start_path(path_style);
  for (i=0; i <= NUM_PTS; ++i) 
    {
      t = -M_PI_2 + i*M_PI/NUM_PTS;
      current = center + rotate*(radius&cis(t)); // (a,b)&(x,y) = (ax,by)
      print(current);

      line_break(i, NUM_PTS, path_style);
    }
}

void 
ellipse_half(pair center, pair radius, double angle)
{
  comment_rotate_ellipse("ellipse_half", center, radius, angle);
  rotate_half_ellipse(center, radius, angle, PLAIN);
  end_stanza();
}

void 
dashellipse_half(pair center, pair radius, double angle)
{
  comment_rotate_ellipse("dashellipse_half", center, radius, angle);
  rotate_half_ellipse(center, radius, angle, DASHED);
  end_stanza();
}

void 
dotellipse_half(pair center, pair radius, double angle)
{
  comment_rotate_ellipse("dotellipse_half", center, radius, angle);
  rotate_half_ellipse(center, radius, angle, DOTTED);
  end_stanza();
}

void 
boldellipse_half(pair center, pair radius, double angle)
{
  comment_rotate_ellipse("boldellipse_half", center, radius, angle);
  bold;
  rotate_half_ellipse(center, radius, angle, BOLD);
  endbold;
  end_stanza();
}

/* 
 * Objects containing circular arcs 
 */

/* Circular arc spanning arbitrary angle */
static void 
comment_arc(char *type, pair center,
		 double radius, double start, double finish)
{
  fprintf(stdout, "\n%%%% %s:\n%%%%   center (%.2f,%.2f), radius %.2f, ",
	  type, center.x1, center.x2, radius);
  fprintf(stdout, "from %.2f to %.2f radians \n%%%%", start, finish);
}

/* 
 * draw_proper_arc is called iff start/finish angles are sensible.
 * Angles are measured in radians, hence may be generated readily
 * by the standard C math functions.
 */

static double 
arc_scale(double r)
{
  pair temp = c2s(P(r,r));
  /* Approx. number of true pts per radian */
  return 0.5*p2t(temp.x1 + temp.x2);
}

void 
draw_proper_arc(pair center, double r, 
		double start, double finish, const int path_style)
{
  double angle = finish - start; 
  int i; 
  pair current;

  /* 
   * Number of points plotted is nearly proportional to radius and
   * angle subtended for large circles, but is no smaller than 20
   * points per circle for small circles. Hybrid of two failed attempts:
   *
   * int num_pts=(int) ceil(fabs(NUM_PTS*angle));
   * 
   * ceil(fabs(angle)*unscale(h_scale(r)+v_scale(r))/(2.0*DASH_LENGTH));
   */
  int num_pts=(int) ceil(fabs(0.5*(angle/M_PI)*(NUM_PTS + arc_scale(r)/DASH_LENGTH)));

  if (num_pts < 2)
    num_pts=2;

  start_path(path_style);
  for (i=0; i <= num_pts; ++i) 
    {
      current = center + polar(r, start+i*angle/num_pts);
      print(current);

      line_break(i, num_pts, path_style);
    }
}

void 
draw_arc(pair center, double r, 
	 double start, double finish, const int path_style)
{
  if (fabs(finish-start) >= 2*M_PI) // One full turn or more
    draw_ellipse(center, P(r, r), path_style);

  else if (0 < finish - start)
    draw_proper_arc(center, r, start, finish, path_style);
    
  else if (0 > finish - start)
    draw_proper_arc(center, r, finish, start, path_style);
  
  else // start == finish
    fprintf(stdout, "\n%%%%   Null arc...?");
}

void 
arc(pair center, double r, double start, double finish)
{
  comment_arc("arc", center, r, start, finish);
  draw_arc(center, r, start, finish, PLAIN);
  end_stanza();
}

void 
dasharc(pair center, double r, double start, double finish)
{
  comment_arc("dasharc", center, r, start, finish);
  draw_arc(center, r, start, finish, DASHED);
  end_stanza();
}

void 
dotarc(pair center, double r, double start, double finish)
{
  comment_arc("dotarc", center, r, start, finish);
  draw_arc(center, r, start, finish, DOTTED);
  end_stanza();
}

void 
boldarc(pair center, double r, double start, double finish)
{
  comment_arc("boldarc", center, r, start, finish);
  bold;
  draw_arc(center, r, start, finish, BOLD);
  endbold;
  end_stanza();
}

/* Angle subtended by arrowhead at Cartesian distance r */

static double subtended(double r)
{
  return ARROWHEAD_WIDTH*ARROWHEAD_RATIO/arc_scale(r);
}

void 
draw_arc_arrow(pair center, double r, 
	       double start, double finish, const int path_style)
{
  if (fabs(start - finish) <= subtended(r))
    fprintf(stdout, "\n%%%%   Arc shorter than arrowhead; not printed");
  
  else {
    if (start < finish)
      finish -= subtended(r);
    else
      finish += subtended(r);
    
    /* Terminal point of arc */
    pair base = center + polar(r, finish);
    /* Unit (1 true pt) vector tangent to arc at <base> */
    pair dir = c2s(cis(finish));

    dir = J(normalize(dir));
    /* Reverse direction if necessary */
    if (start > finish)
      dir = -dir;
    
    /* Magic number 0.01 */
    pair tip = base + 0.01*dir;
    
    draw_arc(center, r, start, finish, path_style);
    
    //  start_path(PLAIN);
    draw_arrow(base, tip, PLAIN);
  }
}

void 
arc_arrow(pair center, double r, double start, double finish)
{
  comment_arc("arc_arrow", center, r, start, finish);
  draw_arc_arrow(center, r, start, finish, PLAIN);
  end_stanza();
}

void 
dasharc_arrow(pair center, double r, double start, double finish)
{
  comment_arc("dasharc_arrow", center, r, start, finish);
  draw_arc_arrow(center, r, start, finish, DASHED);
  end_stanza();
}

void 
dotarc_arrow(pair center, double r, double start, double finish)
{
  comment_arc("dotarc_arrow", center, r, start, finish);
  draw_arc_arrow(center, r, start, finish, DOTTED);
  end_stanza();
}

void 
boldarc_arrow(pair center, double r, double start, double finish)
{
  comment_arc("boldarc_arrow", center, r, start, finish);
  bold;
  draw_arc_arrow(center, r, start, finish, BOLD);
  endbold;
  end_stanza();
}

/* Hyperbolic lines in upper half plane */

void 
draw_hyperbolic_line(pair tail, pair head, const int path_style)
{
  double x;
  pair jump = head - tail;
  pair current;
  double a = tail.x1, b = tail.x2, c = head.x1, d = head.x2;
  int i, n;

  if (tail.x2 < 0 || head.x2 < 0)
    fprintf(stdout, "\n%%%% Error: Point(s) not in upper half-plane");

  /*
   * Position of center of circle is numerically unstable near a=c.
   */
  else if ( truncate(fabs(jump.x1)) == 0 ) {

    n = (int) ceil(p2t(M_PI*fabs( c2p(jump).x2 )/20)); // ad hoc scale factor
    //v_scale(M_PI*fabs(d - b))/20.0));
    if (n < 1)
      n=1; // print at least 2 points

    start_path(path_style);
    for (i=0; i <= n; ++i) 
      {
	current = tail + i*(1.0/n)*(pair(1,0)&jump);
	print(current);
	// fprintf(stdout, "(%g,%g)", h_scale(a), v_scale(b + i*(d - b)/n));
	line_break(i, n, path_style);
      }
  }    

  else {
    x = (0.5)*(hypot(c, d) - hypot(a, b))/(c-a); // center of circle

    draw_arc(P(x,0), hypot(c-x, d), 
	     atan2(d, c-x), atan2(b, a-x), path_style);
  }
}

void 
hyperbolic_line(pair tail, pair head)
{
  comment_line("hyperbolic_line", tail, head);
  draw_hyperbolic_line(tail, head, PLAIN);
  end_stanza();
}

void 
dashhyperbolic_line(pair tail, pair head)
{
  comment_line("dashhyperbolic_line", tail, head);
  draw_hyperbolic_line(tail, head, DASHED);
  end_stanza();
}

void 
dothyperbolic_line(pair tail, pair head)
{
  comment_line("dothyperbolic_line", tail, head);
  draw_hyperbolic_line(tail, head, DOTTED);
  end_stanza();
}

void 
boldhyperbolic_line(pair tail, pair head)
{
  comment_line("boldhyperbolic_line", tail, head);
  bold;
  draw_hyperbolic_line(tail, head, BOLD);
  endbold;
  end_stanza();
}

/* 
 * Lines in Poincare disk model.
 *
 * Consider the "positive" portion of the standard hyperboloid of two 
 * sheets: x^2 + y^2 + 1 = z^2, z>0, and consider copies of the unit
 * disk in the planes z=0 (D0) and z=1 (D1). The Klein model of the disk
 * is gotten by stereographic projection from the origin to D1, while the
 * Poincare model is gotten by stereographic projection from (0,0,-1) to
 * D0. Appropriate compositions of these projection maps are hyperbolic
 * isometries. The algorithm for drawing lines in the disk model is to
 * find the images of the endpoints in the Klein model, draw the line
 * between them, and map this line back to the Poincare model. Because
 * the isometry is "square-root-like" in the radial direction at the
 * unit circle, the points on the Klein line are spaced quadratically
 * close together at the endpoints of the segment (the variable "s") so
 * their images will be roughly equally-spaced in the Poincare model.
 * There is no visual harm if one or both endpoints are far from the
 * circle, and the result is acceptable if both points are on or near the
 * circle. The number of points to draw is determined both by the true
 * distance between the endpoints and by how close they are to the circle.
 */
pair poincare_klein(pair p)
{
  double denom=1+pow(raw_len(p),2); // p=(u,v), denom = 1 + |p|^2
  p *= (2.0/denom);
  return p;
}
pair klein_poincare(pair p)
{
  double denom=1+sqrt(1-pow(raw_len(p),2)); // 1 + sqrt(1 - |p|^2)
  p *= (1.0/denom);
  return p;
}

void 
draw_disk_line(pair tail, pair head, const int path_style)
{
  int i;
  double n; // 2 <= n+1 = number of points on curve
  pair current;

  // Euclidean length between endpoints
  double length = raw_len(head - tail);

  // Roughly twice number of true points between head and tail
  double length_scale = 2*arc_scale(length);

  // Draw more points if head and/or tail are close to unit circle
  double length_weight = (1 + raw_len(head) + raw_len(tail));

  if (1 < raw_len(tail) || 1 < raw_len(head))
    fprintf(stdout, "\n%%%% Error: One or both points not in unit disk");

  // Roughly prop. to true length, weighted by closeness to boundary
  n = ceil(0.1*length_weight*length_scale);

    start_path(path_style);
    for (i=0; i <= (int) n; ++i) 
      {
	/* Space points quadratically closely near endpoints */
	double s = 0.5*(1+cos(M_PI*i/n)); // s in [0,1]
	
	current = (s*poincare_klein(tail)) + ((1-s)*poincare_klein(head));
	print(klein_poincare(current));
	
	line_break(i, (int) n, path_style);
      }
}

void 
disk_line(pair tail, pair head)
{
  comment_line("disk_line", tail, head);
  draw_disk_line(tail, head, PLAIN);
  end_stanza();
}

void 
dashdisk_line(pair tail, pair head)
{
  comment_line("dashdisk_line", tail, head);
  draw_disk_line(tail, head, DASHED);
  end_stanza();
}

void 
dotdisk_line(pair tail, pair head)
{
  comment_line("dotdisk_line", tail, head);
  draw_disk_line(tail, head, DOTTED);
  end_stanza();
}

void 
bolddisk_line(pair tail, pair head)
{
  comment_line("bolddisk_line", tail, head);
  bold;
  draw_disk_line(tail, head, BOLD);
  end_bold;
  end_stanza();
}

/* 
 * Splines 
 */

static inline pair
quad_spline_pt(pair p1, pair p2, pair p3, double t)
{
  return t*t*p1 + 2*t*(1-t)*p2 + (1-t)*(1-t)*p3;
}
static inline pair
cubic_spline_pt(pair p1, pair p2, pair p3, pair p4, double t)
{
  return t*t*t*p1 + 3*t*t*(1-t)*p2 + 3*t*(1-t)*(1-t)*p3 + (1-t)*(1-t)*(1-t)*p4;
}

static void 
comment_spline(char *type, pair p1, pair p2, pair p3)
{
  fprintf(stdout, "\n%%%% %s: control points", type);
  fprintf(stdout, "\n%%%%   ");
  raw_print(p1);
  raw_print(p2);
  raw_print(p3);
  fprintf(stdout, "\n%%%%");
}
static void 
comment_spline(char *type, pair p1, pair p2, pair p3, pair p4)
{
  fprintf(stdout, "\n%%%% %s: control points", type);
  fprintf(stdout, "\n%%%%   ");
  raw_print(p1);
  raw_print(p2);
  raw_print(p3);
  raw_print(p4);
  fprintf(stdout, "\n%%%%");
}

/* quad spline */
void 
draw_spline(pair p1, pair p2, pair p3, const int path_style)
{
  double t;
  pair current;

  if (path_style != DOTTED)
    start_path(path_style);
  
  for (int i=0; i <= NUM_PTS; ++i) 
    {
      t = i*1.0/NUM_PTS;
      current = quad_spline_pt(p1, p2, p3, t);
	
      if (path_style == DOTTED)
	ddot(current);
      
      else
	{
	  print(current);
	  line_break(i, NUM_PTS, path_style);
	}
    }
}

/* cubic spline */
void 
draw_spline(pair p1, pair p2, pair p3, pair p4, const int path_style)
{
  double t;
  pair current;

  if (path_style != DOTTED)
    start_path(path_style);
  
  for (int i=0; i <= NUM_PTS; ++i) 
    {
      t = i*1.0/NUM_PTS;
      current = cubic_spline_pt(p1, p2, p3, p4, t);
	
      if (path_style == DOTTED)
	ddot(current);
      
      else
	{
	  print(current);
	  line_break(i, NUM_PTS, path_style);
	}
    }
}

/* quadratic splines */
void
spline(pair p1, pair p2, pair p3)
{
  comment_spline("quad_spline", p1, p2, p3);
  draw_spline(p1, p2, p3, PLAIN);
  end_stanza();
}
void 
dashspline(pair p1, pair p2, pair p3)
{
  comment_spline("dashquad_spline", p1, p2, p3);
  draw_spline(p1, p2, p3, DASHED);
  end_stanza();
}
void 
dotspline(pair p1, pair p2, pair p3)
{
  comment_spline("dotquad_spline", p1, p2, p3);
  draw_spline(p1, p2, p3, DOTTED);
  end_stanza();
}
void 
boldspline(pair p1, pair p2, pair p3)
{
  comment_spline("boldquad_spline", p1, p2, p3);
  bold;
  draw_spline(p1, p2, p3, BOLD);
  endbold;
  end_stanza();
}

/* cubic splines */
void 
spline(pair p1, pair p2, pair p3, pair p4)
{
  comment_spline("cubic_spline", p1, p2, p3, p4);
  draw_spline(p1, p2, p3, p4, PLAIN);
  end_stanza();
}
void 
dashspline(pair p1, pair p2, pair p3, pair p4)
{
  comment_spline("dashcubic_spline", p1, p2, p3, p4);
  draw_spline(p1, p2, p3, p4, DASHED);
  end_stanza();
}
void 
dotspline(pair p1, pair p2, pair p3, pair p4)
{
  comment_spline("dotcubic_spline", p1, p2, p3, p4);
  draw_spline(p1, p2, p3, p4, DOTTED);
  end_stanza();
}
void 
boldspline(pair p1, pair p2, pair p3, pair p4)
{
  comment_spline("boldcubic_spline", p1, p2, p3, p4);
  bold;
  draw_spline(p1, p2, p3, p4, BOLD);
  endbold;
  end_stanza();
}

/* Planar knot diagram primitives */

static void 
comment_twist(char *type, pair p1, pair p4)
{
  fprintf(stdout, "\n%%%% %s: control points", type);
  fprintf(stdout, "\n%%%%   (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	  p1.x1, p1.x2, p4.x1, p4.x2);
}

static void 
draw_under_strand(pair p3, pair p6, pair p5, pair p2, const int path_style)
{
  double t;

  // Draw two half-splines with given control points
  start_path(path_style);
  for (int i=0; i < NUM_PTS/2 - 1; ++i) 
    {
      t = i*1.0/NUM_PTS;
      print(cubic_spline_pt(p3, p6, p5, p2, t));
      line_break(i, NUM_PTS/2, path_style);
    }
  
  t=1; // Start at end of path, step backward
  start_path(path_style);
  for (int i=0; i < NUM_PTS/2 - 1; ++i) 
    {
      t = 1.0 - i*1.0/NUM_PTS;
      print(cubic_spline_pt(p3, p6, p5, p2, t));
      line_break(i, NUM_PTS/2, path_style);
    }
}

static void 
draw_p_twist(pair p1, pair p4, const int path_style)
{
  pair p2, p3, p5, p6;
  // Set up control points in an H
  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      p2.x1 = p1.x1; // <p2>     <p4>
      p2.x2 = p4.x2; // <p5>     <p6>
      p3.x1 = p4.x1; // <p1>     <p3>
      p3.x2 = p1.x2;

      p5.x1 = p1.x1;
      p6.x1 = p4.x1;
      p5.x2 = p6.x2 = (0.5)*(p1.x2 + p4.x2);
    }

  else
    {
      p2.x1 = p4.x1; // <p1> <p5> <p2>
      p2.x2 = p1.x2; // 
      p3.x1 = p1.x1; // <p3> <p6> <p4>
      p3.x2 = p4.x2;

      p5.x2 = p1.x2;
      p6.x2 = p4.x2;
      p5.x1 = p6.x1 = (0.5)*(p1.x1 + p4.x1);
    }
  
  // Over strand
  draw_spline(p1, p5, p6, p4, path_style);
  draw_under_strand(p3, p6, p5, p2, path_style);
}

static void 
draw_n_twist(pair p1, pair p4, const int path_style)
{
  pair p2, p3, p5, p6;

  // Set up control points in an H -- same as draw_p_twist
  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      p2.x1 = p1.x1; // <p2>     <p4>
      p2.x2 = p4.x2; // <p5>     <p6>
      p3.x1 = p4.x1; // <p1>     <p3>
      p3.x2 = p1.x2;

      p5.x1 = p1.x1;
      p6.x1 = p4.x1;
      p5.x2 = p6.x2 = (0.5)*(p1.x2 + p4.x2);
    }

  else
    {
      p2.x1 = p4.x1; // <p1> <p5> <p2>
      p2.x2 = p1.x2; // 
      p3.x1 = p1.x1; // <p3> <p6> <p4>
      p3.x2 = p4.x2;

      p5.x2 = p1.x2;
      p6.x2 = p4.x2;
      p5.x1 = p6.x1 = (0.5)*(p1.x1 + p4.x1);
    }
  
  // Over strand -- control points reversed from draw_p_twist
  draw_spline(p3, p6, p5, p2, path_style);
  draw_under_strand(p1, p5, p6, p4, path_style);
}

void 
p_twist(pair p1, pair p4)
{
  comment_twist("p_twist", p1, p4);
  draw_p_twist(p1, p4, PLAIN);
  end_stanza();
}

void 
boldp_twist(pair p1, pair p4)
{
  comment_twist("boldp_twist", p1, p4);
  bold;
  draw_p_twist(p1, p4, BOLD);
  endbold;
  end_stanza();
}

void 
n_twist(pair p1, pair p4)
{
  comment_twist("n_twist", p1, p4);
  draw_n_twist(p1, p4, PLAIN);
  end_stanza();
}

void 
boldn_twist(pair p1, pair p4)
{
  comment_twist("boldn_twist", p1, p4);
  bold;
  draw_n_twist(p1, p4, BOLD);
  endbold;
  end_stanza();
}

void 
twists(pair p1, pair p4, int n)
{
  double a;
  double b;
  double c;
  double d;

  int i;

  fprintf(stdout, "\n%%%% twists(%d), (%.2f,%.2f) to (%.2f,%.2f)", 
	 n, p1.x1, p1.x2, p4.x1, p4.x2);

  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      a = p1.x1;
      b = p1.x2;
      c = p4.x1;
      d = p4.x2;
      
      if (n < 0) {
	n = -n;
	for (i=0; i < n; ++i)
	  draw_n_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n), PLAIN);
      }

      else
	for (i=0; i < n; ++i)
	  draw_p_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n), PLAIN);
    }

  else
    {
      a = p1.x2;
      b = p1.x1;
      c = p4.x2;
      d = p4.x1;

      if (n < 0) {
	n = -n;
	for (i=0; i < n; ++i)
	  draw_n_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c), PLAIN);
      }

      else
	for (i=0; i < n; ++i)
	  draw_p_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c), PLAIN);
    }
  end_stanza();
}

void 
boldtwists(pair p1, pair p4, int n)
{
  double a;
  double b;
  double c;
  double d;

  int i;

  fprintf(stdout, "\n%%%% boldtwists(%d), (%.2f,%.2f) to (%.2f,%.2f)", 
	 n, p1.x1, p1.x2, p4.x1, p4.x2);

  bold;
  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      a = p1.x1;
      b = p1.x2;
      c = p4.x1;
      d = p4.x2;
      
      if (n < 0) {
	n = -n;
	for (i=0; i < n; ++i)
	  draw_n_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n), PLAIN);
      }

      else
	for (i=0; i < n; ++i)
	  draw_p_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n), PLAIN);
    }

  else
    {
      a = p1.x2;
      b = p1.x1;
      c = p4.x2;
      d = p4.x1;

      if (n < 0) {
	n = -n;
	for (i=0; i < n; ++i)
	  draw_n_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c), PLAIN);
      }

      else
	for (i=0; i < n; ++i)
	  draw_p_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c), PLAIN);
    }
  endbold;
  end_stanza();
}
