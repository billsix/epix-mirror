/* 
 * objects.h -- Simple picture objects: axes, grids, markers, polygons
 *
 * Andrew D. Hwang                      <ahwang@mathcs.holycross.edu>
 *
 * Version: 0.8.5
 * Last Change: July 8, 2002
 */

#ifndef _EPIX_OBJECTS
#define _EPIX_OBJECTS

#ifdef _EPIX_COMPILE
#include "output.h"
#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                    Picture objects                    *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 * label -- put string constant <label_text> 
 * at Cartesian position <pair> offset by <vect> true points.
 * Accepts an optional LaTeX-style positioning argument after the offset.
 * If no offset is specified, the label is centered at the given Cartesian
 * location.
 * masklabel requires the "color" package, and places the text in 
 * a white box that masks whatever is underneath and earlier in the file.
 */
void label(pair base, pair offset, char *label_text);
void label(pair base, char *label_text);
void label(pair base, pair offset, char *label_text, const int label_posn);
void masklabel(pair base, pair offset, char *label_text);
void masklabel(pair base, char *label_text);
void masklabel(pair base, pair offset, char *label_text, const int label_posn);

/*
 * mask -- filled white rectangle to mask out part of a figure
 * prior to label placement. Parameters designed to match those
 * of labels; <base> is the Cartesian location, <offset> is the
 * offset in true pt, <size> is the size of the box in true pt.
 *
 * Use of "mask" is deprecated; use masklabel and axis_masklabels
 * instead.
 */
void mask(pair base, pair offset, pair size);

/*
 * Empty and filled LaTeX circles of diameter DIAM true pt
 */
// void comment_circ(char *type, double h_posn, double v_posn);
void circ(pair); // filled white circ 4 pt in diameter
void ring(pair, double); // unfilled circ of specified diam
void spot(pair);
void dot(pair);
void ddot(pair);

/* Axes and coordinate grids. */

/* 
 * Coordinate axes, specified by initial and final points, and number
 * of steps. h/v_axis are identical except for style of tick marks.
 */
void h_axis_tick(pair);
void v_axis_tick(pair);
void h_axis(pair tail, pair head, int n);
void v_axis(pair tail, pair head, int n);

/*
 * h_axis_labels: Draws n+1 equally-spaced axis labels between 
 *    <tail> and <head>. Automatically generates label values from
 *    Cartesian coordinates, and offsets labels in true pt.
 */

void h_axis_labels(pair tail, pair head, int n, pair offset);
void v_axis_labels(pair tail, pair head, int n, pair offset);

void h_axis_masklabels(pair tail, pair head, int n, pair offset);
void v_axis_masklabels(pair tail, pair head, int n, pair offset);

/* Axis labels with LaTeX-style alignment option */

void h_axis_labels(pair tail, pair head, int n, pair offset, 
		   const int label_posn);
void v_axis_labels(pair tail, pair head, int n, pair offset, 
		   const int label_posn);

void h_axis_masklabels(pair tail, pair head, int n, pair offset, 
		       const int label_posn);
void v_axis_masklabels(pair tail, pair head, int n, pair offset, 
		       const int label_posn);

/* eepic.sty's ellipse comand */
void draw_native_ellipse (pair, pair);
void native_ellipse (pair, pair);

/* Cartesian grid filling bounding_box */
void grid(int, int);
void dashgrid(int, int);
void dotgrid(int, int);
void boldgrid(int, int);

/* Cartesian grid of specified size */
void grid(pair, pair, int, int);
void dashgrid(pair, pair, int, int);
void dotgrid(pair, pair, int, int);
void boldgrid(pair, pair, int, int);

/* Polar grid with n1 rings and n2 sectors */
// void draw_polar_grid(double, int, int, const int);
void polar_grid(double, int, int);
void dashpolar_grid(double, int, int);
void dotpolar_grid(double, int, int);
void boldpolar_grid(double, int, int);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *             Simple geometric objects                  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

// Lines can be "stretched" by double parameter
void draw_line(pair, pair, int, double, const int); 
void comment_line(char *, pair, pair);
void comment_line(char *, pair, pair, double);

/* Lines with stretch factor */
void line(pair, pair, double);     
void dashline(pair, pair, double); 
void dotline(pair, pair, double); 
void boldline(pair, pair, double); 

/* Unstretched lines */
void line(pair, pair);    
void dashline(pair, pair);
void dotline(pair, pair);
void boldline(pair, pair);

/* Returns >0 iff p0 is left of directed segment from p1 to p2 */
double ccw(pair p0, pair p1, pair p2);
/* "Visible" portion of the line through p1, p2 */
void draw_Line(pair, pair, int, const int);
void Line(pair, pair);
void dashLine(pair, pair);
void dotLine(pair, pair);
void boldLine(pair, pair);

void draw_triangle(pair, pair, pair, const int); 
// void comment_triangle(char *, pair, pair, pair);
void triangle(pair, pair, pair);
void dashtriangle(pair, pair, pair);
void dottriangle(pair, pair, pair);
void boldtriangle(pair, pair, pair);

/* 
 * If (a,b) and (c,d) are opposite corners of a rectangle, then
 * the corners -- in order -- are (a,b), (a,d), (c,d), and (c,b).
 */
void draw_rect(pair, pair, const int); /* opposite corners */
// void comment_rect(char *, pair, pair);
void rect(pair, pair);
void dashrect(pair, pair); 
void dotrect(pair, pair); 
void boldrect(pair, pair); 

void swatch(pair, pair);
void boldswatch(pair, pair);

void draw_arrowhead(pair, pair, double);
void draw_shaft(pair, pair, double);
void draw_arrow(pair, pair, const int);
void draw_boldarrow(pair, pair);
void arrow(pair, pair);
void dasharrow(pair, pair);
void dotarrow(pair, pair);
void boldarrow(pair, pair);

void draw_dart(pair, pair, const int);
void draw_bolddart(pair, pair);
void dart(pair, pair);
void dashdart(pair, pair);
void dotdart(pair, pair);
void bolddart(pair, pair);

#endif /* _EPIX_OBJECTS */
