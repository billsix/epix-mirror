/* 
 * objects.cc -- Simple picture objects: axes, grids, markers, polygons
 *
 * Andrew D. Hwang                      <ahwang@mathcs.holycross.edu>
 *
 * Version: 0.8.5
 * Last Change: July 8, 2002
 */

#define _EPIX_COMPILE
#include "objects.h"

extern double h_size, v_size, h_offset, v_offset;
extern double viewpt1, viewpt2, viewpt3;
extern double x_min, x_max, y_min, y_max, x_size, y_size;
extern double pic_size;
extern char *pic_unit;

extern double stretch_factor;
extern int lines_printed;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                    Picture objects                    *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 * label -- put string constant <label_text> aligned at basepoint
 * at Cartesian position <pair> offset by <vect> true points.
 */
void
label(pair base, pair offset, char *label_text)
{
  pair temp = c2p(base) + t2p(offset);
  fprintf (stdout, "\n%%%% label: \"%s\" at (%g, %g)\n%%%%", \
	 label_text, base.x1, base.x2);
  fprintf (stdout, "\n\\put(%g,%g){%s}", temp.x1, temp.x2, label_text);
  end_stanza();
}

void
masklabel(pair base, pair offset, char *label_text)
{
  pair temp = c2p(base) + t2p(offset);
  fprintf (stdout, "\n%%%% masklabel: \"%s\" at (%g, %g)\n%%%%", \
	 label_text, base.x1, base.x2);
  fprintf (stdout, "\n\\put(%g,%g)", temp.x1, temp.x2);
  fprintf (stdout, "{\\colorbox{white}{%s}}", label_text);
  end_stanza();
}

/* centered labels */
void
label(pair base, char *label_text)
{
  fprintf (stdout, "\n%%%% label: \"%s\" centered at (%g, %g)\n%%%%", 
	   label_text, base.x1, base.x2);
  fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){%s}}", 
	   c2p(base).x1, c2p(base).x2, label_text);

  end_stanza();
}
void
masklabel(pair base, char *label_text)
{
  fprintf (stdout, "\n%%%% masklabel: \"%s\" centered at (%g, %g)\n%%%%", 
	   label_text, base.x1, base.x2);
  fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){\\colorbox{white}{%s}}}", 
	   c2p(base).x1, c2p(base).x2, label_text);

  end_stanza();
}

/* labels with LaTeX-style alignment */
static void print_label_posn(const int label_posn)
{
  if (label_posn == c)
    fprintf (stdout, "[c]");
 
  else if (label_posn == t)
    fprintf (stdout, "[b]");
 
  else if (label_posn == tr || label_posn == rt)
    fprintf (stdout, "[bl]");
 
  else if (label_posn == r)
    fprintf (stdout, "[l]");
 
  else if (label_posn == br || label_posn == rb)
    fprintf (stdout, "[tl]");
 
  else if (label_posn == b)
    fprintf (stdout, "[t]");
 
  else if (label_posn == bl || label_posn == lb)
    fprintf (stdout, "[tr]");
 
  else if (label_posn == l)
    fprintf (stdout, "[r]");
 
  else if (label_posn == tl || label_posn == lt)
    fprintf (stdout, "[br]");
 
  else // Just for good measure...
    fprintf (stderr, "Label alignment error: unknown option\n");   
}

void
label(pair base, pair offset, char *label_text, const int label_posn)
{
  pair temp = c2p(base) + t2p(offset);
  fprintf (stdout, "\n%%%% label: \"%s\" centered at (%g,%g),\n%%%%   aligned ", 
	   label_text, base.x1, base.x2);
  print_label_posn(label_posn); // Unknown option causes compiler exit

  fprintf (stdout, ", offset by (%g, %g) pt\n%%%%", offset.x1, offset.x2);
  fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0)", temp.x1, temp.x2);
  print_label_posn(label_posn);
  fprintf (stdout, "{%s}}", label_text);

  end_stanza();
}
void
masklabel(pair base, pair offset, char *label_text, const int label_posn)
{
  pair temp = c2p(base) + t2p(offset);
  fprintf (stdout, "\n%%%% masklabel: \"%s\" centered at (%g,%g),\n%%%%   aligned ", 
	   label_text, base.x1, base.x2);
  print_label_posn(label_posn); // Unknown option causes compiler exit

  fprintf (stdout, ", offset by (%g, %g) pt\n%%%%", offset.x1, offset.x2);
  fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0)", temp.x1, temp.x2);
  print_label_posn(label_posn);
  fprintf (stdout, "{\\colorbox{white}{%s}}}", label_text);

  end_stanza();
}

/*
 * mask -- filled white rectangle to mask out part of a figure
 * prior to label placement. Parameters designed to match those
 * of labels; <base> is the Cartesian location, <offset> is the
 * offset in true pt, <size> is the size of the box in true pt.
 */
void
mask(pair base, pair offset, pair size)
{
  pair low_left = base + s2c(t2p(offset));
  pair up_right = base + s2c(t2p(offset + size));
  /*
    double a = base.x1 + h_unstretch(scale(offset.x1));
    double b = base.x2 + v_unstretch(scale(offset.x2));
    double c = base.x1 + h_unstretch(scale(offset.x1 + size.x1));
    double d = base.x2 + v_unstretch(scale(offset.x2 + size.x2));
  */

  fprintf (stdout, "\n%%%% mask: %g pt x %g pt at (%g, %g)\n%%%%", \
	 size.x1, size.x2, base.x1, base.x2);
  fprintf (stdout, "\n\\whiten");
  draw_rect(low_left, up_right, PLAIN);
  end_stanza();
}

void
marker(pair p, const int mark_type)
{
  pair out = c2p(p);

  switch(mark_type) {
  case PATH:
    print(p);
    break;

  case CIRC:  
    fprintf (stdout, "\n\\whiten\\put(%g,%g){\\circle{%g}}",
	     out.x1, out.x2, t2p(DIAM));
    break;

  case SPOT:   
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\bullet$}}",
	    out.x1, out.x2); //, scale(DIAM), p.x1, p.x2);
    break;

  case RING:   
    fprintf (stdout, "\n\\put(%g,%g){\\circle{%g}}\t%%%% (%g,%g)",
	    out.x1, out.x2, t2p(DIAM), p.x1, p.x2);
    break;

  case DOT:   
    fprintf (stdout, "\n\\put(%g,%g){\\circle*{%g}}\t%%%% (%g,%g)",
	    out.x1, out.x2, t2p(0.5*DIAM), p.x1, p.x2);
    break;

  case DDOT:   
    fprintf (stdout, "\n\\put(%g,%g){\\circle*{%g}}\t%%%% (%g,%g)",
	 out.x1, out.x2, t2p(0.25*DIAM), p.x1, p.x2);
    break;

  case PLUS:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){+}}", out.x1, out.x2);
    break;

  case OPLUS:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\oplus$}}",
	    out.x1, out.x2);
    break;

  case TIMES:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\times$}}",
	    out.x1, out.x2);
    break;

  case OTIMES:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\otimes$}}",
	    out.x1, out.x2);
    break;

  case DIAMOND:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\diamond$}}",
	    out.x1, out.x2);
    break;

  case UP:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\bigtriangleup$}}",
	    out.x1, out.x2);
    break;

  case DOWN:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\bigtriangledown$}}",
	    out.x1, out.x2);
    break;

  case BOX:   
    /* Magic number 4pt */
    fprintf (stdout, "\n\\put(%g,%g){\\kern -2pt \\rule[-2pt]{4pt}{4pt}}",
	    out.x1, out.x2);
    break;

  case BBOX:   
    /* Magic number 2pt */
    fprintf (stdout, "\n\\put(%g,%g){\\kern -1pt \\rule[-1pt]{2pt}{2pt}}",
	    out.x1, out.x2);
    break;

  default: 
    break;
  }
}

/*
 * Empty and filled LaTeX circles of diameter DIAM true pt
 */

static void
comment_circ(char *type, pair p)
{
  fprintf (stdout, "\n%%%% %s: center (%.2f,%.2f)\n%%%%", type, p.x1, p.x2);
}

void
circ(pair p) // filled white circ 4 pt in diameter
{
  comment_circ("circ", p);
  marker(p, CIRC);
  end_stanza();
}  
void
ring(pair p, double r) // unfilled circ of specified diam
{
  pair out = c2p(p);
  comment_circ("ring", p);
  fprintf (stdout, "\n\\put(%g,%g){\\circle{%g}}",
	   out.x1, out.x2, (r*DIAM/4)/p2t(1.0)); // scale(r*DIAM/4));
  end_stanza();
}  
void
spot(pair p)
{
  comment_circ("spot", p);
  marker(p, SPOT); // LaTeX bullet
  end_stanza();
}  
void
dot(pair p)
{
  comment_circ("dot", p);
  marker(p, DOT);
  end_stanza();
}  
void
ddot(pair p)
{
  comment_circ("ddot", p);
  marker(p, DDOT);
  end_stanza();
}

/* 
 * Axis ticks 
 *
 * N.B. An h_tick is a tall, thin rectangle, for a *horizontal* axis, etc.
 */

static void h_tick(void)
{
  fprintf (stdout, "{\\kern -0.25pt \\rule[-2pt]{0.5pt}{4pt}}");
}
static void v_tick(void)
{
  fprintf (stdout, "{\\kern -2pt \\rule[-0.25pt]{4pt}{0.5pt}}");
}

void
h_axis_tick(pair p)
{
  pair out = c2p(p);
  fprintf (stdout, "\n\\put(%g,%g)", out.x1, out.x2);
  h_tick();
}

void
v_axis_tick(pair p)
{
  pair out = c2p(p);
  fprintf (stdout, "\n\\put(%g,%g)", out.x1, out.x2);
  v_tick();
}

/* 
 * Coordinate axes, specified by initial and final points, and number
 *  of steps. 
 */
static void axis(pair tail, pair head, int n, int tick_type)
{
  pair start = c2p(tail);               // c2p: tail is a point
  pair step = (1.0/n)*c2s(head - tail); // c2s: step is a vector

  fprintf (stdout, "\n%%%% h_axis: (%.2f,%.2f) to (%.2f,%.2f), %d steps",
	   tail.x1, tail.x2, head.x1, head.x2, n);

  //axis
  start_path(PLAIN);
  print(tail);
  print(head);
  ++lines_printed;
  
  fprintf (stdout, "\n%%%% tick marks:");
  fprintf (stdout, "\n\\multiput(%g,%g)(%g,%g){%d}",
	   start.x1, start.x2, step.x1, step.x2, n+1);

  if (tick_type == H_AXIS)
    h_tick();

  else if (tick_type == V_AXIS)
    v_tick();
  
  else // tick_type == NULL or unknown
    ;

  ++lines_printed;
  end_stanza();
}
  
void h_axis(pair tail, pair head, int n)
{
  axis(tail, head, n, H_AXIS);
}

void v_axis(pair tail, pair head, int n)
{
  axis(tail, head, n, V_AXIS);
}
/*
 * h_axis_labels: Draws n+1 equally-spaced axis labels between 
 *    <tail> and <head>. Automatically generates label values from
 *    Cartesian coordinates, and has true-distance offsets.
 *
 * There is a separate version that takes a LaTeX-style alignment argument.
 * The "unaligned" version tries to do constant alignment with labels that
 * may or may not have a sign. It was easier to write a new routine to
 * handle labels with an alignment option than to modify the existing one.
 */

static void
axis_labels(pair tail, pair head, int n, pair offset, 
	    const int tick_type, int mask)
{
  int i=0;
  int neg_flag;
  double label;

  if (tick_type == H_AXIS && head.x1*tail.x1 < 0) // labels change sign
    neg_flag=1;
  else if (tick_type == V_AXIS && head.x2*tail.x2 < 0)
    neg_flag=1;
  else
    neg_flag=0;

  // Select appropriate comment
  if (tick_type == H_AXIS)
    fprintf (stdout, "\n%%%% h_axis_labels");
  else // safe to assume V_AXIS, since this function is static
    fprintf (stdout, "\n%%%% v_axis_labels");

  if (mask == 0)
    fprintf (stdout, ":");
  else 
    fprintf (stdout, " (masked):");

  for (i=0; i<= n; ++i)
    {
      pair current = tail + (i*1.0/n)*(head - tail);
      pair location = c2p(current) + t2p(offset);
      fprintf (stdout, "\n");

      // Compute proper type of label
      if (tick_type == H_AXIS)
	label = current.x1;
      else // V_AXIS
	label = current.x2;

      // Put sign on label?
      if (neg_flag && label >= 0)
	{
	  // Let TeX worry about the non-existent "-"
	  fprintf (stdout, "\\put(%g,%g){$\\phantom{-}",
		   location.x1, location.x2);
	  // mask label?
	  if (mask == 0)
	    fprintf (stdout, "%g$}" , label);
	  else // N.B. Excess "}" ------------------- v
	    fprintf (stdout, "$\\colorbox{white}{$%g$}}" , label);
	}
      else
	{
	  fprintf (stdout, "\\put(%g,%g)", location.x1, location.x2);
	  if (mask == 0)
	    fprintf (stdout, "{$%g$}" , label);
	  else
	    fprintf (stdout, "{\\colorbox{white}{$%g$}}" , label);
	}
    }
  end_stanza();
}

void
h_axis_labels(pair tail, pair head, int n, pair offset)
{
  axis_labels(tail, head, n, offset, H_AXIS, 0);
}
void
v_axis_labels(pair tail, pair head, int n, pair offset)
{
  axis_labels(tail, head, n, offset, V_AXIS, 0);
}
void
h_axis_masklabels(pair tail, pair head, int n, pair offset)
{
  axis_labels(tail, head, n, offset, H_AXIS, 1);
}
void
v_axis_masklabels(pair tail, pair head, int n, pair offset)
{
  axis_labels(tail, head, n, offset, V_AXIS, 1);
}

/* axis labels with alignment option */
static void
axis_labels(pair tail, pair head, int n, pair offset, 
	    const int tick_type, int mask, const int label_posn)
{
  double label;

  // Select appropriate comment
  if (tick_type == H_AXIS)
    fprintf (stdout, "\n%%%% h_axis_labels: ");
  else // safe to assume V_AXIS, since this function is static
    fprintf (stdout, "\n%%%% v_axis_labels: ");

  for (int i=0; i<= n; ++i)
    {
      pair current = tail + (i*1.0/n)*(head - tail);
      pair location = c2p(current) + t2p(offset);
      fprintf (stdout, "\n");

      // Compute proper type of label
      if (tick_type == H_AXIS)
	label = current.x1;
      else // V_AXIS
	label = current.x2;

      fprintf (stdout, "\\put(%g,%g){\\makebox(0,0)",
	       location.x1, location.x2);
      print_label_posn(label_posn);
      if (mask == 0)
	fprintf (stdout, "{$%g$}}" , label);
      else
	fprintf (stdout, "{\\colorbox{white}{$%g$}}}" , label);
    }
  end_stanza();
}

void
h_axis_labels(pair tail, pair head, int n, pair offset, 
	      const int label_posn)
{
  axis_labels(tail, head, n, offset, H_AXIS, 0, label_posn);
}
void
v_axis_labels(pair tail, pair head, int n, pair offset, 
	      const int label_posn)
{
  axis_labels(tail, head, n, offset, V_AXIS, 0, label_posn);
}
void
h_axis_masklabels(pair tail, pair head, int n, pair offset, 
		  const int label_posn)
{
  axis_labels(tail, head, n, offset, H_AXIS, 1, label_posn);
}
void
v_axis_masklabels(pair tail, pair head, int n, pair offset, 
		  const int label_posn)
{
  axis_labels(tail, head, n, offset, V_AXIS, 1, label_posn);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *             Simple geometric objects                  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Lines take a stretch factor, roughly in percent */
void
draw_line(pair tail, pair head, int n, double expand, const int path_style)
{
  double c = expm1(M_LN2*expand/100.0); // 2^{expand/100} - 1
  pair direction = head - tail;

  start_path(path_style);

  /* Ensure at least two points printed */
  n = abs(n);
  if (n<1)
    n=1;

  pair pt = tail - (0.5*c)*direction;
  pair step = ((1+c)/n)*direction; // displacement of stretched line

  for (int i=0; i<=n; ++i)
    {
      print(pt);
      pt += step;
      line_break(i,n, path_style);
    }
}

void
comment_line(char *type, pair tail, pair head)
{
  fprintf (stdout, "\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	   type, tail.x1, tail.x2, head.x1, head.x2);
}

void
comment_line(char *type, pair tail, pair head, double expand)
{
  fprintf (stdout, "\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f), scaled %g\n%%%%",
	   type, tail.x1, tail.x2, head.x1, head.x2, exp(M_LN2*expand/100));
}

/* Lines with expansion factor */
void
line(pair tail, pair head, double expand)
{
  comment_line("line", tail, head, expand);
  draw_line(tail, head, 1, expand, PLAIN);
  end_stanza();
}
void
dashline(pair tail, pair head, double expand)
{
  /* Magic number 12 -- approximate length of unstretched dashes in true pt */
  int n = (int) ceil(p2t(raw_len(c2s(exp(M_LN2*expand/100)*(head-tail))))/(12*stretch_factor));
  comment_line("dashline", tail, head, expand);
  draw_line(tail, head, n, expand, DASHED);			      
  end_stanza();
}
void
dotline(pair tail, pair head, double expand)
{
  comment_line("dotline", tail, head, expand);
  draw_line(tail, head, 1, expand, DOTTED);
  end_stanza();
}
void
boldline(pair tail, pair head, double expand)
{
  comment_line("boldline", tail, head, expand);
  bold;
  draw_line(tail, head, 1, expand, BOLD);
  endbold;
  end_stanza();
}

/* Unstretched lines */
void
line(pair tail, pair head)
{
  comment_line("line", tail, head);
  draw_line(tail, head, 1, 0, PLAIN);
  end_stanza();
}
void
dashline(pair tail, pair head)
{
  /* Magic number 12 -- approximate length of unstretched dashes in true pt */
  int n = (int) ceil(p2t(raw_len(c2s(head-tail)))/(12*stretch_factor));
  comment_line("dashline", tail, head);
  draw_line(tail, head, n, 0, DASHED);			      
  end_stanza();
}
void
dotline(pair tail, pair head)
{
  comment_line("dotline", tail, head);
  draw_line(tail, head, 1, 0, DOTTED);
  end_stanza();
}
void
boldline(pair tail, pair head)
{
  comment_line("boldline", tail, head);
  bold;
  draw_line(tail, head, 1, 0, BOLD);
  endbold;
  end_stanza();
}

/*
 * Returns positive iff vertices (p0,p1,p2) are counterclockwise.
 * Cyclic permutation of parameters has no effect on sign of return value.
 */
double ccw(pair p0, pair p1, pair p2)
{
  double d = truncate(p2.x1 - p1.x1);
  if ( d != 0)
    return truncate(p0.x2 - p1.x2 - (p2.x2 - p1.x2)*(p0.x1 - p1.x1)/d);
  else
    return truncate(p1.x1 - p0.x1);
}

/*
 * Line(p1, p2) -- Portion of line (p1,p2) that lies in bounding_box
 *
 * First check whether p1, p2 lie on a vertical line.
 * If not, find points where (p1,p2) crosses x=x_min, x=x_max, then
 * see if these points satisfy y_min <= y <= y_max.
 */
void draw_Line(pair p1, pair p2, int n, const int path_style)
{
  int found = 0;

  pair tail, head;

  /* Points lie on a vertical line */
  if ( truncate(p2.x1 - p1.x1) == 0 && x_min <= p1.x1 && p1.x1 <= x_max )
    {
      tail = P(p1.x1, y_min);
      head = P(p1.x1, y_max);
      found = 2;
    }
  else
    { 
      double m = (p2.x2 - p1.x2)/(p2.x1 - p1.x1); // slope of line
      tail = P(x_min, p1.x2 + m*(x_min - p1.x1));
      head = P(x_max, p1.x2 + m*(x_max - p1.x1));

      if (m > 0) {
	if ( y_max <= tail.x2 )
	  ; // line misses bounding box
	else if ( y_min <= tail.x2 )	  
	  ++found; // tail is correct
	else // tail.x2 < y_min, adjust tail
	  { 
	    tail = P(p1.x1 + (y_min - p1.x2)/m, y_min);
	    ++found;
	  }

	if ( head.x2 <= y_min )
	  ;
	else if ( head.x2 <= y_max )
	  ++found; // head is correct
	else
	  {
	    head = P(p1.x1 + (y_max - p1.x2)/m, y_max);
	    ++found;
	  }
      }

      else { // m < 0
	if ( tail.x2 <= y_min )
	  ; // line misses bounding box
	else if ( tail.x2 <= y_max )	  
	  ++found; // tail is correct
	else // y_max < tail.x2, adjust tail
	  { 
	    tail = P(p1.x1 + (y_max - p1.x2)/m, y_max);
	    ++found;
	  }

	if ( y_max <= head.x2 )
	  ;
	else if ( y_min <= head.x2 )
	  ++found; // head is correct
	else
	  {
	    head = P(p1.x1 + (y_min - p1.x2)/m, y_min);
	    ++found;
	  }
      }
    }

  if ( found == 2 )
    draw_line(tail, head, n, 0, path_style);
  // else print nothing
}

void
Line(pair tail, pair head)
{
  comment_line("Line", tail, head);
  draw_Line(tail, head, 1, PLAIN);
  end_stanza();
}
void
dashLine(pair tail, pair head)
{
  /* Magic number 12 -- approximate length of unstretched dashes in true pt */
  int n = (int) ceil(p2t(raw_len(c2s(P(x_size, y_size))))/(12*stretch_factor));
  comment_line("dashLine", tail, head);
  draw_Line(tail, head, n, DASHED);			      
  end_stanza();
}
void
dotLine(pair tail, pair head)
{
  comment_line("dotLine", tail, head);
  draw_Line(tail, head, 1, DOTTED);
  end_stanza();
}
void
boldLine(pair tail, pair head)
{
  comment_line("boldLine", tail, head);
  bold;
  draw_Line(tail, head, 1, BOLD);
  endbold;
  end_stanza();
}

/* Triangles */
void
draw_triangle(pair p1, pair p2, pair p3, const int path_style)
{
  start_path(path_style);
  print(p1);
  print(p2);
  print(p3);
  print(p1);
}

static void
comment_triangle(char *type, pair p1, pair p2, pair p3)
{
  fprintf (stdout, "\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	   type, p1.x1, p1.x2, p2.x1, p2.x2, p3.x1, p3.x2);
}

void
triangle(pair p1, pair p2, pair p3)
{
  comment_triangle("triangle", p1, p2, p3);
  draw_triangle(p1, p2, p3, PLAIN);
  end_stanza();
}

void
dashtriangle(pair p1, pair p2, pair p3)
{
  comment_triangle("dashtriangle", p1, p2, p3);
  draw_triangle(p1, p2, p3, DASHED);
  end_stanza();
}

void
dottriangle(pair p1, pair p2, pair p3)
{
  comment_triangle("dottriangle", p1, p2, p3);
  draw_triangle(p1, p2, p3, DOTTED);
  end_stanza();
}

void
boldtriangle(pair p1, pair p2, pair p3)
{
  comment_triangle("boldtriangle", p1, p2, p3);
  bold;
  draw_triangle(p1, p2, p3, BOLD);
  endbold;
  end_stanza();
}

/* 
 * If (a,b) and (c,d) are opposite corners of a rectangle, then
 * the corners -- in order -- are (a,b), (c,b), (c,d), and (a,d).
 */
void
draw_rect(pair p1, pair p2, const int path_style) 
{
  pair h_jump = e_1&(p2-p1); // e_1 = (1,0), e_2 = (0,1), so
  pair v_jump = e_2&(p2-p1); // e_1&(a,b) = (a,0), etc.

  start_path(path_style);
  print(p1);
  print(p1 + h_jump);
  print(p2);
  print(p1 + v_jump);
  print(p1);
}

static void
comment_rect(char *type, pair p1, pair p2)
{
  fprintf (stdout, "\n%%%% %s: corners (%.2f, %.2f) and (%.2f, %.2f)\n%%%%", \
	   type, p1.x1, p1.x2, p2.x1, p2.x2);
}

void
rect(pair p1, pair p2)
{
  comment_rect("rect", p1, p2);
  draw_rect(p1, p2, PLAIN);
  end_stanza();
}

void
dashrect(pair p1, pair p2)
{
  comment_rect("dashrect", p1, p2);
  draw_rect(p1, p2, DASHED);
  end_stanza();
}

void
dotrect(pair p1, pair p2)
{
  comment_rect("dotrect", p1, p2);
  draw_rect(p1, p2, DOTTED);
  end_stanza();
}

void
boldrect(pair p1, pair p2)
{
  comment_rect("boldrect", p1, p2);
  bold;
  draw_rect(p1, p2, BOLD);
  endbold;
  end_stanza();
}

void
swatch(pair p1, pair p2)
{
  comment_rect("swatch", p1, p2);
  fprintf (stdout, "\n\\shade");
  draw_rect(p1, p2, PLAIN);
  end_stanza();
}

void
boldswatch(pair p1, pair p2)
{
  comment_rect("boldswatch", p1, p2);
  bold;
  fprintf (stdout, "\\shade");
  draw_rect(p1, p2, BOLD);
  endbold;
  end_stanza();
}

/* eepic.sty has an \ellipse function; native_ellipse() accesses it */

static void 
comment_ellipse(char *type, pair center, pair radius)
{
  fprintf (stdout, "\n%%%% %s: center (%.2f, %.2f), radius (%.2f, %.2f)\n%%%%",
	  type, center.x1, center.x2, radius.x1, radius.x2);
}

void 
draw_native_ellipse(pair center, pair radius)
{
  center = c2p(center);
  radius = c2s(2*radius);

  fprintf (stdout, "\n\\put(%g,%g){\\ellipse{%g}{%g}}",
	  center.x1, center.x2, radius.x1, radius.x2);
}
static void 
draw_ellipse(pair center, pair radius, const int path_style)
{
  int i;
  pair current;

  start_path(path_style);
  for (i=0; i <= 2*NUM_PTS; ++i) 
    {
      current = center + radius&cis(M_PI*i/NUM_PTS);
      print(current);

      line_break(i, 2*NUM_PTS, path_style);
    }
}  

void 
native_ellipse(pair center, pair radius)
{
  comment_ellipse("native_ellipse", center, radius);
  draw_native_ellipse(center, radius);
  end_stanza();
}

/* 
 * n1 x n2 Cartesian grid
 *
 * If style is DASH or DOTTED, all grid *segments* are drawn; otherwise
 * only grid lines (edge-to-edge) are drawn. 
 */
static void
draw_grid(pair p1, pair p2, int n1, int n2, const int path_style)
{
  int i, num_pts;
  pair h_jump, v_jump;
  h_jump = e_1&(p2 - p1);
  v_jump = e_2&(p2 - p1);

  fprintf (stdout, "\n%%%%   Vertical lines");
  for (i=0; i<=n1; ++i)
    {
      if (path_style == PLAIN || path_style == BOLD)
	num_pts = 1;   // draw line at once
      else num_pts = (int) n2; // draw line in segments

      draw_line(p1 + ((i*1.0/n1)*h_jump),
		(p1 + v_jump) + (i*1.0/n1)*h_jump,
		num_pts, 0, path_style);

      ++lines_printed;
    }

  fprintf (stdout, "\n%%%%   Horizontal lines");
  for (i=0; i<=n2; ++i)
    {
      if (path_style == PLAIN || path_style == BOLD)
	num_pts = 1;   // draw line at once
      else num_pts = (int) n1; // draw line in segments
      
      draw_line(p1 + ((i*1.0/n2)*v_jump),
		(p1 + h_jump) + (i*1.0/n2)*v_jump,
		num_pts, 0, path_style);

      ++lines_printed;
    }
}

/* Grids that fill bounding_box */
void
grid(int n1, int n2)
{
  fprintf (stdout, "\n%%%% grid:");
  draw_grid(P(x_min, y_min), P(x_max, y_max), n1, n2, PLAIN);
  end_stanza();
}
void
dashgrid(int n1, int n2)
{
  /*
    n1 = (int) n1;
    n2 = (int) n2;
  */
  fprintf (stdout, "\n%%%% dashgrid:");
  draw_grid(P(x_min, y_min), P(x_max, y_max), n1, n2, DASHED);
  end_stanza();
}
void
dotgrid(int n1, int n2)
{
  fprintf (stdout, "\n%%%% dotgrid:");
  draw_grid(P(x_min, y_min), P(x_max, y_max), n1, n2, DOTTED);
  end_stanza();
}
void
boldgrid(int n1, int n2)
{
  fprintf (stdout, "\n%%%% boldgrid:");
  bold;
  draw_grid(P(x_min, y_min), P(x_max, y_max), n1, n2, BOLD);
  endbold;
  end_stanza();
}

/* Grids of arbitrary size */
void
grid(pair p1, pair p2, int n1, int n2)
{
  fprintf (stdout, "\n%%%% grid:");
  draw_grid(p1, p2, n1, n2, PLAIN);
  end_stanza();
}
void
dashgrid(pair p1, pair p2, int n1, int n2)
{
  fprintf (stdout, "\n%%%% dashgrid:");
  draw_grid(p1, p2, n1, n2, DASHED);
  end_stanza();
}
void
dotgrid(pair p1, pair p2, int n1, int n2)
{
  fprintf (stdout, "\n%%%% dotgrid:");
  draw_grid(p1, p2, n1, n2, DOTTED);
  end_stanza();
}
void
boldgrid(pair p1, pair p2, int n1, int n2)
{
  fprintf (stdout, "\n%%%% boldgrid:");
  bold;
  draw_grid(p1, p2, n1, n2, BOLD);
  endbold;
  end_stanza();
}

/* Polar grid with n1 rings and n2 sectors */
static void
draw_polar_grid(double radius, int n1, int n2, const int path_style)
{
  fprintf (stdout, "\n%%%%   rings\n%%%%"); 
  for (int i=1; i <= n1; ++i) 
    {
      if (path_style == PLAIN || path_style == BOLD)
	draw_native_ellipse(P(0,0), P(i*radius/n1,i*radius/n1));
      
      else
	draw_ellipse(P(0,0), P(i*radius/n1,i*radius/n1), path_style);

      ++lines_printed;
    }

  fprintf (stdout, "\n%%%%   radii\n%%%%");  
  for (int i=0; i < n2; ++i)
    {
      draw_line(P(0,0), polar(radius, 2*M_PI*i/n2), 2*n1, 0, path_style);
      if (i<n2-1)
	fprintf (stdout, "\n%%%%");

      ++lines_printed;
    }
}

void
polar_grid(double radius, int n1, int n2)
{
  fprintf (stdout, "\n%%%% polar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  draw_polar_grid(radius, n1, n2, PLAIN);
  end_stanza();
}

void
dashpolar_grid(double radius, int n1, int n2)
{
  fprintf (stdout, "\n%%%% dashpolar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  draw_polar_grid(radius, n1, n2, DASHED);
  end_stanza();
}

void
dotpolar_grid(double radius, int n1, int n2)
{
  fprintf (stdout, "\n%%%% dotpolar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  draw_polar_grid(radius, n1, n2, DOTTED);
  end_stanza();
}

void
boldpolar_grid(double radius, int n1, int n2)
{
  fprintf (stdout, "\n%%%% boldpolar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  bold;
  draw_polar_grid(radius, n1, n2, BOLD);
  endbold;
  end_stanza();
}

/* 
 * Arrows joining two specified <pair>s. An arrow consists of a head
 * and a shaft; the head is 2*width true points wide, and width*ratio
 * true points long, while the shaft is long enough to join the <tail>
 * to <new_head> (see below). If the <tail> is inside the arrowhead,
 * the shaft is not drawn. 
 *
 * Because drawing the head and shaft involve separate complications, 
 * they are split into separate functions. The algorithm is:
 *
 * (1) Find Cartesian direction vector from <tail> to <head>, and
 *    convert to picture coords.
 *
 * (2) If shaft is too short, put base of arrowhead at <base>. Precisely,
 *    determine the true pt length of the direction vector, normalize
 *    it, and move width*ratio true points toward <tail> from <head>.
 *    If this backtracks across <tail>, do not draw the shaft; otherwise,
 *    retract the head appropriately, to <new_head>. Draw the shaft.
 *    Stop snickering...
 *
 * (3) Compute the three vertices of the arrowhead; they are two true pt
 *    to either side of <new_head>, and width*ratio true pt along the
 *    unit vector from <new_head> to <head>, i.e., at <head> provided
 *    the arrow is not so short that <tail> lies inside the arrowhead.
 *    To get perpendicular offsets, the rotation operator J is applied
 *    to the true unit vector.
 *
 * As with other polygon objects, draw_arrowhead and draw_shaft print
 * only lists of coordinate pairs, not line styles, etc. draw_arrow is the
 * user analogue of draw_rect (e.g.); it draws the requisite paths and
 * nothing else. This division of labor  allows the pieces to be used in
 * other functions, e.g., plots of tangent vectors to a parametrized curve.
 *
 * A certain amount of mental resistance was required not to use the term
 * "flint" instead of "arrowhead".
 */
void
draw_arrowhead(pair tail, pair head, double width)
{
  double ratio=ARROWHEAD_RATIO;

  /*
   * Vertices of arrowhead:
   *
   *                       <tip1>
   * <cart_to_pict(tail)>  <new_head>    <tip3>
   *                       <tip2>
   */

  pair tip1, tip2, tip3; 

  /* Head/tail of shaft in picture coordinates */
  pair new_head;

  /* Picture coords direction vector from <tail> to <head> */
  pair dir = c2s(head - tail);
  /* Picture coords unit vector parallel to direction vector */
  pair unit_dir = normalize(dir);

  if ( width*ratio < true_len(dir) ) // <tail> outside arrowhead
    {
      tip3 = c2p(head);
      new_head = tip3 - (width*ratio)*unit_dir;
    }

  else // <tail> inside arrowhead
    {
      new_head = c2p(tail);
      tip3 = new_head + (width*ratio)*unit_dir;
    }

  tip1 = new_head + width*J(unit_dir);
  tip2 = new_head - width*J(unit_dir);

  /* N.B. Coordinates already converted from Cartesian */
  raw_print(tip1);
  raw_print(tip2);
  raw_print(tip3);
  raw_print(tip1);
}

void
draw_shaft(pair tail, pair head, double width)
{
  double ratio=ARROWHEAD_RATIO;

  /* Head/tail of shaft in picture coordinates */
  pair new_head;
  /* Picture coords direction vector from <tail> to <head> */
  pair dir = c2s(head - tail);
  // P((head.x1 - tail.x1)*h_size/x_size, (head.x2 - tail.x2)*v_size/y_size);

  /* Picture coords unit vector parallel to direction vector */
  pair unit_dir = normalize(dir);

  if ( width*ratio < true_len(dir) ) // <tail> outside arrowhead
    {
      new_head = c2p(head) - (width*ratio)*unit_dir;
      print(tail);
      raw_print(new_head);
      /*
	fprintf (stdout, "(%g,%g)(%g,%g)", \
	h_scale(tail.x1), v_scale(tail.x2), new_head.x1, new_head.x2);
      */
    }
}

void
draw_arrow(pair tail, pair head, const int path_style)
{
  double width=ARROWHEAD_WIDTH;
  double ratio=ARROWHEAD_RATIO;
  pair dir = c2s(head - tail);
  /*
    P((head.x1 - tail.x1)*h_size/x_size,
    (head.x2 - tail.x2)*v_size/y_size);
  */

  if ( width*ratio < true_len(dir) )
    {
      if (path_style == DOTTED)
	bold;
      start_path(path_style);
      draw_shaft(tail, head, width);
      if (path_style == DOTTED)
	endbold;
    }
  start_path(PLAIN);
  draw_arrowhead(tail, head, width);
}

void
draw_boldarrow(pair tail, pair head)
{
  double width=ARROWHEAD_WIDTH;
  double ratio=ARROWHEAD_RATIO;
  pair dir = c2s(head - tail);

  if ( width*ratio < true_len(dir) )
    {
      bold;
      start_path(BOLD);
      draw_shaft(tail, head, width);
      endbold;
    }
  fprintf (stdout, "\n");
  fill;
  start_path(PLAIN);
  draw_arrowhead(tail, head, width);
}

void
arrow(pair tail, pair head)
{
  comment_line("arrow", tail, head);
  draw_arrow(tail, head, PLAIN);
  end_stanza();
}

void
dasharrow(pair tail, pair head)
{
  comment_line("dasharrow", tail, head);
  draw_arrow(tail, head, DASHED);
  end_stanza();
}

void
dotarrow(pair tail, pair head)
{
  comment_line("dotarrow", tail, head);
   draw_arrow(tail, head, DOTTED);
   end_stanza();
}

void
boldarrow(pair tail, pair head)
{
  comment_line("boldarrow", tail, head);
  draw_boldarrow(tail, head);
  end_stanza();
}

/* Small arrows: "dart"s. Same as arrows with head half size */
void
draw_dart(pair tail, pair head, const int path_style)
{
  double width=0.5*ARROWHEAD_WIDTH;
  double ratio=ARROWHEAD_RATIO;
  pair dir = c2s(head - tail);

  if ( width*ratio < true_len(dir) )
    {
      if (path_style == DOTTED)
	bold;
      start_path(path_style);
      draw_shaft(tail, head, width);
      if (path_style == DOTTED)
	endbold;
    }
  start_path(PLAIN);
  draw_arrowhead(tail, head, width);
}

void
draw_bolddart(pair tail, pair head)
{
  double width=0.5*ARROWHEAD_WIDTH;
  double ratio=ARROWHEAD_RATIO;
  pair dir = c2s(head - tail);

  if ( width*ratio < true_len(dir) )
    {
      bold;
      start_path(BOLD);
      draw_shaft(tail, head, width);
      endbold;
    }
  fprintf (stdout, "\n");
  fill;
  start_path(PLAIN);
  draw_arrowhead(tail, head, width);
}

void
dart(pair tail, pair head)
{
  comment_line("dart", tail, head);
  draw_dart(tail, head, PLAIN);
  end_stanza();
}

void
dashdart(pair tail, pair head)
{
  comment_line("dashdart", tail, head);
  draw_dart(tail, head, DASHED);
  end_stanza();
}

void
dotdart(pair tail, pair head)
{
  comment_line("dotdart", tail, head);
   draw_dart(tail, head, DOTTED);
   end_stanza();
}

void
bolddart(pair tail, pair head)
{
  comment_line("bolddart", tail, head);
  draw_bolddart(tail, head);
  end_stanza();
}
