/* 
 * objects.cc -- Simple picture objects: axes, grids, markers, polygons
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc10
 * Last Change: May 27, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstdarg>

#include "globals.h"
#include "pairs.h"
#include "camera.h"
#include "output.h"
#include "objects.h"

namespace ePiX {

  extern double h_size, v_size, h_offset, v_offset;
  extern double x_min, x_max, y_min, y_max, x_size, y_size;
  extern double pic_size;
  extern char *pic_unit;

  extern double epix_stretch_factor;
  extern double epix_angle_units;
  extern epix_camera camera;
  extern epix_path_style EPIX_PATH_STYLE;

  // Picture objects

  /*
   * label -- put basepoint-aligned string constant <label_text> 
   * at Cartesian position <base> translated by <offset> true points.
   */
  // triple location
  void label(triple base, triple offset, char *label_text)
  {
    // compute position in picture coords
    fprintf (stdout, "\n\\put");
    print(base, offset);
    fprintf (stdout, "{%s}", label_text);
    end_stanza();
  }
  void masklabel(triple base, triple offset, char *label_text)
  {
    fprintf (stdout, "\n\\put");
    print(base, offset);
    fprintf (stdout, "{\\colorbox{white}{%s}}", label_text);
    end_stanza();
  }

  // labels with LaTeX-style alignment
  static void print_epix_label_posn(epix_label_posn POSN)
  {
    switch(POSN) {
    case c:
      fprintf (stdout, "[c]");
      break;

    case t:
      fprintf (stdout, "[b]"); // N.B. Reversal of LaTeX meaning
      break;

    case tr: // fall through
    case rt:
      fprintf (stdout, "[bl]");
      break;

    case r:
      fprintf (stdout, "[l]");
      break;

    case br:
    case rb:
      fprintf (stdout, "[tl]");
      break;

    case b: 
      fprintf (stdout, "[t]");
      break;

    case bl:
    case lb:
      fprintf (stdout, "[tr]");
      break;

    case l: 
      fprintf (stdout, "[r]");
      break;

    case tl:
    case lt: 
      fprintf (stdout, "[br]");
      break;

    default:
      fprintf (stderr, "Label alignment error: unknown option\n");   
    }
  }

  void label(triple base, triple offset, 
	     char *label_text, epix_label_posn POSN)
  {
    fprintf (stdout, "\n\\put");
    print(base, offset);
    fprintf (stdout, "{\\makebox(0,0)");
    print_epix_label_posn(POSN);
    fprintf (stdout, "{%s}}", label_text);

    end_stanza();
  }
  void masklabel(triple base, triple offset, 
		 char *label_text, epix_label_posn POSN)
  {
    fprintf (stdout, "\n\\put");
    print(base, offset);
    fprintf (stdout, "{\\makebox(0,0)");
    print_epix_label_posn(POSN);
    fprintf (stdout, "{\\colorbox{white}{%s}}}", label_text);

    end_stanza();
  }

  // centered labels
  void label(triple base, char *label_text)
  {
    fprintf (stdout, "\n\\put");
    print (base); // convert to picture coordinates
    fprintf (stdout, "{\\makebox(0,0){%s}}", label_text);
    end_stanza();
  }
  void
  masklabel(triple base, char *label_text)
  {
    fprintf (stdout, "\n\\put");
    print (base); // convert to picture coordinates
    fprintf (stdout, "{\\makebox(0,0){\\colorbox{white}{%s}}}", label_text);

    end_stanza();
  }

  void marker(triple arg, epix_mark_type MARK)
  {
    switch(MARK) {
    case PATH:
      print(arg);
      break;

    case CIRC:  
      fprintf (stdout, "\n\\whiten\\put");
      print(arg);
      fprintf (stdout, "{\\circle{%.3f}}", t2p(EPIX_SPOT_DIAM));
      break;

    case SPOT:   
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\makebox(0,0){$\\bullet$}}");
      break;

    case RING:   
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\circle{%.3f}}", t2p(EPIX_SPOT_DIAM));
      break;

    case DOT:   
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\circle*{%.3f}}", t2p(EPIX_DOT_DIAM));
      break;

    case DDOT:
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\circle*{%.3f}}", t2p(EPIX_DDOT_DIAM));
      break;

    case PLUS:
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\makebox(0,0){+}}");
      break;

    case OPLUS:
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\makebox(0,0){$\\oplus$}}");
      break;

    case TIMES:
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\makebox(0,0){$\\times$}}");
      break;

    case OTIMES:
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\makebox(0,0){$\\otimes$}}");
      break;

    case DIAMOND:
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\makebox(0,0){$\\diamond$}}");
      break;

    case UP:
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\makebox(0,0){$\\bigtriangleup$}}");
      break;

    case DOWN:
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\makebox(0,0){$\\bigtriangledown$}}");
      break;

    case BOX:   
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\kern -2pt \\rule[-2pt]{%gpt}{%gpt}}",
	       EPIX_BOX_SIZE, EPIX_BOX_SIZE);
      break;

    case BBOX:   
      fprintf (stdout, "\n\\put");
      print(arg);
      fprintf (stdout, "{\\kern -1pt \\rule[-1pt]{%gpt}{%gpt}}",
	       EPIX_BBOX_SIZE, EPIX_BBOX_SIZE);
      break;

    default: 
      break;
    }
  }

  // Marker aliases
  void circ(triple arg)
  {
    epix_comment("circ");
    marker(arg, CIRC);
    end_stanza();
  }  

  void ring(triple arg, double r)
  {
    epix_comment("ring");
    fprintf (stdout, "\n\\put");
    print(arg);
    fprintf (stdout, "{\\circle{%g}}", (r*EPIX_SPOT_DIAM/4)/p2t(1.0));
    end_stanza();
  }  

  void spot(triple arg)
  {
    epix_comment("spot");
    marker(arg, SPOT); // LaTeX bullet
    end_stanza();
  }  

  void dot(triple arg)
  {
    epix_comment("dot");
    marker(arg, DOT);
    end_stanza();
  }

  void ddot(triple arg)
  {
    epix_comment("ddot");
    marker(arg, DDOT);
    end_stanza();
  }

  void dot(triple arg, double r) // filled circ of specified diam
  {
    epix_comment("dot");
    fprintf (stdout, "\n\\put");
    print(arg);
    fprintf (stdout, "{\\circle*{%g}}", (r*EPIX_SPOT_DIAM/4)/p2t(1.0));
    end_stanza();
  }  

  // Axis ticks (h_tick = tall, thin rectangle, for a *horizontal* axis)

  static void h_tick(void)
  {
    fprintf (stdout, "{\\kern -0.25pt \\rule[-2pt]{0.5pt}{4pt}}");
  }
  static void v_tick(void)
  {
    fprintf (stdout, "{\\kern -2pt \\rule[-0.25pt]{4pt}{0.5pt}}");
  }

  void h_axis_tick(triple arg)
  {
    fprintf (stdout, "\n\\put");
    print(arg);
    h_tick();
  }

  void v_axis_tick(triple arg)
  {
    fprintf (stdout, "\n\\put");
    print(arg);
    v_tick();
  }

  // Coordinate axes
  static void 
  draw_axis(triple tail, triple head, int n, int num_pts, epix_tick_type TICK)
  {
    triple location = tail;
    triple step  = (1.0/num_pts)*(head - tail);

    // axis: print num_pts segments
    start_path();
    for (int i=0; i <= num_pts; ++i, location += step)
      {
        print(location);
        line_break(i, num_pts);
      }
  
    fprintf (stdout, "\n%%%% tick marks:\n%%%%");

    // use multiput for output if camera lens seems to be linear along axis
    if (view(tail) + (1.0/n)*(view(head)-view(tail)) == 
	view(tail  + (1.0/n)*(head-tail)))
	// n*view((1.0/n)*(head-tail))-view(P(0,0,0)) == view(head)-view(tail)
      {
	fprintf (stdout, "\n\\multiput");
	print(tail);
	print_vector((1.0/n)*(head-tail));
	fprintf (stdout, "{%d}", n+1);

	if (TICK == H_AXIS)
	  h_tick();

	else if (TICK == V_AXIS)
	  v_tick();

	else // epix_tick_type == NULL or unknown
	  ;
      }

    else // lens is non-linear along axis, print individual tick marks
      {
	location = tail;
	step  = (1.0/n)*(head - tail); // print n tick marks

	if (TICK == H_AXIS)
	  for (int i=0; i <= n; ++i, location += step)
	    h_axis_tick(location);

	else if (TICK == V_AXIS)
	  for (int i=0; i <= n; ++i, location += step)
	    v_axis_tick(location);

	else // TICK == NULL or unknown
	  ;
      }

    end_stanza();
  }

  /*
  void h_axis(triple tail, triple head, int n)
  {
    if (n < 1)
      fprintf (stderr, "WARNING: Ignoring h_axis with fewer than 2 ticks\n");

    else
      {
	epix_comment("horizontal axis");
	draw_axis(tail, head, n, n, H_AXIS);
      }
  }

  void v_axis(triple tail, triple head, int n)
  {
    if (n < 1)
      fprintf (stderr, "WARNING: Ignoring v_axis with fewer than 2 ticks\n");

    else
      {
	epix_comment("vertical axis");
	draw_axis(tail, head, n, n, V_AXIS);
      }
  }
  */

  // Suitable for curved axes
  void h_axis(triple tail, triple head, int n, int num_pts)
  {
    if (n < 1 || num_pts < 1)
      fprintf (stderr, "WARNING: Ignoring h_axis with fewer than 2 ticks\n");

    else
      {
	epix_comment("horizontal axis");
	draw_axis(tail, head, n, num_pts, H_AXIS);
      }
  }
  void v_axis(triple tail, triple head, int n, int num_pts)
  {
    if (n < 1 || num_pts < 1)
      fprintf (stderr, "WARNING: Ignoring v_axis with fewer than 2 ticks\n");

    else
      {
	epix_comment("vertical axis");
	draw_axis(tail, head, n, num_pts, V_AXIS);
      }
  }

  /*
   * h_axis_labels: Draws n+1 equally-spaced axis labels between 
   *    <tail> and <head>. Automatically generates label values from
   *    Cartesian coordinates, and has true-distance offsets.
   *
   * There is a separate version that takes a LaTeX-style alignment argument.
   * The "unaligned" version tries to do constant alignment with labels that
   * may or may not have a sign. It was easier to write a new routine to
   * handle labels with an alignment option than to modify the existing one.
   */

  static void
  draw_axis_labels(triple tail, triple head, int n, triple offset, 
		   epix_tick_type TICK, bool mask)
  {
    int neg_flag;
    double label;
    triple current = tail;
    triple step = (1.0/n)*(head - tail);

    // determine if labels change sign (may be needed for alignment)
    if (TICK == H_AXIS && head.x1*tail.x1 < 0)
      neg_flag=1;
    else if (TICK == V_AXIS && head.x2*tail.x2 < 0)
      neg_flag=1;
    else
      neg_flag=0;

    for (int i=0; i<= n; ++i, current += step)
      {
	// Compute proper type of label
	if (TICK == H_AXIS)
	  label = current.x1;

	else if (TICK == V_AXIS)
	  label = current.x2;

	else // stub for future "z-axis" labelling...
	  ;

	fprintf (stdout, "\n\\put");
	print(current, offset);

	// Put sign on label?
	if (neg_flag && label >= 0)
	  {
	    // Let TeX worry about the non-existent "-"
	    fprintf (stdout, "{$\\phantom{-}");
	    // mask label?
	    if (mask == false)
	      fprintf (stdout, "%g$}" , label);
	    else // N.B. Excess "}" ------------------- v
	      fprintf (stdout, "$\\colorbox{white}{$%g$}}" , label);
	  }
	else
	  {
	    if (mask == false)
	      fprintf (stdout, "{$%g$}" , label);
	    else
	      fprintf (stdout, "{\\colorbox{white}{$%g$}}" , label);
	  }
      }
    end_stanza();
  }

  void h_axis_labels(triple tail, triple head, int n, triple offset)
  {
    epix_comment("horizontal axis labels");
    draw_axis_labels(tail, head, n, offset, H_AXIS, false);
  }
  void v_axis_labels(triple tail, triple head, int n, triple offset)
  {
    epix_comment("vertical axis labels");
    draw_axis_labels(tail, head, n, offset, V_AXIS, false);
  }
  void h_axis_masklabels(triple tail, triple head, int n, triple offset)
  {
    epix_comment("masked horizontal axis labels");
    draw_axis_labels(tail, head, n, offset, H_AXIS, true);
  }
  void v_axis_masklabels(triple tail, triple head, int n, triple offset)
  {
    epix_comment("masked vertical axis labels");
    draw_axis_labels(tail, head, n, offset, V_AXIS, true);
  }

  // axis labels with alignment option
  static void
  draw_axis_labels(triple tail, triple head, int n, triple offset, 
		   epix_tick_type TICK, bool mask, epix_label_posn POSN)
  {
    double label;
    triple current = tail;
    triple step = (1.0/n)*(head-tail);

    for (int i=0; i<= n; ++i, current += step)
      {
	// Compute proper type of label
	if (TICK == H_AXIS)
	  label = current.x1;
	else // V_AXIS
	  label = current.x2;

	fprintf (stdout, "\n\\put");
	print(current, offset);
	fprintf (stdout, "{\\makebox(0,0)");
	print_epix_label_posn(POSN);
	if (mask == false)
	  fprintf (stdout, "{$%g$}}" , label);
	else
	  fprintf (stdout, "{\\colorbox{white}{$%g$}}}" , label);
      }
    end_stanza();
  }

  void h_axis_labels(triple tail, triple head, int n, triple offset, 
		     epix_label_posn POSN)
  {
    epix_comment("aligned horizontal axis labels");
    draw_axis_labels(tail, head, n, offset, H_AXIS, false, POSN);
  }
  void v_axis_labels(triple tail, triple head, int n, triple offset, 
		     epix_label_posn POSN)
  {
    epix_comment("aligned vertical axis labels");
    draw_axis_labels(tail, head, n, offset, V_AXIS, false, POSN);
  }
  void h_axis_masklabels(triple tail, triple head, int n, triple offset, 
			 epix_label_posn POSN)
  {
    epix_comment("masked, aligned horizontal axis labels");
    draw_axis_labels(tail, head, n, offset, H_AXIS, true, POSN);
  }
  void v_axis_masklabels(triple tail, triple head, int n, triple offset, 
			 epix_label_posn POSN)
  {
    epix_comment("masked, aligned vertical axis labels");
    draw_axis_labels(tail, head, n, offset, V_AXIS, true, POSN);
  }

  // Simple geometric objects

  // Lines take a stretch factor, roughly in percent
  void draw_line(triple tail, triple head, int n, double expand)
  {
    double c = expm1(M_LN2*expand/100.0); // 2^{expand/100} - 1
    triple direction = head - tail;

    start_path();

    // Ensure at least two points printed
    n = abs(n);
    if (n<1)
      n=1;

    if (EPIX_PATH_STYLE != SOLID)
      {
	pair d_posn = view(head) - view(tail); // displacement in screen plane
	double dist = raw_len(p2t(c2s((1+c)*d_posn))); // displacement in true pt

	// default to one printed point every 12 (true printers') points
	n = (int) ceil(dist/(12*epix_stretch_factor));
      }

    triple pt = tail - (0.5*c)*direction;
    triple step = ((1+c)/n)*direction; // displacement of stretched line

    for (int i=0; i<=n; ++i, pt += step)
      {
	print(pt);
	line_break(i,n);
      }
  }

  // Lines with expansion factor
  void line(triple tail, triple head, double expand)
  {
    epix_comment("stretched line");
    draw_line(tail, head, 1, expand);
    end_stanza();
  }

  // Unstretched lines
  void line(triple tail, triple head)
  {
    epix_comment("unstretched line");
    draw_line(tail, head, 1, 0);
    end_stanza();
  }

  /*
   * Returns positive iff vertices (p0,p1,p2) are counterclockwise.
   * Cyclic permutation of parameters has no effect on sign of return value.
   */
  double ccw(triple arg0, triple arg1, triple arg2)
  {
    pair p0 = view(arg0);
    pair p1 = view(arg1);
    pair p2 = view(arg2);

    double d = truncate(p2.x1 - p1.x1);
    if ( d != 0)
      return truncate(p0.x2 - p1.x2 - (p2.x2 - p1.x2)*(p0.x1 - p1.x1)/d);
    else
      return truncate(p1.x1 - p0.x1);
  }

  /*
   * Line(p1, p2) -- Portion of line (p1,p2) that lies in clip_box
   *
   * Algorithm: Consider the line parametrized by arg1 + t*(arg2-arg1),
   * and find the times at which this line crosses the planes bounding
   * the clip_box (if applicable). Take the maximum minimum time (t_min)
   * and the minimum maximum time (t_max). If t_min < t_max, the param
   * line passes through the clip_box, otherwise not.
   */

  static inline double min(double a, double b)
  {
    if (a < b) return a;
    else return b;
  }
  static inline double max(double a, double b)
  {
    if (a > b) return a;
    else return b;
  }

  void draw_Line(triple arg1, triple arg2, int n)
  {
    // entry, exit times
    double t_min, t_max;
    double t1_min, t1_max, t2_min, t2_max, t3_min, t3_max;
    double temp1, temp2;
    triple dir = arg2 - arg1;

    if (dir.x1 != 0)
      {
	temp1 = (clip1_max - arg1.x1)/dir.x1;
	temp2 = (clip1_min - arg1.x1)/dir.x1;

	t1_min = min(temp1, temp2);
	t1_max = max(temp1, temp2);
      }
    else
      {
	// is Line between bounding planes?
	if (clip1_min <= arg1.x1 && arg1.x1 <= clip1_max)
	  {
	    t1_min = -EPIX_INFTY;
	    t1_max =  EPIX_INFTY;
	  }
	else // Line is empty
	  return;
      }

    if (dir.x2 != 0)
      {
	temp1 = (clip2_max - arg1.x2)/dir.x2;
	temp2 = (clip2_min - arg1.x2)/dir.x2;

	t2_min = min(temp1, temp2);
	t2_max = max(temp1, temp2);
      }
    else
      {
	if (clip2_min <= arg1.x2 && arg1.x2 <= clip2_max)
	  {
	    t2_min = -EPIX_INFTY;
	    t2_max =  EPIX_INFTY;
	  }
	else // Line is empty
	  return;
      }

    if (dir.x3 != 0)
      {
	temp1 = (clip3_max - arg1.x3)/dir.x3;
	temp2 = (clip3_min - arg1.x3)/dir.x3;

	t3_min = min(temp1, temp2);
	t3_max = max(temp1, temp2);
      }
    else
      {
	if (clip3_min <= arg1.x3 && arg1.x3 <= clip3_max)
	  {
	    t3_min = -EPIX_INFTY;
	    t3_max =  EPIX_INFTY;
	  }
	else // Line is empty
	  return;
      }

    t_min = max(t1_min, t2_min);
    t_min = max(t_min, t3_min);
    
    t_max = min(t1_max, t2_max);
    t_max = min(t_max, t3_max);
    
    if (t_min < t_max) // Line is non-empty
      {
	triple tail = arg1 + t_min*dir;
	triple head = arg1 + t_max*dir;

	draw_line(tail, head, n, 0);
      }

    else // do nothing
      ;
  }

  void
  Line(triple tail, triple head)
  {
    epix_comment("Line");
    int n=1;
    if (EPIX_PATH_STYLE != SOLID)
      {
	double true_dist = p2t(raw_len(c2s(view(head)-view(tail))));
	n = (int) ceil(true_dist/(12*epix_stretch_factor));
      }
    draw_Line(tail, head, n);
    end_stanza();
  }

  // point-slope form
  void
  Line(triple tail, double slope)
  {
    Line(tail, tail+P(1, slope, 0));
  }


  // triangles
  void triangle(triple arg1, triple arg2, triple arg3)
  {
    epix_comment("triangle");
    draw_triangle(arg1, arg2, arg3);
    end_stanza();
  }

  // quadrilaterals
  void quad(triple arg1, triple arg2, triple arg3, triple arg4)
  {
    epix_comment("quadrilateral");
    draw_quad(arg1, arg2, arg3, arg4);
    end_stanza();
  }

  /* 
   * Draw coordinate rectangle with opposite corners as given. Arguments
   * must lie is a plane parallel to a coordinate plane, but not on a 
   * line parallel to a coordinate axis.
   */
  void draw_rect(triple arg1, triple arg2)
  {
    triple diagonal = arg2 - arg1;
    triple jump;
    int perp_count = 0;

    // count coordinate axes diagonal is perp to and flag normal
    if (fabs(diagonal|E_1) < EPIX_EPSILON)
      {
	++perp_count;
	jump = E_2&(diagonal);
      }
    if (fabs(diagonal|E_2) < EPIX_EPSILON)
      {
	++perp_count;
	jump = E_3&(diagonal);
      }
    if (fabs(diagonal|E_3) < EPIX_EPSILON)
      {
	++perp_count;
	jump = E_1&(diagonal);
      }

    if (perp_count != 1)
      fprintf (stderr, "WARNING: Cannot draw rectangle\n");

    else // jump set exactly once; compute vertices and draw rectangle
      draw_quad(arg1, arg1+jump, arg2, arg2-jump);
  }

  void rect(triple arg1, triple arg2)
  {
    epix_comment("coordinate rectangle");
    draw_rect(arg1, arg2);
    end_stanza();
  }

  void swatch(triple arg1, triple arg2)
  {
    solid();
    epix_comment("shaded coordinate rectangle (\"swatch\")");
    fprintf (stdout, "\n\\shade");
    draw_rect(arg1, arg2);
    end_stanza();
  }

  // polygon specified by number of points and list of vertices
  // draw_polygon prints data points only (for pstricks...)
  // polygon is closed, polyline is not
  void draw_polygon(int num_pts ...)
  {
    va_list ap;
    va_start(ap, num_pts);
  
    triple* curr;

    triple* p1 = va_arg(ap, triple*);

    std::cout << "\n";
//    print(p1);
    print(*p1);

    for (int i=1; i <= num_pts-1; ++i) {
      curr = va_arg(ap, triple*);
      print(*curr);

      line_break(i, num_pts);
    }

    va_end(ap);

    print(*p1); // close path
  }

  void polygon(int num_pts ...)
  {
    epix_comment("polygon");
    start_path();

    va_list ap;
    va_start(ap, num_pts);
  
    triple* curr;

    triple* p1 = va_arg(ap, triple*);
    print(*p1);
//    print(p1);

    for (int i=1; i <= num_pts-1; ++i) {
      curr = va_arg(ap, triple*);
      print(*curr);

      line_break(i, num_pts);
    }

    va_end(ap);
    print(*p1); // close path
    end_stanza();
  }

  void polyline(int num_pts ...)
  {
    epix_comment("polyline");
    start_path();

    va_list ap;
    va_start(ap, num_pts);
  
    triple* curr;

//    print(p1);

    for (int i=1; i <= num_pts; ++i) {
      curr = va_arg(ap, triple*);
      print(*curr);

      line_break(i, num_pts);
    }

    va_end(ap);
    end_stanza();
  }

  // eepic.sty has an \ellipse function; native_ellipse() accesses it.
  // Provided only for compatibility
  void draw_native_ellipse(triple center, triple radius)
  {
    triple diam = 2*radius;
    pair screen_radius = c2s(pair(diam.x1, diam.x2));

    fprintf (stdout, "\n\\put");
    print(center);
    fprintf (stdout, "{\\ellipse{%g}{%g}}",screen_radius.x1,screen_radius.x2);
  }

  // User-callable draw_ellipse is identical, in curves.cc
  static void draw_ellipse(triple center, triple axis1, triple axis2, 
			   int num_pts=EPIX_NUM_PTS)
  {
    triple current;

    start_path();
    for (int i=0; i <= 2*num_pts; ++i) 
      {
	current = center + 
	  ePiX::cos(M_PI*i/(num_pts*epix_angle_units)) * axis1 +
	  ePiX::sin(M_PI*i/(num_pts*epix_angle_units)) * axis2;
	print(current);

	line_break(i, 2*num_pts);
      }
  }  

  void 
  native_ellipse(triple center, triple radius)
  {
    fprintf (stderr, "WARNING: native_ellipse is strongly deprecated\n");
    epix_comment("native ellipse");
    draw_native_ellipse(center, radius);
    end_stanza();
  }

  // n1 x n2 Cartesian grid, where coarse = (n1, n2)
  void draw_grid(triple arg1, triple arg2, mesh coarse, mesh fine)
  {
    triple diagonal = arg2 - arg1;
    triple jump1, jump2; // sides of grid

    int perp_count = 0;

    // count coordinate axes diagonal is perp to and flag normal
    if (fabs(diagonal|E_1) < EPIX_EPSILON)
      {
	++perp_count;
	jump1 = E_2&diagonal;
	jump2 = E_3&diagonal;

      }
    if (fabs(diagonal|E_2) < EPIX_EPSILON)
      {
	++perp_count;
	jump1 = E_3&diagonal;
	jump2 = E_1&diagonal;
      }
    if (fabs(diagonal|E_3) < EPIX_EPSILON)
      {
	++perp_count;
	jump1 = E_1&diagonal;
	jump2 = E_2&diagonal;
      }

    if (perp_count != 1)
      fprintf (stderr, "WARNING: Ignoring degenerate coordinate grid\n");

    else
      {
	// grid line spacing
	triple grid_step1 = (1.0/coarse.n1)*jump1;
	triple grid_step2 = (1.0/coarse.n2)*jump2;

	fprintf (stdout, "\n%%%%   Vertical lines");
	for (int i=0; i <= coarse.n1; ++i)
	  draw_line(arg1+i*grid_step1, arg1+i*grid_step1+jump2, fine.n2, 0);

	fprintf (stdout, "\n%%%%   Horizontal lines");
	for (int j=0; j <= coarse.n2; ++j)
	  draw_line(arg1+j*grid_step2, arg1+j*grid_step2+jump1, fine.n1, 0);
      }
  }

  // Grids that fill bounding_box with default camera
  void grid(int n1, int n2)
  {
    fprintf (stdout, "\n%%%% grid:");
    draw_grid(P(x_min, y_min), P(x_max, y_max), Net(n1, n2), Net(n1, n2));
    end_stanza();
  }

  // Grids of arbitrary size
  void grid(triple arg1, triple arg2, int n1, int n2)
  {
    fprintf (stdout, "\n%%%% grid:");
    draw_grid(arg1, arg2, Net(n1,n2), Net(n1,n2));
    end_stanza();
  }

  // Grid of arbitrary mesh and resolution
  void grid(triple arg1, triple arg2, mesh coarse, mesh fine)
  {
    fprintf (stdout, "\n%%%% grid:");
    draw_grid(arg1, arg2, coarse, fine);
    end_stanza();
  }

  // polar grid with specified radius, mesh (rings and sectors), and resolution
  void draw_polar_grid(double radius, mesh coarse, mesh fine)
  {
    fprintf (stdout, "\n%%%%   rings\n%%%%"); 
    for (int i=1; i <= coarse.n1; ++i) 
      draw_ellipse(P(0,0,0), 
		   i*(radius/coarse.n1)*E_1, 
		   i*(radius/coarse.n1)*E_2, 
		   fine.n2);

    fprintf (stdout, "\n%%%%   radii\n%%%%");  
    for (int j=0; j < coarse.n2; ++j)
      {
	draw_line(P(0,0,0), 
		  polar(radius, 2*M_PI*j/(epix_angle_units*coarse.n2)), 
		  2*fine.n1, 0);
	if (j<coarse.n2-1)
	  fprintf (stdout, "\n%%%%");
      }
  }

  void polar_grid(double radius, mesh coarse, mesh fine)
  {
    epix_comment("polar grid");
    draw_polar_grid(radius, coarse, fine);
    end_stanza();
  }

  void polar_grid(double radius, int n1, int n2)
  {
    epix_comment("polar grid");
    draw_polar_grid(radius, Net(n1,n2), Net(n1,n2));
    end_stanza();
  }

  /* 
   * Arrows joining two specified <triple>s. An arrow consists of a head
   * and a shaft; the head is a cone 2*width true points wide and width*ratio
   * true points high (in perpendicular), while the shaft is long enough to
   * join the <tail> to <base> (see below). If the projection of the arrow
   * is so short that the <tail> would be inside the arrowhead (with head
   * at <tip3>), the shaft is not drawn. 
   *
   * Vertices of arrow:
   *
   *                       <tip1>
   * <tail> ====shaft====  <base>    <tip3> (aka <head>)
   *                       <tip2>
   *
   * Some of the points defining an arrowhead must be computed from true 
   * coords, since the aspect ratio of a figure is not generally unity. 
   * The algorithm is:
   *
   * (1) Find Cartesian direction vector from <tail> to <head>, and
   *    convert it to picture coords. Find the cosine of the angle between
   *    camera.eye and the Cartesian direction vector; call this cos_theta.
   *
   * (2) If the true length of the printed arrow is less than the height of 
   *    a tilted arrowhead, put <base> at <tail> and do not draw the shaft.
   *    Otherwise, put <tip3> at <head> and calculate <base> so that
   *    <tip3 - base> projects to a vector of true length width*ratio*sin_theta
   *    in the screen plane.
   *
   * (3) Find a vector in page coordinates that is perpendicular to the
   *    <direction> and is 2 true pt long. Lift to object space, using the
   *    {sea, sky, eye} coordinates of the camera, and find <tip1>, <tip2>.
   *
   * (4) Now we're ready to draw. For simplicity, use PostScript layering.
   * (a) If the arrow points away from the camera, draw segments from <tip3>
   *    to <tip1> and <tip2>, then draw a filled white ellipse (the base of
   *    the arrowhead), then draw the shaft up to <base>.
   * (b) If the arrow points toward the camera, draw the shaft, then draw a
   *    black-filled circle through <tip1> and <tip2>, then white fill the
   *    region enclosed by the appropriate semi-circle and the polygon
   *    <tip1>, <tip3>, <tip2>. (These circles are perpendicular to the
   *    shaft in object space, and are usually rendered as ellipses.)
   *
   * As with other polygon objects, draw_arrowhead and draw_shaft print
   * only lists of coordinate pairs, not line styles, etc. draw_arrow is the
   * user analogue of draw_rect (e.g.); it draws the requisite paths and
   * nothing else. This division of labor  allows the pieces to be used in
   * other functions, e.g., plots of tangent vectors to a parametrized curve.
   *
   */
  void draw_arrowhead(triple tail, triple head, double width, double scale)
  {
    // may assume head-tail is not the zero vector in object/screen
    double ratio=EPIX_ARROWHEAD_RATIO;
    width *= fabs(scale); // introduce overall scale

    triple tip1, tip2, tip3, base;
    triple object_dir = head - tail;
    double cos_theta = (object_dir|get_eye(camera))/norm(object_dir);
    double sin_theta = sqrt(1 - cos_theta*cos_theta);
    double arrowhead_height = sin_theta*width*ratio; // in true pt

    pair screen_dir = view(head) - view(tail);
    pair picture_dir = c2s(screen_dir);
    double true_sep = true_length(picture_dir); // in true pt

    triple object_unit = (1.0/true_sep)*object_dir; // projects to 1 true pt

    if (arrowhead_height  < true_sep) // <tail> outside arrowhead
      {
	tip3 = head;
	base = tip3 - arrowhead_height*object_unit;
      }

    else // <tail> inside arrowhead
      {
	base = tail;
	tip3 = base + arrowhead_height*object_unit;
      }

    // compute page normals in object coordinates
    // 1 true pt, in picture coords
    pair picture_perp = (1.0/true_sep)*J(picture_dir); 
    pair screen_perp  = s2c(picture_perp);

    // object, projects to 1 true pt normal
    triple object_perp = ((screen_perp.x1)*get_sea(camera)) +
      ((screen_perp.x2)*get_sky(camera));

    triple object_perp2 = -cos_theta*object_unit;

    tip1 = base + width*object_perp;
    tip2 = base - width*object_perp;

    // Hardwired constant NUM_BASE
    // draw arrowhead...
    const int NUM_BASE = 8 + (int)(4*ceil(fabs(scale)-1));

    if (cos_theta < -EPIX_EPSILON) // arrow points away
      {
	fprintf (stdout, "\n\\path");
	print(tip1);
	print(tip3);
	print(tip2);
	fprintf (stdout, "\n\\whiten\\path");
	for (int i=0; i <= NUM_BASE; ++i)
	  {
	    print(base + std::cos(2*i*M_PI/NUM_BASE)*width*object_perp +
		         std::sin(2*i*M_PI/NUM_BASE)*width*object_perp2);
	    line_break(i,NUM_BASE);
	  }
      }
    else if (cos_theta > EPIX_EPSILON) // arrow points toward
      {
	/*
	fprintf (stdout, "\n\\blacken\\path");
	for (int i=0; i <= NUM_BASE; ++i)
	  {
	    print(base + std::cos(2*i*M_PI/NUM_BASE)*width*object_perp + 
		         std::sin(2*i*M_PI/NUM_BASE)*width*object_perp2);
	    line_break(i, NUM_BASE);
	  }
	*/
	fprintf (stdout, "\n\\whiten\\path");
	print(tip2);
	print(tip3);
	print(tip1);
	fprintf (stdout, "\n");
	// draw half-ellipse
	for (int i=0; i <= 0.5*NUM_BASE; ++i)
	  print(base + std::cos(2*i*M_PI/NUM_BASE)*width*object_perp +
		       std::sin(2*i*M_PI/NUM_BASE)*width*object_perp2);
      }
    else // shaft perp to camera.eye
      draw_triangle(tip1, tip2, tip3);
  }

  void draw_shaft(triple tail, triple head, double width, double scale)
  {
    double ratio=EPIX_ARROWHEAD_RATIO;
    width *= fabs(scale); // introduce overall scale

    triple base;
    triple object_dir = head - tail;
    double cos_theta = (object_dir|get_eye(camera))/norm(object_dir);
    double sin_theta = sqrt(1 - cos_theta*cos_theta);
    double arrowhead_height = sin_theta*width*ratio; // in true pt

    pair screen_dir = view(head) - view(tail);
    pair picture_dir = c2s(screen_dir);
    double true_sep = true_length(picture_dir); // in true pt

    triple object_unit = (1/true_sep)*object_dir; // projects to 1 true pt

    if (arrowhead_height  < true_sep) // <tail> outside arrowhead
	base = head - arrowhead_height*object_unit;
    else // <tail> inside arrowhead
      base = tail;

    print(tail);
    print(base);
  }

  void draw_arrow(triple tail, triple head, double scale)
  {
    triple direction = head - tail;
    pair screen_direction = view(head) - view(tail);

    // handle degenerate arrows
    if (norm(direction) < EPIX_EPSILON)
      marker(tail, BBOX);

    // arrow parallel to eye
    else if (raw_len(screen_direction) < 0.01*EPIX_EPSILON) 
      circ(head);

    // non-degenerate case
    else
      {
	double width=EPIX_ARROWHEAD_WIDTH;

	if ((direction|get_eye(camera)) < -EPIX_EPSILON) // arrow points away
	  {
	    draw_arrowhead(tail, head, width, scale);
	    start_path();
	    draw_shaft(tail, head, width, scale);
	  }
	else
	  {
	    start_path();
	    draw_shaft(tail, head, width, scale);
	    draw_arrowhead(tail, head, width, scale);
	  }
      }
  }

  void draw_boldarrow(triple tail, triple head, double scale)
  {
    draw_arrow(tail, head, scale);
  }

  void arrow(triple tail, triple head, double scale)
  {
    epix_comment("arrow");
    draw_arrow(tail, head, scale);
    end_stanza();
  }
  void boldarrow(triple tail, triple head, double scale)
  {
    epix_comment("bold arrow");
    draw_boldarrow(tail, head, scale);
    end_stanza();
  }

  // Small arrows: "dart"s. Same as arrows with head half size
  void draw_dart(triple tail, triple head)
  {
    draw_arrow(tail, head, 0.5);
    /*
    triple direction = head - tail;

    if (raw_len(direction) < EPIX_EPSILON)
      marker(tail, BBOX);

    else
      {
	double width=0.5*EPIX_ARROWHEAD_WIDTH;

	if ((direction|get_eye(camera)) < -EPIX_EPSILON) // arrow points away
	  {
	    draw_arrowhead(tail, head, width);
	    start_path();
	    draw_shaft(tail, head, width);
	  }
	else
	  {
	    start_path();
	    draw_shaft(tail, head, width);
	    draw_arrowhead(tail, head, width);
	  }
      }
    */
  }

  void dart(triple tail, triple head)
  {
    epix_comment("dart");
    draw_dart(tail, head);
    end_stanza();
  }
  void bolddart(triple tail, triple head)
  {
    dart(tail, head);
  }

} /* end of namespace */
