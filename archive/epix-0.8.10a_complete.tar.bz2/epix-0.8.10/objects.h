/* 
 * objects.h -- Simple picture objects: axes, grids, markers, polygons
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc10
 * Last Change: June 04, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_OBJECTS
#define _EPIX_OBJECTS

#include <cstdarg>

#include "pairs.h"
#include "segment.h"
#include "triples.h"
#include "output.h"

namespace ePiX {

  // Picture objects

  /*
   * label -- put string constant <label_text> at Cartesian position <base>
   * translated by (offset.x1, offset.x2) true points (i.e., 3rd component
   * of <offset> is discarded).
   *
   * Accepts an optional LaTeX-style positioning argument.
   * If no offset is specified, the label is centered at the given Cartesian
   * location.
   * masklabel requires the "color" package, and places the text in 
   * a white box that masks whatever is underneath and earlier in the file.
   */
  // location given as a <triple>
  void label(triple base, triple offset, char *label_text);
  void label(triple base, char *label_text);
  void label(triple base, triple offset, char *label_text,
	     epix_label_posn);

  void masklabel(triple base, triple offset, char *label_text);
  void masklabel(triple base, char *label_text);
  void masklabel(triple base, triple offset, char *label_text,
		 epix_label_posn);

  // Empty and filled LaTeX circles of diameter EPIX_SPOT_DIAM true pt
  void circ(triple); // filled white circ 4 pt in diameter
  void ring(triple, double); // unfilled circ of specified diam
  void spot(triple);
  void dot(triple);
  void ddot(triple);
  void dot(triple, double); // filled circ of specified diam
  void marker (triple, epix_mark_type);

  // Axes and coordinate grids.

  /* 
   * Coordinate axes, specified by initial and final points, number of
   * tick marks, and (optionally) number of points (for cameras that do
   * not map lines to lines). Generally num_pts should be a multiple of n.
   * h/v_axis are identical except for style of tick marks.
   */
  void h_axis_tick(triple location);
  void v_axis_tick(triple location);

  //  void h_axis(triple tail, triple head, int n);
  //  void v_axis(triple tail, triple head, int n);

  // n+1 = #ticks, num_pts = #segments used to draw
  void h_axis(triple tail, triple head, int n, int num_pts=1);
  void v_axis(triple tail, triple head, int n, int num_pts=1);

  // These versions may be used with gcc 2.96 and later
  /*
  inline void h_axis(int n=(int)x_size) { h_axis(P(x_min,0), P(x_max,0), n); }
  inline void v_axis(int n=(int)y_size) { v_axis(P(0,y_min), P(0,y_max), n); }
  */
  inline void h_axis(int n=x_size) { h_axis(P(x_min,0), P(x_max,0), n); }
  inline void v_axis(int n=y_size) { v_axis(P(0,y_min), P(0,y_max), n); }

  // n+1 = #ticks, num_pts = #segments used to draw
  inline void h_axis(int n, int num_pts) 
    { h_axis(P(x_min,0), P(x_max,0), n, num_pts); }
  inline void v_axis(int n, int num_pts) 
    { v_axis(P(0,y_min), P(0,y_max), n, num_pts); }

  /*
   * h_axis_labels: Draws n+1 equally-spaced axis labels between 
   *    <tail> and <head>. Automatically generates label values from
   *    Cartesian coordinates, and offsets labels in true pt.
   */

  void h_axis_labels(triple tail, triple head, int n, triple offset);
  void v_axis_labels(triple tail, triple head, int n, triple offset);

  void h_axis_masklabels(triple tail, triple head, int n, triple offset);
  void v_axis_masklabels(triple tail, triple head, int n, triple offset);

  // Axis labels with LaTeX-style alignment option

  void h_axis_labels(triple tail, triple head, int n, 
		     triple offset, epix_label_posn POSN);
  void v_axis_labels(triple tail, triple head, int n, 
		     triple offset, epix_label_posn POSN);

  void h_axis_masklabels(triple tail, triple head, int n, 
			 triple offset, epix_label_posn POSN);
  void v_axis_masklabels(triple tail, triple head, int n, 
			 triple offset, epix_label_posn POSN);

  // Axis labels with default endpoints
  inline void h_axis_labels(int n, triple offset)
    { h_axis_labels(P(x_min,0), P(x_max,0), n, offset); }
  inline void h_axis_masklabels(int n, triple offset)
    { h_axis_masklabels(P(x_min,0), P(x_max,0), n, offset); }

  inline void h_axis_labels(int n, triple offset, epix_label_posn POSN)
    { h_axis_labels(P(x_min,0), P(x_max,0), n, offset, POSN); }
  inline void h_axis_masklabels(int n, triple offset, epix_label_posn POSN)
    { h_axis_masklabels(P(x_min,0), P(x_max,0), n, offset, POSN); }


  inline void v_axis_labels(int n, triple offset)
    { v_axis_labels(P(0,y_min), P(0,y_max), n, offset); }
  inline void v_axis_masklabels(int n, triple offset)
    { v_axis_masklabels(P(0,y_min), P(0,y_max), n, offset); }

  inline void v_axis_labels(int n, triple offset, epix_label_posn POSN)
    { v_axis_labels(P(0,y_min), P(0,y_max), n, offset, POSN); }
  inline void v_axis_masklabels(int n, triple offset, epix_label_posn POSN)
    { v_axis_masklabels(P(0,y_min), P(0,y_max), n, offset, POSN); }



  // eepic.sty's ellipse comand
  void draw_native_ellipse (triple, triple);
  void native_ellipse (triple, triple);

  /*
   * A "mesh" is an ordered pair of positive integers, and is used to
   * specify the "fineness" of a mesh. Grids, like parametric surface
   * meshes, have a "coarse mesh" -- the numbers of grid intervals in
   * each direction, and a "fine mesh" -- the numbers of points used
   * to render the grid lines. Since an ePiX camera does not always
   * map lines in object space to lines on the screen, grid lines cannot
   * generally be drawn using only two points.
   * A grid may look strange unless each component of fine is a multiple
   * of the corresponding entry of coarse, of course. :)
   */

  // Cartesian grid of specified size, mesh, and resolution
  void draw_grid(triple arg1, triple arg2, mesh coarse, mesh fine);
  void grid(triple arg1, triple arg2, mesh coarse, mesh fine);

  // coarse = fine = (n1,n2)
  void grid(triple arg1, triple arg2, int n1, int n2);
  // arg1 = P(x_min, y_min), arg2 = P(x_max, y_max)
  void grid(int n1, int n2);

  // polar grid of specified radius, mesh (rings and sectors), and resolution
  void draw_polar_grid(double r, mesh coarse, mesh fine);
  void polar_grid(double r, mesh coarse, mesh fine);

  // polar grid with n1 rings and n2 sectors
  void polar_grid(double r, int n1, int n2);

  // Simple geometric objects

  // lines can be "stretched" by double parameter
  void draw_line(triple, triple, int, double); 

  // lines with stretch factor
  void line(triple, triple, double);     

  // Unstretched lines
  void line(triple, triple);    

  inline void draw(segment arg) { line(arg.end1(), arg.end2()); }

  // Returns >0 iff p0 is left of directed segment from p1 to p2
  double ccw(triple p0, triple p1, triple p2);
  // "Visible" portion of the line through p1, p2
  void draw_Line(triple, triple, int);
  void Line(triple, triple);

  // point-slope form
  void Line(triple, double);

  // triangles and quadrilaterals
  inline void draw_triangle(triple arg1, triple arg2, triple arg3)
  {
    start_path();
    print(arg1);
    print(arg2);
    print(arg3);
    print(arg1);
  }
  void triangle(triple, triple, triple);

  inline void draw_quad(triple arg1, triple arg2, triple arg3, triple arg4)
  {
    start_path();
    print(arg1);
    print(arg2);
    print(arg3);
    print(arg4);
    print(arg1);
  }
  void quad(triple, triple, triple, triple);

  void draw_rect(triple, triple); // opposite corners
  void rect(triple, triple);
  // filled rectangle
  void swatch(triple, triple);

  // polygon/polyline with variable number of vertices
  void draw_polygon(int num_pts ...); // data points only
  void polygon(int num_pts ...);
  void polyline(int num_pts ...);

  void draw_arrowhead(triple tail, triple head, double width, double scale=1);
  void draw_shaft(triple tail, triple head, double width, double scale=1);
  void draw_arrow(triple tail, triple head, double scale=1);
  void draw_boldarrow(triple tail, triple head, double scale=1);
  void arrow(triple tail, triple head, double scale=1);
  void boldarrow(triple tail, triple head, double scale=1);

  void draw_dart(triple, triple);
  void draw_bolddart(triple, triple);
  void dart(triple, triple);
  void bolddart(triple, triple);

} /* end of namespace */

#endif /* _EPIX_OBJECTS */
