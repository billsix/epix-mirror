/*
 * curves.h -- Ellipses, arcs, splines
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.10rc11
 * Last Change: June 04, 2003
 *
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_CURVES
#define _EPIX_CURVES

#include "globals.h"
#include "pairs.h"
#include "triples.h"

namespace ePiX {

  // Ellipses, half-ellipses, circular arcs, splines -- curves.c

  /* * * Deprecated functions * * */
  // Point-plotting functions
  void draw_half_ellipse (triple, triple);
  // Stanza-creating whole ellipse functions
  void draw_ellipse (triple, triple); 
  void ellipse (triple, triple);
  // Stanza-creating standard half-ellipse functions
  void draw_half_ellipse(triple, triple, double);
  void ellipse_left (triple, triple);
  void ellipse_right (triple, triple);
  void ellipse_top (triple, triple);
  void ellipse_bottom (triple, triple);
  // Right half ellipse rotated through <double> revolutions
  //  void rotate_half_ellipse(triple, triple, double);
  //  void ellipse_half (triple, triple, double);

  // Circular arcs parallel to (x,y)-plane
  void draw_arc (triple, double, double, double);

  void arc (triple, double, double, double);

  void draw_arc_arrow (triple center, double r, double start, double finish, 
		       double scale=1);
  void arc_arrow (triple center, double r, double start, double finish,
		  double scale=1);
  // End of deprecated functions

  /* * * 3-D ellipse functions * * */
  void draw_ellipse_arc(triple center, triple axis1, triple axis2, 
			double t_min, double t_max, int num_pts);
  void draw_ellipse(triple center, triple axis1, triple axis2, 
		    int num_pts=EPIX_NUM_PTS);
  void ellipse_arc(triple center, triple axis1, triple axis2, 
		   double t_min, double t_max, int num_pts);
  void ellipse(triple center, triple axis1, triple axis2, 
	       int num_pts=EPIX_NUM_PTS);

  // Quadratic and cubic splines
  void draw_spline(triple p1, triple p2, triple p3,
		   int num_pts=EPIX_NUM_PTS);
  void draw_spline(triple p1, triple p2, triple p3, triple p4,
		   int num_pts=EPIX_NUM_PTS);

  void spline (triple p1, triple p2, triple p3,
	       int num_pts=EPIX_NUM_PTS);
  void spline (triple p1, triple p2, triple p3, triple p4,
	       int num_pts=EPIX_NUM_PTS);

  /*
  // Knot diagram primitives
  void draw_under_strand(triple p3, triple p6, triple p5, triple p2);
  void draw_p_twist(triple p1, triple p4);
  void draw_n_twist(triple p1, triple p4);

  void p_twist (triple, triple);
  void n_twist (triple, triple);
  void twists (triple, triple, int);
  */

} /* end of namespace */

#endif /* _EPIX_CURVES */
