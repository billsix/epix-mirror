/*
 * legacy.h -- inlined functions for ePiX legacy features
 *
 * This file is part of ePiX, a preprocessor for creating high-quality
 * line figures in LaTeX
 *
 * Version 0.8.10
 *
 * Last change: April 23, 2003
 */

/*
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

/*
 * WARNING: The features provided by this file are unsupported and
 *   may be removed at any time.  Do not use these features in new 
 *   files, and consider porting old code.
 *
 * This file provides:
 *
 *   - {add,diff,mult}_pair
 *   - end_color();
 *   - {line,triangle,rect,swatch,ellipse{t,b,l,r},{quad,cubic}spline}()
 *   - {param,clip}plot{3d}()
 */

#ifndef _EPIX_LEGACY
#define _EPIX_LEGACY

#include <cstdio>
#include <cstdlib>

#include "globals.h"

#include "pairs.h"
#include "triples.h"
#include "lengths.h"
#include "output.h"
#include "objects.h"
#include "curves.h"

namespace ePiX_legacy {

  using namespace ePiX;

  inline void legacy_warn(const char *msg)
    { fprintf (stderr, "WARNING: Legacy function \"%s\"\n", msg); }

  inline void raw_print(triple arg)
    { fprintf (stdout, "(%.3f,%.3f,%.3f)", arg.x1, arg.x2, arg.x3); }

  /* Pair operations */
  inline pair add_pair(pair p1, pair p2) { return p1+p2; }
  inline pair diff_pair(pair p1, pair p2) { return p1-p2; }
  inline pair mult_s(double c, pair p2) { return c*p2; }
  inline pair mult_pair(pair p1, pair p2) { return p1*p2; }

  inline triple add_pair(triple p1, triple p2) { return p1+p2; }
  inline triple diff_pair(triple p1, triple p2) { return p1-p2; }
  inline triple mult_s(double c, triple p2) { return c*p2; }
  // no mult_pair -- triple mult does not generalize pair mult

  /* Old color handling: revert color to black */
  inline void end_red(void) { black(); }
  inline void end_blue(void) { black(); }
  inline void end_green(void) { black(); }

  inline void end_cyan(void) { black(); }
  inline void end_magenta(void) { black(); }
  inline void end_yellow(void) { black(); }

  /* comment functions */
  /* Collected comment functions */
  /* objects.cc */
  static void comment_line(char *type, triple p1, triple p2)
    {
      legacy_warn(type);
      fprintf (stdout, "\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	       type, p1.x1, p1.x2, p2.x1, p2.x2);
    }
  static void comment_line(char *type, triple p1, triple p2, double expand)
    {
      legacy_warn(type);
      fprintf (stdout, "\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f), %.2f%%\n%%%%",
	       type, p1.x1, p1.x2, p2.x1, p2.x2, 100*(exp(M_LN2*expand/100)));
    }
  static void comment_triangle(char *type, triple p1, triple p2, triple p3)
    {
      legacy_warn(type);
      fprintf (stdout, 
	       "\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	       type, p1.x1, p1.x2, p2.x1, p2.x2, p3.x1, p3.x2);
    }
  static void comment_rect(char *type, triple p1, triple p2)
    {
      legacy_warn(type);
      fprintf (stdout, 
	       "\n%%%% %s: corners (%.2f, %.2f) and (%.2f, %.2f)\n%%%%",
	       type, p1.x1, p1.x2, p2.x1, p2.x2);
    }
  static void comment_ellipse(char *type, triple center, triple radius)
    {
      legacy_warn(type);
      fprintf(stdout, 
	      "\n%%%% %s: center (%.2f, %.2f), radius (%.2f, %.2f)\n%%%%",
	      type, center.x1, center.x2, radius.x1, radius.x2);
    }
  /*
  static void comment_rotate_ellipse(char *type, triple center, triple radius, 
				     double angle)
    {
      legacy_warn(type);
      fprintf(stdout, "\n%%%% %s: center (%.2f, %.2f), radius (%.2f, %.2f),",
	      type, center.x1, center.x2, radius.x1, radius.x2);
      fprintf(stdout, "\n%%%%   rotated %.1f degrees\n%%%%", angle);
    }
  */
  static void comment_arc(char *type, triple center,
			  double radius, double start, double finish)
    {
      legacy_warn(type);
      fprintf(stdout, "\n%%%% %s:\n%%%%   center (%.2f,%.2f), radius %.2f, ",
	      type, center.x1, center.x2, radius);
      fprintf(stdout, "from %.2f to %.2f\n%%%%", start, finish);
    }
  static void comment_spline(char *type, triple p1, triple p2, triple p3)
    {
      legacy_warn(type);
      fprintf(stdout, "\n%%%% %s: control points", type);
      fprintf(stdout, "\n%%%%   ");
      raw_print(p1);
      raw_print(p2);
      raw_print(p3);
      fprintf(stdout, "\n%%%%");
    }
  static void comment_spline(char *type, 
			     triple p1, triple p2, triple p3, triple p4)
    {
      legacy_warn(type);
      fprintf(stdout, "\n%%%% %s: control points", type);
      fprintf(stdout, "\n%%%%   ");
      raw_print(p1);
      raw_print(p2);
      raw_print(p3);
      raw_print(p4);
      fprintf(stdout, "\n%%%%");
    }

  /* lines with stretch factor */
  inline void dashline(triple tail, triple head, double expand=0)
    {
      /*
      // Hardwired constant 12 -- approx len of unstretched dashes in true pt
      pair temp = view(head) - view(tail);
      double scale = exp(M_LN2*expand/100)/(12*epix_stretch_factor);

      int n = (int) ceil(scale*p2t(norm(c2s(temp))));

      if (n < 1)
	n=1;
      */
      dashed();
      comment_line("dashline", tail, head, expand);
      draw_line(tail, head, EPIX_NUM_PTS, expand);
      solid();
      end_stanza();
    }
  inline void dotline(triple tail, triple head, double expand=0)
    {
      dotted();
      comment_line("dotline", tail, head, expand);
      draw_line(tail, head, EPIX_NUM_PTS, expand);
      solid();
      end_stanza();
    }
  inline void boldline(triple tail, triple head, double expand=0)
    {
      solid();
      comment_line("boldline", tail, head, expand);
      bold();
      draw_line(tail, head, EPIX_NUM_PTS, expand);
      plain();
      end_stanza();
    }

  /* triangles */
  inline void dashtriangle(triple p1, triple p2, triple p3)
    {
      dashed();
      comment_triangle("dashtriangle", p1, p2, p3);
      draw_triangle(p1, p2, p3);
      solid();
      end_stanza();
    }
  inline void dottriangle(triple p1, triple p2, triple p3)
    {
      dotted();
      comment_triangle("dottriangle", p1, p2, p3);
      draw_triangle(p1, p2, p3);
      solid();
      end_stanza();
    }
  inline void boldtriangle(triple p1, triple p2, triple p3)
    {
      solid();
      comment_triangle("boldtriangle", p1, p2, p3);
      bold();
      draw_triangle(p1, p2, p3);
      endbold();
      end_stanza();
    }

  /* coordinate rectangles */
  inline void dashrect(triple p1, triple p2)
    {
      dashed();
      comment_rect("dashrect", p1, p2);
      draw_rect(p1, p2);
      solid();
      end_stanza();
    }
  inline void dotrect(triple p1, triple p2)
    {
      dotted();
      comment_rect("dotrect", p1, p2);
      draw_rect(p1, p2);
      solid();
      end_stanza();
    }
  inline void boldrect(triple p1, triple p2)
    {
      solid();
      comment_rect("boldrect", p1, p2);
      bold();
      draw_rect(p1, p2);
      endbold();
      end_stanza();
    }
  
  inline void boldswatch(triple p1, triple p2)
  {
    solid();
    comment_rect("boldswatch", p1, p2);
    bold();
    fprintf (stdout, "\\shade");
    draw_rect(p1, p2);
    endbold();
    end_stanza();
  }
  
  /* Ellipses */
  inline void dashellipse(triple center, triple radius)
  {
    dashed();
    comment_ellipse("dashellipse", center, radius);
    draw_ellipse(center, radius);
    solid();
    end_stanza();
  }
  inline void dotellipse(triple center, triple radius)
  {
    dotted();
    comment_ellipse("dotellipse", center, radius);
    draw_ellipse(center, radius);
    solid();
    end_stanza();
  }
  inline void boldellipse(triple center, triple radius)
  {
    solid(); 
    comment_ellipse("boldellipse", center, radius);
    bold();
    draw_ellipse(center, radius);
    endbold();
    end_stanza();
  }

  /* Half ellipses */
  inline void dashellipse_top(triple center, triple radius)
  {
    dashed();
    comment_ellipse("dashellipse_top", center, radius);
    draw_half_ellipse(center, radius, 0);
    solid();
    end_stanza();
  }
  inline void dashellipse_bottom(triple center, triple radius)
  {
    dashed();
    comment_ellipse("dashellipse_bottom", center, radius);
    draw_half_ellipse(center, radius, 180);
    solid();
    end_stanza();
  }
  inline void dashellipse_left(triple center, triple radius)
  {
    dashed();
    comment_ellipse("dashellipse_left", center, radius);
    draw_half_ellipse(center, radius, 90);
    solid();
    end_stanza();
  }
  inline void dashellipse_right(triple center, triple radius)
  {
    dashed();
    comment_ellipse("dashellipse_right", center, radius);
    draw_half_ellipse(center, radius, -90);
    solid();
    end_stanza();
  }

  inline void dotellipse_top(triple center, triple radius)
  {
    dotted();
    comment_ellipse("dotellipse_top", center, radius);
    draw_half_ellipse(center, radius, 0);
    solid();
    end_stanza();
  }
  inline void dotellipse_bottom(triple center, triple radius)
  {
    dotted();
    comment_ellipse("dotellipse_bottom", center, radius);
    draw_half_ellipse(center, radius, 180);
    solid();
    end_stanza();
  }
  inline void dotellipse_left(triple center, triple radius)
  {
    dotted();
    comment_ellipse("dotellipse_left", center, radius);
    draw_half_ellipse(center, radius, 90);
    solid();
    end_stanza();
  }
  inline void dotellipse_right(triple center, triple radius)
  {
    dotted();
    comment_ellipse("dotellipse_right", center, radius);
    draw_half_ellipse(center, radius, -90);
    solid();
    end_stanza();
  }

  inline void boldellipse_top(triple center, triple radius)
  {
    solid();
    comment_ellipse("boldellipse_top", center, radius);
    bold();
    draw_half_ellipse(center, radius, 0);
    endbold();
    end_stanza();
  }
  inline void boldellipse_bottom(triple center, triple radius)
  {
    solid();
    comment_ellipse("boldellipse_bottom", center, radius);
    bold();
    draw_half_ellipse(center, radius, 180);
    endbold();
    end_stanza();
  }
  inline void boldellipse_left(triple center, triple radius)
  {
    solid();
    comment_ellipse("boldellipse_left", center, radius);
    bold();
    draw_half_ellipse(center, radius, 90);
    endbold();
    end_stanza();
  }
  inline void boldellipse_right(triple center, triple radius)
  {
    solid();
    comment_ellipse("boldellipse_right", center, radius);
    bold();
    draw_half_ellipse(center, radius, -90);
    endbold();
    end_stanza();
  }

  /* Circular arcs */
  inline void dasharc (triple center, double rad, double tmin, double tmax)
    {
      dashed();
      comment_arc("dasharc", center, rad, tmin, tmax);
      draw_arc(center, rad, tmin, tmax);
      solid();
      end_stanza();
  }
  inline void dotarc (triple center, double rad, double tmin, double tmax)
    {
      dotted();
      comment_arc("dotarc", center, rad, tmin, tmax);
      draw_arc(center, rad, tmin, tmax);
      solid();
      end_stanza();
  }
  inline void boldarc (triple center, double rad, double tmin, double tmax)
    {
      solid();
      bold();
      comment_arc("boldarc", center, rad, tmin, tmax);
      draw_arc(center, rad, tmin, tmax);
      plain();
      end_stanza();
  }

  /* Splines */
  inline void dashspline(triple p1, triple p2, triple p3)
  {
    dashed();
    comment_spline("dashquad_spline", p1, p2, p3);
    draw_spline(p1, p2, p3);
    solid();
    end_stanza();
  }
  inline void dotspline(triple p1, triple p2, triple p3)
  {
    dotted();
    comment_spline("dotquad_spline", p1, p2, p3);
    draw_spline(p1, p2, p3);
    solid();
    end_stanza();
  }
  inline void boldspline(triple p1, triple p2, triple p3)
  {
    solid();
    comment_spline("boldquad_spline", p1, p2, p3);
    bold();
    draw_spline(p1, p2, p3);
    endbold();
    end_stanza();
  }

  inline void dashspline(triple p1, triple p2, triple p3, triple p4)
  {
    dashed();
    comment_spline("dashcubic_spline", p1, p2, p3, p4);
    draw_spline(p1, p2, p3, p4);
    solid();
    end_stanza();
  }
  inline void dotspline(triple p1, triple p2, triple p3, triple p4)
  {
    dotted();
    comment_spline("dotcubic_spline", p1, p2, p3, p4);
    draw_spline(p1, p2, p3, p4);
    solid();
    end_stanza();
  }
  inline void boldspline(triple p1, triple p2, triple p3, triple p4)
  {
    solid();
    comment_spline("boldcubic_spline", p1, p2, p3, p4);
    bold();
    draw_spline(p1, p2, p3, p4);
    endbold();
    end_stanza();
  }

  /* 0.6.x-style splines */
  inline void draw_quad_spline(triple p1, triple p2, triple p3, 
			       epix_path_style STYLE) 
    { 
      legacy_warn("0.6.x-style quad_spline");
      draw_spline(p1, p2, p3); 
    }
  inline void draw_cubic_spline(triple p1, triple p2, triple p3, triple p4, 
				epix_path_style STYLE) 
    { 
      legacy_warn("0.6.x-style cubic_spline");
      draw_spline(p1, p2, p3, p4, STYLE); 
    }

  inline void quad_spline(triple p1, triple p2, triple p3)
    { spline(p1, p2, p3); }
  inline void dashquad_spline(triple p1, triple p2, triple p3) 
    { dashspline(p1, p2, p3); }
  inline void dotquad_spline(triple p1, triple p2, triple p3)  
    { dotspline(p1, p2, p3); }
  inline void boldquad_spline(triple p1, triple p2, triple p3) 
    { boldspline(p1, p2, p3); }

  inline void cubic_spline(triple p1, triple p2, triple p3, triple p4)
    { spline(p1, p2, p3, p4); }
  inline void dashcubic_spline(triple p1, triple p2, triple p3, triple p4) 
    { dashspline(p1, p2, p3, p4); }
  inline void dotcubic_spline(triple p1, triple p2, triple p3, triple p4)  
    { dotspline(p1, p2, p3, p4); }
  inline void boldcubic_spline(triple p1, triple p2, triple p3, triple p4) 
    { boldspline(p1, p2, p3, p4); }

  /* Plotting */
  inline void dashplot(double f1(double), double a, double b, int n) 
    { 
      legacy_warn("dashplot");
      dashed();
      plot(f1, a, b, n); 
      solid();
    }
  inline void dotplot(double f1(double), double a, double b, int n) 
    { 
      legacy_warn("dotplot");
      dotted();
      plot(f1, a, b, n); 
      solid();
    }
  inline void boldplot(double f1(double), double a, double b, int n) 
    { 
      legacy_warn("boldplot");
      bold();
      plot(f1, a, b, n); 
      plain();
    }

  inline void paramplot(double f1(double), double f2(double), 
			double a, double b, int n) 
    { 
      legacy_warn("paramplot");
      plot(f1, f2, a, b, n); 
    }
  inline void dashparamplot(double f1(double), double f2(double), 
			    double a, double b, int n) 
    { 
      legacy_warn("dashparamplot");
      dashed();
      plot(f1, f2, a, b, n); 
      solid();
    }
  inline void dotparamplot(double f1(double), double f2(double), 
			   double a, double b, int n) 
    { 
      legacy_warn("dotparamplot");
      dotted();
      plot(f1, f2, a, b, n); 
      solid();
    }
  inline void boldparamplot(double f1(double), double f2(double), 
			    double a, double b, int n) 
    { 
      legacy_warn("boldparamplot");
      bold();
      plot(f1, f2, a, b, n); 
      plain();
    }

  inline void plot3d(double f1(double), double f2(double), double f3(double), 
			double a, double b, int n) 
    { 
      legacy_warn("plot3d");
      plot(f1, f2, f3, a, b, n); 
    }
  inline void dashplot3d(double f1(double), double f2(double), 
			 double f3(double), double a, double b, int n) 
    { 
      legacy_warn("dashplot3d");
      dashed();
      plot(f1, f2, f3, a, b, n); 
      solid();
    }
  inline void dotplot3d(double f1(double), double f2(double), 
			double f3(double), double a, double b, int n) 
    { 
      legacy_warn("dotplot3d");
      dotted();
      plot(f1, f2, f3, a, b, n); 
      solid();
    }
  inline void boldplot3d(double f1(double), double f2(double), 
			 double f3(double), double a, double b, int n) 
    { 
      legacy_warn("boldplot3d");
      bold();
      plot(f1, f2, f3, a, b, n); 
      plain();
    }

  /* clipplot */
  inline void dashclipplot(double f1(double), double a, double b, int n) 
    { 
      legacy_warn("dashclipplot");
      dashed();
      cropplot(f1, a, b, n); 
      solid();
    }
  inline void dotclipplot(double f1(double), double a, double b, int n) 
    { 
      legacy_warn("dotclipplot");
      dotted();
      cropplot(f1, a, b, n); 
      solid();
    }
  inline void boldclipplot(double f1(double), double a, double b, int n) 
    { 
      legacy_warn("boldclipplot");
      bold();
      cropplot(f1, a, b, n); 
      plain();
    }

  inline void dashclipplot(double f1(double), double f2(double), 
			    double a, double b, int n) 
    { 
      legacy_warn("dashclipplot");
      dashed();
      cropplot(f1, f2, a, b, n); 
      solid();
    }
  inline void dotclipplot(double f1(double), double f2(double), 
			   double a, double b, int n) 
    { 
      legacy_warn("dotclipplot");
      dotted();
      cropplot(f1, f2, a, b, n); 
      solid();
    }
  inline void boldclipplot(double f1(double), double f2(double), 
			    double a, double b, int n) 
    { 
      legacy_warn("boldclipplot");
      bold();
      cropplot(f1, f2, a, b, n); 
      plain();
    }

  inline void clipplot3d(double f1(double), double f2(double), 
			 double f3(double), double a, double b, int n) 
    { 
      legacy_warn("clipplot3d");
      plot(f1, f2, f3, a, b, n); 
    }
  inline void dashclipplot3d(double f1(double), double f2(double), 
			     double f3(double), double a, double b, int n) 
    { 
      legacy_warn("dashclipplot3d");
      dashed();
      clipplot(f1, f2, f3, a, b, n); 
      solid();
    }
  inline void dotclipplot3d(double f1(double), double f2(double), 
			    double f3(double), double a, double b, int n) 
    { 
      legacy_warn("dotclipplot3d");
      dotted();
      clipplot(f1, f2, f3, a, b, n); 
      solid();
    }
  inline void boldclipplot3d(double f1(double), double f2(double), 
			     double f3(double), double a, double b, int n) 
    { 
      legacy_warn("boldclipplot3d");
      bold();
      clipplot(f1, f2, f3, a, b, n); 
      plain();
    }

} /* end of namespace */

#endif /* _EPIX_LEGACY */
