/* 
 * lengths.cc: Scaling and length conversion
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc10
 * Last Change: May 27, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003  
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

/*
 *
 * There are three types of coordinates/length in ePiX:
 *   (1) Cartesian (the user interface)
 *   (2) LaTeX picture coordinates (unitlength, the output)
 *   (3) File-independent true unit (pt, used for visual formatting)
 *
 * Cartesian coordinates live in [x_min, x_max] x [y_min, y_max], the 
 * "bounding box". Latex picture coordinates live in the "picture box"
 * [0, h_size] x [0, v_size]. The functions hscale and vscale handle
 * Cartesian to picture coordinate conversion; h_unscale and v_unscale
 * are the inverse functions.
 * 
 * The user specifies objects' locations in Cartesian coordinates, which
 * facilitates the design of portable, mathematically accurate figures. 
 * There is also a facility for offsetting labels by amounts in true pt;
 * This eases the visual placement of labels, and helps to make the figure 
 * portable: A change of bounding box re-positions the label's basepoint
 * globally, while the offset (which is scale-independent) adjusts the
 * label from its new basepoint.
 *
 * True-coordinate changes are handled by scale (which converts true pt
 * to (user-specified) LaTeX picture units and its inverse, unscale. In
 * summary, "scale" functions convert *to* picture coordinates, "unscale"
 * functions convert *from* picture coordinates. These functions know about 
 * the following LaTeX dimensions: "cm", "in", "mm", "pc", and "pt"
 */

#include <cstdio>
#include <cstdlib>
#include <iostream>

#include "globals.h"
#include "pairs.h"
#include "triples.h"
#include "lengths.h"

namespace ePiX {

  extern double h_size, v_size, h_offset, v_offset;
  extern double x_min, x_max, y_min, y_max;
  extern double x_size, y_size;
  extern double pic_size;
  extern char *pic_unit;

  short int scale_warning=0;

  // truncate only used in pairs.cc, output.cc
  double truncate(double t)
  {
    if (fabs(t) < EPIX_EPSILON)
      t=0;

    return t;
  }

  pair truncate (pair p)
  {
    if (fabs(p.x1) < EPIX_EPSILON)
      p.x1=0;
    if (fabs(p.x2) < EPIX_EPSILON)
      p.x2=0;

    return p; // P(p.x1, p.x2);
  }

  // length conversions

  pair c2p(pair X)
  {
    pair scale = pair(h_size/x_size, v_size/y_size);
    pair origin = pair(x_min, y_min);
    //    return truncate(scale&(X - origin));
    return scale&(X - origin);
  }

  pair p2c(pair H)
  {
    pair scale = pair(x_size/h_size, y_size/v_size);
    pair lower_left = pair(x_min, y_min);

    return lower_left + scale&H;
  }

  pair c2s(pair X)
  {
    pair scale = pair(h_size/x_size, v_size/y_size);
    //    return truncate(scale&X);
    return scale&X;
  }

  pair s2c(pair H)
  {
    pair scale = pair(x_size/h_size, y_size/v_size);
    return scale&H;
  }

  double p2t(double dimen) // Formerly unscale
  {
    if (! strcmp((char *)pic_unit,"cm"))
      return (pic_size)*(72.27/2.54)*dimen;

    else if (! strcmp((char *)pic_unit,"in"))
      return (pic_size)*(72.27)*dimen;

    else if (! strcmp((char *)pic_unit,"mm"))
      return (pic_size)*(72.27/25.4)*dimen;

    else if (! strcmp((char *)pic_unit,"pc"))
      return (pic_size)*(12.0)*dimen;

    else if (! strcmp((char *)pic_unit,"pt"))
      return (pic_size)*dimen;

    // Invalid unit length and no warning printed yet
    else if (scale_warning == 0) 
      {
	scale_warning = 1;
      
	fprintf(stdout, "%%%% ePiX WARNING: Unrecognized units \"%s\"! ", 
		pic_unit);
	fprintf(stdout, "Scaling may be incorrect.\n");
	fprintf(stdout, "%%%%   Valid units are ");
	fprintf(stdout, "\"cm\", \"in\", \"mm\", \"pc\", and \"pt\".\n");
	fprintf(stdout, "%%%%   Please check preamble of source file.\n");
	fprintf(stdout, "%%%%\n");
	return (pic_size)*dimen;
      }

    // Warning issued already; try our best to comply...
    else
      return (pic_size)*dimen;
  }

  double t2p(double t)
  {
    return t/p2t(1.0);
  }
  pair t2p(pair T)
  {
    return (1.0/p2t(1.0))*T;
  }

  pair p2t(pair H)
  {
    return p2t(1.0)*H;
  }

  // Pythagorean length of pair/triple
  double raw_len(pair p)
  {
    return hypot(p.x1, p.x2);
  }

  double raw_len(triple p)
  {
    return sqrt(p.x1*p.x1 + p.x2*p.x2 + p.x3*p.x3);
  }

  // True length of pair given in picture coordinates
  double true_length(pair p)
  {
    return raw_len(p2t(p));
  }

  // Scale vector in picture units to 1 true pt length
  pair true_unit(pair p)
  {
    if ( true_length(p) > EPIX_EPSILON) // return (0,0) if p = (0,0)
      p *= 1.0/true_length(p);

    return p;
  }

} /* end of namespace */
