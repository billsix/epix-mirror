/* 
   segment.h -- ePiX::segment class
 
   This file provides:

   The segment class (unordered pair of points),
   and operators:
    - join() (alternative constructor)
    - endpt1(), endpt2() (no guaranteed order)
    - segment += triple (translate by <triple>)
    - draw() (ePiX line)
    - midpoint(); (also callable on pair of triples)
    - segment*segment (point of intersection of _lines_ determined by segments)
 */

/*
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc7
 * Last Change: April 21, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_SEGMENT
#define _EPIX_SEGMENT

#include "globals.h"
#include "triples.h"

namespace ePiX {

  class segment
    {
    private:
      triple endpt1;
      triple endpt2;

    public:
      segment() {};
      segment(triple p1, triple p2) { endpt1 = p1; endpt2 = p2; }

      // Note: Ends of segment are not "ordered" meaningfully
      triple end1() const { return endpt1; }
      triple end2() const { return endpt2; }

      // translation
      segment& operator += (const triple& arg)
	{
	  endpt1 += arg;
	  endpt2 += arg;

	  return *this;
	}

      // segment
      void draw();

    }; /* end of segment class */

  inline triple midpoint(segment arg) 
    { 
      return 0.5*(arg.end1() + arg.end2()); 
    }

  // translation
  inline segment& operator + (const segment& seg, const triple& arg)
    {
      segment temp=seg;
      return temp += arg;
    }

  inline segment& operator + (const triple& arg, const segment& seg)
    {
      segment temp=seg;
      return temp += arg;
    }

  // intersection
  triple& operator * (const segment& seg1, const segment& seg2);


  // alternative constructor
  inline segment join(triple p1, triple p2) { return segment(p1,p2); }

  // midpoint of pair of triples      
  inline triple midpoint(triple arg1, triple arg2) 
    { 
      return 0.5*(arg1 + arg2); 
    }

} /* end of namespace */

#endif /* _EPIX_SEGMENT */
