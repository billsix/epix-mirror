/* 
 * meshplots.cc -- Wire mesh surfaces
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc6
 * Last Change: April 16, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include "meshplots.h"
#include "functions.h"
#include "output.h"

namespace ePiX {

  extern epix_path_style EPIX_PATH_STYLE;

  // Wiremesh plotting -- no hidden line removal
  void 
  draw_plot(double f1(double u1, double u2),
	    double f2(double u1, double u2),
	    double f3(double u1, double u2),
	    triple p1, triple p2, mesh N, mesh num_pts)
  {
    // third coordinates of p1, p2 ignored
    // Fineness of plotted mesh
    const double step_u1 = (p2.x1 - p1.x1)/N.n1;
    const double step_u2 = (p2.x2 - p1.x2)/N.n2;
    // Point increments in each direction
    const double du1 = (p2.x1 - p1.x1)/num_pts.n1;
    const double du2 = (p2.x2 - p1.x2)/num_pts.n2;

    for (int i = 0; i <= N.n1; ++i)
      {
	double temp1 = p1.x1 + i*step_u1;
	fprintf (stdout, "\n%%%%  x1 = %g", temp1);
	start_path();
	for (int j = 0; j <= num_pts.n2; ++j)
	  {
	    double temp2 = p1.x2 + j*du2;
	    print(P(f1(temp1, temp2), f2(temp1, temp2), f3(temp1, temp2)));
	    line_break(j, num_pts.n2);
	  }
	fprintf (stdout, "\n%%%%");
      }

    for (int j = 0; j <= N.n2; ++j)
      {
	double temp2 = p1.x2 + j*step_u2;
	fprintf (stdout, "\n%%%%  x2 = %g", temp2);
	start_path();
	for (int i = 0; i <= num_pts.n1; ++i)
	  {
	    double temp1 = p1.x1 + i*du1;
	    print(P(f1(temp1, temp2), f2(temp1, temp2), f3(temp1, temp2)));
	    line_break(i, num_pts.n1);
	  }
      }
  }

  void plot(double f1(double, double), double f2(double, double), 
	    double f3(double, double), triple p1, triple p2, mesh N,
	    mesh num_pts)
  {
    epix_comment("wire mesh parametrized surface");
    draw_plot(f1, f2, f3, p1, p2, N, num_pts);
    end_stanza();
  } 

  // Wire mesh plot of function of two real variables
  void plot(double f(double, double), triple p1, triple p2, mesh N,
	    mesh num_pts)
  {
    epix_comment("wire mesh graph");
    draw_plot(proj1, proj2, f, p1, p2, N, num_pts);
    end_stanza();
  } 

  // triple-valued plot argument
  void draw_plot(triple Phi(double u1, double u2),
		 triple p1, triple p2, mesh N, mesh num_pts)
  {
    // Fineness of plotted mesh
    const double step_u1 = (p2.x1 - p1.x1)/N.n1;
    const double step_u2 = (p2.x2 - p1.x2)/N.n2;
    // Point increments in each direction
    const double du1 = (p2.x1 - p1.x1)/num_pts.n1;
    const double du2 = (p2.x2 - p1.x2)/num_pts.n2;

    for (int i = 0; i <= N.n1; ++i)
      {
	double temp1 = p1.x1 + i*step_u1;
	fprintf (stdout, "\n%%%%  x1 = %g", temp1);
	start_path();
	for (int j = 0; j <= num_pts.n2; ++j)
	  {
	    double temp2 = p1.x2 + j*du2;
	    print(Phi(temp1, temp2));
	    line_break(j, num_pts.n2);
	  }
	fprintf (stdout, "\n%%%%");
      }

    for (int j = 0; j <= N.n2; ++j)
      {
	double temp2 = p1.x2 + j*step_u2;
	fprintf (stdout, "\n%%%%  x2 = %g", temp2);
	start_path();
	for (int i = 0; i <= num_pts.n1; ++i)
	  {
	    double temp1 = p1.x1 + i*du1;
	    print(Phi(temp1, temp2));
	    line_break(i, num_pts.n1);
	  }
      }
  }

  void plot(triple Phi(double, double), 
	    triple p1, triple p2, mesh N, mesh num_pts)
  {
    epix_comment("wire mesh parametrized surface");
    draw_plot(Phi, p1, p2, N, num_pts);
    end_stanza();
  } 

  /* * * clipped mesh plots * * */

  /*
   * edge_seek
   *
   * Approximates point where plot goes outside clip_box.
   * Algorithm: Start at point known to be inside, use bisection
   * method on parameter
   */

  /* * * Three double-valued arguments * * */
  // increment first variable
  static triple edge_seek1(double f1(double, double), 
			   double f2(double, double), 
			   double f3(double, double),
			   double s, double t, double step)
  {
    double ds = step; // initialize
    // N.B. we're assuming F(s,t) is inside, F(s+ds,t) is outside
    triple in_pt  = P(f1(s,t), f2(s,t), f3(s,t)); 
    triple out_pt = P(f1(s+ds,t), f2(s+ds,t), f3(s+ds,t)); 
    triple temp;

    while (raw_len(out_pt - in_pt) > EPIX_EPSILON)
      {
	ds *= 0.5; // bisect
	temp = P(f1(s+ds, t), f2(s+ds, t), f3(s+ds, t)); // parameter midpoint
	if (is_in_bounds(temp))
	  {
	    in_pt = temp;
	    s += ds; // increment parameter
	  }
	else
	  out_pt = temp; // no need to increment s
      }

    return in_pt; // return value guaranteed to be inside clip_box
  }
  // increment second variable
  static triple edge_seek2(double f1(double, double), 
			   double f2(double, double), 
			   double f3(double, double),
			   double s, double t, double step)
  {
    double dt = step; // initialize
    // N.B. we're assuming F(s,t) is inside, F(s,t+dt) is outside
    triple in_pt  = P(f1(s,t), f2(s,t), f3(s,t)); 
    triple out_pt = P(f1(s,t+dt), f2(s,t+dt), f3(s,t+dt)); 
    triple temp;

    while (raw_len(out_pt - in_pt) > EPIX_EPSILON)
      {
	dt *= 0.5; // bisect
	temp = P(f1(s, t+dt), f2(s, t+dt), f3(s, t+dt)); // parameter midpoint
	if (is_in_bounds(temp))
	  {
	    in_pt = temp;
	    t += dt; // increment parameter
	  }
	else
	  out_pt = temp; // no need to increment s
      }

    return in_pt; // return value guaranteed to be inside clip_box
  }

  // draw plot holding second variable constant
  static void
  draw_clipplot1(double f1(double, double), double f2(double, double), 
		 double f3(double, double), 
		 double s_min, double s_max, double t0, int num_pts)
  {
    triple curr, prev;
    int current=1, previous=0;

    int pt_count=0; 
    int pr_flag=0;
    double s = 0;
    const double step = (s_max - s_min)/num_pts;
  
    for (int i=0; i <= num_pts; ++i)
      {
	s = s_min + i*step;
	curr = P(f1(s,t0), f2(s,t0), f3(s,t0));

	if (is_in_bounds(curr))
	  current=1;
	else
	  current=0;
      
	// Four cases: Previous is in/out, current is in/out.
      
	// Start new path component
	if (current == 1 && previous == 0)
	  {
	    if (s == s_min) // print first point
	      {
		start_path();
		print(curr);
		pt_count = 1;
	      }
	    else // print 2 points: seek-back and current
	      {
		if (pr_flag == 0)
		  start_path();

		else
		  {
		    fprintf(stdout, "\n%%%%"); // New sub-stanza
		    start_path();
		  }

		// Seek back to edge of clip_box
		print(edge_seek1(f1, f2, f3, s, t0, -step));
		print(curr);
		pt_count=2;
	      }
	    pr_flag=1;
	    previous=1;
	    prev=curr;
	  }
      
	// Continue path
	else if (current == 1 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(curr);
	    previous=1;
	    prev=curr;
	  
	    ++pt_count;
	  }
      
	// End current path
	else if (current == 0 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);

	    print(edge_seek1(f1, f2, f3, s-step, t0, step));
	    previous=0;
	    prev=curr;
	    pt_count=0;
	  }
      
	// (current == 0 && previous == 0), keep searching...
	else 
	  {
	    previous=0;
	    prev=curr;
	  }
      }
  }

  // draw plot holding first variable constant
  static void
  draw_clipplot2(double f1(double, double), double f2(double, double),
		 double f3(double, double),
		 double t_min, double t_max, double s0, int num_pts)
  {
    triple curr, prev;
    int current=1, previous=0;

    int pt_count=0; 
    int pr_flag=0;
    double t = 0;
    const double step = (t_max - t_min)/num_pts;
  
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*step;
	curr = P(f1(s0,t), f2(s0,t), f3(s0,t));

	if (is_in_bounds(curr))
	  current=1;
	else
	  current=0;
      
	// Four cases: Previous is in/out, current is in/out.
      
	// Start new path component
	if (current == 1 && previous == 0)
	  {
	    if (t == t_min) // print first point
	      {
		start_path();
		print(curr);
		pt_count = 1;
	      }
	    else // print 2 points: seek-back and current
	      {
		if (pr_flag == 0)
		  start_path();

		else
		  {
		    fprintf(stdout, "\n%%%%"); // New sub-stanza
		    start_path();
		  }

		// Seek back to edge of clip_box
		print(edge_seek2(f1, f2, f3, s0, t, -step));
		print(curr);
		pt_count=2;
	      }
	    pr_flag=1;
	    previous=1;
	    prev=curr;
	  }
      
	// Continue path
	else if (current == 1 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(curr);
	    previous=1;
	    prev=curr;
	  
	    ++pt_count;
	  }
      
	// End current path
	else if (current == 0 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(edge_seek2(f1, f2, f3, s0, t-step, step));
	    previous=0;
	    prev=curr;
	    pt_count=0;
	  }
      
	// (current == 0 && previous == 0), keep searching...
	else 
	  {
	    previous=0;
	    prev=curr;
	  }
      }
  }

  /* * * triple-valued argument * * */
  // increment first variable
  static
  triple edge_seek1(triple Phi(double, double), 
		    double s, double t, double step)
  {
    double ds = step; // initialize
    // N.B. we're assuming Phi(s,t) is inside, Phi(s+ds,t) is outside
    triple in_pt  = Phi(s,t);
    triple out_pt = Phi(s+ds,t);
    triple temp;

    while (raw_len(out_pt - in_pt) > EPIX_EPSILON)
      {
	ds *= 0.5; // bisect
	temp = Phi(s+ds, t); // parameter midpoint
	if (is_in_bounds(temp))
	  {
	    in_pt = temp;
	    s += ds; // increment parameter
	  }
	else
	  out_pt = temp; // no need to increment s
      }

    return in_pt; // return value guaranteed to be inside clip_box
  }
  // increment second variable
  static
  triple edge_seek2(triple Phi(double, double), 
		    double s, double t, double step)
  {
    double dt = step; // initialize
    // N.B. we're assuming Phi(s,t) is inside, Phi(s,t+dt) is outside
    triple in_pt  = Phi(s,t);
    triple out_pt = Phi(s,t+dt);
    triple temp;

    while (raw_len(out_pt - in_pt) > EPIX_EPSILON)
      {
	dt *= 0.5;

	temp = Phi(s, t+dt); // parameter midpoint
	if (is_in_bounds(temp))
	  {
	    in_pt = temp;
	    t += dt;
	  }
	else
	  out_pt = temp;
      }

    return in_pt; // return value guaranteed to be inside clip_box
  }
  // End of edge_seek functions

  // clipplot helper functions
  // one curve; hold second variable constant
  static void
  draw_clipplot1(triple Phi(double, double), 
		 double s_min, double s_max, double t0, int num_pts)
  {
    triple curr, prev;
    int current=1, previous=0;

    int pt_count=0; 
    int pr_flag=0;
    double s = 0;
    const double step = (s_max - s_min)/num_pts;
  
    for (int i=0; i <= num_pts; ++i)
      {
	s = s_min + i*step;
	curr = Phi(s,t0);

	if (is_in_bounds(curr))
	  current=1;
	else
	  current=0;
      
	// Four cases: Previous is in/out, current is in/out.
      
	// Start new path component
	if (current == 1 && previous == 0)
	  {
	    if (s == s_min) // print first point
	      {
		start_path();
		print(curr);
		pt_count = 1;
	      }
	    else // print 2 points: seek-back and current
	      {
		if (pr_flag == 0)
		  start_path();

		else
		  {
		    fprintf(stdout, "\n%%%%"); // New sub-stanza
		    start_path();
		  }

		// Seek back to edge of clip_box
		print(edge_seek1(Phi, s, t0, -step));
		print(curr);
		pt_count=2;
	      }
	    pr_flag=1;
	    previous=1;
	    prev=curr;
	  }
      
	// Continue path
	else if (current == 1 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(curr);
	    previous=1;
	    prev=curr;
	  
	    ++pt_count;
	  }
      
	// End current path
	else if (current == 0 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(edge_seek1(Phi, s-step, t0, step));
	    previous=0;
	    prev=curr;
	    pt_count=0;
	  }
      
	// (current == 0 && previous == 0), keep searching...
	else 
	  {
	    previous=0;
	    prev=curr;
	  }
      }
  }

  // one curve; hold first variable constant
  static void
  draw_clipplot2(triple Phi(double, double), 
		 double t_min, double t_max, double s0, int num_pts)
  {
    triple curr, prev;
    int current=1, previous=0;

    int pt_count=0; 
    int pr_flag=0;
    double t = 0;
    const double step = (t_max - t_min)/num_pts;
  
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*step;
	curr = Phi(s0,t);

	if (is_in_bounds(curr))
	  current=1;
	else
	  current=0;
      
	// Four cases: Previous is in/out, current is in/out.
      
	// Start new path component
	if (current == 1 && previous == 0)
	  {
	    if (t == t_min) // print first point
	      {
		start_path();
		print(curr);
		pt_count = 1;
	      }
	    else // print 2 points: seek-back and current
	      {
		if (pr_flag == 0)
		  start_path();

		else
		  {
		    fprintf(stdout, "\n%%%%"); // New sub-stanza
		    start_path();
		  }

		// Seek back to edge of clip_box
		print(edge_seek2(Phi, s0, t, -step));
		print(curr);
		pt_count=2;
	      }
	    pr_flag=1;
	    previous=1;
	    prev=curr;
	  }
      
	// Continue path
	else if (current == 1 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(curr);
	    previous=1;
	    prev=curr;
	  
	    ++pt_count;
	  }
      
	// End current path
	else if (current == 0 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(edge_seek2(Phi, s0, t-step, step));
	    previous=0;
	    prev=curr;
	    pt_count=0;
	  }
      
	// (current == 0 && previous == 0), keep searching...
	else 
	  {
	    previous=0;
	    prev=curr;
	  }
      }
  }

  // End of clipplot helpers

  static void 
  draw_clipplot(double f1(double u1, double u2),
		double f2(double u1, double u2),
		double f3(double u1, double u2),
		triple p1, triple p2, mesh N, mesh num_pts)
  {
    // Fineness of plotted mesh
    const double step_u1 = (p2.x1 - p1.x1)/N.n1;
    const double step_u2 = (p2.x2 - p1.x2)/N.n2;

    for (int i = 0; i <= N.n1; ++i)
      {
	double temp1 = p1.x1 + i*step_u1;
	fprintf (stdout, "\n%%%%  x1 = %g", temp1);
	// print path segment(s)
	draw_clipplot2(f1, f2, f3, p1.x2, p2.x2, temp1, num_pts.n2);
      }

    for (int j = 0; j <= N.n2; ++j)
      {
	double temp2 = p1.x2 + j*step_u2;
	fprintf (stdout, "\n%%%%  x2 = %g", temp2);
	draw_clipplot1(f1, f2, f3, p1.x1, p2.x1, temp2, num_pts.n1);
      }
  }

  // three double-valued arguments
  void clipplot(double f1(double, double), double f2(double, double), 
		double f3(double, double), triple p1, triple p2, mesh N,
		mesh num_pts)
  {
    epix_comment("wire mesh parametrized surface");
    draw_clipplot(f1, f2, f3, p1, p2, N, num_pts);
    end_stanza();
  }

  // triple-valued plot argument
  static void 
  draw_clipplot(triple Phi(double u1, double u2),
		triple p1, triple p2, mesh N, mesh num_pts)
  {
    // Fineness of plotted mesh
    const double step_u1 = (p2.x1 - p1.x1)/N.n1;
    const double step_u2 = (p2.x2 - p1.x2)/N.n2;

    for (int i = 0; i <= N.n1; ++i)
      {
	double temp1 = p1.x1 + i*step_u1;
	fprintf (stdout, "\n%%%%  x1 = %g", temp1);
	// print path segment(s)
	draw_clipplot2(Phi, p1.x2, p2.x2, temp1, num_pts.n2);
      }

    for (int j = 0; j <= N.n2; ++j)
      {
	double temp2 = p1.x2 + j*step_u2;
	fprintf (stdout, "\n%%%%  x2 = %g", temp2);
	// print path segment(s)
	draw_clipplot1(Phi, p1.x1, p2.x1, temp2, num_pts.n1);
      }
  }

  void clipplot(triple Phi(double, double), 
		triple p1, triple p2, mesh N, mesh num_pts)
  {
    epix_comment("wire mesh parametrized surface");
    draw_clipplot(Phi, p1, p2, N, num_pts);
    end_stanza();
  } 

} /* end of namespace */
