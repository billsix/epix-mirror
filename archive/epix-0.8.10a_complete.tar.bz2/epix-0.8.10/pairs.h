/* 
 * pairs.h -- ePiX pair:: class and mathematical operators
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc5
 * Last Change: April 04, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_PAIRS
#define _EPIX_PAIRS

#include <cstdlib>
#include <cstdio>
#include <cmath>

#include "functions.h"

namespace ePiX {

  class pair 
    {
    public:
      double x1;
      double x2;

      // void constructor
      pair(void) {}

      // Cartesian constructor
      pair(double x1, double x2);

      // copy
      pair(const pair& old);

      // destructor
      ~pair() {}

      // increment operators
      pair& operator += (const pair&);
      pair& operator -= (const pair&);
      pair& operator *= (const double&);
      
      // complex multiplication and division
      pair& operator *= (const pair&);
      pair& operator /= (const pair&);
    }; /* end of pair class */

  int  operator == (const pair&, const pair&);
  pair operator - (const pair&);
  pair operator + (const pair&, const pair&);
  pair operator - (const pair&, const pair&);

  // scalar multiplication
  pair operator * (const double&, const pair&);
  // Multiplication by i
  pair J(pair);

  // complex multiplication and division
  pair operator * (const pair& u, const pair& v);
  pair operator / (const pair& u, const pair& v);

  // dot product
  double operator |(const pair&, const pair&);
  // (a,b)&(x,y)=(ax,by), for unit/coordinate conversion
  pair operator &(const pair&, const pair&);

  struct mesh {
    int n1;
    int n2;
  };

  struct mesh Net(int, int);

  /* * * * Deprecated functions * * * */

  /* Vector operations (now overloaded operators) */
  pair add_pair(pair, pair);

  pair diff_pair(pair, pair);

  pair mult_s(double, pair);

  /* Complex Multiplication */
  pair mult_pair(pair, pair);

} /* end of namespace */

#endif /* _EPIX_PAIRS */
