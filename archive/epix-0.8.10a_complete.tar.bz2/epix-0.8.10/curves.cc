/* 
 * curves.cc -- Ellipses, circular arcs, splines
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc11
 * Last Change: June 04, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include "globals.h"
#include "functions.h"
#include "pairs.h"
#include "camera.h"
#include "triples.h"
#include "lengths.h"
#include "output.h"
#include "objects.h"
#include "curves.h"

namespace ePiX {

  extern epix_path_style EPIX_PATH_STYLE;
  extern double epix_angle_units;
  extern epix_camera camera;

  // Ellipses and half-ellipses

  /* * * For backward compatibility only * * */
  void draw_ellipse(triple center, triple radius)
  {
    triple current;

    start_path();
    for (int i=0; i <= EPIX_NUM_PTS; ++i) 
      {
	current = center+(radius&cis(2*M_PI*i/(EPIX_NUM_PTS*epix_angle_units)));
	print(current);

	line_break(i, EPIX_NUM_PTS);
      }
  }

  void ellipse(triple center, triple radius)
  {
    epix_comment("ellipse");
    draw_ellipse(center, radius);
    end_stanza();
  }

  static void draw_ellipse_arc(triple center, triple radius, 
			       double theta_min, double theta_max)
  {
    int num_pts = 1+(int)ceil(EPIX_NUM_PTS*fabs(theta_max-theta_min)*epix_angle_units/M_PI);

    start_path();
    for (int i=0; i <= num_pts; ++i) 
      {
	print(center+(radius&cis(theta_min+M_PI*i/(num_pts*epix_angle_units))));
	line_break(i, num_pts);
      }
  }

  // Plain half-ellipses
  void ellipse_top(triple center, triple radius)
  {
    double old_angle_units = epix_angle_units; // store angle mode
    degrees();
    epix_comment("top half ellipse");
    draw_ellipse_arc(center, radius, 0, 180);
    end_stanza();
    epix_angle_units = old_angle_units; // restore state
  }

  void ellipse_bottom(triple center, triple radius)
  {
    double old_angle_units = epix_angle_units;
    degrees();
    epix_comment("bottom half ellipse");
    draw_ellipse_arc(center, radius, 180, 360);
    end_stanza();
    epix_angle_units = old_angle_units;
  }

  void ellipse_left(triple center, triple radius)
  {
    double old_angle_units = epix_angle_units;
    degrees();
    epix_comment("left half ellipse");
    draw_ellipse_arc(center, radius, 90, 270);
    end_stanza();
    epix_angle_units = old_angle_units;
  }

  void ellipse_right(triple center, triple radius)
  {
    double old_angle_units = epix_angle_units;
    degrees();
    epix_comment("right half ellipse");
    draw_ellipse_arc(center, radius, -90, 90);
    end_stanza();
    epix_angle_units = old_angle_units;
  }

  /* * * circular arcs parallel to (x,y)-plane * * */
  static double arc_scale(double r)
  {
    pair temp = c2s(pair(r,r));
    // Approx. number of true pts per angular unit
    return 0.5*epix_angle_units*p2t(temp.x1 + temp.x2);
  }

  // draw_proper_arc is called iff start/finish angles are sensible.
  static void draw_proper_arc(triple center,
		       double r, double start, double finish)
  {
    double angle = finish - start;

    /* 
     * Number of points plotted is nearly proportional to radius and
     * angle subtended for large circles, but is no smaller than 20
     * points per circle for small circles. Hybrid of two failed attempts:
     *
     * int num_pts=(int) ceil(fabs(EPIX_NUM_PTS*angle));
     * 
     * ceil(fabs(angle)*unscale(h_scale(r)+v_scale(r))/(2.0*EPIX_DASH_LENGTH));
     */
    int num_pts=(int) ceil(fabs((epix_angle_units*angle/M_PI)*
			  (EPIX_NUM_PTS + arc_scale(r)/EPIX_DASH_LENGTH)));

    if (num_pts < 2)
      num_pts=2;

    start_path();
    for (int i=0; i <= num_pts; ++i) 
      {
	print(center + polar(r, start+i*angle/num_pts));
	line_break(i, num_pts);
      }
  }

  void draw_arc(triple center, double r, double start, double finish)
  {
    double interval = finish - start;
    if (fabs(interval) >= 2*M_PI/epix_angle_units) // One full turn or more
      draw_ellipse(center, P(r, r));

    else if (0 < interval)
      draw_proper_arc(center, r, start, finish);
    
    else if (interval < 0)
      draw_proper_arc(center, r, finish, start);
  
    else // start == finish
      fprintf(stdout, "\n%%%%   Null arc...?");
  }

  void arc(triple center, double r, double start, double finish)
  {
    epix_comment("circular arc");
    draw_arc(center, r, start, finish);
    end_stanza();
  }

  // Angle subtended by arrowhead at Cartesian distance r
  static double subtended(double r, double scale)
  {
    return scale*EPIX_ARROWHEAD_WIDTH*EPIX_ARROWHEAD_RATIO/arc_scale(r);
  }

  void draw_arc_arrow(triple center, double r, double start, double finish,
		      double scale)
  {
    if (fabs(start - finish) <= subtended(r, scale))
      fprintf(stdout, "\n%%%%   Arc shorter than arrowhead; not printed");
  
    else {
      if (start < finish)
	finish -= subtended(r, scale);
      else
	finish += subtended(r, scale);
    
      // Terminal point of arc
      triple base = center + polar(r, finish);

      // create vector tangent to arc at <base>
      triple dir = J(cis(finish));
      //      triple dir = cis(finish);
      //      dir = E_3*dir;
      // Reverse direction if necessary
      if (start > finish)
	dir = -dir;

      if ((dir|get_eye(camera)) < 0) // end of arc points away
	{
	  draw_arrow(base, base + (2*EPIX_EPSILON/norm(dir))*dir, scale);
	  draw_arc(center, r, start, finish);
	}

      else
	{
	  draw_arc(center, r, start, finish);
	  draw_arrow(base, base + (2*EPIX_EPSILON/norm(dir))*dir, scale);
	}
    }
  }

  void arc_arrow(triple center, double r, double start, double finish,
		 double scale)
  {
    epix_comment("arc arrow");
    draw_arc_arrow(center, r, start, finish, scale);
    end_stanza();
  }

  /* * * 3-D ellipse functions * * */
  void draw_ellipse_arc(triple center, triple axis1, triple axis2, 
			double t_min, double t_max, int num_pts)
  {
    double t = t_min;
    double dt = (t_max - t_min)/num_pts;

    start_path();
    for (int i=0; i <= num_pts; ++i, t += dt) 
      {
	print(center + ePiX::cos(t)*axis1 + ePiX::sin(t)*axis2);
	line_break(i, num_pts);
      }
  }

  void ellipse_arc(triple center, triple axis1, triple axis2, 
		   double t_min, double t_max, int num_pts)
  {
    epix_comment("ellipse arc");
    draw_ellipse_arc(center, axis1, axis2, t_min, t_max, num_pts);
    end_stanza();
  }

  void draw_ellipse(triple center, triple axis1, triple axis2, int num_pts)
  {
    draw_ellipse_arc(center, axis1, axis2, 0, 2*M_PI/epix_angle_units, num_pts);
  }

  void ellipse(triple center, triple axis1, triple axis2, 
	       int num_pts)
  {
    epix_comment("ellipse");
    draw_ellipse(center, axis1, axis2, num_pts);
    end_stanza();
  }

  // Splines
  static inline triple
  quad_spline_pt(triple p1, triple p2, triple p3, double t)
  {
    return t*t*p1 + 2*t*(1-t)*p2 + (1-t)*(1-t)*p3;
  }

  static inline triple
  cubic_spline_pt(triple p1, triple p2, triple p3, triple p4, double t)
  {
    return t*t*t*p1 + 3*t*t*(1-t)*p2 + 
      3*t*(1-t)*(1-t)*p3 + (1-t)*(1-t)*(1-t)*p4;
  }

  // quadratic spline
  void draw_spline(triple p1, triple p2, triple p3, int num_pts)
  {
    double t = 0;
    triple current;

    if (EPIX_PATH_STYLE != DOTTED)
      start_path();
  
    for (int i=0; i <= num_pts; ++i, t += 1.0/num_pts) 
      {
	current = quad_spline_pt(p1, p2, p3, t);
	
	if (EPIX_PATH_STYLE == DOTTED)
	  ddot(current);
	else
	  {
	    print(current);
	    line_break(i, num_pts);
	  }
      }
  }

  // cubic spline
  void draw_spline(triple p1, triple p2, triple p3, triple p4, int num_pts)
  {
    double t = 0;
    triple current;

    if (EPIX_PATH_STYLE != DOTTED)
      start_path();
  
    for (int i=0; i <= num_pts; ++i, t += 1.0/num_pts) 
      {
	current = cubic_spline_pt(p1, p2, p3, p4, t);
	
	if (EPIX_PATH_STYLE == DOTTED)
	  ddot(current);
      
	else
	  {
	    print(current);
	    line_break(i, num_pts);
	  }
      }
  }

  void spline(triple p1, triple p2, triple p3, int num_pts)
  {
    epix_comment("quadratic spline");
    draw_spline(p1, p2, p3, num_pts);
    end_stanza();
  }

  void spline(triple p1, triple p2, triple p3, triple p4, int num_pts)
  {
    epix_comment("cubic spline");
    draw_spline(p1, p2, p3, p4, num_pts);
    end_stanza();
  }

} /* end of namespace */
