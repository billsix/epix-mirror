/* 
 * pairs.cc -- Ordered pairs and operations
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc5
 * Last Change: April 05, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <cstdlib>

#include "globals.h"
#include "pairs.h"

namespace ePiX {

/* Member functions */

// constructor
  pair::pair(double init1, double init2)
  {
    x1 = init1;
    x2 = init2;
  }

  // copy
  pair::pair(const pair& old)
  {
    x1 = old.x1;
    x2 = old.x2;
  }

  // increment operators
  pair& pair::operator += (const pair& oper)
  {
    x1 += oper.x1;
    x2 += oper.x2;
  
    return (*this);
  }

  pair& pair::operator -= (const pair& oper)
  {
    x1 -= oper.x1;
    x2 -= oper.x2;
  
    return (*this);
  }

  pair& pair::operator *= (const double& c)
  {
    x1 *= c;
    x2 *= c;
  
    return (*this);
  }

  // complex multiplication and division
  pair& pair::operator *= (const pair& oper)
  {
    double temp = x1;
    x1 = temp * oper.x1 - x2 * oper.x2;
    x2 = temp * oper.x2 + x2 * oper.x1;
  
    return (*this);
  }
  pair& pair::operator /= (const pair& oper)
  {
    double denom = hypot(oper.x1, oper.x2);

    double temp = x1;
    x1 = (temp * oper.x1 + x2 * oper.x2)/denom;
    x2 = (x2 * oper.x1 - temp * oper.x2)/denom;
  
    return (*this);
  }

  // equality
  int operator == (const pair& u, const pair& v)
  {
    return ((u.x1 == v.x1) && (u.x2 == v.x2) );
  }

  // negation
  pair operator - (const pair& u)
  {
    return pair(-u.x1, -u.x2);
  }
  
  // addition
  pair operator + (const pair& u, const pair& v)
  {
    return pair(u.x1 + v.x1, u.x2 + v.x2);
  }

  pair operator - (const pair& u, const pair& v)
  {
    return pair(u.x1 - v.x1, u.x2 - v.x2);
  }

  // scalar multiplication
  pair operator * (const double& c, const pair& v)
  {
    return pair(c*(v.x1), c*(v.x2));
  }

  /* 1/4-rotation (mult by i) */
  pair J(pair p)
  {
    return pair(-p.x2, p.x1);
  }

  // complex product
  pair operator * (const pair& u, const pair& v)
  {
    return pair(u.x1*v.x1 - u.x2*v.x2, u.x2*v.x1 + u.x1*v.x2);
  }

  // complex quotient
  pair operator / (const pair& u, const pair& v)
  {
    double denom = hypot(v.x1, v.x2);
  
    if (denom < EPIX_EPSILON) // cf. truncate
      fprintf (stderr, "Error: complex division by 0\n");

    return (1.0/denom)*pair(u.x1*v.x1 + u.x2*v.x2, u.x2*v.x1 - u.x1*v.x2);
  }

  // dot product
  double operator | (const pair& u, const pair& v)
  {
    return u.x1*v.x1 + u.x2*v.x2;
  }

  // componentwise product (a,b)&(x,y)=(ax,by)
  pair operator & (const pair& u, const pair& v)
  {
    return pair(u.x1*v.x1, u.x2*v.x2);
  }

  struct mesh Net (int N1, int N2) 
  {
    struct mesh temp;
  
    temp.n1 = N1;
    temp.n2 = N2;
  
    return temp;
  };

} /* end of namespace */
