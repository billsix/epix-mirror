/* 
 * arcana.cc -- functions not likely to be of general interest
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc5
 * Last Change: April 14, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003  
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <math.h>

#include "pairs.h"
#include "output.h"
#include "objects.h"
#include "arcana.h"

namespace ePiX {

  extern epix_path_style EPIX_PATH_STYLE;
  extern double epix_angle_units;

  static double dt;

  // Difference quotient of f at t
  static double deriv(double f(double), double t, double dt)
  {
    return (f(t + 0.5*dt) - f(t - 0.5*dt))/dt;
  }

  // Convert a momentum profile to a geometric profile
  void 
  draw_profile(double f(double), double a, double b, double x0, int num_pts)
  {
    double x=x0;
    double y0;
    double t=a;
    int i=0, pt_count=0;
    const int N= num_pts*EPIX_ITERATIONS;
    dt = (b-a)/N;

    start_path();
    print(P(x0, sqrt(f(a))));
    ++pt_count;
    t += 0.5*dt;
    y0 = 0.5*deriv(f, t, dt);
    x += dt*sqrt((1-y0*y0)/f(t));

    while (0 <= f(t) && fabs(y0) <= 1 && i < N)
      {
	if ( i%EPIX_ITERATIONS == 0 )
	  {
	    print(P(x, sqrt(f(t))));
	    ++pt_count;
	    line_break(pt_count, num_pts);
	  }

	++i;
	y0 = 0.5*deriv(f, t, dt);
	x += dt*sqrt((1-y0*y0)/f(t));
	t += dt;
      }
    print(P(x, sqrt(f(b))));
  }

  void plot_profile(double f(double), double a, double b, int num_pts)
  {
    epix_comment("profile plot");
    draw_profile(f, a, b, x_min, num_pts);
    end_stanza();
  }

  void 
  plot_profile(double f(double), double a, double b, double x0, int num_pts)
  {
    epix_comment("profile plot");
    draw_profile(f, a, b, x0, num_pts);
    end_stanza();
  }

  // Plane linear transformations

  // 2x2 matrix multiplication [a1 a2][in] = [out]
  pair transf(pair a1, pair a2, pair in)
  {
    pair out;

    out.x1 = a1.x1*in.x1 + a2.x1*in.x2;
    out.x2 = a1.x2*in.x1 + a2.x2*in.x2;

    return out;
  }

  pair reflect(double theta, pair in)
  {
    double a = ePiX::cos(2*theta);
    double b = ePiX::sin(2*theta);
    pair out;

    // Columns of reflection matrix are P(a,b), P(b,-a)
    out=transf(pair(a,b), pair(b,-a), in);

    return out; 
  }

  void 
  std_F(pair a1, pair a2)
  {
    pair p1, p2, p3, p4, p5, p6, p7, p8, p9, p10;
    pair q1, q2, q3, q4, q5, q6, q7, q8, q9, q10;
    pair c1, c2, c3, c4;

    double r=1.0/6.0;

    // Vertices of standard F
    p1 = pair(r,   0.75*r);
    p2 = pair(2*r, 0.75*r);
    p3 = pair(2*r, 2.25*r);
    p4 = pair(4*r, 2.25*r);
    p5 = pair(4*r, 3.25*r);
    p6 = pair(2*r, 3.25*r);
    p7 = pair(2*r, 4.25*r);
    p8 = pair(5*r, 4.25*r);
    p9 = pair(5*r, 5.25*r);
    p10= pair(r,   5.25*r);

    // Vertices of transformed F
    q1 = transf(a1, a2, p1);
    q2 = transf(a1, a2, p2);
    q3 = transf(a1, a2, p3);
    q4 = transf(a1, a2, p4);
    q5 = transf(a1, a2, p5);
    q6 = transf(a1, a2, p6);
    q7 = transf(a1, a2, p7);
    q8 = transf(a1, a2, p8);
    q9 = transf(a1, a2, p9);
    q10= transf(a1, a2, p10);

    // Vertices of parallelogram
    c1 = transf(a1, a2, pair(0,0));
    c2 = transf(a1, a2, pair(1,0));
    c3 = transf(a1, a2, pair(1,1));
    c4 = transf(a1, a2, pair(0,1));

    epix_comment("standard \"F\"");

    // Boundary of parallelogram
    fprintf (stdout, "\n\\path");
    print(c1);
    print(c2);
    print(c3);
    print(c4);
    print(c1);

    dot(P(0,0));

    // The actual F
    fprintf (stdout, "\n\\blacken\\path");
    print(q1);
    print(q2);
    print(q3);
    print(q4);
    print(q5);
    print(q6);
    print(q7);
    print(q8);
    print(q9);
    print(q10);
    print(q1);

    end_stanza();
  }

  /*
   * fractal generation
   *
   * The basic recursion unit is a piecewise-linear path whose segments
   * are parallel to spokes on a wheel, labelled modulo <spokes>.
   * Recursively up to <depth>, each segment is replaced by a copy of the
   * recursion unit, scaled and rotated in order to join p to q.
   *
   * Kludge: pre_seed[0] = spokes, pre_seed[1] = length of seed;
   *
   * Sample data for _/\_ standard Koch snowflake:
   * const int seed[] = {6, 4, 0, 1, -1, 0};
   */

  static int get_spokes(const int *pre_seed) { return pre_seed[0]; }
  static int get_length(const int *pre_seed) { return pre_seed[1]; }

  static pair get_scale(int spokes, int length, const int *seed)
  {
    pair sum = pair(0,0);

    for (int i=0; i< length; ++i)
      //      sum += cis(2*M_PI*seed[i]/(epix_angle_units*spokes));
      sum += pair(std::cos(seed[i]*2*M_PI/spokes), 
      		  std::sin(seed[i]*2*M_PI/spokes));
    return sum;
  }

  void fractal(triple p, triple q, int depth, const int *pre_seed)
  {
    int spokes = get_spokes(pre_seed);
    int seed_length = get_length(pre_seed);

    // Kludge to extract seed from pre_seed
    int seed[seed_length];
    for (int i=0; i<seed_length; ++i)
      seed[i] = pre_seed[i+2];

    // Unit-length steps in <seed> sequence add up to <scale>
    pair scale = get_scale(spokes, seed_length, seed);

    // Number of points in final fractal
    int length = 1+(int)pow(seed_length, depth); 
    int direction[length]; // stepping information

    triple location = p; // coordinates of current point
    triple step; // increment between successive points

    for(int i=0; i<length; ++i) // initialize direction[]
      direction[i]=0;

    /* 
     * direction[] starts out [0, 1, -1, 0, ..., 0] (seed_length^depth entries)
     * then take repeated "Kronecker sum" with seed = [0, 1, -1, 0]
     */

    for(int i=0; i<seed_length; ++i)
      direction[i]=seed[i];

    for(int i=1; i<depth; ++i) // recursively fill direction array
      for(int j=0; j < pow(seed_length,i); ++j)
	for(int k=seed_length-1; 0 < k; --k)
	  direction[k*(int)pow(seed_length,i) + j] = direction[j] + seed[k];

    epix_comment("fractal curve");
    start_path();

    print(location);
    pair temp;

    for(int i=0; i<length; ++i)
      // Hardwired constant: Split output into 200-point blocks (TeX memory)
      if(i < length-1)
	{
	  if (i%200 == 0 && 0 < i)
	    {
	      start_path();
	      print(location); // New path segment -- repeat point
	    }
	  else 
	    line_break(i, length);
	  /*
	  step = polar(pow(raw_len(scale),-depth),
		       (2*M_PI/(epix_angle_units*spokes))*direction[i])*(q-p);
	  */
	  double radius = pow(raw_len(scale),-depth);
	  temp = radius*pair(std::cos((2*M_PI/spokes)*direction[i]),
			     std::sin((2*M_PI/spokes)*direction[i])) *
	    pair((q-p).x1, (q-p).x2);
	  temp /= scale;
	  step = P(temp.x1, temp.x2);
	  location += step;      
	  print(location);
	}
    end_stanza();
  }

} /* end of namespace */
