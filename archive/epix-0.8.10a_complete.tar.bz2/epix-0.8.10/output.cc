/* 
 * output.cc -- output file formatting routines
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc10
 * Last Change: May 27, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <cstdio>
#include <iostream>

#define _EPIX_COMPILE_OUTPUT

#include "globals.h"
#include "pairs.h"
#include "triples.h"
#include "camera.h"
#include "lengths.h"
#include "output.h"

namespace ePiX {

  extern const char *epix_version;

  double epix_stretch_factor=1.0;
  double epix_angle_units=1.0;

  double h_size, v_size, h_offset, v_offset;
  double x_min, x_max, y_min, y_max, x_size, y_size;
  double clip1_min, clip1_max, clip2_min, clip2_max, clip3_min, clip3_max;
  double pic_size;
  char *pic_unit;

  epix_path_style EPIX_PATH_STYLE;
  epix_camera camera; // initialized in begin()

  int epix_begin_count=0; // number of calls to begin()

  // Functions for setting variables
  void bounding_box(triple arg1, triple arg2)
  {
    pair p1 = pair(arg1.x1, arg1.x2);
    pair p2 = pair(arg2.x1, arg2.x2);

    if (p1.x1 < p2.x1)
      {
	x_min = p1.x1;
	x_max = p2.x1;
      }

    else if (p1.x1 > p2.x1)
      {
	x_min = p2.x1;
	x_max = p1.x1;
      }
    else
      {
	fprintf (stderr, "Error: Bounding box has width zero!\n");
	exit(1);
      }

    if (p1.x2 < p2.x2)
      {
	y_min = p1.x2;
	y_max = p2.x2;
      }

    else if (p1.x2 > p2.x2)
      {
	y_min = p2.x2;
	y_max = p1.x2;
      }
    else
      {
	fprintf (stderr, "Error: Bounding box has height zero!\n");
	exit(1);
      }

    x_size = x_max - x_min;
    y_size = y_max - y_min;
  }

  void picture(triple sizes)
  {
    h_size = sizes.x1;
    v_size = sizes.x2;
  }

  void offset(triple shift)
  {
    h_offset = shift.x1;
    v_offset = shift.x2;
  }

  // visibility tests for (screen) cropping and (object space) clipping
  bool is_visible(triple arg)
  {
    pair image = view(arg);
    return (x_min <= image.x1 && image.x1 <= x_max &&
	    y_min <= image.x2 && image.x2 <= y_max);
  }

  bool is_in_bounds(triple arg)
  {
    return (clip1_min <= arg.x1 && arg.x1 <= clip1_max &&
	    clip2_min <= arg.x2 && arg.x2 <= clip2_max &&
	    clip3_min <= arg.x3 && arg.x3 <= clip3_max);
  }

  void unitlength(const char *units)
  {
    pic_size = strtod(units, &pic_unit);
  }

  void clip_box(triple p1, triple p2)
  {
    // first coordinate
    if (p1.x1 <= p2.x1)
      {
	clip1_min = p1.x1;
	clip1_max = p2.x1;
      }
    else
      {
	clip1_min = p2.x1;
	clip1_max = p1.x1;
      }

    // second coordinate
    if (p1.x2 <= p2.x2)
      {
	clip2_min = p1.x2;
	clip2_max = p2.x2;
      }
    else
      {
	clip2_min = p2.x2;
	clip2_max = p1.x2;
      }

    // third coordinate
    if (p1.x3 <= p2.x3)
      {
	clip3_min = p1.x3;
	clip3_max = p2.x3;
      }

    else
      {
	clip3_min = p2.x3;
	clip3_max = p1.x3;
      }

    if (clip1_min == clip1_max || 
	clip2_min == clip2_max || 
	clip3_min == clip3_max)
      std::cerr << "WARNING: Clipping to planar box\n";
  }

  void clip_to(triple arg) { clip_box(P(0,0,0), arg); }
  void clip_box(triple arg) { clip_box(arg, -arg); }

  // Sectioning Functions

  // Print standard ePiX picture header and set clip_box
  void begin(void)
  {
    solid(); // initialize EPIX_PATH_STYLE
    camera = epix_camera(); // defaults to projection along z-axis

    if (epix_begin_count == 0)
      fprintf (stdout, "%%%% ePiX-%s\n", epix_version);
    ++epix_begin_count;

    fprintf (stdout, "%%%%");
    fprintf (stdout, "\n%%%%   Cartesian bounding box: [%g,%g] x [%g,%g]",
	     x_min, x_max, y_min, y_max);
    fprintf (stdout, "\n%%%%   Actual size: %g%s x %g%s",
	     h_size*pic_size, pic_unit, v_size*pic_size, pic_unit);
    fprintf (stdout, "\n%%%%   Figure offset: %s by %g%s, %s by %g%s",
	     (h_offset >= 0) ? "right" : "left", fabs(h_offset)*pic_size, pic_unit, 
	     (v_offset >= 0) ? "up"    : "down", fabs(v_offset)*pic_size, pic_unit);
    fprintf (stdout, "\n%%%%");
    fprintf (stdout, "\n\\setlength{\\unitlength}{%g%s}", pic_size, pic_unit);
    fprintf (stdout, "\n\\begin{picture}(%g,%g)(%g,%g)", \
	     h_size, v_size, -h_offset, -v_offset);

    clip_box(P(x_min, y_min, -EPIX_INFTY), P(x_max, y_max, EPIX_INFTY));
    end_stanza();
  }

  void end() { fprintf (stdout, "\n\\end{picture}\n"); }

  // Print Cartesian pair/triple in LaTeX coordinates
  void print(triple location)
  {
    pair out = truncate(c2p(view(location)));
    fprintf (stdout, "(%g,%g)", out.x1, out.x2);
  }
  void print(pair location)
  {
    pair out = truncate(c2p(view(P(location.x1, location.x2, 0))));
    fprintf (stdout, "(%g,%g)", out.x1, out.x2);
  }

  // print command for label locations
  void print(triple location, triple offset)
  {
    pair loc = truncate(c2p(view(location)) + t2p(pair(offset.x1, offset.x2)));
    fprintf (stdout, "(%g,%g)", loc.x1, loc.x2);
  }
  // print command for spatial displacements
  void print_vector(triple direction)
  {
    pair out = truncate(c2s(view(direction)));
    fprintf (stdout, "(%g,%g)", out.x1, out.x2);
  }

  void
  stretch(double t)
  {
    epix_stretch_factor = t;
  }

  void radians(void)
  {
    epix_angle_units = 1.0;
  }
  void degrees(void)
  {
    epix_angle_units = M_PI/180;
  }
  void revolutions(void)
  {
    epix_angle_units = 2*M_PI;
  }

  // Path style declarations
  void
  pen(char *pen_width) // valid LaTeX length, e.g. "0.01in"
  {
    fprintf (stdout, "\n\\allinethickness{%s}%%", pen_width);
  }

  void 
  pen(double width) // true points
  {
    fprintf (stdout, "\n\\allinethickness{%gpt}%%", width);
  }

  void start_path(void)
  {
    fprintf (stdout, "\n");

    if (EPIX_PATH_STYLE == SOLID)
      fprintf (stdout, "\\path");

    else if (EPIX_PATH_STYLE == DASHED)
      fprintf (stdout, "\\dashline{%.3f}", 
	       t2p(epix_stretch_factor*EPIX_DASH_LENGTH));

    else if (EPIX_PATH_STYLE == DOTTED)
      fprintf (stdout, "\\dottedline{%.3f}", 
	       t2p(epix_stretch_factor*EPIX_DOT_SEP));

    else // defensive measure...
      fprintf (stdout, "\\path");
  }

  // Unified comment function
  void epix_comment(char *type)
  {
    fprintf(stdout, "\n%%%% %s:\n%%%%", type);
  } 

  // End current stanza of .eepic file
  void end_stanza(void)
  {
    int i=0;
    // Stanza separator of width EPIX_FILE_WIDTH
    fprintf (stdout, "\n%%%%\n%%%%");
    for (i=0; i<= EPIX_FILE_WIDTH - 4; ++i)
      fprintf (stdout, "-");
    fprintf (stdout, "%%%%");
  }

  void line_break(int i, int num_pts)
  {
    // Print only 3 points on first line of dashed/dotted path
    if (EPIX_PATH_STYLE == DASHED || EPIX_PATH_STYLE == DOTTED)
      ++i;
  
    if ((i+1) % EPIX_PAIRS_PER_LINE == 0 && i < num_pts)
      fprintf (stdout, "\n  ");
  }

  // Variable color handling, requires "color" package

  // Force double to [0,1]
  static double 
  clip_to_unit(double t)
  {
    if (t < 0)
      return 0;
    else if (t > 1)
      return 1;
    else
      return t;
  }

  // Red-Blue-Green color model
  void
  rgb(double r, double g, double b)
  {
    r = clip_to_unit(r);
    g = clip_to_unit(g);
    b = clip_to_unit(b);
    fprintf (stdout, "\n\\color[rgb]{%.2f,%.2f,%.2f}", r, g, b);
  }

  // Cyan-Magenta-Yellow-Black color model, better for printing
  void
  cmyk(double c, double m, double y, double k)
  {
    c = clip_to_unit(c);
    m = clip_to_unit(m);
    y = clip_to_unit(y);
    k = clip_to_unit(k);
    fprintf (stdout, "\n\\color[cmyk]{%.2f,%.2f,%.2f,%.2f}", c, m, y, k);
  }

  // Changing the shading

  void gray(double x)
  {
    if (x<0) x=0;
    if (x>1) x=1;

    fprintf(stdout, "\n\\special{sh %g}%%%%", x);
  }

} /* end of namespace */
