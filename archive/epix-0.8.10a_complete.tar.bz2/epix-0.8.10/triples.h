/* 
   triples.h -- ePiX::triple class
 
   This file provides:

   The triple class (ordered triple of <double>s) and operators

    - triple(), P() (default to origin), E_1, E_2, E_3 (standard basis)
    - polar(r, theta), cis(theta), sph(rho, theta, phi)
    - Vector space operators
    - Other vector operators, operands (a,b,c), (x,y,z)
       | dot product                      ax + by + cz
       norm(p) = sqrt(p|p)
       & componentwise product            (ax, by, cz)
       * cross product                    (bz-cy, cx-az, ay-bx)
       J rotate (x1,x2,0)-plane 1/4 turn  (-b,a,0)
       % orthogonalization                u%v = u - ((u|v)/(v|v))*v
 */

/*
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc7
 * Last Change: April 21, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_TRIPLES
#define _EPIX_TRIPLES

#include "functions.h"
#include "pairs.h"

namespace ePiX {

  class triple 
    {
    public:
      double x1, x2, x3;

      triple(double arg1=0, double arg2=0, double arg3=0)
	{x1 = arg1; x2 = arg2; x3 = arg3; }

      triple(const triple& old)
      	{ x1 = old.x1; x2 = old.x2; x3 = old.x3; }

     // increment operators
      triple& operator += (const triple& arg)
	{
	  x1 += arg.x1; x2 += arg.x2; x3 += arg.x3;
	  return (*this);
	}

      triple& operator -= (const triple& arg)
	{
	  x1 -= arg.x1; x2 -= arg.x2; x3 -= arg.x3;  
	  return (*this);
	}

      triple& operator *= (const double& c) // scalar multipication
	{
	  x1 *= c; x2 *= c; x3 *= c;
	  return (*this);
	}

      // dot product
      double operator |= (const triple& v)
	{
	  return (this->x1)*(v.x1) + (this->x2)*(v.x2) + (this->x3)*(v.x3);
	}

      // cross product
      triple operator *= (const triple& v)
	{
	  return triple(this->x2 * v.x3 - this->x3 * v.x2,
			this->x3 * v.x1 - this->x1 * v.x3,
			this->x1 * v.x2 - this->x2 * v.x1);
	}
    }; /* end of class */

  inline triple P(double arg1=0, double arg2=0, double arg3=0)
    { return triple(arg1, arg2, arg3); }

  const triple E_1 = P(1,0,0);
  const triple E_2 = P(0,1,0);
  const triple E_3 = P(0,0,1);

  // N.B. ePiX:: trig functions are sensitive to angle units
  inline triple polar(double r, double t) 
    { return P(r*ePiX::cos(t),r*ePiX::sin(t),0); }

  inline triple cis(double t) 
    { return P(ePiX::cos(t), ePiX::sin(t),0); }

  inline triple sph(double r, double t, double phi) 
    {
      return P(r*(ePiX::cos(t))*(ePiX::cos(phi)), 
	       r*(ePiX::sin(t))*(ePiX::cos(phi)), 
	       r*(ePiX::sin(phi)));
    }

  // (in)equality
  inline bool operator == (const triple& u, const triple& v)
  { return ((u.x1 == v.x1) && (u.x2 == v.x2) && (u.x3 == v.x3) ); }

  inline bool operator != (const triple& u, const triple& v)
  { return ((u.x1 != v.x1) || (u.x2 != v.x2) || (u.x3 != v.x3) ); }

  // vector space operations
  inline triple operator - (const triple& u)
  { return P(-u.x1, -u.x2, -u.x3); }
  
  inline triple operator + (const triple& u, const triple& v)
  { return P(u.x1 + v.x1, u.x2 + v.x2, u.x3 + v.x3); }

  inline triple operator - (const triple& u, const triple& v)
  { return P(u.x1 - v.x1, u.x2 - v.x2, u.x3 - v.x3); }

  // scalar multiplication
  inline triple operator * (const double& c, const triple& v)
  { return P(c*(v.x1), c*(v.x2), c*(v.x3)); }

  // cross product
  inline triple operator * (const triple& u, const triple& v)
  {
    return P(u.x2 * v.x3 - u.x3 * v.x2,	
	     u.x3 * v.x1 - u.x1 * v.x3,
	     u.x1 * v.x2 - u.x2 * v.x1);
  }

  inline triple J(const triple arg) { return E_3*arg; }

  // dot product
  inline double operator | (const triple& u, const triple& v)
    { return u.x1*v.x1 + u.x2*v.x2 + u.x3*v.x3; }

  inline double norm(triple arg) { return sqrt(arg|arg); }

  // componentwise product (a,b,c)&(x,y,z)=(ax,by,cz)
  inline triple operator & (const triple& u, const triple& v)
    { return P(u.x1*v.x1, u.x2*v.x2, u.x3*v.x3); }

  // orthogonalization: u%v is component of u perp to v
  inline triple operator % (triple& u, const triple& v)
    { return u - ((u|v)/(v|v))*v; }

} /* end of namespace */

#endif /* _EPIX_TRIPLES */
