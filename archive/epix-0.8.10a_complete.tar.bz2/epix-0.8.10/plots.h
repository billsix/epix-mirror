/*
 * plots.h -- function plotting
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.10rc10
 * Last Change: May 26, 2003
 *
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_PLOTS
#define _EPIX_PLOTS

#include "pairs.h"
#include "triples.h"
#include "objects.h"
#include "functions.h"

namespace ePiX {
  // utility functions
  inline void plot_pt(double f(double), double t) 
    { print(P(t, f(t), 0)); }
  inline void plot_pt(double f1(double), double f2(double), double t)
    { print(P(f1(t), f2(t), 0)); }
  inline void plot_pt(double f1(double), double f2(double), 
			double f3(double), double t) 
    { print(P(f1(t), f2(t), f3(t))); }

  inline void plot_pt(pair F(double), double t) 
    { print(P(F(t).x1, F(t).x2, 0)); }
  inline void plot_pt(triple F(double), double t) 
    { print(F(t)); }

  inline void polar_plot_pt(double f(double), double t) 
    { print(polar(f(t),t)); }

  // Adaptive plotting
  void draw_adapt_plot (double f1(double), double f2(double), 
			double, double, int);
  void adplot     (double f(double), double, double, int);
  void adplot     (double f1(double), double f2(double), double, double, int);

  void draw_adapt_plot (triple f(double), double, double, int);
  void adplot     (triple f(double), double, double, int);

  // Ordinary graph plot
  void draw_plot (double f(double), double, double, int);
  void plot      (double f(double), double, double, int);

  // Parametric plane curve
  void draw_plot (double f1(double), double f2(double), double, double, int);
  void plot      (double f1(double), double f2(double), double, double, int);

  void draw_plot (triple f(double), double, double, int);
  void plot      (triple f(double), double, double, int);

  // Parametric space curve
  void draw_plot (double f1(double), double f2(double), double f3(double),
		  double, double, int);

  void plot      (double f1(double), double f2(double), double f3(double),
		  double, double, int);

  void draw_plot (triple f(double), double, double, int);
  void plot      (triple f(double), double, double, int);

  /*
  // Projection of space curve to plane through the origin
  void draw_shadowplot (double f1(double), double f2(double), 
			double f3(double), triple, double, double, int);
  void shadow          (double f1(double), double f2(double), 
			double f3(double), triple, double, double, int);

  void draw_shadowplot (triple f(double), triple, double, double, int);
  void shadow          (triple f(double), triple, double, double, int);
  */

  // Polar graph
  void draw_polarplot (double r(double), double, double, int);
  void polarplot      (double r(double), double, double, int);

  // Plotting families of curves -- sliceplot1 holds first variable constant
  void draw_sliceplot1(double f1(double, double), double f2(double, double), 
		       double, double, double, int);
  void draw_sliceplot2(double f1(double, double), double f2(double, double), 
		       double, double, double, int);

  void sliceplot1 (double f1(double, double), double f2(double, double), 
		   double, double, double, int);
  void sliceplot2 (double f1(double, double), double f2(double, double), 
		   double, double, double, int);

  // triple-valued plot argument
  void draw_sliceplot1(triple f(double, double), double, double, double, int);
  void draw_sliceplot2(triple f(double, double), double, double, double, int);
  void sliceplot1 (triple f(double, double), double, double, double, int);
  void sliceplot2 (triple f(double, double), double, double, double, int);

  // multiplot = several sliceplots
  void draw_multiplot1 (double f1(double, double), double f2(double, double), 
			triple, triple, mesh, int);
  void draw_multiplot2 (double f1(double, double), double f2(double, double), 
			triple, triple, mesh, int);

  void multiplot1 (double f1(double, double), double f2(double, double), 
		   triple, triple, mesh, int);
  void multiplot2 (double f1(double, double), double f2(double, double), 
		   triple, triple, mesh, int);
  // triple-valued plot argument
  void draw_multiplot1 (triple f(double, double), triple, triple, mesh, int);
  void draw_multiplot2 (triple f(double, double), triple, triple, mesh, int);
  void multiplot1 (triple f1(double, double), triple, triple, mesh, int);
  void multiplot2 (triple f1(double, double), triple, triple, mesh, int);

  // "Cropped" plotting -- truncated to bounding_box
  void draw_cropplot (double f1(double), double f2(double), double f3(double),
		      double, double, int);
  void draw_cropplot (triple f(double), double, double, int);
  void draw_cropplot (triple f(double), double, double, int);

  // Ordinary plots
  void cropplot (double f(double), double, double, int);
  // Parametric plane curves
  void cropplot (double f1(double), double f2(double), double, double, int);
  // Parametric space curves
  void cropplot (double f1(double), double f2(double), double f3(double),
		 double t_min, double t_max, int num_pts);
  void cropplot (triple f(double), double t_min, double t_max, int num_pts);

  // For backward compatibility
  inline void clipplot (double f(double), double t_min, double t_max, 
			int num_pts) { cropplot(f, t_min, t_max, num_pts); }

  inline void clipplot (double f1(double), double f2(double), 
			double t_min, double t_max, int num_pts)
    { cropplot(f1, f2, t_min, t_max, num_pts); }

  inline void clipplot (double f1(double),double f2(double),double f3(double),
			double t_min, double t_max, int num_pts)
    { cropplot(f1, f2, f3, t_min, t_max, num_pts); }

  inline void clipplot (triple f(double),double t_min,double t_max,int num_pts)
    { cropplot(f, t_min, t_max, num_pts); }

  // Data plotting from file
  void data_plot (const char *, epix_mark_type);

  // Derivatives and integrals
  void draw_deriv     (double f(double), double, double, int);
  void plot_deriv     (double f(double t), double, double, int);

  void tan_line(double f1(double t), double f2(double t), double t0);
  void tan_line(double f(double t), double t0);
  void tan_line(triple f(double t), double t0);

  void envelope(double f1(double), double f2(double), double, double, int);
  void envelope(double f(double), double, double, int);
  void envelope(triple f(double), double, double, int);

  void tan_field     (double f1(double), double f2(double), 
		      double, double, double);
  //  void boldtan_field (double f1(double), double f2(double), 
  //		      double, double, double);
  void tan_field     (triple f(double), double, double, double);
  //  void boldtan_field (triple f(double), double, double, double);

  // lower limit is endpoint of plot interval
  double integrate  (double f(double), double a, double b);
  void draw_int     (double f(double), double, double, int);
  void plot_int     (double f(double), double, double, int);

  // separate lower limit
  void draw_int     (double f(double), double, double, double, int);
  void plot_int     (double f(double), double, double, double, int);

  // Slope, dart, and vector fields
  void draw_slope_field (double f1(double, double), double f2(double, double),
			 triple, triple, int, int);
  void slope_field      (double f1(double, double), double f2(double, double),
			 triple, triple, int, int);
  void boldslope_field  (double f1(double, double), double f2(double, double),
			 triple, triple, int, int);

  void draw_dart_field  (double f1(double, double), double f2(double, double),
			 triple, triple, int, int);
  void dart_field       (double f1(double, double), double f2(double, double),
			 triple, triple, int, int);
  void bolddart_field   (double f1(double, double), double f2(double, double),
			 triple, triple, int, int);

  void draw_vector_field (double f1(double, double), double f2(double, double),
			  triple, triple, int, int);
  void vector_field      (double f1(double, double), double f2(double, double),
			  triple, triple, int, int);
  void boldvector_field  (double f1(double, double), double f2(double, double),
			  triple, triple, int, int);

  // triple-valued vector field
  void draw_slope_field  (triple F(double, double), triple, triple, int, int);
  void slope_field       (triple F(double, double), triple, triple, int, int);
  void boldslope_field   (triple F(double, double), triple, triple, int, int);

  void draw_dart_field   (triple F(double, double), triple, triple, int, int);
  void dart_field        (triple F(double, double), triple, triple, int, int);
  void bolddart_field    (triple F(double, double), triple, triple, int, int);

  void draw_vector_field (triple F(double, double), triple, triple, int, int);
  void vector_field      (triple F(double, double), triple, triple, int, int);
  void boldvector_field  (triple F(double, double), triple, triple, int, int);

  // Solutions of ODE systems
  void draw_ode_plot (double f1(double, double), double f2(double, double),
		      triple, double, int);
  void ode_plot      (double f1(double, double), double f2(double, double),
		      triple, double, int);

  // triple-valued vector field
  void draw_ode_plot (triple F(double, double), triple, double, int);
  void ode_plot      (triple F(double, double), triple, double, int);

  // Image of a point set under a planar flow
  void draw_flow_plot(double f1(double, double), double f2(double, double),
		      triple f(double), triple color(double), double, int, int);
  // With and without color function
  void flow_plot(double f1(double, double), double f2(double, double),
		 triple f(double), triple color(double), double, int, int);
  void flow_plot(double f1(double, double), double f2(double, double),
		 triple f(double), double, int, int);

  // triple-valued vector field
  void draw_flow_plot(triple F(double, double), triple f(double), 
		      triple color(double), double, int, int);
  void flow_plot(triple F(double, double), triple f(double), 
		 triple color(double), double, int, int);
  void flow_plot(triple F(double, double), triple f(double), double, int, int);

  // Jay Belanger's shaded plot routines -- December 1, 2002

  void blackplot(double f(double), double, double, int);
  void blackplot(double f1(double), double f2(double), double, double, int);

  void whiteplot(double f(double), double, double, int);
  void whiteplot(double f1(double), double f2(double), double, double, int);

  void shadeplot(double f(double), double, double, int);
  void shadeplot(double f1(double), double f2(double), double, double, int);

} /* end of namespace */

#endif /* _EPIX_PLOTS */
