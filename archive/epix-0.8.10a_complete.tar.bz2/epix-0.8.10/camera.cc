/* 
 * camera.cc -- camera and methods
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc8
 * Last Change: April 21, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

// n.b. ePiX::trig functions are sensitive to current angle units

#include <iostream>
#include <cstdlib>

#include "globals.h"
#include "functions.h"
#include "camera.h"

namespace ePiX {

  // frame constructor, suitable for (sea,sky,eye) frames: Usually we
  // know the eye vector and want to preserve its direction. The frame
  // is guaranteed to be right-handed, and the first arg is immaterial.
  frame::frame(triple arg1, triple arg2, triple arg3)
  {
    if (norm(arg2*arg3) < EPIX_EPSILON) // too nearly linearly dependent
      {
	std::cerr << "ERROR: Linearly dependent arguments to frame()\n";
	exit(1);
      }

    // partial Gram-Schmidt
    arg3 *= 1/norm(arg3); // normalize eye

    arg2 = arg2%arg3; // orthogonalize sky_vector, preserving screen direction
    arg2 *= 1/norm(arg2); // and normalize

    frame1 = arg2*arg3;
    frame2 = arg2;
    frame3 = arg3;
  }

  epix_camera::epix_camera()
  { 
    orientation = frame();
    target = triple(0,0,0);
    distance = 0;
    screen_projection = shadow; // orthog projection when distance = 0
  }

  // screen projection mappings ("lenses")

  extern epix_camera camera;

  // Point projection to sea-sky plane from point at given "distance"
  // from "target" along "eye" axis
  pair shadow(triple arg)
  {
    triple arg_vector = arg - camera.get_target();
	
    // get frame coordinates; "|" = dot product
    double u1=get_sea(camera)|arg_vector;
    double u2=get_sky(camera)|arg_vector;
    double u3=get_eye(camera)|arg_vector;

    // if Distance = 0, dist (the reciprocal distance) is also 0
    double dist = recip(camera.get_range());

    // camera should be farther from screen plane than object :)
    return pair(u1/(1-dist*u3), u2/(1-dist*u3));
  }

  pair fisheye(triple arg) 
  {
    double d = camera.get_range();
    if (d == 0)
      return pair(0,0); // at infinite distance, everything maps to a point
    else
      {
	triple cam_eye = get_eye(camera);
	triple camera_location = camera.get_target() + d*cam_eye;

	// vector from camera to arg, based at camera
	triple arg_vector = arg - camera_location;
	double length = norm(arg_vector);

	if (fabs(length) < EPIX_EPSILON)
	  return pair(0,0);

	else
	  {
	    // radially project to unit sphere centered at camera
	    triple temp = (1/length)*arg_vector;
	    double u1=get_sea(camera)|temp;
	    double u2=get_sky(camera)|temp;

	    return pair(u1, u2);
	    //	return (std::acos(u3/d)/sqrt(d*d-u3*u3))*pair(u1,u2);
	  }
      }
  }

  pair bubble(triple arg) 
  {
    double d = camera.get_range(); // d=0 does *not* put camera "at infinity"

    triple camera_location = camera.get_target() + d*get_eye(camera);

    // vector from camera to arg, based at camera
    triple arg_vector = arg - camera_location;
    double length = norm(arg_vector);

    if (fabs(length) < EPIX_EPSILON)
      return pair(0,0);

    else
      {
	// radially project to unit sphere centered at camera
	triple temp = (1/length)*arg_vector;
	// get coordinates in camera frame
	double u1=get_sea(camera)|temp;
	double u2=get_sky(camera)|temp;
	double u3=get_eye(camera)|temp;

	return (1/(1-u3))*pair(u1, u2);
      }
  }

  triple get_sea(epix_camera camera) { return camera.orientation.sea(); }
  triple get_sky(epix_camera camera) { return camera.orientation.sky(); }
  triple get_eye(epix_camera camera) { return camera.orientation.eye(); }

  void viewpoint(double a1, double a2, double a3)
  {
    triple temp = P(a1,a2,a3);
    double d = norm(temp);
    temp *= 1.0/d; // normalize

    // (a1,a2,a3) lies along positive z-axis or is the origin
    if (norm(temp - E_3) < EPIX_EPSILON || d == 0)
      camera.orientation = frame(); // standard frame
    // or negative z-axis
    else if (norm(temp + E_3) < EPIX_EPSILON)
      camera.orientation = frame(-E_1, E_2, -E_3);

    else
      camera.orientation = frame(P(-temp.x2, temp.x1, 0), P(0,0,1), temp);

    // and in any case
    camera.range(d);
  }

  void viewpoint(triple arg) { viewpoint(arg.x1, arg.x2, arg.x3); }

} /* end of namespace */
