/*
 * Header file for ePiX_ext
 *
 * Svend Daugaard Pedersen
 *
 * December 07, 2001
 *
 * Last Change: April 14, 2003 (ADH)
 *
 */

#ifndef _EPIX_EXT
#define _EPIX_EXT

#include "../triples.h"

using namespace ePiX;

namespace ePiX_contrib {

  /*
    #define CENTER  0
    #define ABOVE   1
    #define BELOW  -1
    #define LEFT   -2
    #define RIGHT   2
  */

  enum epix_mrkpos { LEFT = -2, BELOW, CENTER, ABOVE, RIGHT };

  /*
   *  Style parameters for cartesian coordinate system
   *
   *  Default values will give a reasonable look.
   */
  struct CartesianStyle
  {
    triple ll;         /* lower left corner  (default is (x_min,y_min))        */
    triple ur;         /* upper right corner (default is (x_max,y_max))        */
    
    double x0;       /* x-position of y-axis, default: 0                     */
    double y0;       /* y-position of x-axis, default: 0                     */
  
    bool   xbroken;  /* broken x-axis, default: FALSE                        */
    bool   ybroken;  /* broken y-axis, default: FALSE                        */
    
    int    xn;       /* number of division marks on x-axis, default: 1       */
    double x1;       /* position of first division mark, default: 1          */
    double dx;       /* distance between marks, default: 1 (ignored if xn<2) */
    double xmrklen;  /* length of marks (measured in pt), default: 3pt       */
    epix_mrkpos xmrkpos; /* mark position (ABOVE,CENTER,BELOW), default: CENTER  */
    
    int    yn;       /* number of division marks on y-axis, default: 1       */
    double y1;       /* position of first division mark, default: 1          */
    double dy;       /* distance between marks, default: 1 (ignored if yn<2) */
    double ymrklen;  /* length of marks (measured in pt), default: 3pt       */
    epix_mrkpos ymrkpos; /* name position (LEFT,CENTER,RIGHT), default: CENTER */

    char** xlabels;  /* labels on x-axis, default: {"1",NULL}                */
    double xlabel1;  /* where to place first label,                          */
                     /*   default: 1 if default label is used, otherwise x1  */
    double dxlabel;  /* distance between labels, defauly: dx                 */
    epix_mrkpos xlabpos;  /* label position (ABOVE,BELOW), default: BELOW    */

    char** ylabels;  /* labels on y-axis, default: {"1",NULL}                */
    double ylabel1;  /* where to place first label,                          */
                     /*   default: 1 if default label is used, otherwise y1  */
    double dylabel;  /* distance between labels, default: dy                 */
    epix_mrkpos ylabpos; /* label position (LEFT,RIGHT), default: RIGHT      */

    char*  xname;    /* name of x-axis, default: "(1)"                       */
    epix_mrkpos xnampos; /*name position (ABOVE,CENTER,BELOW), default: BELOW*/

    char*  yname;    /* name of y-axis, default: "(2)"                       */
    epix_mrkpos ynampos; /* name position (LEFT,CENTER,RIGHT), default: RIGHT*/
  
    bool   graphpap; /* make graphpaper, default: FALSE                      */
    triple gpll;/* lower left corner of paper, default: ll              */
    triple gpur;/* upper right corner of paper, default: uu             */
    triple gp0; /* position of bold line cross, default: (cs.x0,cs.y0)  */
    double xbolddist;/* distance between vertical bold lines, default: 1     */
    double ybolddist;/* distance between horizontal bold lines, default: 1   */
    int    nfinevert;/* no of fine vert lines between bold, default: 9       */
    int    nfinehorz;/* no of fine horiz lines between bold, default: 9      */
  };

  /*
   *  New style coordinate system
   */
  void initCartesianStruct(struct CartesianStyle* cs);
  void cartesianCoord(struct CartesianStyle cs);

  /*
   *  Hatched polygon
   */
  void hatch_polygon(double angle, double dist, int corners, triple& points, ...);

  /*
   *  Hatched area between two graphs
   */
  extern void hatch_area(double angle, double dist, 
			 double f(double), double g(double),
			 double a, double b, int n);

} /* end of namespace */

#endif /* _EPIX_EXT */
