/* 
 * camera.h -- Vectors and operations
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc7
 * Last Change: April 19, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

/*
 * In geometry, a "frame" is a right-handed orthonormal basis, that is,
 * an ordered set of three mututally perpendicular unit vectors, oriented
 * according to the right-hand rule. A frame has nothing to do with
 * picture frames.
 *
 * ePiX uses a camera metaphor to view points in R^3. The camera consists
 * of:
 *   - a frame ({sea, sky, eye}, with the intuitive meanings:)
 *   - a point to look at (the "target")
 *   - the distance from the camera to the target
 *   - a projection mapping from R^3 to R^2 (the "lens")
 *
 * While specific behavior is determined by the lens, the idea is that the
 * viewer sits at given <distance> from the <target>, in the direction of
 * the <eye>. The vectors <sea> and <sky> point horizontally to the right
 * and vertically upward on the screen. A <distance> of zero is taken to
 * mean "infinitely far away"; for example, point projection (<shadow>)
 * becomes orthogonal projection along the <eye> axis. Again, a specific
 * lens can override this behavior, for example by ignoring the distance.
 *
 *
 * This file provides:
 *   - the frame class, and routines for rotating a frame about the axes
 *     determined by its elements. (Note that there are no methods for
 *     rotating about fixed coordinate axes, and that rotations in R^3 do
 *     not generally commute.
 *
 *   - the camera class and routines:
 *       void rotate_sea(double); // change camera orientation
 *       void rotate_sky(double); // about respective axes
 *       void rotate_eye(double);
 *
 *       void range(double d); // set distance from camera to origin
 *       void look_at(P arg); // set target (center of field of view)
 *       void lens(pair (*screen_projection(P))); // set projection mapping
 *
 *       pair shoot(P arg); // project a point to the screen ("take a photo")
 *
 */

#ifndef _EPIX_CAMERA
#define _EPIX_CAMERA

#include "functions.h"
#include "pairs.h"
#include "triples.h"

namespace ePiX {

  class frame {
  private:
    // orthonormal triple
    triple frame1;
    triple frame2;
    triple frame3;

  public:
    //constructors
    frame(void) { frame1 = E_1; frame2 = E_2; frame3 = E_3; }

    // Gram-Schmidt
    frame(triple arg1, triple arg2, triple arg3);

    // frame elements
    triple sea() { return frame1; }
    triple sky() { return frame2; }
    triple eye() { return frame3; }

    // rotations about frame elements
    frame rotate_frame1(double angle)
      {
	triple temp2 = frame2;
	triple temp3 = frame3;

	frame2 = 
	  (ePiX::cos(angle)*(temp2)) - (ePiX::sin(angle)*(temp3));
	frame3 = 
	  (ePiX::sin(angle)*(temp2)) + (ePiX::cos(angle)*(temp3));

	return *this;
      }


    frame rotate_frame2(double angle)
      {
	triple temp3 = frame3;
	triple temp1 = frame1;

	frame3 = 
	  (ePiX::cos(angle)*(temp3)) - (ePiX::sin(angle)*(temp1));

	frame1 = 
	  (ePiX::sin(angle)*(temp3)) + (ePiX::cos(angle)*(temp1));

	return *this;
      }

    frame rotate_frame3(double angle)
      {
	triple temp1 = frame1;
	triple temp2 = frame2;

	frame1 = 
	  (ePiX::cos(angle)*(temp1)) - (ePiX::sin(angle)*(temp2));

	frame2 = 
	  (ePiX::sin(angle)*(temp1)) + (ePiX::cos(angle)*(temp2));

	return *this;
      }

  }; // end of class frame

  class epix_camera {
  private:
    frame orientation;
    double distance;
    triple target;
    pair (*screen_projection)(triple);

  public:

    // defaults to orthog projection on (x,y) plane from pos z-axis
    epix_camera(void);

    double get_range(void) { return distance; }
    triple get_target(void) { return target; }

    // pitch: rotate camera up/down
    void rotate_sea(double angle)
      { 
	orientation = orientation.rotate_frame1(angle);
      }

    // yaw: rotate camera left/right
    void rotate_sky(double angle)
      { 
	orientation = orientation.rotate_frame2(angle);
      }

    // roll: rotate camera about viewing axis
    void rotate_eye(double angle)
      { 
	orientation = orientation.rotate_frame3(angle);
      }

    // get/set distance from camera to origin
    void range(double d) { distance = d; }

    // set target (center of field of view)
    void look_at(triple arg) { target = arg; }

    // set projection mapping
    void lens(pair proj(triple)) { screen_projection = proj; }

    // project a point to the screen ("shoot a photo")
    pair shoot(triple arg) { return screen_projection(arg); }

    // get/set eye vector
    friend triple get_sea(epix_camera camera);
    friend triple get_sky(epix_camera camera);
    friend triple get_eye(epix_camera camera);

    friend void viewpoint(double a1, double a2, double a3);
    
  }; // end of class epix_camera 

  void viewpoint(triple arg);

  // screen projection mappings ("lenses")
  pair shadow(triple arg);
  pair fisheye(triple arg);
  pair bubble(triple arg);

  extern epix_camera camera;
  // Project <triple> according to current camera
  inline pair view(triple arg) { return camera.shoot(arg); }

} /* end of namespace */

#endif /* _EPIX_CAMERA */
