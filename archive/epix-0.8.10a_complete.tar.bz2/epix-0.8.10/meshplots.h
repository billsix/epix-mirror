/*
 * meshplots.h
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.10rc6
 * Last Change: April 16, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_MESH
#define _EPIX_MESH

#include <cstdlib>

#include "pairs.h"
#include "triples.h"

namespace ePiX {

  // meshplots.cc

  void draw_plot(double f1(double, double),
		     double f2(double, double),
		     double f3(double, double), 
		     triple p1, triple p2, mesh N, mesh num_pts);

  // Parametric surfaces
  void plot(double f1(double, double), 
		double f2(double, double), 
		double f3(double, double), 
		triple p1, triple p2, mesh N, mesh num_pts);

  // Graphs of functions of two real variables
  void plot(double f(double, double), 
		triple p1, triple p2, mesh N, mesh num_pts);
  
  // triple-valued plot argument
  void draw_plot(triple Phi(double, double), 
		     triple p1, triple p2, mesh N, mesh num_pts);
  void plot     (triple Phi(double, double), 
		     triple p1, triple p2, mesh N, mesh num_pts);

  // clipped wire mesh plots
  void clipplot(double f1(double, double), 
		double f2(double, double), 
		double f3(double, double), 
		triple p1, triple p2, mesh N, mesh num_pts);
  void clipplot(triple Phi(double, double), 
		triple p1, triple p2, mesh N, mesh num_pts);

  /* * * backward compatibility * * */
  inline void draw_wiremesh(double f1(double, double),
			    double f2(double, double),
			    double f3(double, double), 
			    triple p1, triple p2, mesh N, mesh num_pts)
    { draw_plot(f1,f2,f3, p1,p2, N, num_pts); }

  // Parametric surfaces
  inline void wiremesh(double f1(double, double), 
		       double f2(double, double), 
		       double f3(double, double), 
		       triple p1, triple p2, mesh N, mesh num_pts)
    { plot(f1,f2,f3, p1,p2, N, num_pts); }

  // Graphs of functions of two real variables
  inline void wiremesh(double f(double, double), 
		       triple p1, triple p2, mesh N, mesh num_pts)
    { plot(f, p1,p2, N, num_pts); }
  
  // triple-valued plot argument
  inline void draw_wiremesh(triple Phi(double, double), 
			    triple p1, triple p2, mesh N, mesh num_pts)
    { draw_plot(Phi, p1,p2, N, num_pts); }

  inline void wiremesh     (triple Phi(double, double), 
			    triple p1, triple p2, mesh N, mesh num_pts)
    { plot(Phi, p1, p2, N, num_pts); }

  // clipped wire mesh plots
  inline void clipmesh(double f1(double, double), 
		       double f2(double, double), 
		       double f3(double, double), 
		       triple p1, triple p2, mesh N, mesh num_pts)
    { clipplot(f1,f2,f3, p1,p2, N,num_pts); }

  inline void clipmesh(triple Phi(double, double), 
		       triple p1, triple p2, mesh N, mesh num_pts)
    { clipplot(Phi, p1,p2, N,num_pts); }

} /* end of namespace */

#endif /* _EPIX_MESH */
