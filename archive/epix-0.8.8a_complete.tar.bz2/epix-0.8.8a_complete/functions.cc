/* 
 * functions.cc -- non-standard mathematical functions
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.8rc6
 * Last Change: December 02, 2002
 */

/* 
 * Copyright (C) 2001, 2002  
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <math.h>
#define _INCLUDE
#include "globals.h"

namespace ePiX {

  using namespace std;

/* identity and coordinate projections */
double
id (double x)
{
  return x;
}

double
proj1 (double x, double y)
{
  return x;
}
double
proj2 (double x, double y)
{
  return y;
}

/* sin(x)/x */
double
sinx (double x)
{
  if (x != 0)
    return sin(x)/x;
  else
    return 1;
}

/* reciprocal */
double
recip (double x)
{
  if (x != 0)
    return 1/x;
  else
    return 0;
}

/* signum */
double
sgn (double x)
{
  if (x != 0)
    return x/fabs(x);
  else
    return 0;
}

/* Charlie Brown: Period-2 extension of |x| on [-1,1] /\/\/\/\/\/ */
double
cb (double x)
{
  x = fabs(x); // cb is even

  while (x > 1)
    x += -2;

  return fabs(x); // cb extends |x|
}

/* N.B.: gcd(0,i) = |i| */
int gcd (int i, int j)
{
  int temp;

  i=abs(i);
  j=abs(j);

  if (i==0 || j==0) // (1,0) and (0,1) coprime, others not
    return i+j;

  else {
    if (j < i) // swap them
      {
	temp = j;
	j=i;
	i=temp;
      }
    /* Euclidean algorithm */    
    while ((temp = j%i)) // i does not evenly divide j
      {
	j=i;
	i=temp;
      }
    
    return i;
  }
}

/* inf and sup of f on [a,b] */
double
inf (double f(double), double a, double b)
{
  int i = 0;
  int N = (int) ceil(fabs(b-a)); // N >= 1 unless a=b
  double y = f(a);
  double dx = (b-a)/(N*EPIX_ITERATIONS);

  for (i=1; i <= N*EPIX_ITERATIONS; ++i)
    if (f(a + i*dx) < y)
      y = f(a + i*dx);

  return y;
}

double
sup (double f(double), double a, double b)
{
  int i = 0;
  int N = (int) ceil(fabs(b-a)); // N >= 1 unless a=b
  double y = f(a);
  double dx = (b-a)/(N*EPIX_ITERATIONS);

  for (i=1; i <= N*EPIX_ITERATIONS; ++i)
    if (f(a + i*dx) > y)
      y = f(a + i*dx);

  return y;
}

} /* end of namespace */
