/* 
 * curves.cc -- Ellipses, circular arcs, splines
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.8rc6
 * Last Change: August 06, 2002
 */

/* 
 * Copyright (C) 2001, 2002  
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#define _EPIX_COMPILE
#include "curves.h"

namespace ePiX {

  using namespace std;

extern int EPIX_PATH_STYLE;

/* 
 * Ellipses and half-ellipses 
 */
void 
draw_ellipse(pair center, pair radius)
{
  pair current;

  start_path();
  for (int i=0; i <= 2*EPIX_NUM_PTS; ++i) 
    {
      current = center + (radius&cis(M_PI*i/EPIX_NUM_PTS));
      print(current);

      line_break(i, 2*EPIX_NUM_PTS);
    }
}  

void
ellipse(pair center, pair radius)
{
  epix_comment("ellipse");
  draw_ellipse(center, radius);
  end_stanza();
}

/* 
 * draw_half_ellipse -- draws a *top* half_ellipse with center <center>, 
 *   semi-axes <radius>, EPIX_NUM_PTS+1 points, and translated (in parameter) 
 *   by <phase> (measured in degrees).
 */
void 
draw_half_ellipse(pair center, pair radius, double phase)
{
  int i;
  pair current;

  start_path();
  for (i=0; i <= EPIX_NUM_PTS; ++i) 
    {
      current = center + (radius&cis(M_PI*(i*1.0/EPIX_NUM_PTS + phase/180)));
      print(current);

      line_break(i, EPIX_NUM_PTS);
    }
}  

/* Plain half-ellipses */
void 
ellipse_top(pair center, pair radius)
{
  epix_comment("top half ellipse");
  draw_half_ellipse(center, radius, 0);
  end_stanza();
}

void 
ellipse_bottom(pair center, pair radius)
{
  epix_comment("bottom half ellipse");
  draw_half_ellipse(center, radius, 180);
  end_stanza();
}

void 
ellipse_left(pair center, pair radius)
{
  epix_comment("left half ellipse");
  draw_half_ellipse(center, radius, 90);
  end_stanza();
}

void 
ellipse_right(pair center, pair radius)
{
  epix_comment("right half ellipse");
  draw_half_ellipse(center, radius, -90);
  end_stanza();
}

/* Rotated half_ellipses */
/*
 * draw_ellipse_half -- right ellipse rotated counterclockwise by <angle>
 */
void 
rotate_half_ellipse(pair center, pair radius, double angle)
{
  double t;
  pair current;
  pair rotate = cis(M_PI*angle/180.0);

  start_path();
  for (int i=0; i <= EPIX_NUM_PTS; ++i) 
    {
      t = -M_PI_2 + i*M_PI/EPIX_NUM_PTS;
      current = center + rotate*(radius&cis(t)); // (a,b)&(x,y) = (ax,by)
      print(current);

      line_break(i, EPIX_NUM_PTS);
    }
}

void 
ellipse_half(pair center, pair radius, double angle)
{
  epix_comment("rotated half ellipse");
  rotate_half_ellipse(center, radius, angle);
  end_stanza();
}

/* * * Objects containing circular arcs * * */

/* Circular arc spanning arbitrary angle */
/* 
 * draw_proper_arc is called iff start/finish angles are sensible.
 * Angles are measured in radians, hence may be generated readily
 * by the standard C math functions.
 */
static double 
arc_scale(double r)
{
  pair temp = c2s(P(r,r));
  /* Approx. number of true pts per radian */
  return 0.5*p2t(temp.x1 + temp.x2);
}

void 
draw_proper_arc(pair center, double r, double start, double finish)
{
  double angle = finish - start; 
  pair current;

  /* 
   * Number of points plotted is nearly proportional to radius and
   * angle subtended for large circles, but is no smaller than 20
   * points per circle for small circles. Hybrid of two failed attempts:
   *
   * int num_pts=(int) ceil(fabs(EPIX_NUM_PTS*angle));
   * 
   * ceil(fabs(angle)*unscale(h_scale(r)+v_scale(r))/(2.0*EPIX_DASH_LENGTH));
   */
  int num_pts=(int) ceil(fabs(0.5*(angle/M_PI)*(EPIX_NUM_PTS + arc_scale(r)/EPIX_DASH_LENGTH)));

  if (num_pts < 2)
    num_pts=2;

  start_path();
  for (int i=0; i <= num_pts; ++i) 
    {
      current = center + polar(r, start+i*angle/num_pts);
      print(current);

      line_break(i, num_pts);
    }
}

void 
draw_arc(pair center, double r, double start, double finish)
{
  if (fabs(finish-start) >= 2*M_PI) // One full turn or more
    draw_ellipse(center, P(r, r));

  else if (0 < finish - start)
    draw_proper_arc(center, r, start, finish);
    
  else if (0 > finish - start)
    draw_proper_arc(center, r, finish, start);
  
  else // start == finish
    fprintf(stdout, "\n%%%%   Null arc...?");
}

void 
arc(pair center, double r, double start, double finish)
{
  epix_comment("circular arc");
  draw_arc(center, r, start, finish);
  end_stanza();
}

/* Angle subtended by arrowhead at Cartesian distance r */

static double subtended(double r)
{
  return EPIX_ARROWHEAD_WIDTH*EPIX_ARROWHEAD_RATIO/arc_scale(r);
}

void 
draw_arc_arrow(pair center, double r, double start, double finish)
{
  if (fabs(start - finish) <= subtended(r))
    fprintf(stdout, "\n%%%%   Arc shorter than arrowhead; not printed");
  
  else {
    if (start < finish)
      finish -= subtended(r);
    else
      finish += subtended(r);
    
    /* Terminal point of arc */
    pair base = center + polar(r, finish);
    /* Unit (1 true pt) vector tangent to arc at <base> */
    pair dir = c2s(cis(finish));

    dir = J(normalize(dir));
    /* Reverse direction if necessary */
    if (start > finish)
      dir = -dir;
    
    /* Hardwired constant 0.01 */
    pair tip = base + 0.01*dir;
    
    draw_arc(center, r, start, finish);
    
    //  start_path();
    draw_arrow(base, tip);
  }
}

void 
arc_arrow(pair center, double r, double start, double finish)
{
  epix_comment("arc arrow");
  draw_arc_arrow(center, r, start, finish);
  end_stanza();
}

/* Splines */
static inline pair
quad_spline_pt(pair p1, pair p2, pair p3, double t)
{
  return t*t*p1 + 2*t*(1-t)*p2 + (1-t)*(1-t)*p3;
}
static inline pair
cubic_spline_pt(pair p1, pair p2, pair p3, pair p4, double t)
{
  return t*t*t*p1 + 3*t*t*(1-t)*p2 + 3*t*(1-t)*(1-t)*p3 + (1-t)*(1-t)*(1-t)*p4;
}

/* quad spline */
void 
draw_spline(pair p1, pair p2, pair p3)
{
  double t;
  pair current;

  if (EPIX_PATH_STYLE != DOTTED)
    start_path();
  
  for (int i=0; i <= EPIX_NUM_PTS; ++i) 
    {
      t = i*1.0/EPIX_NUM_PTS;
      current = quad_spline_pt(p1, p2, p3, t);
	
      if (EPIX_PATH_STYLE == DOTTED)
	ddot(current);
      
      else
	{
	  print(current);
	  line_break(i, EPIX_NUM_PTS);
	}
    }
}

/* cubic spline */
void 
draw_spline(pair p1, pair p2, pair p3, pair p4)
{
  double t;
  pair current;

  if (EPIX_PATH_STYLE != DOTTED)
    start_path();
  
  for (int i=0; i <= EPIX_NUM_PTS; ++i) 
    {
      t = i*1.0/EPIX_NUM_PTS;
      current = cubic_spline_pt(p1, p2, p3, p4, t);
	
      if (EPIX_PATH_STYLE == DOTTED)
	ddot(current);
      
      else
	{
	  print(current);
	  line_break(i, EPIX_NUM_PTS);
	}
    }
}

/* quadratic splines */
void
spline(pair p1, pair p2, pair p3)
{
  epix_comment("quadratic spline");
  draw_spline(p1, p2, p3);
  end_stanza();
}

/* cubic splines */
void 
spline(pair p1, pair p2, pair p3, pair p4)
{
  epix_comment("cubic spline");
  draw_spline(p1, p2, p3, p4);
  end_stanza();
}

/* Planar knot diagram primitives */
void 
draw_under_strand(pair p3, pair p6, pair p5, pair p2)
{
  double t;

  // Draw two half-splines with given control points
  start_path();
  for (int i=0; i < EPIX_NUM_PTS/2 - 1; ++i) 
    {
      t = i*1.0/EPIX_NUM_PTS;
      print(cubic_spline_pt(p3, p6, p5, p2, t));
      line_break(i, EPIX_NUM_PTS/2);
    }
  
  t=1; // Start at end of path, step backward
  start_path();
  for (int i=0; i < EPIX_NUM_PTS/2 - 1; ++i) 
    {
      t = 1.0 - i*1.0/EPIX_NUM_PTS;
      print(cubic_spline_pt(p3, p6, p5, p2, t));
      line_break(i, EPIX_NUM_PTS/2);
    }
}

void 
draw_p_twist(pair p1, pair p4)
{
  pair p2, p3, p5, p6;
  // Set up control points in an H
  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      p2.x1 = p1.x1; // <p2>     <p4>
      p2.x2 = p4.x2; // <p5>     <p6>
      p3.x1 = p4.x1; // <p1>     <p3>
      p3.x2 = p1.x2;

      p5.x1 = p1.x1;
      p6.x1 = p4.x1;
      p5.x2 = p6.x2 = (0.5)*(p1.x2 + p4.x2);
    }

  else
    {
      p2.x1 = p4.x1; // <p1> <p5> <p2>
      p2.x2 = p1.x2; // 
      p3.x1 = p1.x1; // <p3> <p6> <p4>
      p3.x2 = p4.x2;

      p5.x2 = p1.x2;
      p6.x2 = p4.x2;
      p5.x1 = p6.x1 = (0.5)*(p1.x1 + p4.x1);
    }
  
  // Over strand
  draw_spline(p1, p5, p6, p4);
  draw_under_strand(p3, p6, p5, p2);
}

void 
draw_n_twist(pair p1, pair p4)
{
  pair p2, p3, p5, p6;

  // Set up control points in an H -- same as draw_p_twist
  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      p2.x1 = p1.x1; // <p2>     <p4>
      p2.x2 = p4.x2; // <p5>     <p6>
      p3.x1 = p4.x1; // <p1>     <p3>
      p3.x2 = p1.x2;

      p5.x1 = p1.x1;
      p6.x1 = p4.x1;
      p5.x2 = p6.x2 = (0.5)*(p1.x2 + p4.x2);
    }

  else
    {
      p2.x1 = p4.x1; // <p1> <p5> <p2>
      p2.x2 = p1.x2; // 
      p3.x1 = p1.x1; // <p3> <p6> <p4>
      p3.x2 = p4.x2;

      p5.x2 = p1.x2;
      p6.x2 = p4.x2;
      p5.x1 = p6.x1 = (0.5)*(p1.x1 + p4.x1);
    }
  
  // Over strand -- control points reversed from draw_p_twist
  draw_spline(p3, p6, p5, p2);
  draw_under_strand(p1, p5, p6, p4);
}

void 
p_twist(pair p1, pair p4)
{
  epix_comment("knot twist, left over right");
  draw_p_twist(p1, p4);
  end_stanza();
}

void 
n_twist(pair p1, pair p4)
{
  epix_comment("knot twist, right over left");
  draw_n_twist(p1, p4);
  end_stanza();
}

void 
twists(pair p1, pair p4, int n)
{
  double a;
  double b;
  double c;
  double d;

  int i;

  fprintf(stdout, "\n%%%% twists(%d), (%.2f,%.2f) to (%.2f,%.2f)", 
	 n, p1.x1, p1.x2, p4.x1, p4.x2);

  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      a = p1.x1;
      b = p1.x2;
      c = p4.x1;
      d = p4.x2;
      
      if (n < 0) {
	n = -n;
	for (i=0; i < n; ++i)
	  draw_n_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n));
      }

      else
	for (i=0; i < n; ++i)
	  draw_p_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n));
    }

  else
    {
      a = p1.x2;
      b = p1.x1;
      c = p4.x2;
      d = p4.x1;

      if (n < 0) {
	n = -n;
	for (i=0; i < n; ++i)
	  draw_n_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c));
      }

      else
	for (i=0; i < n; ++i)
	  draw_p_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c));
    }
  end_stanza();
}

} /* end of namespace */
