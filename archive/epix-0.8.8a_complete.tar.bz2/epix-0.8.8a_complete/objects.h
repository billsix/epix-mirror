/* 
 * objects.h -- Simple picture objects: axes, grids, markers, polygons
 *
 * Andrew D. Hwang                      <ahwang@mathcs.holycross.edu>
 *
 * Version: 0.8.8rc6
 * Last Change: December 02, 2002
 */

#ifndef _EPIX_OBJECTS
#define _EPIX_OBJECTS

#ifdef _EPIX_COMPILE
#include "output.h"
#endif

namespace ePiX {

  using namespace std;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                    Picture objects                    *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 * label -- put string constant <label_text> 
 * at Cartesian position <pair> offset by <vect> true points.
 * Accepts an optional LaTeX-style positioning argument after the offset.
 * If no offset is specified, the label is centered at the given Cartesian
 * location.
 * masklabel requires the "color" package, and places the text in 
 * a white box that masks whatever is underneath and earlier in the file.
 */
void label(pair base, pair offset, char *label_text);
void label(pair base, char *label_text);
void label(pair base, pair offset, char *label_text, 
	   const int epix_label_posn);
void masklabel(pair base, pair offset, char *label_text);
void masklabel(pair base, char *label_text);
void masklabel(pair base, pair offset, char *label_text, 
	       const int epix_label_posn);

/*
 * Empty and filled LaTeX circles of diameter EPIX_SPOT_DIAM true pt
 */
void circ(pair); // filled white circ 4 pt in diameter
void ring(pair, double); // unfilled circ of specified diam
void spot(pair);
void dot(pair);
void ddot(pair);
void dot(pair, double); // filled circ of specified diam

/* Axes and coordinate grids. */

/* 
 * Coordinate axes, specified by initial and final points, and number
 * of steps. h/v_axis are identical except for style of tick marks.
 */
void h_axis_tick(pair);
void v_axis_tick(pair);
void h_axis(pair tail, pair head, int n);
void v_axis(pair tail, pair head, int n);

/*
 * h_axis_labels: Draws n+1 equally-spaced axis labels between 
 *    <tail> and <head>. Automatically generates label values from
 *    Cartesian coordinates, and offsets labels in true pt.
 */

void h_axis_labels(pair tail, pair head, int n, pair offset);
void v_axis_labels(pair tail, pair head, int n, pair offset);

void h_axis_masklabels(pair tail, pair head, int n, pair offset);
void v_axis_masklabels(pair tail, pair head, int n, pair offset);

/* Axis labels with LaTeX-style alignment option */

void h_axis_labels(pair tail, pair head, int n, pair offset, 
		   const int epix_label_posn);
void v_axis_labels(pair tail, pair head, int n, pair offset, 
		   const int epix_label_posn);

void h_axis_masklabels(pair tail, pair head, int n, pair offset, 
		       const int epix_label_posn);
void v_axis_masklabels(pair tail, pair head, int n, pair offset, 
		       const int epix_label_posn);

/* eepic.sty's ellipse comand */
void draw_native_ellipse (pair, pair);
void native_ellipse (pair, pair);

/* Cartesian grid filling bounding_box */
void draw_grid(int, int);
void grid(int, int);

/* Cartesian grid of specified size */
void draw_grid(pair, pair, int, int);
void grid(pair, pair, int, int);

/* Polar grid with n1 rings and n2 sectors */
void draw_polar_grid(double, int, int);
void polar_grid(double, int, int);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *             Simple geometric objects                  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Lines can be "stretched" by double parameter */
void draw_line(pair, pair, int, double); 

/* Lines with stretch factor */
void line(pair, pair, double);     

/* Unstretched lines */
void line(pair, pair);    

/* Returns >0 iff p0 is left of directed segment from p1 to p2 */
double ccw(pair p0, pair p1, pair p2);
/* "Visible" portion of the line through p1, p2 */
void draw_Line(pair, pair, int);
void Line(pair, pair);

/* point-slope form */
void Line(pair, double);

void draw_triangle(pair, pair, pair); 
void triangle(pair, pair, pair);

/* 
 * If (a,b) and (c,d) are opposite corners of a rectangle, then
 * the corners -- in order -- are (a,b), (a,d), (c,d), and (c,b).
 */
void draw_rect(pair, pair); /* opposite corners */
void rect(pair, pair);
/* filled rectangle */
void swatch(pair, pair);

void draw_arrowhead(pair, pair, double);
void draw_shaft(pair, pair, double);
void draw_arrow(pair, pair);
void draw_boldarrow(pair, pair);
void arrow(pair, pair);
void boldarrow(pair, pair);

void draw_dart(pair, pair);
void draw_bolddart(pair, pair);
void dart(pair, pair);
void bolddart(pair, pair);

} /* end of namespace */

#endif /* _EPIX_OBJECTS */
