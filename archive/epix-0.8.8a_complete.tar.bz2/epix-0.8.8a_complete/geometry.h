/*
 * geometry.h 
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.8rc6
 * Last Change: December 02, 2002
 */

#ifndef _EPIX_GEOMETRY
#define _EPIX_GEOMETRY

#ifdef _EPIX_COMPILE
#include "curves.h"
#include "functions.h"
#endif

namespace ePiX {

  using namespace std;

/* Radial projection from origin to unit sphere */
void plot_R      (double f1(double), double f2(double), double f3(double), 
		  double t_min, double t_max, int num_pts);
void frontplot_R (double f1(double), double f2(double), double f3(double), 
		  double t_min, double t_max, int num_pts);
void backplot_R  (double f1(double), double f2(double), double f3(double), 
		  double t_min, double t_max, int num_pts);

/* triple-valued plot argument */
void plot_R      (triple phi(double), double t_min, double t_max, int num_pts);
void frontplot_R (triple phi(double), double t_min, double t_max, int num_pts);
void backplot_R  (triple phi(double), double t_min, double t_max, int num_pts);

/* Stereographic projection from the north pole... */
void plot_N      (double f1(double), double f2(double),
		  double t_min, double t_max, int num_pts);
void frontplot_N (double f1(double), double f2(double),
		  double t_min, double t_max, int num_pts);
void backplot_N  (double f1(double), double f2(double),
		  double t_min, double t_max, int num_pts);

/* and the south */
void plot_S      (double f1(double), double f2(double),
		  double t_min, double t_max, int num_pts);
void frontplot_S (double f1(double), double f2(double),
		  double t_min, double t_max, int num_pts);
void backplot_S  (double f1(double), double f2(double),
		  double t_min, double t_max, int num_pts);

/* Hyperbolic lines */
void draw_hyperbolic_line (pair, pair);
void hyperbolic_line (pair, pair);

void draw_disk_line (pair, pair);
void disk_line (pair, pair);

} /* end of namespace */

#endif /* _EPIX_GEOMETRY */
