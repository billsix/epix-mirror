/*
 * functions.h
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.8rc6
 * Last Change: December 02, 2002
 *
 */

#ifndef _EPIX_FUNCTIONS
#define _EPIX_FUNCTIONS

namespace ePiX {

  using namespace std;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                         functions.c                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

double
id (double);

double
proj1 (double, double);

double
proj2 (double, double);

double
sinx (double);

double
sgn (double);

double
recip (double);

double
cb (double);

int 
gcd (int, int);

double
inf (double f(double), double, double);

double
sup (double f(double), double, double);

} /* end of namespace */

#endif /* _EPIX_FUNCTIONS */
