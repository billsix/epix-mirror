/* 
 * pairs.h -- ePiX pair:: class and mathematical operators
 *
 * Andrew D. Hwang                      <ahwang@mathcs.holycross.edu>
 *
 * Version: 0.8.8rc6
 * Last Change: December 02, 2002
 */

#ifndef _EPIX_PAIRS
#define _EPIX_PAIRS

#ifdef _EPIX_COMPILE
#define _INCLUDE // Used to flag declaration of size variables
#include "globals.h"
#endif

using namespace std;

class pair 
{
 public:
  double x1;
  double x2;

  // void constructor
  pair(void) {}

  // Cartesian constructor
  pair(double x1, double x2);

  // copy
  pair(const pair& old);

  // destructor
  ~pair() {}

  // increment operators
  pair& operator += (const pair&);
  pair& operator -= (const pair&);
  pair& operator *= (const double&);

  // complex multiplication and division
  pair& operator *= (const pair&);
  pair& operator /= (const pair&);
}; /* end of pair class */

/* pair creation */
pair P(double, double); 

#define polar(r, t) P((r)*cos(t),(r)*sin(t))

#define cis(t) P(cos(t), sin(t))

const pair e_1 = P(1,0);
const pair e_2 = P(0,1);

int  operator == (const pair&, const pair&);
pair operator - (const pair&);
pair operator + (const pair&, const pair&);
pair operator - (const pair&, const pair&);

// scalar multiplication
pair operator * (const double&, const pair&);
// Multiplication by i
pair J(pair);

// complex multiplication and division
pair operator * (const pair& u, const pair& v);
pair operator / (const pair& u, const pair& v);

// dot product
double operator |(const pair&, const pair&);
// (a,b)&(x,y)=(ax,by), for unit/coordinate conversion
pair operator &(const pair&, const pair&);

struct mesh {
  int n1;
  int n2;
};

struct mesh Net(int, int);

pair V(double, double, double); // (x1, x2, x3) projected by <viewpoint>

/* * * * Deprecated functions * * * */

/* Vector operations (now overloaded operators) */
pair add_pair(pair, pair);

pair diff_pair(pair, pair);

pair mult_s(double, pair);

/* Complex Multiplication */
pair mult_pair(pair, pair);

#endif /* _EPIX_PAIRS */
