
#include <epix.h>

main() 
{
  struct CartesianStyle cs;

  bounding_box(P(-2,-1), P(4,5));
  picture(P(12, 12));

  unitlength("5mm");

  begin();

  initCartesianStruct(&cs);
  cs.graphpap = 1;
  cartesianCoord(cs);

  end();
}

