
#include <epix.h>

main()
{
  struct CartesianStyle cs;

  bounding_box(P(-3,-2), P(5,6));
  picture(P(12, 12));

  unitlength("5mm");

  begin();

  initCartesianStruct(&cs);
  cs.xname = "t/s";
  cs.xnampos = ABOVE;
  cs.yname = "E/kJ";
  cs.ynampos = LEFT;
  cartesianCoord(cs);

  end();
}




