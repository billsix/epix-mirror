
#include <epix.h>

main()
{
  struct CartesianStyle cs;

  bounding_box(P(-3,-2), P(5,6));
  picture(P(12, 12));

  unitlength("5mm");

  begin();

  initCartesianStruct(&cs);
  cs.ur = P(4,5);
  cs.xnampos = CENTER;
  cs.ynampos = CENTER;
  cartesianCoord(cs);

  end();
}





