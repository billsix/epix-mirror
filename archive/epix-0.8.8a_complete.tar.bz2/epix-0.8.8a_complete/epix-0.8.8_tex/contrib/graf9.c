#include "epix.h"

pair p1 = P(-2,-3), p2 = P(-3,1), p3 = e_1;
pair p4 = P(2,3), p5 = P(4,-2), p6 = P(-1,-1);

main() 
{
  bounding_box(P(-4,-3),P(4,2)); // [-4,4] x [-3,2]
  picture(P(12, 7.5));           // picture is 12 x 7.5 units
  unitlength("5mm");

  /* Start picture */
  begin();

  /* hatched polygon */
  grid(P(x_min, y_min), P(x_max, y_max), x_size, y_size);

  hatch_polygon(45, 0.2, 6, p1, p2, p3, p4, p5, p6);

  /* End picture */
  end();
}
