
#include <epix.h>

static char* xlabels[] =
  {"-2","-1","","1","2","3",NULL};
static char* ylabels[] =
  {"-1","","1","2","3","4",NULL};

main() 
{
  struct CartesianStyle cs;

  bounding_box(P(-3,-2), P(5,6));
  picture(P(12, 12));

  unitlength("5mm");

  begin();

  initCartesianStruct(&cs);
  cs.xn = 6;
  cs.x1 = -2;
  cs.xlabels = xlabels;
  cs.yn = 6;
  cs.y1 = -1;
  cs.ylabels = ylabels;
  cartesianCoord(cs);

  end();
}


