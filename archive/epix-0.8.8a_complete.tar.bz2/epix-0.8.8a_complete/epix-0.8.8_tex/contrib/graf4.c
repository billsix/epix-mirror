
#include <epix.h>

main()
{
  struct CartesianStyle cs;

  bounding_box(P(-3,-2), P(5,6));
  picture(P(12, 12));

  unitlength("5mm");

  begin();

  initCartesianStruct(&cs);
  cs.xmrklen = 2;
  cs.xmrkpos = ABOVE;
  cs.xlabpos = ABOVE;
  cs.ymrklen = 2;
  cs.ylabpos = LEFT;
  cartesianCoord(cs);

  end();
}



