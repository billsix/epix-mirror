/*
 * legacy.h
 *
 * This header contains C macros and declarations for deprecated
 * epix functions.
 *
 * Version 0.8.8rc6
 *
 * Last change: December 02, 2002
 */

#ifndef _EPIX_LEGACY
#define _EPIX_LEGACY

#ifdef _EPIX_COMPILE
#include "objects.h"
#include "curves.h"
#include "geometry.h"
#include "plots.h"
#include "meshplots.h"
#include "arcana.h"
#endif

using namespace std;
using namespace ePiX;

namespace ePiX_legacy {

  using ePiX::draw_profile;

/* * * Macros * * */

/* Pair operations */
#define add_pair(p1, p2) (p1)+(p2)
#define diff_pair(p1, p2) (p1)-(p2)
#define mult_s(c, p2) (c)*(p2)      /* Scalar multiplication */
#define mult_pair(p1, p2) (p1)*(p2) /* Complex product */

/* Old color handling: revert color to black */
#define end_red       fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")
#define end_green     fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")
#define end_blue      fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")

#define end_cyan      fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")
#define end_magenta   fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")
#define end_yellow    fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")

/* macro names for 0.6.x-style splines */
#define draw_quad_spline(p1, p2, p3, STYLE) draw_spline((p1), (p2), (p3), (SYTLE))
#define draw_cubic_spline(p1, p2, p3, p4, STYLE) draw_spline((p1), (p2), (p3), (p4), (SYTLE))

#define quad_spline(p1, p2, p3)     spline((p1), (p2), (p3))
#define dashquad_spline(p1, p2, p3) dashspline((p1), (p2), (p3))
#define dotquad_spline(p1, p2, p3)  dotspline((p1), (p2), (p3))
#define boldquad_spline(p1, p2, p3) boldspline((p1), (p2), (p3))

#define cubic_spline(p1, p2, p3, p4)     spline((p1), (p2), (p3), (p4))
#define dashcubic_spline(p1, p2, p3, p4) dashspline((p1), (p2), (p3), (p4))
#define dotcubic_spline(p1, p2, p3, p4)  dotspline((p1), (p2), (p3), (p4))
#define boldcubic_spline(p1, p2, p3, p4) boldspline((p1), (p2), (p3), (p4))

/* * * plot.h * * */
/* Parametric plane curves */
#define paramplot(f1, f2, a, b, n)     plot(f1, f2, (a), (b), (n))
#define dashparamplot(f1, f2, a, b, n) dashplot(f1, f2, (a), (b), (n))
#define dotparamplot(f1, f2, a, b, n)  dotplot(f1, f2, (a), (b), (n))
#define boldparamplot(f1, f2, a, b, n) boldplot(f1, f2, (a), (b), (n))

/* Parametric space curves */
#define plot3d(u1, u2, u3, a, b, n)     plot(u1,  u2, u3, (a), (b), (n))
#define dashplot3d(u1, u2, u3, a, b, n) dashplot(u1,  u2, u3, (a), (b), (n))
#define dotplot3d(u1, u2, u3, a, b, n)  dotplot(u1,  u2, u3, (a), (b), (n))
#define boldplot3d(u1, u2, u3, a, b, n) boldplot(u1,  u2, u3, (a), (b), (n))

/* clipplot */
/* Clipped parametric plane curves */
#define clipparamplot(f1, f2, a, b, n)     clipplot(f1, f2, (a), (b), (n))
#define dashclipparamplot(f1, f2, a, b, n) dashclipplot(f1, f2, (a), (b), (n))
#define dotclipparamplot(f1, f2, a, b, n)  dotclipplot(f1, f2, (a), (b), (n))
#define boldclipparamplot(f1, f2, a, b, n) boldclipplot(f1, f2, (a), (b), (n))

/* Clipped parametric space curves */
#define clipplot3d(f1,f2,f3,a,b,n)     clipplot(f1,f2,f3,(a),(b),(n))
#define dashclipplot3d(f1,f2,f3,a,b,n) dashclipplot(f1,f2,f3,(a),(b),(n))
#define dotclipplot3d(f1,f2,f3,a,b,n)  dotclipplot(f1,f2,f3,(a),(b),(n))
#define boldclipplot3d(f1,f2,f3,a,b,n) boldclipplot(f1,f2,f3,(a),(b),(n))

/* * * Legacy Declarations */

/* * * objects.h * * */
/*
 * mask -- filled white rectangle to mask out part of a figure
 * prior to label placement. Parameters designed to match those
 * of labels; <base> is the Cartesian location, <offset> is the
 * offset in true pt, <size> is the size of the box in true pt.
 *
 * Use of "mask" is deprecated; use masklabel and axis_masklabels
 * instead.
 */
void mask(pair base, pair offset, pair size);

/* Cartesian coordinate grid */
void dashgrid(int, int);
void dotgrid(int, int);
void boldgrid(int, int);

/* Cartesian grid of arbitrary size */
void dashgrid(pair, pair, int, int);
void dotgrid(pair, pair, int, int);
void boldgrid(pair, pair, int, int);

/* Polar grid */
void dashpolar_grid(double, int, int);
void dotpolar_grid(double, int, int);
void boldpolar_grid(double, int, int);

/* Two-point lines with stretch factor */
void dashline(pair, pair, double); 
void dotline(pair, pair, double); 
void boldline(pair, pair, double); 

/* Two-point lines, no stretch */
void dashline(pair, pair);
void dotline(pair, pair);
void boldline(pair, pair);

/* Two-point Lines */
void dashLine(pair, pair);
void dotLine(pair, pair);
void boldLine(pair, pair);

/* Point-slope Lines */
void dashLine(pair, double);
void dotLine(pair, double);
void boldLine(pair, double);

/* Triangles */
void dashtriangle(pair, pair, pair);
void dottriangle(pair, pair, pair);
void boldtriangle(pair, pair, pair);

/* Coordinate rectangles */
void dashrect(pair, pair); 
void dotrect(pair, pair); 
void boldrect(pair, pair); 
/* filled */
void boldswatch(pair, pair);

/* Arrows and darts */
void dasharrow(pair, pair);
void dotarrow(pair, pair);

void dashdart(pair, pair);
void dotdart(pair, pair);

/* * * curves.h * * */

/* Ellipses and half ellipses */
void dashellipse (pair, pair); 
void dotellipse (pair, pair); 
void boldellipse (pair, pair); 

void dashellipse_left (pair, pair);
void dashellipse_right (pair, pair);
void dashellipse_top (pair, pair);
void dashellipse_bottom (pair, pair);

void dotellipse_left (pair, pair);
void dotellipse_right (pair, pair);
void dotellipse_top (pair, pair);
void dotellipse_bottom (pair, pair);

void boldellipse_left (pair, pair);
void boldellipse_right (pair, pair);
void boldellipse_top (pair, pair);
void boldellipse_bottom (pair, pair);

void dashellipse_half (pair, pair, double);
void dotellipse_half (pair, pair, double);
void boldellipse_half (pair, pair, double);

/* circular arcs and arrows */
void dasharc (pair, double, double, double);
void dotarc (pair, double, double, double);
void boldarc (pair, double, double, double);

void dasharc_arrow (pair, double, double, double);
void dotarc_arrow (pair, double, double, double);
void boldarc_arrow (pair, double, double, double);

/* Splines */
/* declarations of 0.8.x-style splines */
void dashspline (pair, pair, pair);
void dotspline (pair, pair, pair);
void boldspline (pair, pair, pair);

void dashspline (pair, pair, pair, pair);
void dotspline (pair, pair, pair, pair);
void boldspline (pair, pair, pair, pair);

void boldp_twist (pair, pair);
void boldn_twist (pair, pair);
void boldtwists (pair, pair, int);

/* * * geometry.h * * */
/* hyperbolic lines */
void dashhyperbolic_line (pair, pair);
void dothyperbolic_line (pair, pair);
void boldhyperbolic_line (pair, pair);

void dashdisk_line (pair, pair);
void dotdisk_line (pair, pair);
void bolddisk_line (pair, pair);

/* * * meshplots.h * * */
/* parametric surfaces */
void dashwiremesh(double f1(double, double), double f2(double, double), 
		  double f3(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts);
void dotwiremesh(double f1(double, double), double f2(double, double), 
		 double f3(double, double), pair p1, pair p2, mesh N,
		 mesh num_pts);
void boldwiremesh(double f1(double, double), double f2(double, double), 
		  double f3(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts);

/* graphs */
void dashwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts);
void dotwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		 mesh num_pts);
void boldwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts);

/* * * Version 0.8.x-style names * * */
void dashadplot (double f(double), double, double, int);
void dotadplot  (double f(double), double, double, int);
void boldadplot (double f(double), double, double, int);

/* Ordinary graph plot */
void dashplot  (double f(double), double, double, int);
void dotplot   (double f(double), double, double, int);
void boldplot  (double f(double), double, double, int);

/* Parametric plane curve */
void dashplot  (double f1(double), double f2(double), double, double, int);
void dotplot   (double f1(double), double f2(double), double, double, int);
void boldplot  (double f1(double), double f2(double), double, double, int);

/* Parametric space curve */
void dashplot  (double f1(double), double f2(double), double f3(double),
		double, double, int);
void dotplot   (double f1(double), double f2(double), double f3(double),
		double, double, int);
void boldplot  (double f1(double), double f2(double), double f3(double),
		double, double, int);

/* Polar graph */
void dashpolarplot  (double r(double), double, double, int);
void dotpolarplot   (double r(double), double, double, int);
void boldpolarplot  (double r(double), double, double, int);

/* Plotting families of curves -- sliceplot1 holds first variable constant */
void dashsliceplot1 (double f1(double, double), double f2(double, double), 
		     double, double, double, int);
void dashsliceplot2 (double f1(double, double), double f2(double, double), 
		     double, double, double, int);

void dotsliceplot1 (double f1(double, double), double f2(double, double), 
		    double, double, double, int);
void dotsliceplot2 (double f1(double, double), double f2(double, double), 
		    double, double, double, int);

void boldsliceplot1 (double f1(double, double), double f2(double, double), 
		     double, double, double, int);
void boldsliceplot2 (double f1(double, double), double f2(double, double), 
		     double, double, double, int);

/* multiplot = several sliceplots */
void dashmultiplot1 (double f1(double, double), double f2(double, double), 
		     pair, pair, mesh, int);
void dashmultiplot2 (double f1(double, double), double f2(double, double), 
		     pair, pair, mesh, int);

void dotmultiplot1 (double f1(double, double), double f2(double, double), 
		    pair, pair, mesh, int);
void dotmultiplot2 (double f1(double, double), double f2(double, double), 
		    pair, pair, mesh, int);

void boldmultiplot1 (double f1(double, double), double f2(double, double), 
		     pair, pair, mesh, int);
void boldmultiplot2 (double f1(double, double), double f2(double, double), 
		     pair, pair, mesh, int);

/* "Clipped" plotting -- truncated to bounding_box */
/* Ordinary plots */
void dashclipplot (double f(double), double, double, int);
void dotclipplot  (double f(double), double, double, int);
void boldclipplot (double f(double), double, double, int);

/* Parametric plane curves */
void dashclipplot (double f1(double), double f2(double), double, double, int);
void dotclipplot  (double f1(double), double f2(double), double, double, int);
void boldclipplot (double f1(double), double f2(double), double, double, int);

/* Parametric space curves */
void dashclipplot (double f1(double), double f2(double), double f3(double),
		   double t_min, double t_max, int num_pts);
void dotclipplot  (double f1(double), double f2(double), double f3(double),
		   double t_min, double t_max, int num_pts);
void boldclipplot (double f1(double), double f2(double), double f3(double),
		   double t_min, double t_max, int num_pts);

/* Derivatives and integrals */
void dashplot_deriv (double f(double t), double, double, int);
void dotplot_deriv  (double f(double t), double, double, int);
void boldplot_deriv (double f(double t), double, double, int);

/* lower limit is endpoint of plot interval */
void dashplot_int (double f(double), double, double, int);
void dotplot_int  (double f(double), double, double, int);
void boldplot_int (double f(double), double, double, int);

/* separate lower limit */
void dashplot_int (double f(double), double, double, double, int);
void dotplot_int  (double f(double), double, double, double, int);
void boldplot_int (double f(double), double, double, double, int);

/* Solutions of ODE systems */
void dashode_plot  (double f1(double, double), double f2(double, double),
		    pair, double, int);
void dotode_plot   (double f1(double, double), double f2(double, double),
		    pair, double, int);
void boldode_plot  (double f1(double, double), double f2(double, double),
		    pair, double, int);

/* arcana.h */
/*
  void dashplot_profile (double f(double), double, double, int);
  void dotplot_profile (double f(double), double, double, int);
  void boldplot_profile (double f(double), double, double, int);
*/

} /* end of namespace */

#endif /* _EPIX_LEGACY */
