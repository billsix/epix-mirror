/*
 * plots.h 
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.8rc6
 * Last Change: December 02, 2002
 */

#ifndef _EPIX_PLOTS
#define _EPIX_PLOTS

#ifdef _EPIX_COMPILE
#include "objects.h"
#include "functions.h"
#endif

namespace ePiX {

  using namespace std;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *          Plots of user-specified functions -- plots.c         *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Adaptive plotting */
void draw_adapt_plot (double f1(double), double f2(double), 
		      double, double, int);
void adplot     (double f(double), double, double, int);
void adplot     (double f1(double), double f2(double), double, double, int);

void draw_adapt_plot (pair f(double), double, double, int);
void adplot     (pair f(double), double, double, int);

/* Ordinary graph plot */
void draw_plot (double f(double), double, double, int);
void plot      (double f(double), double, double, int);

/* Parametric plane curve */
void draw_plot (double f1(double), double f2(double), double, double, int);
void plot      (double f1(double), double f2(double), double, double, int);

void draw_plot (pair f(double), double, double, int);
void plot      (pair f(double), double, double, int);

/* Parametric space curve */
void draw_plot (double f1(double), double f2(double), double f3(double),
		double, double, int);

void plot      (double f1(double), double f2(double), double f3(double),
	        double, double, int);

void draw_plot (triple f(double), double, double, int);
void plot      (triple f(double), double, double, int);

/* Projection of space curve to plane through the origin */
void draw_shadowplot (double f1(double), double f2(double), double f3(double),
		      triple, double, double, int);
void shadow          (double f1(double), double f2(double), double f3(double),
		      triple, double, double, int);

void draw_shadowplot (triple f(double), triple, double, double, int);
void shadow          (triple f(double), triple, double, double, int);

/* Polar graph */
void draw_polarplot (double r(double), double, double, int);
void polarplot      (double r(double), double, double, int);

/* Plotting families of curves -- sliceplot1 holds first variable constant */
void draw_sliceplot1(double f1(double, double), double f2(double, double), 
		     double, double, double, int);
void draw_sliceplot2(double f1(double, double), double f2(double, double), 
		     double, double, double, int);

void sliceplot1 (double f1(double, double), double f2(double, double), 
		 double, double, double, int);
void sliceplot2 (double f1(double, double), double f2(double, double), 
		 double, double, double, int);

/* pair-valued plot argument */
void draw_sliceplot1(pair f(double, double), double, double, double, int);
void draw_sliceplot2(pair f(double, double), double, double, double, int);
void sliceplot1 (pair f(double, double), double, double, double, int);
void sliceplot2 (pair f(double, double), double, double, double, int);

/* multiplot = several sliceplots */
void draw_multiplot1 (double f1(double, double), double f2(double, double), 
		      pair, pair, mesh, int);
void draw_multiplot2 (double f1(double, double), double f2(double, double), 
		      pair, pair, mesh, int);

void multiplot1 (double f1(double, double), double f2(double, double), 
		 pair, pair, mesh, int);
void multiplot2 (double f1(double, double), double f2(double, double), 
		 pair, pair, mesh, int);
/* pair-valued plot argument */
void draw_multiplot1 (pair f(double, double), pair, pair, mesh, int);
void draw_multiplot2 (pair f(double, double), pair, pair, mesh, int);
void multiplot1 (pair f1(double, double), pair, pair, mesh, int);
void multiplot2 (pair f1(double, double), pair, pair, mesh, int);

/* "Clipped" plotting -- truncated to bounding_box */
void draw_clipplot (double f1(double), double f2(double), double f3(double),
		    double, double, int);
void draw_clipplot (pair f(double), double, double, int);
void draw_clipplot (triple f(double), double, double, int);

/* Ordinary plots */
void clipplot     (double f(double), double, double, int);
/* Parametric plane curves */
void clipplot     (double f1(double), double f2(double), double, double, int);
void clipplot     (pair f(double), double, double, int);

/* Parametric space curves */
void clipplot     (double f1(double), double f2(double), double f3(double),
		   double t_min, double t_max, int num_pts);
void clipplot     (triple f(double), double t_min, double t_max, int num_pts);

/* Data plotting from file */
void marker (pair, const int);
void data_plot (const char *, const int);

/* Derivatives and integrals */
void draw_deriv     (double f(double), double, double, int);
void plot_deriv     (double f(double t), double, double, int);

void tan_line(double f1(double t), double f2(double t), double t0);
void tan_line(double f(double t), double t0);
void tan_line(pair f(double t), double t0);

void envelope(double f1(double), double f2(double), double, double, int);
void envelope(double f(double), double, double, int);
void envelope(pair f(double), double, double, int);

void tan_field     (double f1(double), double f2(double), 
		    double, double, double);
void boldtan_field (double f1(double), double f2(double), 
		    double, double, double);
void tan_field     (pair f(double), double, double, double);
void boldtan_field (pair f(double), double, double, double);

/* lower limit is endpoint of plot interval */
void draw_int     (double f(double), double, double, int);
void plot_int     (double f(double), double, double, int);

/* separate lower limit */
void draw_int     (double f(double), double, double, double, int);
void plot_int     (double f(double), double, double, double, int);

/* Slope, dart, and vector fields */
void draw_slope_field  (double f1(double, double), double f2(double, double),
		        pair, pair, int, int);
void slope_field       (double f1(double, double), double f2(double, double),
		        pair, pair, int, int);
void boldslope_field   (double f1(double, double), double f2(double, double),
		        pair, pair, int, int);

void draw_dart_field   (double f1(double, double), double f2(double, double),
		        pair, pair, int, int);
void dart_field        (double f1(double, double), double f2(double, double),
		        pair, pair, int, int);
void bolddart_field    (double f1(double, double), double f2(double, double),
		        pair, pair, int, int);

void draw_vector_field (double f1(double, double), double f2(double, double),
			pair, pair, int, int);
void vector_field      (double f1(double, double), double f2(double, double),
			pair, pair, int, int);
void boldvector_field  (double f1(double, double), double f2(double, double),
			pair, pair, int, int);

/* pair-valued vector field */
void draw_slope_field  (pair F(double, double), pair, pair, int, int);
void slope_field       (pair F(double, double), pair, pair, int, int);
void boldslope_field   (pair F(double, double), pair, pair, int, int);

void draw_dart_field   (pair F(double, double), pair, pair, int, int);
void dart_field        (pair F(double, double), pair, pair, int, int);
void bolddart_field    (pair F(double, double), pair, pair, int, int);

void draw_vector_field (pair F(double, double), pair, pair, int, int);
void vector_field      (pair F(double, double), pair, pair, int, int);
void boldvector_field  (pair F(double, double), pair, pair, int, int);

/* Solutions of ODE systems */
void draw_ode_plot (double f1(double, double), double f2(double, double),
		    pair, double, int);
void ode_plot      (double f1(double, double), double f2(double, double),
		    pair, double, int);

/* pair-valued vector field */
void draw_ode_plot (pair F(double, double), pair, double, int);
void ode_plot      (pair F(double, double), pair, double, int);

/* Image of a point set under a planar flow */
void draw_flow_plot(double f1(double, double), double f2(double, double),
		    pair f(double), triple color(double), double, int, int);
/* With and without color function */
void flow_plot(double f1(double, double), double f2(double, double),
	       pair f(double), triple color(double), double, int, int);
void flow_plot(double f1(double, double), double f2(double, double),
	       pair f(double), double, int, int);

/* pair-valued vector field */
void draw_flow_plot(pair F(double, double), pair f(double), 
		    triple color(double), double, int, int);
void flow_plot(pair F(double, double), pair f(double), 
	       triple color(double), double, int, int);
void flow_plot(pair F(double, double), pair f(double), double, int, int);

/* Jay Belanger's shaded plot routines -- December 1, 2002 */

void blackplot(double f(double), double, double, int);
void blackplot(double f1(double), double f2(double), double, double, int);

void whiteplot(double f(double), double, double, int);
void whiteplot(double f1(double), double f2(double), double, double, int);

void shadeplot(double f(double), double, double, int);
void shadeplot(double f1(double), double f2(double), double, double, int);

} /* end of namespace */

#endif /* _EPIX_PLOTS */
