/*
 * arcana.h
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.8rc6
 * Last Change: December 02, 2002
 *
 */

#ifndef _EPIX_ARCANA
#define _EPIX_ARCANA

#ifdef _EPIX_COMPILE
#include "plots.h"
#endif

namespace ePiX {

  using namespace std;

/* Implementation of the momentum construction */
void draw_profile (double f(double), double, double, int);
void plot_profile (double f(double), double, double, int);
void plot_profile (double f(double), double, double, double, int);

/* Plane linear transformations */
pair 
transf (pair, pair, pair);

pair 
reflect (double, pair);

/* Image of the "standard F" under a linear transformation */
void 
std_F (pair, pair);

/*
 * fractal generation
 *
 * The basic "level-1" recursion unit is a piecewise-linear path whose 
 * segments are parallel to spokes on a wheel, labelled modulo <spokes>.
 * Recursively up to <depth>, each segment is replaced by a copy of the
 * recursion unit.
 *
 * Sample data for _/\_ standard Koch snowflake:
 * const int pre_seed[] = {6, 4, 0, 1, -1, 0};
 * pre_seed[0] = spokes, pre_seed[1] = seed_length;
 */

void 
fractal (pair p, pair q, int depth, const int *pre_seed);

} /* end of namespace */

#endif /* _EPIX_ARCANA */
