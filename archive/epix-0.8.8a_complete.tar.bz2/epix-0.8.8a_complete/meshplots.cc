/* 
 * meshplots.cc -- Wire mesh surfaces
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.8rc6
 * Last Change: December 02, 2002
 */

/* 
 * Copyright (C) 2001, 2002  
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#define _EPIX_COMPILE
#include "meshplots.h"
#include "functions.h"

namespace ePiX {

  using namespace std;

extern int EPIX_PATH_STYLE;

/* 
 * Wiremesh plotting -- no hidden line removal
 */
void 
draw_wiremesh(double f1(double u1, double u2),
	      double f2(double u1, double u2),
	      double f3(double u1, double u2),
	      pair p1, pair p2, mesh N, mesh num_pts)
{
  // Fineness of plotted mesh
  const double step_u1 = (p2.x1 - p1.x1)/N.n1;
  const double step_u2 = (p2.x2 - p1.x2)/N.n2;
  // Number of points plotted in each direction
  const double du1 = (p2.x1 - p1.x1)/num_pts.n1;
  const double du2 = (p2.x2 - p1.x2)/num_pts.n2;

  for (int i = 0; i <= N.n1; ++i)
    {
      double temp1 = p1.x1 + i*step_u1;
      fprintf (stdout, "\n%%%%  x1 = %g", temp1);
      start_path();
      for (int j = 0; j <= num_pts.n2; ++j)
      {
	double temp2 = p1.x2 + j*du2;
	print(V(f1(temp1, temp2), f2(temp1, temp2), f3(temp1, temp2)));
	line_break(j, num_pts.n2);
      }
      fprintf (stdout, "\n%%%%");
    }

  for (int j = 0; j <= N.n2; ++j)
    {
      double temp2 = p1.x2 + j*step_u2;
      fprintf (stdout, "\n%%%%  x2 = %g", temp2);
      start_path();
      for (int i = 0; i <= num_pts.n1; ++i)
      {
	double temp1 = p1.x1 + i*du1;
	print(V(f1(temp1, temp2), f2(temp1, temp2), f3(temp1, temp2)));
	line_break(i, num_pts.n1);
      }
    }
}

void wiremesh(double f1(double, double), double f2(double, double), 
	      double f3(double, double), pair p1, pair p2, mesh N,
	      mesh num_pts)
{
  epix_comment("wire mesh parametrized surface");
  draw_wiremesh(f1, f2, f3, p1, p2, N, num_pts);
  end_stanza();
} 

/* Wire mesh plot of function of two real variables */
void wiremesh(double f(double, double), pair p1, pair p2, mesh N,
	      mesh num_pts)
{
  epix_comment("wire mesh graph");
  draw_wiremesh(proj1, proj2, f, p1, p2, N, num_pts);
  end_stanza();
} 

/* triple-valued plot argument */
void 
draw_wiremesh(triple Phi(double u1, double u2),
	      pair p1, pair p2, mesh N, mesh num_pts)
{
  // Fineness of plotted mesh
  const double step_u1 = (p2.x1 - p1.x1)/N.n1;
  const double step_u2 = (p2.x2 - p1.x2)/N.n2;
  // Number of points plotted in each direction
  const double du1 = (p2.x1 - p1.x1)/num_pts.n1;
  const double du2 = (p2.x2 - p1.x2)/num_pts.n2;

  for (int i = 0; i <= N.n1; ++i)
    {
      double temp1 = p1.x1 + i*step_u1;
      fprintf (stdout, "\n%%%%  x1 = %g", temp1);
      start_path();
      for (int j = 0; j <= num_pts.n2; ++j)
      {
	double temp2 = p1.x2 + j*du2;
	print(Phi(temp1, temp2));
	line_break(j, num_pts.n2);
      }
      fprintf (stdout, "\n%%%%");
    }

  for (int j = 0; j <= N.n2; ++j)
    {
      double temp2 = p1.x2 + j*step_u2;
      fprintf (stdout, "\n%%%%  x2 = %g", temp2);
      start_path();
      for (int i = 0; i <= num_pts.n1; ++i)
      {
	double temp1 = p1.x1 + i*du1;
	print(Phi(temp1, temp2));
	line_break(i, num_pts.n1);
      }
    }
}

void wiremesh(triple Phi(double, double), 
	      pair p1, pair p2, mesh N, mesh num_pts)
{
  epix_comment("wire mesh parametrized surface");
  draw_wiremesh(Phi, p1, p2, N, num_pts);
  end_stanza();
} 

} /* end of namespace */
