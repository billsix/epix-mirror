/* 
 * globals.h -- Top-level header file
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.7rc1
 * Last Change: August 06, 2002
 */

/* 
 * Copyright (C) 2001, 2002  
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX
#define _EPIX

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef _EPIX_VERSION /* We're compiling output.cc */
const char *epix_version="0.8.7"; 
#endif

/* 
 * To find hardwired constants in the source code, do
 *
 *             grep "Hardwired" *.cc
 */

/* * * Tweakable constants * * */

const int EPIX_NUM_PTS=40;     /* Number of points in half-ellipses, splines */
const int EPIX_FILE_WIDTH=70;  /* Width of output file, in characters */
const double EPIX_SPOT_DIAM=4; /* Diameter of circles and spots in true pt */
const double EPIX_ARROWHEAD_WIDTH=1.5; /* Half-width of arrowheads in pt */
const double EPIX_ARROWHEAD_RATIO=5.5; /* Aspect ratio of arrowheads */

/* 
 * Determines accuracy of truncation in clipplot et. al.
 * smaller -> better accuracy, longer run
 */
const double EPIX_SEEK_SIZE=0.01;

/*
 * In calculus plotting, determines the size of the increment dt
 * and the number of increments per point printed. A value of 100
 * is adequate for simple plotting, while a value larger than
 * 1000 is not likely to improve the accuracy noticeably.
 *
 * larger -> better accuracy, longer run
 */
const int EPIX_ITERATIONS=200;

/* Dash length/dot separation parameters */
const double EPIX_DASH_LENGTH=5.0;
const double EPIX_DOT_SEP=40.0;

/* * * End of tweakable constans * * */

/* Path styles, data plot markers, and label alignment types */
enum epix_path_style {SOLID, DASHED, DOTTED};

enum epix_mark_type {PATH, CIRC, SPOT, RING, DOT, DDOT, PLUS, OPLUS, 
		     TIMES, OTIMES, DIAMOND, UP, DOWN, BOX, BBOX};

enum epix_label_posn {c, r, tr, rt, t, tl, lt, l, bl, lb, b, br, rb};


// coordinate axis tick marks
enum epix_tick_type {TICK_NULL, H_AXIS, V_AXIS};

// "vector field"-type objects
enum epix_field_type {SLOPE, DART, VECTOR};

/* Deprecated constants */

const int EPIX_PAIRS_PER_LINE=4;/* Number of pairs per line in output file */
const int EPIX_MAX_LINES=20000; /* Fatal error if this many lines printed */
extern int epix_lines_printed;  /* output counter */

/* 
 * ePiX depicts the rectangle [x_min, x_max] x [y_min, y_max] in a LaTeX
 * figure occupying (h_offset, v_offset) + [0, h_size] x [0, v_size]. If
 * appropriate, orthogonal projection to the plane normal to <viewpoint>
 * is performed.
 */

/* 
 * <Size> and <offset> of picture in PICTURE coordinates. Sizes 
 * define space in document alotted by LaTeX. Offsets shift the
 * origin from the CENTER of the picture; positive offsets shift
 * RIGHT and UP (contrast LaTeX behavior).
 */
extern double h_size, v_size, h_offset, v_offset; // zero offset by default

/*
 * Components of normal vector for 3-d plotting. When set to (0,0,a3),
 * ePiX draws the standard x-y plane in standard orientation. Otherwise
 * ePiX does orthogonal projection to the plane normal to <viewpoint>,
 * keeping the z-axis vertical. Because projection is orthogonal, overall
 * scale in <viewpoint> is immaterial (aside from round-off).
 */
extern double viewpt1, viewpt2, viewpt3; // default viewpoint (0,0,0)

/* Bounding box of picture in Cartesian coordinates. */
extern double x_min, x_max, y_min, y_max;
/* Cartesian width and height of bounding box */
extern double x_size, y_size;

/*
 * Picture length units
 *
 * <pic_unit> is one of the following valid LaTeX length units: 
 *    cm, in, mm, pc, or pt.
 * <pic_size> is a double that (with pic_unit) specifies unitlength
 */
extern double pic_size; // e.g., 1
extern char *pic_unit;  // e.g., "pt" 

#endif /* _EPIX */
