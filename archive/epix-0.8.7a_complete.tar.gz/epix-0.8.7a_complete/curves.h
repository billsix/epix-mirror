/*
 * curves.h -- Ellipses, arcs, splines
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.6rc2
 * Last Change: July 24, 2002
 *
 */

#ifndef _EPIX_CURVES
#define _EPIX_CURVES

#ifdef _EPIX_COMPILE
#include "objects.h"
#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *  Ellipses, half-ellipses, circular arcs, splines -- curves.c  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Ellipses */

/* Point-plotting functions */
void draw_half_ellipse (pair, pair);

/* Stanza-creating whole ellipse functions */
void draw_ellipse (pair, pair); 
void ellipse (pair, pair);

/* Stanza-creating standard half-ellipse functions */
void draw_half_ellipse(pair, pair, double);
void ellipse_left (pair, pair);
void ellipse_right (pair, pair);
void ellipse_top (pair, pair);
void ellipse_bottom (pair, pair);

/* Right half ellipse rotated through <double> revolutions */
void rotate_half_ellipse(pair, pair, double);
void ellipse_half (pair, pair, double);

/* Circular arcs */
void draw_proper_arc (pair, double, double, double);
void draw_arc (pair, double, double, double);

void arc (pair, double, double, double);

void draw_arc_arrow (pair, double, double, double);
void arc_arrow (pair, double, double, double);

/* Splines */
void draw_spline (pair, pair, pair);
void draw_spline (pair, pair, pair, pair);

/* Quadratc */
void spline (pair, pair, pair);

/* Cubic */
void spline (pair, pair, pair, pair);

/* Knot diagram primitives */
void draw_under_strand(pair p3, pair p6, pair p5, pair p2);
void draw_p_twist(pair p1, pair p4);
void draw_n_twist(pair p1, pair p4);

void p_twist (pair, pair);
void n_twist (pair, pair);
void twists (pair, pair, int);

#endif /* _EPIX_CURVES */
