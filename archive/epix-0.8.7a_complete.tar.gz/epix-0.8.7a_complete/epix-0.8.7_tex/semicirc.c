/* semicirc.c -- A rectangle inscribed in a semi-circle */
#include "epix.h"

double width = 0.6;
double posn=0.5, y_posn=sqrt(1-posn*posn);

main()
{
  unitlength("1in");
  bounding_box(P(-1, 0), P(1, 1));
  picture(P(2.5, 1.25));
  offset(P(0,0.125));

  begin();

  line(P(x_min, 0), P(x_max, 0));
  line(P(0, y_min), P(0, y_max));

  ellipse_top(P(0,0), P(1,1));

  bold;
  rect(P(-width,0), P(width, sqrt(1-width*width)));

  label(P(posn, y_posn), P(2,4), "$y=\\sqrt{1-x^2}$");
  h_axis_labels(P(x_min,0), P(x_max,0), x_size, P(-12, -12));

  end();
}
