/* p-twists.c -- Knot primitives */
#include "epix.h"

main()
{
  unitlength("1pt");
  bounding_box(P(0,0), P(3,1));
  picture(P(150,50));

  begin();
  dashed;
  rect(P(0,1), P(3,0));
  solid;

  label(P(0,1), P(-4,0), "$(0,1)$", bl);
  label(P(3,0), P(4, 0), "$(3,0)$", tr);

  bold;
  twists(P(0,1), P(3,0), -5);

  label(P(1.5,0), P(0,-2), "Bold {\\tt twists(P(0,1), P(3,0), -5);}", b);

  end();
}
