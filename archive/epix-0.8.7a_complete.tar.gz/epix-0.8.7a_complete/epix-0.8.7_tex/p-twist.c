/* p-twist.c -- Knot primitives */
#include "epix.h"

main()
{
  unitlength("1pt");
  bounding_box(P(0,0), P(3,1));
  picture(P(150,50));

  begin();

  dashed;
  rect(P(0,0), P(1,1));
  rect(P(2,0), P(3,1));
  solid;

  label(P(0,0), P(-4, 0), "$(a,b)$", tl);
  label(P(1,1), P(4,0), "$(c,d)$", br);

  p_twist(P(0,0), P(1,1));
  p_twist(P(2,1), P(3,0));

  label(P(2,1), P(0,4), "$(a,b)$", tr);
  label(P(3,0), P(4,0), "$(c,d)$", tr);

  label(P(-1.5,0.5), P(0,0), "{\\tt p\\underline{ }twist}");

  end();
}
