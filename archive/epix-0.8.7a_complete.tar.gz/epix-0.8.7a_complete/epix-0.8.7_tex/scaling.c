/* scaling.c */
#include "epix.h"

main()
{
  unitlength("1pt");
  bounding_box(P(0,-0.125), P(5, 1));
  picture(P(300, 60));
  offset(P(0,5));

  begin();

  rect(P(0,0), P(1.5, 0.75));
  rect(P(3,0), P(5, 0.875));

  dot(P(0,0));
  dot(P(1.5, 0.75));

  dot(P(3,0));
  dot(P(5,0.875));

  arrow(P(1.75, 0.25), P(2.75,0.25));
  label(P(2.25, 0.25), P(0,4), "{\\tt ePiX}", t);

  label(P(0,0), P(2,2), 
	"\\scriptsize$(x_\\mathrm{min},y_\\mathrm{min})$", tr);
  label(P(1.5, 0.75), P(-2,-2), 
	"\\scriptsize$(x_\\mathrm{max},y_\\mathrm{max})$", bl);
  label(P(0.75,0), P(0,-4), "Cartesian bounding box", b);

  label(P(3,0), P(2,2), "\\scriptsize$(0,0)$", tr);
  label(P(5, 0.875), P(-2,-2), 
	"\\scriptsize$(h_\\mathrm{size},v_\\mathrm{size})$", bl);
  label(P(4,0), P(0, -4), "\\LaTeX\\ picture box", b);
  end();
}
