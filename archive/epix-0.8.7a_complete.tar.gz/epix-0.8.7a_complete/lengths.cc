/* 
 * lengths.cc: Scaling and length conversion
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.7rc1
 * Last Change: August 06, 2002
 */

/* 
 * Copyright (C) 2001, 2002  
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

/*
 *
 * There are three types of coordinates/length in ePiX:
 *   (1) Cartesian (the user interface)
 *   (2) LaTeX picture coordinates (unitlength, the output)
 *   (3) File-independent true unit (pt, used for visual formatting)
 *
 * Cartesian coordinates live in [x_min, x_max] x [y_min, y_max], the 
 * "bounding box". Latex picture coordinates live in the "picture box"
 * [0, h_size] x [0, v_size]. The functions hscale and vscale handle
 * Cartesian to picture coordinate conversion; h_unscale and v_unscale
 * are the inverse functions.
 * 
 * The user specifies objects' locations in Cartesian coordinates, which
 * facilitates the design of portable, mathematically accurate figures. 
 * There is also a facility for offsetting labels by amounts in true pt;
 * This eases the visual placement of labels, and helps to make the figure 
 * portable: A change of bounding box re-positions the label's basepoint
 * globally, while the offset (which is scale-independent) adjusts the
 * label from its new basepoint.
 *
 * True-coordinate changes are handled by scale (which converts true pt
 * to (user-specified) LaTeX picture units and its inverse, unscale. In
 * summary, "scale" functions convert *to* picture coordinates, "unscale"
 * functions convert *from* picture coordinates. These functions know about 
 * the following LaTeX dimensions: "cm", "in", "mm", "pc", and "pt"
 */

#define _EPIX_COMPILE

#include "lengths.h"

extern double h_size, v_size, h_offset, v_offset;
extern double viewpt1, viewpt2, viewpt3;
extern double x_min, x_max, y_min, y_max;
extern double x_size, y_size;
extern double pic_size;
extern char *pic_unit;

short int scale_warning=0;

/*
 * About truncation and numerical accuracy of output:
 *
 * Functions that convert Cartesian to picture units truncate output
 * to avoid printing %e-type expressions in output.  This means that
 * p2c is not the inverse of c2p to machine precision.  Similar
 * remarks hold for c2s, but s2c is only provided for completeness.
 */

/* 
 * Upper bound on truncation prevents %e-type output; not strictly a
 * magic number, since the bound is built into C.
 */
double truncate(double t)
{
  if (fabs(t) < 0.0001) // 10^-4
    t=0;

  return t;
}

pair truncate (pair p)
{
  if (fabs(p.x1) < 0.0001) // 10^-4
    p.x1=0;
  if (fabs(p.x2) < 0.0001) // 10^-4
    p.x2=0;

  return p; // P(p.x1, p.x2);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                 Non-Printing Functions                *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Functions for setting variables */
void
bounding_box(pair p1, pair p2)
{
  if (p1.x1 < p2.x1)
    {
      x_min = p1.x1;
      x_max = p2.x1;
    }

  else if (p1.x1 > p2.x1)
    {
      x_min = p2.x1;
      x_max = p1.x1;
    }
  else
    {
      fprintf (stderr, "Error: Bounding box has width zero!\n");
      exit(1);
    }

  if (p1.x2 < p2.x2)
    {
      y_min = p1.x2;
      y_max = p2.x2;
    }

  else if (p1.x2 > p2.x2)
    {
      y_min = p2.x2;
      y_max = p1.x2;
    }
  else
    {
      fprintf (stderr, "Error: Bounding box has height zero!\n");
      exit(1);
    }

  x_size = x_max - x_min;
  y_size = y_max - y_min;
}

void picture(pair sizes)
{
  h_size = sizes.x1;
  v_size = sizes.x2;
}

void offset(pair shift)
{
  h_offset = shift.x1;
  v_offset = shift.x2;
}

void unitlength(const char *units)
{
  pic_size = strtod(units, &pic_unit);
}

void viewpoint(double a1, double a2, double a3)
{
  viewpt1 = a1;
  viewpt2 = a2;
  viewpt3 = a3;
}

/* length conversions */

pair c2p(pair X)
{
  pair scale = P(h_size/x_size, v_size/y_size);
  pair origin = P(x_min, y_min);
  return truncate(scale&(X - origin));
}

pair p2c(pair H)
{
  pair scale = P(x_size/h_size, y_size/v_size);
  pair lower_left = P(x_min, y_min);

  return lower_left + scale&H;
}

pair c2s(pair X)
{
  pair scale = P(h_size/x_size, v_size/y_size);
  return truncate(scale&X);
}

pair s2c(pair H)
{
  pair scale = P(x_size/h_size, y_size/v_size);
  return scale&H;
}

double p2t(double dimen) // Formerly unscale
{
  if (! strcmp((char *)pic_unit,"cm"))
    return (pic_size)*(72.27/2.54)*dimen;

  else if (! strcmp((char *)pic_unit,"in"))
    return (pic_size)*(72.27)*dimen;

  else if (! strcmp((char *)pic_unit,"mm"))
    return (pic_size)*(72.27/25.4)*dimen;

  else if (! strcmp((char *)pic_unit,"pc"))
    return (pic_size)*(12.0)*dimen;

  else if (! strcmp((char *)pic_unit,"pt"))
    return (pic_size)*dimen;

  /* Invalid unit length and no warning printed yet */
  else if (scale_warning == 0) 
    {
      scale_warning = 1;
      
      fprintf(stdout, "%%%% ePiX WARNING: Unrecognized units \"%s\"! ", 
	      pic_unit);
      fprintf(stdout, "Scaling may be incorrect.\n");
      fprintf(stdout, "%%%%   Valid units are ");
      fprintf(stdout, "\"cm\", \"in\", \"mm\", \"pc\", and \"pt\".\n");
      fprintf(stdout, "%%%%   Please check preamble of source file.\n");
      fprintf(stdout, "%%%%\n");
      return (pic_size)*dimen;
    }

  /* Warning issued already; try our best to comply... */
  else
    return (pic_size)*dimen;
}

double t2p(double t)
{
  return t/p2t(1.0);
}
pair t2p(pair T)
{
  return (1.0/p2t(1.0))*T;
}

pair p2t(pair H)
{
  return p2t(1.0)*H;
}

/* Pythagorean length of pair/triple */
double raw_len(pair p)
{
  return hypot(p.x1, p.x2);
}

double raw_len(triple p)
{
  return sqrt(p.x1*p.x1 + p.x2*p.x2 + p.x3*p.x3);
}

/* True length of pair given in picture coordinates */
double true_len(pair p)
{
  return raw_len(p2t(p));
}

/* Scale vector in picture units to 1 true pt length */
pair normalize(pair p)
{
  if ( true_len(p) > 0) // return (0,0) if p = (0,0)
    p *= 1.0/true_len(p);

  return p;
}



