#!/bin/bash
#
# helpfiles.sh: (un)install/test sample files
#
# This script is NOT INTENDED TO BE RUN MANUALLY!!
#
#   Options: --install, --uninstall, --test
#   Assumes EPIX_ROOTDIR is set to install directory from Makefile
#
# September 07, 2002  Andrew D. Hwang,  ahwang@mathcs.holycross.edu
#

PROG=$(basename $0)

if [ "$EPIX_ROOTDIR" = "" ]
then 
    echo "$PROG: Please do not run this script manually!" && exit 1
fi

EPIX_SHARE=${EPIX_ROOTDIR}/share
EPIX_SAMPLEDIR=${EPIX_SHARE}/epix

EPIX_DOCDIR=$(ls -d epix-*_tex 2>/dev/null)
EPIX_MAJOR_VERSION=${EPIX_DOCDIR%%"_tex/"} # "epix-0.8.x"
EPIX_VERSION=epix-$(cat VERSION) # VERSION has rc number
EPIX_TARBALL=${EPIX_VERSION}_samples.tar

# Mimic run of epix on sample file, using newly-compiled library
ePiX() {
FILEROOT=${1%%".c"}

$CXX $CFLAGS $1 -o $FILEROOT.exe -I. -L. -lm -lepixtest 

if [ -x "$FILEROOT.exe" ] 
then ./$FILEROOT.exe > $FILEROOT.eepic
fi

if [ -f "$FILEROOT.eepic" ] 
then
    echo -n "." # Progress meter :)
    rm -f $FILEROOT.exe
    return 0;

else 
    echo "failed, exiting"
    rm -f $FILEROOT.exe libepixtest.a 2>/dev/null
    exit 1;
fi
} # end of ePiX()

case "$1" in

    --install)
	if [ ! -d $EPIX_SAMPLEDIR ]; then
	    # pre-install script has failed...
	    echo "$PROG: Can't find \"$EPIX_SAMPLEDIR\""
	    exit 1;
	fi

	if [ "$EPIX_DOCDIR" != "" ]; then
	    cd $EPIX_DOCDIR && ../laps -ps -Pamz -Pcmz tutorial.tex
	    install -m 644 tutorial.ps \
		    $EPIX_SAMPLEDIR/${EPIX_MAJOR_VERSION}_howto.ps

	    rm tutorial.{dvi,log,ps}
	    cd ..
	fi

	cd samples && tar -cf $EPIX_TARBALL *.c sample.* makefigs template
	install -m 644 $EPIX_TARBALL $EPIX_SAMPLEDIR/$EPIX_TARBALL

	rm $EPIX_TARBALL

	cd $EPIX_SAMPLEDIR && tar -xf $EPIX_TARBALL 
	chown -R $USER:$GROUPS *
	if [ $UID -eq 0 ]; then # Public installation
	    chmod go+rX * # Give everyone read permission
	fi
	;;

    --uninstall)
	# Delete $INSTALL/share/epix; Makefile handles the rest
	cd $EPIX_SHARE 
	if [ -d epix ]; then rm -Rf epix; fi
	;;

    --test)
	CXX="g++"
	CFLAGS="-w"

	if [ -d samples ] 
	then cd ./samples
	else echo "$PROG: Directory \"samples\" does not exist" && exit 1;
	fi

	# Now we're in samples
	cp -p ../libepix.a libepixtest.a
	cp -p ../epix.h epix.h

	echo -n "Creating .eepic files  "
	for FILE in *.c ; do 
	    if [ ! -f ${FILE%%"c"}eepic ] || [ $FILE -nt ${FILE%%"c"}eepic ]
	    then
		ePiX $FILE # N.B. Shell function ePiX
	    fi
	done
	echo " done"

	# Clean up
	rm -f libepixtest.a epix.h

	echo; echo -n "Testing laps..."

	../laps sample.tex &>/dev/null

	if [ -f "sample.ps" ] 
	then echo "success"
	     mv -f sample.dvi  sample.ps ..
	     rm -f sample.log
	     echo "You may now preview sample.dvi or sample.ps"; exit 0;
	else echo "failed"; exit 1;
	fi
	;;

    *)
	echo "$PROG: Unknown option $1" && exit 1
	;;
esac

exit 0
