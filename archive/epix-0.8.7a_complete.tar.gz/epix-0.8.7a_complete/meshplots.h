/*
 * meshplots.h
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.6rc5
 * Last Change: July 27, 2002
 *
 */

#ifndef _EPIX_MESH
#define _EPIX_MESH

#ifdef _EPIX_COMPILE
#include "output.h"
#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                        meshplots.cc                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void 
draw_wiremesh(double f1(double, double),
	      double f2(double, double),
	      double f3(double, double), pair, pair, mesh, mesh);

/* Parametric surfaces */
void wiremesh(double f1(double, double), double f2(double, double), 
	      double f3(double, double), pair, pair, mesh, mesh);

/* Graphs of functions of two real variables */
void wiremesh(double f(double, double), pair, pair, mesh, mesh);

/* triple-valued plot argument */
void draw_wiremesh(triple Phi(double, double), pair, pair, mesh, mesh);
void wiremesh     (triple Phi(double, double), pair, pair, mesh, mesh);

#endif /* _EPIX_MESH */
