/*
 * output.h -- ePiX file-formatting output routines
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.6rc5
 * Last Change: July 27, 2002
 *
 */

#ifndef _EPIX_OUTPUT
#define _EPIX_OUTPUT

#ifdef _EPIX_COMPILE
#include "lengths.h"
#endif

extern int EPIX_PATH_STYLE;

/* Sectioning Functions */

/* Begin/end picture */
void begin(void);

#define end() fprintf (stdout, "\n\\end{picture}\n")

/* Print Cartesian pair in form (p.x1,p.x2) */
void print(pair);
void print(triple);
void raw_print(pair);

void stretch(double);

/* Path style declarations */
void start_path(void);
/* (Un)fill closed path */
#define fill   fprintf (stdout, "\\blacken")
#define unfill fprintf (stdout, "\\whiten")

void epix_comment(char *);
void end_stanza(void);
void fatal_error(void);
void output(void);
void line_break(int, int);

/* Misc Styles and output formatting */
/* Output styles */
void pen(char *);
void pen(double);

#define bold     fprintf (stdout, "\n\\thicklines")
#define endbold  fprintf (stdout, "\n\\thinlines")
#define end_bold fprintf (stdout, "\n\\thinlines")
#define plain    fprintf (stdout, "\n\\thinlines")

/* set state variable */
#define solid    EPIX_PATH_STYLE = SOLID
#define dashed   EPIX_PATH_STYLE = DASHED
#define dotted   EPIX_PATH_STYLE = DOTTED

/*
 * Color handling
 *
 * ePiX provides  "pstcol" style colors, which are declarations rather 
 * than delimited environments. To make part of an ePiX file print red 
 * (say), use one of the following:
 *
 *   red;
 *   <epix commands>
 *   end_red;
 *
 *   rgb(1,0,0);
 *   <epix commands>
 *   black;
 *
 * rgb and cmyk colors are specified (respectively) by 3 or 4 floats,
 * the densities of the corresponding primary colors. If these densities
 * are specified outside the unit interval [0,1], they will be truncated,
 * e.g., rgb(2, -1, 0.3) = rgb(1, 0, 0.3).
 */

// red-green-blue
void rgb(double r, double g, double b); 
// cyan-magenta-yellow-black
void cmyk(double c, double m, double y, double k);

/* primary colors */

#define red     fprintf (stdout, "\n\\color[rgb]{1,0,0}")
#define green   fprintf (stdout, "\n\\color[rgb]{0,1,0}")
#define blue    fprintf (stdout, "\n\\color[rgb]{0,0,1}")
#define white   fprintf (stdout, "\n\\color[rgb]{1,1,1}")

#define cyan      fprintf (stdout, "\n\\color[cmyk]{1,0,0,0}")
#define magenta   fprintf (stdout, "\n\\color[cmyk]{0,1,0,0}")
#define yellow    fprintf (stdout, "\n\\color[cmyk]{0,0,1,0}")
#define black     fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}")

#endif /* _EPIX_OUTPUT */
