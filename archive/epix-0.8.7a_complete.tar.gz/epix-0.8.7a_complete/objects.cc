/* 
 * objects.cc -- Simple picture objects: axes, grids, markers, polygons
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.7rc1
 * Last Change: August 06, 2002
 */

/* 
 * Copyright (C) 2001, 2002  
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#define _EPIX_COMPILE
#include "objects.h"

extern double h_size, v_size, h_offset, v_offset;
extern double viewpt1, viewpt2, viewpt3;
extern double x_min, x_max, y_min, y_max, x_size, y_size;
extern double pic_size;
extern char *pic_unit;

extern double epix_stretch_factor;
extern int epix_lines_printed;
extern int EPIX_PATH_STYLE;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                    Picture objects                    *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 * label -- put string constant <label_text> aligned at basepoint
 * at Cartesian position <pair> offset by <vect> true points.
 */
void
label(pair base, pair offset, char *label_text)
{
  pair temp = c2p(base) + t2p(offset);
  fprintf (stdout, "\n\\put(%g,%g){%s}", temp.x1, temp.x2, label_text);
  end_stanza();
}

void
masklabel(pair base, pair offset, char *label_text)
{
  pair temp = c2p(base) + t2p(offset);
  fprintf (stdout, "\n\\put(%g,%g)", temp.x1, temp.x2);
  fprintf (stdout, "{\\colorbox{white}{%s}}", label_text);
  end_stanza();
}

/* centered labels */
void
label(pair base, char *label_text)
{
  fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){%s}}", 
	   c2p(base).x1, c2p(base).x2, label_text);

  end_stanza();
}
void
masklabel(pair base, char *label_text)
{
  fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){\\colorbox{white}{%s}}}", 
	   c2p(base).x1, c2p(base).x2, label_text);

  end_stanza();
}

/* labels with LaTeX-style alignment */
static void print_epix_label_posn(const int epix_label_posn)
{
  if (epix_label_posn == c)
    fprintf (stdout, "[c]");
 
  else if (epix_label_posn == t)
    fprintf (stdout, "[b]");
 
  else if (epix_label_posn == tr || epix_label_posn == rt)
    fprintf (stdout, "[bl]");
 
  else if (epix_label_posn == r)
    fprintf (stdout, "[l]");
 
  else if (epix_label_posn == br || epix_label_posn == rb)
    fprintf (stdout, "[tl]");
 
  else if (epix_label_posn == b)
    fprintf (stdout, "[t]");
 
  else if (epix_label_posn == bl || epix_label_posn == lb)
    fprintf (stdout, "[tr]");
 
  else if (epix_label_posn == l)
    fprintf (stdout, "[r]");
 
  else if (epix_label_posn == tl || epix_label_posn == lt)
    fprintf (stdout, "[br]");
 
  else // Just for good measure...
    fprintf (stderr, "Label alignment error: unknown option\n");   
}

void
label(pair base, pair offset, char *label_text, const int epix_label_posn)
{
  pair temp = c2p(base) + t2p(offset);
  fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0)", temp.x1, temp.x2);
  print_epix_label_posn(epix_label_posn);
  fprintf (stdout, "{%s}}", label_text);

  end_stanza();
}
void
masklabel(pair base, pair offset, char *label_text, const int epix_label_posn)
{
  pair temp = c2p(base) + t2p(offset);
  fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0)", temp.x1, temp.x2);
  print_epix_label_posn(epix_label_posn);
  fprintf (stdout, "{\\colorbox{white}{%s}}}", label_text);

  end_stanza();
}

void
marker(pair p, const int epix_mark_type)
{
  pair out = c2p(p);

  switch(epix_mark_type) {
  case PATH:
    print(p);
    break;

  case CIRC:  
    fprintf (stdout, "\n\\whiten\\put(%g,%g){\\circle{%.3f}}",
	     out.x1, out.x2, t2p(EPIX_SPOT_DIAM));
    break;

  case SPOT:   
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\bullet$}}",
	     out.x1, out.x2);
    break;

  case RING:   
    fprintf (stdout, "\n\\put(%g,%g){\\circle{%.3f}}",
	     out.x1, out.x2, t2p(EPIX_SPOT_DIAM));
    break;

  case DOT:   
    fprintf (stdout, "\n\\put(%g,%g){\\circle*{%.3f}}",
	     out.x1, out.x2, t2p(0.5*EPIX_SPOT_DIAM));
    break;

  case DDOT:   
    fprintf (stdout, "\n\\put(%g,%g){\\circle*{%.3f}}",
	     out.x1, out.x2, t2p(0.25*EPIX_SPOT_DIAM));
    break;

  case PLUS:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){+}}", out.x1, out.x2);
    break;

  case OPLUS:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\oplus$}}",
	    out.x1, out.x2);
    break;

  case TIMES:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\times$}}",
	    out.x1, out.x2);
    break;

  case OTIMES:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\otimes$}}",
	    out.x1, out.x2);
    break;

  case DIAMOND:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\diamond$}}",
	    out.x1, out.x2);
    break;

  case UP:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\bigtriangleup$}}",
	    out.x1, out.x2);
    break;

  case DOWN:
    fprintf (stdout, "\n\\put(%g,%g){\\makebox(0,0){$\\bigtriangledown$}}",
	    out.x1, out.x2);
    break;

  case BOX:   
    /* Hardwired constant 4pt */
    fprintf (stdout, "\n\\put(%g,%g){\\kern -2pt \\rule[-2pt]{4pt}{4pt}}",
	    out.x1, out.x2);
    break;

  case BBOX:   
    /* Hardwired constant 2pt */
    fprintf (stdout, "\n\\put(%g,%g){\\kern -1pt \\rule[-1pt]{2pt}{2pt}}",
	    out.x1, out.x2);
    break;

  default: 
    break;
  }
}

/*
 * Empty and filled LaTeX circles of diameter EPIX_SPOT_DIAM true pt
 */
void
circ(pair p) // filled white circ 4 pt in diameter
{
  epix_comment("circ");
  marker(p, CIRC);
  end_stanza();
}  
void
ring(pair p, double r) // unfilled circ of specified diam
{
  pair out = c2p(p);
  epix_comment("ring");
  fprintf (stdout, "\n\\put(%g,%g){\\circle{%g}}",
	   out.x1, out.x2, (r*EPIX_SPOT_DIAM/4)/p2t(1.0));
  end_stanza();
}  
void
spot(pair p)
{
  epix_comment("spot");
  marker(p, SPOT); // LaTeX bullet
  end_stanza();
}  
void
dot(pair p)
{
  epix_comment("dot");
  marker(p, DOT);
  end_stanza();
}  
void
ddot(pair p)
{
  epix_comment("ddot");
  marker(p, DDOT);
  end_stanza();
}

/* 
 * Axis ticks 
 *
 * N.B. An h_tick is a tall, thin rectangle, for a *horizontal* axis, etc.
 */

static void h_tick(void)
{
  fprintf (stdout, "{\\kern -0.25pt \\rule[-2pt]{0.5pt}{4pt}}");
}
static void v_tick(void)
{
  fprintf (stdout, "{\\kern -2pt \\rule[-0.25pt]{4pt}{0.5pt}}");
}

void
h_axis_tick(pair p)
{
  pair out = c2p(p);
  fprintf (stdout, "\n\\put(%g,%g)", out.x1, out.x2);
  h_tick();
}

void
v_axis_tick(pair p)
{
  pair out = c2p(p);
  fprintf (stdout, "\n\\put(%g,%g)", out.x1, out.x2);
  v_tick();
}

/* 
 * Coordinate axes, specified by initial and final points, and number
 *  of steps. 
 */
static void 
draw_axis(pair tail, pair head, int n, int epix_tick_type)
{
  pair start = c2p(tail);               // c2p: tail is a point
  pair step = (1.0/n)*c2s(head - tail); // c2s: step is a vector

  //axis
  start_path();
  print(tail);
  print(head);
  ++epix_lines_printed;
  
  fprintf (stdout, "\n%%%% tick marks:\n%%%%");
  fprintf (stdout, "\n\\multiput(%g,%g)(%g,%g){%d}",
	   start.x1, start.x2, step.x1, step.x2, n+1);

  if (epix_tick_type == H_AXIS)
    h_tick();

  else if (epix_tick_type == V_AXIS)
    v_tick();
  
  else // epix_tick_type == NULL or unknown
    ;

  ++epix_lines_printed;
  end_stanza();
}
  
void h_axis(pair tail, pair head, int n)
{
  epix_comment("horizontal axis");
  draw_axis(tail, head, n, H_AXIS);
}

void v_axis(pair tail, pair head, int n)
{
  epix_comment("vertical axis");
  draw_axis(tail, head, n, V_AXIS);
}
/*
 * h_axis_labels: Draws n+1 equally-spaced axis labels between 
 *    <tail> and <head>. Automatically generates label values from
 *    Cartesian coordinates, and has true-distance offsets.
 *
 * There is a separate version that takes a LaTeX-style alignment argument.
 * The "unaligned" version tries to do constant alignment with labels that
 * may or may not have a sign. It was easier to write a new routine to
 * handle labels with an alignment option than to modify the existing one.
 */

static void
draw_axis_labels(pair tail, pair head, int n, pair offset, 
		 const int epix_tick_type, int mask)
{
  int neg_flag;
  double label;

  // determine if labels change sign (may be needed for alignment)
  if (epix_tick_type == H_AXIS && head.x1*tail.x1 < 0)
    neg_flag=1;
  else if (epix_tick_type == V_AXIS && head.x2*tail.x2 < 0)
    neg_flag=1;
  else
    neg_flag=0;

  for (int i=0; i<= n; ++i)
    {
      pair current = tail + (i*1.0/n)*(head - tail);
      pair location = c2p(current) + t2p(offset);
      fprintf (stdout, "\n");

      // Compute proper type of label
      if (epix_tick_type == H_AXIS)
	label = current.x1;
      else // V_AXIS
	label = current.x2;

      // Put sign on label?
      if (neg_flag && label >= 0)
	{
	  // Let TeX worry about the non-existent "-"
	  fprintf (stdout, "\\put(%g,%g){$\\phantom{-}",
		   location.x1, location.x2);
	  // mask label?
	  if (mask == 0)
	    fprintf (stdout, "%g$}" , label);
	  else // N.B. Excess "}" ------------------- v
	    fprintf (stdout, "$\\colorbox{white}{$%g$}}" , label);
	}
      else
	{
	  fprintf (stdout, "\\put(%g,%g)", location.x1, location.x2);
	  if (mask == 0)
	    fprintf (stdout, "{$%g$}" , label);
	  else
	    fprintf (stdout, "{\\colorbox{white}{$%g$}}" , label);
	}
    }
  end_stanza();
}

void
h_axis_labels(pair tail, pair head, int n, pair offset)
{
  epix_comment("horizontal axis labels");
  draw_axis_labels(tail, head, n, offset, H_AXIS, 0);
}
void
v_axis_labels(pair tail, pair head, int n, pair offset)
{
  epix_comment("vertical axis labels");
  draw_axis_labels(tail, head, n, offset, V_AXIS, 0);
}
void
h_axis_masklabels(pair tail, pair head, int n, pair offset)
{
  epix_comment("masked horizontal axis labels");
  draw_axis_labels(tail, head, n, offset, H_AXIS, 1);
}
void
v_axis_masklabels(pair tail, pair head, int n, pair offset)
{
  epix_comment("masked vertical axis labels");
  draw_axis_labels(tail, head, n, offset, V_AXIS, 1);
}

/* axis labels with alignment option */
static void
draw_axis_labels(pair tail, pair head, int n, pair offset, 
		 const int epix_tick_type, int mask, const int epix_label_posn)
{
  double label;

  for (int i=0; i<= n; ++i)
    {
      pair current = tail + (i*1.0/n)*(head - tail);
      pair location = c2p(current) + t2p(offset);
      fprintf (stdout, "\n");

      // Compute proper type of label
      if (epix_tick_type == H_AXIS)
	label = current.x1;
      else // V_AXIS
	label = current.x2;

      fprintf (stdout, "\\put(%g,%g){\\makebox(0,0)",
	       location.x1, location.x2);
      print_epix_label_posn(epix_label_posn);
      if (mask == 0)
	fprintf (stdout, "{$%g$}}" , label);
      else
	fprintf (stdout, "{\\colorbox{white}{$%g$}}}" , label);
    }
  end_stanza();
}

void
h_axis_labels(pair tail, pair head, int n, pair offset, 
	      const int epix_label_posn)
{
  epix_comment("aligned horizontal axis labels");
  draw_axis_labels(tail, head, n, offset, H_AXIS, 0, epix_label_posn);
}
void
v_axis_labels(pair tail, pair head, int n, pair offset, 
	      const int epix_label_posn)
{
  epix_comment("aligned vertical axis labels");
  draw_axis_labels(tail, head, n, offset, V_AXIS, 0, epix_label_posn);
}
void
h_axis_masklabels(pair tail, pair head, int n, pair offset, 
		  const int epix_label_posn)
{
  epix_comment("masked, aligned horizontal axis labels");
  draw_axis_labels(tail, head, n, offset, H_AXIS, 1, epix_label_posn);
}
void
v_axis_masklabels(pair tail, pair head, int n, pair offset, 
		  const int epix_label_posn)
{
  epix_comment("masked, aligned vertical axis labels");
  draw_axis_labels(tail, head, n, offset, V_AXIS, 1, epix_label_posn);
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *             Simple geometric objects                  *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Lines take a stretch factor, roughly in percent */
void
draw_line(pair tail, pair head, int n, double expand)
{
  double c = expm1(M_LN2*expand/100.0); // 2^{expand/100} - 1
  pair direction = head - tail;

  start_path();

  /* Ensure at least two points printed */
  n = abs(n);
  if (n<1)
    n=1;

  if (EPIX_PATH_STYLE != SOLID)
    n = (int) ceil(p2t(raw_len(c2s((1+c)*(head-tail))))/(12*epix_stretch_factor));

  pair pt = tail - (0.5*c)*direction;
  pair step = ((1+c)/n)*direction; // displacement of stretched line

  for (int i=0; i<=n; ++i)
    {
      print(pt);
      pt += step;
      line_break(i,n);
    }
}

/* Lines with expansion factor */
void
line(pair tail, pair head, double expand)
{
  epix_comment("stretched line");
  draw_line(tail, head, 1, expand);
  end_stanza();
}

/* Unstretched lines */
void
line(pair tail, pair head)
{
  epix_comment("unstretched line");
  draw_line(tail, head, 1, 0);
  end_stanza();
}

/*
 * Returns positive iff vertices (p0,p1,p2) are counterclockwise.
 * Cyclic permutation of parameters has no effect on sign of return value.
 */
double ccw(pair p0, pair p1, pair p2)
{
  double d = truncate(p2.x1 - p1.x1);
  if ( d != 0)
    return truncate(p0.x2 - p1.x2 - (p2.x2 - p1.x2)*(p0.x1 - p1.x1)/d);
  else
    return truncate(p1.x1 - p0.x1);
}

/*
 * Line(p1, p2) -- Portion of line (p1,p2) that lies in bounding_box
 *
 * First check whether p1, p2 lie on a vertical line.
 * If not, find points where (p1,p2) crosses x=x_min, x=x_max, then
 * see if these points satisfy y_min <= y <= y_max.
 */
void draw_Line(pair p1, pair p2, int n)
{
  int found = 0;

  pair tail, head;

  /* Points lie on a vertical line */
  if ( truncate(p2.x1 - p1.x1) == 0 && x_min <= p1.x1 && p1.x1 <= x_max )
    {
      tail = P(p1.x1, y_min);
      head = P(p1.x1, y_max);
      found = 2;
    }
  else
    { 
      double m = (p2.x2 - p1.x2)/(p2.x1 - p1.x1); // slope of line
      tail = P(x_min, p1.x2 + m*(x_min - p1.x1));
      head = P(x_max, p1.x2 + m*(x_max - p1.x1));

      if (m > 0) {
	if ( y_max <= tail.x2 )
	  ; // line misses bounding box
	else if ( y_min <= tail.x2 )	  
	  ++found; // tail is correct
	else // tail.x2 < y_min, adjust tail
	  { 
	    tail = P(p1.x1 + (y_min - p1.x2)/m, y_min);
	    ++found;
	  }

	if ( head.x2 <= y_min )
	  ;
	else if ( head.x2 <= y_max )
	  ++found; // head is correct
	else
	  {
	    head = P(p1.x1 + (y_max - p1.x2)/m, y_max);
	    ++found;
	  }
      }

      else { // m < 0
	if ( tail.x2 <= y_min )
	  ; // line misses bounding box
	else if ( tail.x2 <= y_max )	  
	  ++found; // tail is correct
	else // y_max < tail.x2, adjust tail
	  { 
	    tail = P(p1.x1 + (y_max - p1.x2)/m, y_max);
	    ++found;
	  }

	if ( y_max <= head.x2 )
	  ;
	else if ( y_min <= head.x2 )
	  ++found; // head is correct
	else
	  {
	    head = P(p1.x1 + (y_min - p1.x2)/m, y_min);
	    ++found;
	  }
      }
    }

  if ( found == 2 )
    draw_line(tail, head, n, 0);
  // else print nothing
}

void
Line(pair tail, pair head)
{
  epix_comment("Line");
  int n=1;
  if (EPIX_PATH_STYLE != SOLID)
    n = (int) ceil(p2t(raw_len(c2s(head-tail)))/(12*epix_stretch_factor));

  draw_Line(tail, head, n);
  end_stanza();
}

/* point-slope specification */
void
Line(pair tail, double slope)
{
  Line(tail, tail+P(1, slope));
}

/* Triangles */
void
draw_triangle(pair p1, pair p2, pair p3)
{
  start_path();
  print(p1);
  print(p2);
  print(p3);
  print(p1);
}

void
triangle(pair p1, pair p2, pair p3)
{
  epix_comment("triangle");
  draw_triangle(p1, p2, p3);
  end_stanza();
}

/* 
 * If (a,b) and (c,d) are opposite corners of a rectangle, then
 * the corners -- in order -- are (a,b), (c,b), (c,d), and (a,d).
 */
void
draw_rect(pair p1, pair p2)
{
  pair h_jump = e_1&(p2-p1); // e_1 = (1,0), e_2 = (0,1), so
  pair v_jump = e_2&(p2-p1); // e_1&(a,b) = (a,0), etc.

  start_path();
  print(p1);
  print(p1 + h_jump);
  print(p2);
  print(p1 + v_jump);
  print(p1);
}

void
rect(pair p1, pair p2)
{
  epix_comment("coordinate rectangle");
  draw_rect(p1, p2);
  end_stanza();
}

void
swatch(pair p1, pair p2)
{
  solid;
  epix_comment("shaded coordinate rectangle (\"swatch\")");
  fprintf (stdout, "\n\\shade");
  draw_rect(p1, p2);
  end_stanza();
}

/* eepic.sty has an \ellipse function; native_ellipse() accesses it */
void 
draw_native_ellipse(pair center, pair radius)
{
  center = c2p(center);
  radius = c2s(2*radius);

  fprintf (stdout, "\n\\put(%g,%g){\\ellipse{%g}{%g}}",
	  center.x1, center.x2, radius.x1, radius.x2);
}

/* User-callable draw_ellipse is identical, in curves.cc */
static void 
draw_ellipse(pair center, pair radius)
{
  int i;
  pair current;

  start_path();
  for (i=0; i <= 2*EPIX_NUM_PTS; ++i) 
    {
      current = center + radius&cis(M_PI*i/EPIX_NUM_PTS);
      print(current);

      line_break(i, 2*EPIX_NUM_PTS);
    }
}  

void 
native_ellipse(pair center, pair radius)
{
  epix_comment("native ellipse");
  draw_native_ellipse(center, radius);
  end_stanza();
}

/* 
 * n1 x n2 Cartesian grid
 *
 * If style is DASH or DOTTED, all grid *segments* are drawn; otherwise
 * only grid lines (edge-to-edge) are drawn. 
 */
void
draw_grid(pair p1, pair p2, int n1, int n2)
{
  int i, num_pts;
  pair h_jump, v_jump;
  h_jump = e_1&(p2 - p1);
  v_jump = e_2&(p2 - p1);

  fprintf (stdout, "\n%%%%   Vertical lines");
  for (i=0; i<=n1; ++i)
    {
      if (EPIX_PATH_STYLE == SOLID)
	num_pts = 1;   // draw line at once
      else num_pts = (int) n2; // draw line in segments

      draw_line(p1 + ((i*1.0/n1)*h_jump),
		(p1 + v_jump) + (i*1.0/n1)*h_jump, num_pts, 0);

      ++epix_lines_printed;
    }

  fprintf (stdout, "\n%%%%   Horizontal lines");
  for (i=0; i<=n2; ++i)
    {
      if (EPIX_PATH_STYLE == SOLID)
	num_pts = 1;   // draw line at once
      else num_pts = (int) n1; // draw line in segments
      
      draw_line(p1 + ((i*1.0/n2)*v_jump),
		(p1 + h_jump) + (i*1.0/n2)*v_jump, num_pts, 0);

      ++epix_lines_printed;
    }
}

/* Grids that fill bounding_box */
void
grid(int n1, int n2)
{
  fprintf (stdout, "\n%%%% grid:");
  draw_grid(P(x_min, y_min), P(x_max, y_max), n1, n2);
  end_stanza();
}

/* Grids of arbitrary size */
void
grid(pair p1, pair p2, int n1, int n2)
{
  fprintf (stdout, "\n%%%% grid:");
  draw_grid(p1, p2, n1, n2);
  end_stanza();
}

/* Polar grid with n1 rings and n2 sectors */
void
draw_polar_grid(double radius, int n1, int n2)
{
  fprintf (stdout, "\n%%%%   rings\n%%%%"); 
  for (int i=1; i <= n1; ++i) 
    {
      if (EPIX_PATH_STYLE == SOLID)
	draw_native_ellipse(P(0,0), P(i*radius/n1,i*radius/n1));
      
      else
	draw_ellipse(P(0,0), P(i*radius/n1,i*radius/n1));

      ++epix_lines_printed;
    }

  fprintf (stdout, "\n%%%%   radii\n%%%%");  
  for (int i=0; i < n2; ++i)
    {
      draw_line(P(0,0), polar(radius, 2*M_PI*i/n2), 2*n1, 0);
      if (i<n2-1)
	fprintf (stdout, "\n%%%%");

      ++epix_lines_printed;
    }
}

void
polar_grid(double radius, int n1, int n2)
{
  epix_comment("polar grid");
  draw_polar_grid(radius, n1, n2);
  end_stanza();
}

/* 
 * Arrows joining two specified <pair>s. An arrow consists of a head
 * and a shaft; the head is 2*width true points wide, and width*ratio
 * true points long, while the shaft is long enough to join the <tail>
 * to <new_head> (see below). If the <tail> is inside the arrowhead,
 * the shaft is not drawn. 
 *
 * Because drawing the head and shaft involve separate complications, 
 * they are split into separate functions. The algorithm is:
 *
 * (1) Find Cartesian direction vector from <tail> to <head>, and
 *    convert to picture coords.
 *
 * (2) If shaft is too short, put base of arrowhead at <base>. Precisely,
 *    determine the true pt length of the direction vector, normalize
 *    it, and move width*ratio true points toward <tail> from <head>.
 *    If this backtracks across <tail>, do not draw the shaft; otherwise,
 *    retract the head appropriately, to <new_head>. Draw the shaft.
 *    Stop snickering...
 *
 * (3) Compute the three vertices of the arrowhead; they are two true pt
 *    to either side of <new_head>, and width*ratio true pt along the
 *    unit vector from <new_head> to <head>, i.e., at <head> provided
 *    the arrow is not so short that <tail> lies inside the arrowhead.
 *    To get perpendicular offsets, the rotation operator J is applied
 *    to the true unit vector.
 *
 * As with other polygon objects, draw_arrowhead and draw_shaft print
 * only lists of coordinate pairs, not line styles, etc. draw_arrow is the
 * user analogue of draw_rect (e.g.); it draws the requisite paths and
 * nothing else. This division of labor  allows the pieces to be used in
 * other functions, e.g., plots of tangent vectors to a parametrized curve.
 *
 * A certain amount of mental resistance was required not to use the term
 * "flint" instead of "arrowhead".
 */
void
draw_arrowhead(pair tail, pair head, double width)
{
  double ratio=EPIX_ARROWHEAD_RATIO;

  /*
   * Vertices of arrowhead:
   *
   *                       <tip1>
   * <cart_to_pict(tail)>  <new_head>    <tip3>
   *                       <tip2>
   */

  pair tip1, tip2, tip3; 

  /* Head/tail of shaft in picture coordinates */
  pair new_head;

  /* Picture coords direction vector from <tail> to <head> */
  pair dir = c2s(head - tail);
  /* Picture coords unit vector parallel to direction vector */
  pair unit_dir = normalize(dir);

  if ( width*ratio < true_len(dir) ) // <tail> outside arrowhead
    {
      tip3 = c2p(head);
      new_head = tip3 - (width*ratio)*unit_dir;
    }

  else // <tail> inside arrowhead
    {
      new_head = c2p(tail);
      tip3 = new_head + (width*ratio)*unit_dir;
    }

  tip1 = new_head + width*J(unit_dir);
  tip2 = new_head - width*J(unit_dir);

  /* N.B. Coordinates already converted from Cartesian */
  raw_print(tip1);
  raw_print(tip2);
  raw_print(tip3);
  raw_print(tip1);
}

void
draw_shaft(pair tail, pair head, double width)
{
  double ratio=EPIX_ARROWHEAD_RATIO;

  /* Head/tail of shaft in picture coordinates */
  pair new_head;
  /* Picture coords direction vector from <tail> to <head> */
  pair dir = c2s(head - tail);
  /* Picture coords unit vector parallel to direction vector */
  pair unit_dir = normalize(dir);

  if ( width*ratio < true_len(dir) ) // <tail> outside arrowhead
    {
      new_head = c2p(head) - (width*ratio)*unit_dir;
      print(tail);
      raw_print(new_head);
    }
}

void
draw_arrow(pair tail, pair head)
{
  double width=EPIX_ARROWHEAD_WIDTH;
  double ratio=EPIX_ARROWHEAD_RATIO;
  pair dir = c2s(head - tail);

  if ( width*ratio < true_len(dir) )
    {
      if (EPIX_PATH_STYLE == DOTTED)
	bold;
      start_path();
      draw_shaft(tail, head, width);
      if (EPIX_PATH_STYLE == DOTTED)
	endbold;
    }
  start_path();
  draw_arrowhead(tail, head, width);
}

void
draw_boldarrow(pair tail, pair head)
{
  double width=EPIX_ARROWHEAD_WIDTH;
  double ratio=EPIX_ARROWHEAD_RATIO;
  pair dir = c2s(head - tail);

  if ( width*ratio < true_len(dir) )
    {
      bold;
      start_path();
      draw_shaft(tail, head, width);
      endbold;
    }
  fprintf (stdout, "\n");
  fill;
  start_path();
  draw_arrowhead(tail, head, width);
}

void
arrow(pair tail, pair head)
{
  epix_comment("arrow");
  draw_arrow(tail, head);
  end_stanza();
}
void
boldarrow(pair tail, pair head)
{
  solid;
  epix_comment("bold arrow");
  draw_boldarrow(tail, head);
  end_stanza();
}

/* Small arrows: "dart"s. Same as arrows with head half size */
void
draw_dart(pair tail, pair head)
{
  double width=0.5*EPIX_ARROWHEAD_WIDTH;
  double ratio=EPIX_ARROWHEAD_RATIO;
  pair dir = c2s(head - tail);

  if ( width*ratio < true_len(dir) )
    {
      if (EPIX_PATH_STYLE == DOTTED)
	bold;
      start_path();
      draw_shaft(tail, head, width);
      if (EPIX_PATH_STYLE == DOTTED)
	endbold;
    }
  start_path();
  draw_arrowhead(tail, head, width);
}

void
draw_bolddart(pair tail, pair head)
{
  double width=0.5*EPIX_ARROWHEAD_WIDTH;
  double ratio=EPIX_ARROWHEAD_RATIO;
  pair dir = c2s(head - tail);

  if ( width*ratio < true_len(dir) )
    {
      bold;
      start_path();
      draw_shaft(tail, head, width);
      endbold;
    }
  fprintf (stdout, "\n");
  fill;
  start_path();
  draw_arrowhead(tail, head, width);
}

void
dart(pair tail, pair head)
{
  epix_comment("dart");
  draw_dart(tail, head);
  end_stanza();
}
void
bolddart(pair tail, pair head)
{
  solid;
  epix_comment("bold dart");
  draw_bolddart(tail, head);
  end_stanza();
}
