/* 
 * legacy.cc -- deprecated routines, needed only to process old files
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.7rc10
 * Last Change: September 21, 2002
 */

/* 
 * Copyright (C) 2001, 2002  
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#define _EPIX_COMPILE
#include "legacy.h"

extern double epix_stretch_factor;

static double zero(double t) {return 0;}

/* Collected comment functions */
/* objects.cc */
static void
comment_line(char *type, pair p1, pair p2)
{
  fprintf (stdout, "\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	   type, p1.x1, p1.x2, p2.x1, p2.x2);
}
static void
comment_line(char *type, pair p1, pair p2, double expand)
{
  fprintf (stdout, "\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f), %.2f%%\n%%%%",
	   type, p1.x1, p1.x2, p2.x1, p2.x2, 100*(exp(M_LN2*expand/100)));
}
static void
comment_triangle(char *type, pair p1, pair p2, pair p3)
{
  fprintf (stdout, "\n%%%% %s: (%.2f, %.2f), (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	   type, p1.x1, p1.x2, p2.x1, p2.x2, p3.x1, p3.x2);
}
static void
comment_rect(char *type, pair p1, pair p2)
{
  fprintf (stdout, "\n%%%% %s: corners (%.2f, %.2f) and (%.2f, %.2f)\n%%%%", \
	   type, p1.x1, p1.x2, p2.x1, p2.x2);
}

/* curves.cc */
static void 
comment_ellipse(char *type, pair center, pair radius)
{
  fprintf(stdout, "\n%%%% %s: center (%.2f, %.2f), radius (%.2f, %.2f)\n%%%%",
	  type, center.x1, center.x2, radius.x1, radius.x2);
}
static void 
comment_rotate_ellipse(char *type, pair center, pair radius, double angle)
{
  fprintf(stdout, "\n%%%% %s: center (%.2f, %.2f), radius (%.2f, %.2f),",
	  type, center.x1, center.x2, radius.x1, radius.x2);
  fprintf(stdout, "\n%%%%   rotated %.1f degrees\n%%%%", angle);
}
static void 
comment_arc(char *type, pair center,
		 double radius, double start, double finish)
{
  fprintf(stdout, "\n%%%% %s:\n%%%%   center (%.2f,%.2f), radius %.2f, ",
	  type, center.x1, center.x2, radius);
  fprintf(stdout, "from %.2f to %.2f radians \n%%%%", start, finish);
}
static void 
comment_spline(char *type, pair p1, pair p2, pair p3)
{
  fprintf(stdout, "\n%%%% %s: control points", type);
  fprintf(stdout, "\n%%%%   ");
  raw_print(p1);
  raw_print(p2);
  raw_print(p3);
  fprintf(stdout, "\n%%%%");
}
static void 
comment_spline(char *type, pair p1, pair p2, pair p3, pair p4)
{
  fprintf(stdout, "\n%%%% %s: control points", type);
  fprintf(stdout, "\n%%%%   ");
  raw_print(p1);
  raw_print(p2);
  raw_print(p3);
  raw_print(p4);
  fprintf(stdout, "\n%%%%");
}
static void 
comment_twist(char *type, pair p1, pair p4)
{
  fprintf(stdout, "\n%%%% %s: control points", type);
  fprintf(stdout, "\n%%%%   (%.2f, %.2f), (%.2f, %.2f)\n%%%%",
	  p1.x1, p1.x2, p4.x1, p4.x2);
}
static void 
comment_plot(char *type)
{
  fprintf(stdout, "\n%%%% %s", type);
}

/* * * objects.cc * * */

/* "mask"s -- filled white rectangles (very rare) */
/*
 * mask -- filled white rectangle to mask out part of a figure
 * prior to label placement. Parameters designed to match those
 * of labels; <base> is the Cartesian location, <offset> is the
 * offset in true pt, <size> is the size of the box in true pt.
 */
void
mask(pair base, pair offset, pair size)
{
  pair low_left = base + s2c(t2p(offset));
  pair up_right = base + s2c(t2p(offset + size));
  /*
    double a = base.x1 + h_unstretch(scale(offset.x1));
    double b = base.x2 + v_unstretch(scale(offset.x2));
    double c = base.x1 + h_unstretch(scale(offset.x1 + size.x1));
    double d = base.x2 + v_unstretch(scale(offset.x2 + size.x2));
  */

  fprintf (stdout, "\n%%%% mask: %g pt x %g pt at (%g, %g)\n%%%%", \
	 size.x1, size.x2, base.x1, base.x2);
  fprintf (stdout, "\n\\whiten");
  draw_rect(low_left, up_right);
  end_stanza();
}

/* lines with stretch factor */
void
dashline(pair tail, pair head, double expand)
{
  /* Hardwired constant 12 -- approximate length of unstretched dashes in true pt */
  int n = (int) ceil(p2t(raw_len(c2s(exp(M_LN2*expand/100)*(head-tail))))/(12*epix_stretch_factor));
  dashed;
  comment_line("dashline", tail, head, expand);
  draw_line(tail, head, n, expand);
  solid;
  end_stanza();
}
void
dotline(pair tail, pair head, double expand)
{
  dotted;
  comment_line("dotline", tail, head, expand);
  draw_line(tail, head, 1, expand);
  solid;
  end_stanza();
}
void
boldline(pair tail, pair head, double expand)
{
  solid;
  comment_line("boldline", tail, head, expand);
  bold;
  draw_line(tail, head, 1, expand);
  endbold;
  end_stanza();
}

/* lines given by endpoints */
void
dashline(pair tail, pair head)
{
  /* Hardwired constant 12 -- approximate length of unstretched dashes in true pt */
  int n = (int) ceil(p2t(raw_len(c2s(head-tail)))/(12*epix_stretch_factor));
  dashed;
  comment_line("dashline", tail, head);
  draw_line(tail, head, n, 0);
  solid;
  end_stanza();
}
void
dotline(pair tail, pair head)
{
  dotted;
  comment_line("dotline", tail, head);
  draw_line(tail, head, 1, 0);
  solid;
  end_stanza();
}
void
boldline(pair tail, pair head)
{
  solid;
  comment_line("boldline", tail, head);
  bold;
  draw_line(tail, head, 1, 0);
  endbold;
  end_stanza();
}

/* Two-point Lines */
void
dashLine(pair tail, pair head)
{
  /* Hardwired constant 12 -- approximate length of unstretched dashes in true pt */
  int n = (int) ceil(p2t(raw_len(c2s(P(x_size, y_size))))/(12*epix_stretch_factor));
  dashed;
  comment_line("dashLine", tail, head);
  draw_Line(tail, head, n);
  solid;
  end_stanza();
}
void
dotLine(pair tail, pair head)
{
  dotted;
  comment_line("dotLine", tail, head);
  draw_Line(tail, head, 1);
  solid;
  end_stanza();
}
void
boldLine(pair tail, pair head)
{
  solid;
  comment_line("boldLine", tail, head);
  bold;
  draw_Line(tail, head, 1);
  endbold;
  end_stanza();
}

/* Point-slope Lines */
void
dashLine(pair tail, double slope)
{
  dashLine(tail, tail+P(1, slope));
}
void
dotLine(pair tail, double slope)
{
  dotLine(tail, tail+P(1, slope));
}
void
boldLine(pair tail, double slope)
{
  boldLine(tail, tail+P(1, slope));
}

/* triangles */
void
dashtriangle(pair p1, pair p2, pair p3)
{
  dashed;
  comment_triangle("dashtriangle", p1, p2, p3);
  draw_triangle(p1, p2, p3);
  solid;
  end_stanza();
}
void
dottriangle(pair p1, pair p2, pair p3)
{
  dotted;
  comment_triangle("dottriangle", p1, p2, p3);
  draw_triangle(p1, p2, p3);
  solid;
  end_stanza();
}
void
boldtriangle(pair p1, pair p2, pair p3)
{
  solid;
  comment_triangle("boldtriangle", p1, p2, p3);
  bold;
  draw_triangle(p1, p2, p3);
  endbold;
  end_stanza();
}

/* coordinate rectangles */
void
dashrect(pair p1, pair p2)
{
  dashed;
  comment_rect("dashrect", p1, p2);
  draw_rect(p1, p2);
  solid;
  end_stanza();
}
void
dotrect(pair p1, pair p2)
{
  dotted;
  comment_rect("dotrect", p1, p2);
  draw_rect(p1, p2);
  solid;
  end_stanza();
}
void
boldrect(pair p1, pair p2)
{
  solid;
  comment_rect("boldrect", p1, p2);
  bold;
  draw_rect(p1, p2);
  endbold;
  end_stanza();
}

void
boldswatch(pair p1, pair p2)
{
  solid;
  comment_rect("boldswatch", p1, p2);
  bold;
  fprintf (stdout, "\\shade");
  draw_rect(p1, p2);
  endbold;
  end_stanza();
}

/* Cartesian coordinate grids */
void
dashgrid(int n1, int n2)
{
  dashed;
  fprintf (stdout, "\n%%%% dashgrid:");
  draw_grid(P(x_min, y_min), P(x_max, y_max), n1, n2);
  solid;
  end_stanza();
}
void
dotgrid(int n1, int n2)
{
  dotted;
  fprintf (stdout, "\n%%%% dotgrid:");
  draw_grid(P(x_min, y_min), P(x_max, y_max), n1, n2);
  dotted;
  end_stanza();
}
void
boldgrid(int n1, int n2)
{
  solid;
  fprintf (stdout, "\n%%%% boldgrid:");
  bold;
  draw_grid(P(x_min, y_min), P(x_max, y_max), n1, n2);
  endbold;
  end_stanza();
}

/* Cartesian grid of arbitrary size */
void
dashgrid(pair p1, pair p2, int n1, int n2)
{
  dashed;
  fprintf (stdout, "\n%%%% dashgrid:");
  draw_grid(p1, p2, n1, n2);
  solid;
  end_stanza();
}
void
dotgrid(pair p1, pair p2, int n1, int n2)
{
  dotted;
  fprintf (stdout, "\n%%%% dotgrid:");
  draw_grid(p1, p2, n1, n2);
  solid;
  end_stanza();
}
void
boldgrid(pair p1, pair p2, int n1, int n2)
{
  solid;
  fprintf (stdout, "\n%%%% boldgrid:");
  bold;
  draw_grid(p1, p2, n1, n2);
  endbold;
  end_stanza();
}

/* polar grids */
void
dashpolar_grid(double radius, int n1, int n2)
{
  dashed;
  fprintf (stdout, "\n%%%% dashpolar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  draw_polar_grid(radius, n1, n2);
  solid;
  end_stanza();
}
void
dotpolar_grid(double radius, int n1, int n2)
{
  dotted;
  fprintf (stdout, "\n%%%% dotpolar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  draw_polar_grid(radius, n1, n2);
  solid;
  end_stanza();
}
void
boldpolar_grid(double radius, int n1, int n2)
{
  solid;
  fprintf (stdout, "\n%%%% boldpolar_grid: Radius %.2f, %d rings, %d sectors\n%%%%", 
	 radius, n1, 2*n2);
  bold;
  draw_polar_grid(radius, n1, n2);
  endbold;
  end_stanza();
}

/* arrows */
void
dasharrow(pair tail, pair head)
{
  dashed;
  comment_line("dasharrow", tail, head);
  draw_arrow(tail, head);
  solid;
  end_stanza();
}
void
dotarrow(pair tail, pair head)
{
  dotted;
  comment_line("dotarrow", tail, head);
  draw_arrow(tail, head);
  solid;
  end_stanza();
}

/* darts */
void
dashdart(pair tail, pair head)
{
  dashed;
  comment_line("dashdart", tail, head);
  draw_dart(tail, head);
  solid;
  end_stanza();
}
void
dotdart(pair tail, pair head)
{
  dotted;
  comment_line("dotdart", tail, head);
  draw_dart(tail, head);
  solid;
  end_stanza();
}

/* * * curves.cc * * */
/* Ellipses */
void 
dashellipse(pair center, pair radius)
{
  dashed;
  comment_ellipse("dashellipse", center, radius);
  draw_ellipse(center, radius);
  solid;
  end_stanza();
}
void 
dotellipse(pair center, pair radius)
{
  dotted;
  comment_ellipse("dotellipse", center, radius);
  draw_ellipse(center, radius);
  solid;
  end_stanza();
}
void 
boldellipse(pair center, pair radius)
{
  solid; 
  comment_ellipse("boldellipse", center, radius);
  bold;
  draw_ellipse(center, radius);
  endbold;
  end_stanza();
}

/* Half ellipses */
/* Dashed half-ellipses */
void 
dashellipse_top(pair center, pair radius)
{
  dashed;
  comment_ellipse("dashellipse_top", center, radius);
  draw_half_ellipse(center, radius, 0);
  solid;
  end_stanza();
}
void 
dashellipse_bottom(pair center, pair radius)
{
  dashed;
  comment_ellipse("dashellipse_bottom", center, radius);
  draw_half_ellipse(center, radius, 180);
  solid;
  end_stanza();
}
void 
dashellipse_left(pair center, pair radius)
{
  dashed;
  comment_ellipse("dashellipse_left", center, radius);
  draw_half_ellipse(center, radius, 90);
  solid;
  end_stanza();
}
void 
dashellipse_right(pair center, pair radius)
{
  dashed;
  comment_ellipse("dashellipse_right", center, radius);
  draw_half_ellipse(center, radius, -90);
  solid;
  end_stanza();
}

/* Dotted half-ellipses */
void 
dotellipse_top(pair center, pair radius)
{
  dotted;
  comment_ellipse("dotellipse_top", center, radius);
  draw_half_ellipse(center, radius, 0);
  solid;
  end_stanza();
}
void 
dotellipse_bottom(pair center, pair radius)
{
  dotted;
  comment_ellipse("dotellipse_bottom", center, radius);
  draw_half_ellipse(center, radius, 180);
  solid;
  end_stanza();
}
void 
dotellipse_left(pair center, pair radius)
{
  dotted;
  comment_ellipse("dotellipse_left", center, radius);
  draw_half_ellipse(center, radius, 90);
  solid;
  end_stanza();
}
void 
dotellipse_right(pair center, pair radius)
{
  dotted;
  comment_ellipse("dotellipse_right", center, radius);
  draw_half_ellipse(center, radius, -90);
  solid;
  end_stanza();
}

/* Bold half-ellipses */
void 
boldellipse_top(pair center, pair radius)
{
  solid;
  comment_ellipse("boldellipse_top", center, radius);
  bold;
  draw_half_ellipse(center, radius, 0);
  endbold;
  end_stanza();
}
void 
boldellipse_bottom(pair center, pair radius)
{
  solid;
  comment_ellipse("boldellipse_bottom", center, radius);
  bold;
  draw_half_ellipse(center, radius, 180);
  endbold;
  end_stanza();
}
void 
boldellipse_left(pair center, pair radius)
{
  solid;
  comment_ellipse("boldellipse_left", center, radius);
  bold;
  draw_half_ellipse(center, radius, 90);
  endbold;
  end_stanza();
}
void 
boldellipse_right(pair center, pair radius)
{
  solid;
  comment_ellipse("boldellipse_right", center, radius);
  bold;
  draw_half_ellipse(center, radius, -90);
  endbold;
  end_stanza();
}

/* General half ellipses */
void 
dashellipse_half(pair center, pair radius, double angle)
{
  dashed;
  comment_rotate_ellipse("dashellipse_half", center, radius, angle);
  rotate_half_ellipse(center, radius, angle);
  solid;
  end_stanza();
}
void 
dotellipse_half(pair center, pair radius, double angle)
{
  dotted;
  comment_rotate_ellipse("dotellipse_half", center, radius, angle);
  rotate_half_ellipse(center, radius, angle);
  solid;
  end_stanza();
}
void 
boldellipse_half(pair center, pair radius, double angle)
{
  solid;
  comment_rotate_ellipse("boldellipse_half", center, radius, angle);
  bold;
  rotate_half_ellipse(center, radius, angle);
  endbold;
  end_stanza();
}

/* Circular arcs */
void 
dasharc(pair center, double r, double start, double finish)
{
  dashed;
  comment_arc("dasharc", center, r, start, finish);
  draw_arc(center, r, start, finish);
  solid;
  end_stanza();
}
void 
dotarc(pair center, double r, double start, double finish)
{
  dotted;
  comment_arc("dotarc", center, r, start, finish);
  draw_arc(center, r, start, finish);
  end_stanza();
}
void 
boldarc(pair center, double r, double start, double finish)
{
  solid;
  comment_arc("boldarc", center, r, start, finish);
  bold;
  draw_arc(center, r, start, finish);
  endbold;
  end_stanza();
}

/* Arc arrows */
void 
dasharc_arrow(pair center, double r, double start, double finish)
{
  dashed;
  comment_arc("dasharc_arrow", center, r, start, finish);
  draw_arc_arrow(center, r, start, finish);
  solid;
  end_stanza();
}
void 
dotarc_arrow(pair center, double r, double start, double finish)
{
  dotted;
  comment_arc("dotarc_arrow", center, r, start, finish);
  draw_arc_arrow(center, r, start, finish);
  solid;
  end_stanza();
}
void 
boldarc_arrow(pair center, double r, double start, double finish)
{
  solid;
  comment_arc("boldarc_arrow", center, r, start, finish);
  bold;
  draw_arc_arrow(center, r, start, finish);
  endbold;
  end_stanza();
}

/* Quadratic splines */
void 
dashspline(pair p1, pair p2, pair p3)
{
  dashed;
  comment_spline("dashquad_spline", p1, p2, p3);
  draw_spline(p1, p2, p3);
  solid;
  end_stanza();
}
void 
dotspline(pair p1, pair p2, pair p3)
{
  dotted;
  comment_spline("dotquad_spline", p1, p2, p3);
  draw_spline(p1, p2, p3);
  solid;
  end_stanza();
}
void 
boldspline(pair p1, pair p2, pair p3)
{
  solid;
  comment_spline("boldquad_spline", p1, p2, p3);
  bold;
  draw_spline(p1, p2, p3);
  endbold;
  end_stanza();
}

/* Cubic splines */
void 
dashspline(pair p1, pair p2, pair p3, pair p4)
{
  dashed;
  comment_spline("dashcubic_spline", p1, p2, p3, p4);
  draw_spline(p1, p2, p3, p4);
  solid;
  end_stanza();
}
void 
dotspline(pair p1, pair p2, pair p3, pair p4)
{
  dotted;
  comment_spline("dotcubic_spline", p1, p2, p3, p4);
  draw_spline(p1, p2, p3, p4);
  solid;
  end_stanza();
}
void 
boldspline(pair p1, pair p2, pair p3, pair p4)
{
  solid;
  comment_spline("boldcubic_spline", p1, p2, p3, p4);
  bold;
  draw_spline(p1, p2, p3, p4);
  endbold;
  end_stanza();
}

/* Knot twists */
void 
boldp_twist(pair p1, pair p4)
{
  solid;
  comment_twist("boldp_twist", p1, p4);
  bold;
  draw_p_twist(p1, p4);
  endbold;
  end_stanza();
}
void 
boldn_twist(pair p1, pair p4)
{
  solid;
  comment_twist("boldn_twist", p1, p4);
  bold;
  draw_n_twist(p1, p4);
  endbold;
  end_stanza();
}
void 
boldtwists(pair p1, pair p4, int n)
{
  double a;
  double b;
  double c;
  double d;

  fprintf(stdout, "\n%%%% boldtwists(%d), (%.2f,%.2f) to (%.2f,%.2f)", 
	 n, p1.x1, p1.x2, p4.x1, p4.x2);
  bold;
  if ((p4.x1 - p1.x1)*(p4.x2 - p1.x2) >= 0)
    {
      a = p1.x1;
      b = p1.x2;
      c = p4.x1;
      d = p4.x2;
      
      if (n < 0) {
	n = -n;
	for (int i=0; i < n; ++i)
	  draw_n_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n));
      }

      else
	for (int i=0; i < n; ++i)
	  draw_p_twist(P(a, b + i*(d-b)/n), P(c, b+(i+1)*(d-b)/n));
    }
  else
    {
      a = p1.x2;
      b = p1.x1;
      c = p4.x2;
      d = p4.x1;

      if (n < 0) {
	n = -n;
	for (int i=0; i < n; ++i)
	  draw_n_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c));
      }
      else
	for (int i=0; i < n; ++i)
	  draw_p_twist(P(b + i*(d-b)/n, a), P(b+(i+1)*(d-b)/n, c));
    }
  endbold;
  end_stanza();
}

/* * * geometry.cc * * */
/* hyperbolic lines */
void 
dashhyperbolic_line(pair tail, pair head)
{
  dashed;
  comment_line("dashhyperbolic_line", tail, head);
  draw_hyperbolic_line(tail, head);
  solid;
  end_stanza();
}
void 
dothyperbolic_line(pair tail, pair head)
{
  dotted;
  comment_line("dothyperbolic_line", tail, head);
  draw_hyperbolic_line(tail, head);
  solid;
  end_stanza();
}
void 
boldhyperbolic_line(pair tail, pair head)
{
  bold;
  solid;
  comment_line("boldhyperbolic_line", tail, head);
  draw_hyperbolic_line(tail, head);
  endbold;
  end_stanza();
}

/* Poincare disk */
void 
dashdisk_line(pair tail, pair head)
{
  dashed;
  comment_line("dashdisk_line", tail, head);
  draw_disk_line(tail, head);
  solid;
  end_stanza();
}
void 
dotdisk_line(pair tail, pair head)
{
  dotted;
  comment_line("dotdisk_line", tail, head);
  draw_disk_line(tail, head);
  solid;
  end_stanza();
}
void 
bolddisk_line(pair tail, pair head)
{
  bold;
  solid;
  comment_line("bolddisk_line", tail, head);
  draw_disk_line(tail, head);
  end_bold;
  end_stanza();
}

/* * * plots.cc * * */
/* Graph plots */
void
dashplot(double f(double), double t_min, double t_max, int num_pts)
{
  dashed;
  comment_plot("dashplot");
  draw_plot(f, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
dotplot(double f(double), double t_min, double t_max, int num_pts)
{
  dotted;
  comment_plot("dotplot");
  draw_plot(f, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
boldplot(double f(double), double t_min, double t_max, int num_pts)
{
  solid;
  comment_plot("boldplot");
  bold;
  draw_plot(f, t_min, t_max, num_pts);
  endbold;
  end_stanza();
}

/* Adaptive plots */
void
dashadplot(double f(double), double t_min, double t_max, int num_pts)
{
  dashed;
  comment_plot("dashadplot");
  draw_adapt_plot(id, f, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
dotadplot(double f(double), double t_min, double t_max, int num_pts)
{
  dotted;
  comment_plot("dotadplot");
  draw_adapt_plot(id, f, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
boldadplot(double f(double), double t_min, double t_max, int num_pts)
{
  solid;
  comment_plot("boldadplot");
  bold;
  draw_adapt_plot(id, f, t_min, t_max, num_pts);
  end_bold;
  end_stanza();
}

/* Plane parametric plots */
void
dashplot(double f1(double), double f2(double),
	 double t_min, double t_max, int num_pts)
{
  dashed;
  comment_plot("dashplot");
  draw_plot(f1, f2, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
dotplot(double f1(double), double f2(double),
	double t_min, double t_max, int num_pts)
{
  dotted;
  comment_plot("dotplot");
  draw_plot(f1, f2, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
boldplot(double f1(double), double f2(double),
	 double t_min, double t_max, int num_pts)
{
  solid;
  comment_plot("boldplot");
  bold;
  draw_plot(f1, f2, t_min, t_max, num_pts);
  endbold;
  end_stanza();
}

/* Space parametric plots */
void
dashplot(double u1(double), double u2(double), double u3(double),
	 double t_min, double t_max, int num_pts)
{
  dashed;
  comment_plot("dashplot3d");
  draw_plot(u1, u2, u3, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
dotplot(double u1(double), double u2(double), double u3(double),
	double t_min, double t_max, int num_pts)
{
  dotted;
  comment_plot("dotplot3d");
  draw_plot(u1, u2, u3, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
boldplot(double u1(double), double u2(double), double u3(double),
	 double t_min, double t_max, int num_pts)
{
  solid;
  comment_plot("boldplot3d");
  bold;
  draw_plot(u1, u2, u3, t_min, t_max, num_pts);
  end_bold;
  end_stanza();
}

/* Polar plots */
void
dashpolarplot(double r(double), double t_min, double t_max, int num_pts)
{
  dashed;
  comment_plot("dashpolarplot");
  draw_polarplot(r, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
dotpolarplot(double r(double), double t_min, double t_max, int num_pts)
{
  dotted;
  comment_plot("dotpolarplot");
  draw_polarplot(r, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
boldpolarplot(double r(double), double t_min, double t_max, int num_pts)
{
  solid;
  comment_plot("boldpolarplot");
  bold;
  draw_polarplot(r, t_min, t_max, num_pts);
  endbold;
  end_stanza();
}

/* Plotting one function in a family */
void
dashsliceplot1 (double f1(double, double), double f2(double, double), 
		double t_min, double t_max, double s0, int num_pts)
{
  dashed;
  comment_plot("dashsliceplot1");
  draw_sliceplot1(f1, f2, t_min, t_max, s0, num_pts);
  solid;
  end_stanza();
}
void
dashsliceplot2 (double f1(double, double), double f2(double, double), 
		double s_min, double s_max, double t0, int num_pts)
{
  dashed;
  comment_plot("dashsliceplot2");
  draw_sliceplot2(f1, f2, s_min, s_max, t0, num_pts);
  solid;
  end_stanza();
}
void
dotsliceplot1 (double f1(double, double), double f2(double, double), 
	       double t_min, double t_max, double s0, int num_pts)
{
  dotted;
  comment_plot("dotsliceplot1");
  draw_sliceplot1(f1, f2, t_min, t_max, s0, num_pts);
  solid;
  end_stanza();
}
void
dotsliceplot2 (double f1(double, double), double f2(double, double), 
	       double s_min, double s_max, double t0, int num_pts)
{
  dotted;
  comment_plot("dotsliceplot2");
  draw_sliceplot2(f1, f2, s_min, s_max, t0, num_pts);
  solid;
  end_stanza();
}
void
boldsliceplot1 (double f1(double, double), double f2(double, double), 
		double t_min, double t_max, double s0, int num_pts)
{
  solid;
  comment_plot("boldsliceplot1");
  bold;
  draw_sliceplot1(f1, f2, t_min, t_max, s0, num_pts);
  end_bold;
  end_stanza();
}
void
boldsliceplot2 (double f1(double, double), double f2(double, double), 
		double s_min, double s_max, double t0, int num_pts)
{
  solid;
  comment_plot("boldsliceplot2");
  bold;
  draw_sliceplot2(f1, f2, s_min, s_max, t0, num_pts);
  end_bold;
  end_stanza();
}

/* and several functions in a family */
void
dashmultiplot1 (double f1(double, double), double f2(double, double), 
		pair lowleft, pair upright, struct mesh netsize,
		int num_pts)
{
  dashed;
  draw_multiplot1 (f1, f2, lowleft, upright, netsize, num_pts);
  solid;
}
void
dashmultiplot2 (double f1(double, double), double f2(double, double), 
		pair lowleft, pair upright, struct mesh netsize,
		int num_pts)
{
  dashed;
  draw_multiplot2 (f1, f2, lowleft, upright, netsize, num_pts);
  solid;
}
void
dotmultiplot1 (double f1(double, double), double f2(double, double), 
	       pair lowleft, pair upright, struct mesh netsize,
	       int num_pts)
{
  dotted;
  draw_multiplot1 (f1, f2, lowleft, upright, netsize, num_pts);
  solid;
}
void
dotmultiplot2 (double f1(double, double), double f2(double, double), 
	       pair lowleft, pair upright, struct mesh netsize,
	       int num_pts)
{
  dotted;
  draw_multiplot2 (f1, f2, lowleft, upright, netsize, num_pts);
  solid;
}
void
boldmultiplot1 (double f1(double, double), double f2(double, double), 
		pair lowleft, pair upright, struct mesh netsize,
		int num_pts)
{
  bold;
  draw_multiplot1 (f1, f2, lowleft, upright, netsize, num_pts);
  end_bold;
}
void
boldmultiplot2 (double f1(double, double), double f2(double, double), 
		pair lowleft, pair upright, struct mesh netsize,
		int num_pts)
{
  bold;
  draw_multiplot2 (f1, f2, lowleft, upright, netsize, num_pts);
  end_bold;
}

/* Graph clipplots */
void
dashclipplot(double f(double), double t_min, double t_max, int num_pts)
{
  dashed;
  fprintf(stdout, "\n%%%% dashclipplot:");  
  draw_clipplot(id, f, zero, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
dotclipplot(double f(double), double t_min, double t_max, int num_pts)
{
  dotted;
  fprintf(stdout, "\n%%%% dotclipplot:");  
  draw_clipplot(id, f, zero, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
boldclipplot(double f(double), double t_min, double t_max, int num_pts)
{
  solid;
  fprintf(stdout, "\n%%%% boldclipplot:");  
  bold;
  draw_clipplot(id, f, zero, t_min, t_max, num_pts);
  endbold;
  end_stanza();
}

/* Plane parametric clipplots */
void
dashclipplot(double f1(double), double f2(double), 
	     double t_min, double t_max, int num_pts)
{
  dashed;
  fprintf(stdout, "\n%%%% dashclipplot:");  
  draw_clipplot(f1, f2, zero, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
dotclipplot(double f1(double), double f2(double), 
	    double t_min, double t_max, int num_pts)
{
  dotted;
  fprintf(stdout, "\n%%%% dotclipplot:");  
  draw_clipplot(f1, f2, zero, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
boldclipplot(double f1(double), double f2(double), 
	     double t_min, double t_max, int num_pts)
{
  solid;
  fprintf(stdout, "\n%%%% boldclipplot:");  
  bold;
  draw_clipplot(f1, f2, zero, t_min, t_max, num_pts);
  end_bold;
  end_stanza();
}

/* Space parametric clipplots */
void
dashclipplot(double f1(double), double f2(double), double f3(double),
	     double t_min, double t_max, int num_pts)
{
  dashed;
  fprintf(stdout, "\n%%%% dashclipplot3d:");  
  draw_clipplot(f1, f2, f3, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
dotclipplot(double f1(double), double f2(double), double f3(double),
	    double t_min, double t_max, int num_pts)
{
  dotted;
  fprintf(stdout, "\n%%%% dotclipplot3d:");  
  draw_clipplot(f1, f2, f3, t_min, t_max, num_pts);
  solid;
  end_stanza();
}
void
boldclipplot(double f1(double), double f2(double), double f3(double),
	     double t_min, double t_max, int num_pts)
{
  solid;
  fprintf(stdout, "\n%%%% boldclipplot3d:");  
  bold;
  draw_clipplot(f1, f2, f3, t_min, t_max, num_pts);
  end_bold;
  end_stanza();
}

/* Calculus plots */
/* derivatives */
void
dashplot_deriv(double f(double t), double a, double b, int num_pts)
{
  dashed;
  comment_plot("dashplot_deriv");
  draw_deriv(f, a, b, num_pts);
  solid;
  end_stanza();
}
void
dotplot_deriv(double f(double t), double a, double b, int num_pts)
{
  dotted;
  comment_plot("dotplot_deriv");
  draw_deriv(f, a, b, num_pts);
  solid;
  end_stanza();
}
void
boldplot_deriv(double f(double t), double a, double b, int num_pts)
{
  solid;
  comment_plot("boldplot_deriv");
  bold;
  draw_deriv(f, a, b, num_pts);
  endbold;
  end_stanza();
}

/* integrals */
/* arbitrary lower limit and plot bounds */
void
dashplot_int(double f(double), double x0, double a, double b, int num_pts)
{
  dashed;
  comment_plot("dashplot_int");
  draw_int(f, x0, a, b, num_pts);
  solid;
  end_stanza();
}
void
dotplot_int(double f(double), double x0, double a, double b, int num_pts)
{
  dotted;
  comment_plot("dotplot_int");
  draw_int(f, x0, a, b, num_pts);
  solid;
  end_stanza();
}
void
boldplot_int(double f(double), double x0, double a, double b, int num_pts)
{
  solid;
  comment_plot("plot_int");
  bold;
  draw_int(f, x0, a, b, num_pts);
  endbold;
  end_stanza();
}

/* lower limit is lower plot bound */
void
dashplot_int(double f(double), double a, double b, int num_pts)
{
  dashed;
  comment_plot("dashplot_int");
  draw_int(f, a, b, num_pts);
  solid;
  end_stanza();
}
void
dotplot_int(double f(double), double a, double b, int num_pts)
{
  dotted;
  comment_plot("dotplot_int");
  draw_int(f, a, b, num_pts);
  solid;
  end_stanza();
}
void
boldplot_int(double f(double), double a, double b, int num_pts)
{
  solid;
  comment_plot("plot_int");
  bold;
  draw_int(f, a, b, num_pts);
  endbold;
  end_stanza();
}

/* ODE plots */
void
dashode_plot(double f1(double, double), double f2(double, double),
	     pair start, double t_max, int num_pts)
{
  dashed;
  comment_plot("dashode_plot");
  draw_ode_plot(f1, f2, start, t_max, num_pts);
  solid;
  end_stanza();
}
void
dotode_plot(double f1(double, double), double f2(double, double),
	    pair start, double t_max, int num_pts)
{
  dotted;
  comment_plot("dotode_plot");
  draw_ode_plot(f1, f2, start, t_max, num_pts);
  solid;
  end_stanza();
}
void
boldode_plot(double f1(double, double), double f2(double, double),
	     pair start, double t_max, int num_pts)
{
  solid;
  comment_plot("boldode_plot");
  bold;
  draw_ode_plot(f1, f2, start, t_max, num_pts);
  endbold;
  end_stanza();
}

/* * * meshplots.cc * * */
/* wiremesh parametrized surfaces */
void dashwiremesh(double f1(double, double), double f2(double, double), 
		 double f3(double, double), pair p1, pair p2, mesh N,
		 mesh num_pts)
{
  dashed;
  fprintf (stdout, "\n%%%% dashwiremesh:");
  draw_wiremesh(f1, f2, f3, p1, p2, N, num_pts);
  solid;
  end_stanza();
} 
void dotwiremesh(double f1(double, double), double f2(double, double), 
		 double f3(double, double), pair p1, pair p2, mesh N,
		 mesh num_pts)
{
  dotted;
  fprintf (stdout, "\n%%%% dotwiremesh:");
  draw_wiremesh(f1, f2, f3, p1, p2, N, num_pts);
  solid;
  end_stanza();
} 
void boldwiremesh(double f1(double, double), double f2(double, double), 
		  double f3(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts)
{
  solid;
  fprintf (stdout, "\n%%%% boldwiremesh:");
  bold;
  draw_wiremesh(f1, f2, f3, p1, p2, N, num_pts);
  end_bold;
  end_stanza();
} 

/* wiremesh graphs */
void dashwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts)
{
  dashed;
  fprintf (stdout, "\n%%%% dashwiremesh:");
  draw_wiremesh(proj1, proj2, f, p1, p2, N, num_pts);
  solid;
  end_stanza();
} 
void dotwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		 mesh num_pts)
{
  dotted;
  fprintf (stdout, "\n%%%% dotwiremesh:");
  draw_wiremesh(proj1, proj2, f, p1, p2, N, num_pts);
  solid;
  end_stanza();
} 
void boldwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts)
{
  solid;
  fprintf (stdout, "\n%%%% boldwiremesh:");
  bold;
  draw_wiremesh(proj1, proj2, f, p1, p2, N, num_pts);
  end_bold;
  end_stanza();
} 

/* * * arcana.cc * * */
void 
dashplot_profile(double f(double), double a, double b, int num_pts)
{
  dashed;
  comment_plot("dashplot_profile");
  draw_profile(f, a, b, num_pts);
  solid;
  end_stanza();
}
void 
dotplot_profile(double f(double), double a, double b, int num_pts)
{
  dotted;
  comment_plot("dotplot_profile");
  draw_profile(f, a, b, num_pts);
  solid;
  end_stanza();
}
void 
boldplot_profile(double f(double), double a, double b, int num_pts)
{
  bold;
  solid;
  comment_plot("boldplot_profile");
  draw_profile(f, a, b, num_pts);
  endbold;
  end_stanza();
}
