/*
 * meshplots.h
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.9rc1
 * Last Change: January 30, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_MESH
#define _EPIX_MESH

#include <cstdlib>

#include "pairs.h"
#include "triples.h"

namespace ePiX {

  // meshplots.cc

  void 
    draw_wiremesh(double f1(double, double),
		  double f2(double, double),
		  double f3(double, double), pair, pair, mesh, mesh);

  // Parametric surfaces
  void wiremesh(double f1(double, double), double f2(double, double), 
		double f3(double, double), pair, pair, mesh, mesh);

  // Graphs of functions of two real variables
  void wiremesh(double f(double, double), pair, pair, mesh, mesh);
  
  // triple-valued plot argument
  void draw_wiremesh(triple Phi(double, double), pair, pair, mesh, mesh);
  void wiremesh     (triple Phi(double, double), pair, pair, mesh, mesh);

} /* end of namespace */

#endif /* _EPIX_MESH */
