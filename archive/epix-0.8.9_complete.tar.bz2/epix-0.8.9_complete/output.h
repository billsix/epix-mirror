/*
 * output.h -- ePiX file-formatting output routines
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.9rc5
 * Last Change: February 10, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_OUTPUT
#define _EPIX_OUTPUT

#include "globals.h"
#include "pairs.h"
#include "triples.h"
#include "lengths.h"

namespace ePiX {

  extern epix_path_style EPIX_PATH_STYLE;
  extern double epix_stretch_factor;

  // Sectioning Functions

  // Begin/end picture
  void begin(void);
  void end(void);
  
  // Print Cartesian pair in form (p.x1,p.x2)
  void print(pair);
  void print(triple);
  void raw_print(pair);

  void stretch(double);

  // set angle units
  void radians(void);
  void degrees(void);
  void revolutions(void);

  // Path style declarations
  void start_path(void);
  // (Un)fill closed path

  inline void fill(void)   { fprintf (stdout, "\\blacken"); }
  inline void unfill(void) { fprintf (stdout, "\\whiten"); }

  void epix_comment(char *);
  void end_stanza(void);
  void fatal_error(void);
  void output(void);
  void line_break(int, int);

  // Misc Styles and output formatting
  // Output styles
  void pen(char *);
  void pen(double);

  inline void bold(void)     { fprintf (stdout, "\n\\thicklines"); }
  inline void endbold(void)  { fprintf (stdout, "\n\\thinlines"); }
  inline void end_bold(void) { fprintf (stdout, "\n\\thinlines"); }
  inline void plain(void)    { fprintf (stdout, "\n\\thinlines"); }

  // set state variable
  inline void solid(void)  { EPIX_PATH_STYLE = SOLID; }
  inline void dashed(void) { EPIX_PATH_STYLE = DASHED; }
  inline void dotted(void) { EPIX_PATH_STYLE = DOTTED; }

  inline void dashed(double t) 
    { 
      EPIX_PATH_STYLE = DASHED; 
      epix_stretch_factor = t;
    }
  inline void dotted(double t) 
    { 
      EPIX_PATH_STYLE = DOTTED; 
      epix_stretch_factor = t;
    }

  /*
   * Color handling
   *
   * ePiX provides  "pstcol" style colors, which are declarations rather 
   * than delimited environments. To make part of an ePiX file print red 
   * (say), use one of the following:
   *
   *   red;
   *   <epix commands>
   *   end_red;
   *
   *   rgb(1,0,0);
   *   <epix commands>
   *   black;
   *
   * rgb and cmyk colors are specified (respectively) by 3 or 4 floats,
   * the densities of the corresponding primary colors. If these densities
   * are specified outside the unit interval [0,1], they will be truncated,
   * e.g., rgb(2, -1, 0.3) = rgb(1, 0, 0.3).
   */

  // red-green-blue
  void rgb(double r, double g, double b); 
  // cyan-magenta-yellow-black
  void cmyk(double c, double m, double y, double k);

  // primary colors

  inline void red(void)     { fprintf (stdout, "\n\\color[rgb]{1,0,0}"); }
  inline void green(void)   { fprintf (stdout, "\n\\color[rgb]{0,1,0}"); }
  inline void blue(void)    { fprintf (stdout, "\n\\color[rgb]{0,0,1}"); }
  inline void white(void)   { fprintf (stdout, "\n\\color[rgb]{1,1,1}"); }

  inline void cyan(void)    { fprintf (stdout, "\n\\color[cmyk]{1,0,0,0}"); }
  inline void magenta(void) { fprintf (stdout, "\n\\color[cmyk]{0,1,0,0}"); }
  inline void yellow(void)  { fprintf (stdout, "\n\\color[cmyk]{0,0,1,0}"); }
  inline void black(void)   { fprintf (stdout, "\n\\color[cmyk]{0,0,0,1}"); }

  /* 
   * depth of gray in shaded objects; argument is an integer from 0
   * (white) to 32 (black) 
   */
  void gray(double);

} /* end of namespace */

#endif /* _EPIX_OUTPUT */
