/*
 * arcana.h
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.9rc1
 * Last Change: January 30, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_ARCANA
#define _EPIX_ARCANA

#include <cstdlib>

#include "pairs.h"

namespace ePiX {

  // Implementation of the momentum construction
  void draw_profile (double f(double), double, double, int);
  void plot_profile (double f(double), double, double, int);
  void plot_profile (double f(double), double, double, double, int);

  // Plane linear transformations
  pair 
    transf (pair, pair, pair);

  pair 
    reflect (double, pair);

  // Image of the "standard F" under a linear transformation
  void 
    std_F (pair, pair);

  /*
   * fractal generation
   *
   * The basic "level-1" recursion unit is a piecewise-linear path whose 
   * segments are parallel to spokes on a wheel, labelled modulo <spokes>.
   * Recursively up to <depth>, each segment is replaced by a copy of the
   * recursion unit.
   *
   * Sample data for _/\_ standard Koch snowflake:
   * const int pre_seed[] = {6, 4, 0, 1, -1, 0};
   * pre_seed[0] = spokes, pre_seed[1] = seed_length;
   */

  void 
    fractal (pair p, pair q, int depth, const int *pre_seed);

} /* end of namespace */

#endif /* _EPIX_ARCANA */
