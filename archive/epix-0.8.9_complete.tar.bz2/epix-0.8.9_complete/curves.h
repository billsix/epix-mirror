/*
 * curves.h -- Ellipses, arcs, splines
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.9rc1
 * Last Change: January 30, 2003
 *
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_CURVES
#define _EPIX_CURVES

#include "pairs.h"

namespace ePiX {

  // Ellipses, half-ellipses, circular arcs, splines -- curves.c

  // Point-plotting functions
  void draw_half_ellipse (pair, pair);

  // Stanza-creating whole ellipse functions
  void draw_ellipse (pair, pair); 
  void ellipse (pair, pair);

  // Stanza-creating standard half-ellipse functions
  void draw_half_ellipse(pair, pair, double);
  void ellipse_left (pair, pair);
  void ellipse_right (pair, pair);
  void ellipse_top (pair, pair);
  void ellipse_bottom (pair, pair);

  // Right half ellipse rotated through <double> revolutions
  void rotate_half_ellipse(pair, pair, double);
  void ellipse_half (pair, pair, double);

  // Circular arcs
  void draw_proper_arc (pair, double, double, double);
  void draw_arc (pair, double, double, double);

  void arc (pair, double, double, double);

  void draw_arc_arrow (pair, double, double, double);
  void arc_arrow (pair, double, double, double);

  // Splines
  void draw_spline (pair, pair, pair);
  void draw_spline (pair, pair, pair, pair);

  // Quadratc
  void spline (pair, pair, pair);

  // Cubic
  void spline (pair, pair, pair, pair);

  // Knot diagram primitives
  void draw_under_strand(pair p3, pair p6, pair p5, pair p2);
  void draw_p_twist(pair p1, pair p4);
  void draw_n_twist(pair p1, pair p4);

  void p_twist (pair, pair);
  void n_twist (pair, pair);
  void twists (pair, pair, int);

} /* end of namespace */

#endif /* _EPIX_CURVES */
