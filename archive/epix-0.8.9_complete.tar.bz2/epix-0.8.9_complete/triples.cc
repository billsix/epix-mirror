/* 
 * triples.cc -- Ordered triples and operations
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.9rc1
 * Last Change: January 30, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include "triples.h"
#include "pairs.h"

namespace ePiX {

  extern double viewpt1, viewpt2, viewpt3;

  /* Member functions */

  // constructor
  triple::triple(double init1, double init2, double init3)
  {
    x1 = init1;
    x2 = init2;
    x3 = init3;
  }

  // copy
  triple::triple(const triple& old)
  {
    x1 = old.x1;
    x2 = old.x2;
    x3 = old.x3;
  }

  // increment operators
  triple& triple::operator += (const triple& oper)
  {
    x1 += oper.x1;
    x2 += oper.x2;
    x3 += oper.x3;
  
    return (*this);
  }

  triple& triple::operator -= (const triple& oper)
  {
    x1 -= oper.x1;
    x2 -= oper.x2;
    x3 -= oper.x3;
  
    return (*this);
  }

  triple& triple::operator *= (const double& c)
  {
    x1 *= c;
    x2 *= c;
    x3 *= c;
  
    return (*this);
  }

  // triple creation

  triple P(double x1, double x2, double x3)
  {
    return triple(x1, x2, x3);
  } 

  // triple projection
  pair V(triple init)
  {
    return V(init.x1, init.x2, init.x3);
  }

  // equality
  int operator == (const triple& u, const triple& v)
  {
    return ((u.x1 == v.x1) && (u.x2 == v.x2) && (u.x3 == v.x3) );
  }

  // negation
  triple operator - (const triple& u)
  {
    return P(-u.x1, -u.x2, -u.x3);
  }
  
  // addition
  triple operator + (const triple& u, const triple& v)
  {
    return P(u.x1 + v.x1, u.x2 + v.x2, u.x3 + v.x3);
  }

  triple operator - (const triple& u, const triple& v)
  {
    return P(u.x1 - v.x1, u.x2 - v.x2, u.x3 - v.x3);
  }

  // cross product
  triple operator * (const triple& u, const triple& v)
  {
    return P(u.x2 * v.x3 - u.x3 * v.x2,
	     u.x3 * v.x1 - u.x1 * v.x3,
	     u.x1 * v.x2 - u.x2 * v.x1);
  }

  // scalar multiplication
  triple operator * (const double& c, const triple& v)
  {
    return P(c*(v.x1), c*(v.x2), c*(v.x3));
  }

  // dot product
  double operator | (const triple& u, const triple& v)
  {
    return u.x1*v.x1 + u.x2*v.x2 + u.x3*v.x3;
  }

  // componentwise product (a,b,c)&(x,y,z)=(ax,by,cz)
  triple operator & (const triple& u, const triple& v)
  {
    return P(u.x1*v.x1, u.x2*v.x2, u.x3*v.x3);
  }

} /* end of namespace */
