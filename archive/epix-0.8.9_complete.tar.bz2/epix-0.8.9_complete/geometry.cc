/* 
 * geometry.cc -- spherical and hyperbolic geometry
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.9rc5
 * Last Change: February 10, 2003
 */

/* 
 * Copyright (C) 2001, 2002  
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <math.h>

#include "pairs.h"
#include "triples.h"
#include "curves.h"
#include "plots.h"
#include "geometry.h"

namespace ePiX {

  extern int epix_lines_printed;
  extern epix_path_style EPIX_PATH_STYLE;

  extern double viewpt1, viewpt2, viewpt3;

  static triple camera;

  // Flag for type of projection to the sphere
  enum sphere_proj_type {RADIAL, STEREO_N, STEREO_S};

  // the zero function
  static double 
  zero (double t)
  {
    return 0;
  }

  static double 
  arc_scale(double r)
  {
    pair temp = c2s(P(r,r));
    // Approx. number of true pts per radian
    return 0.5*p2t(temp.x1 + temp.x2);
  }

  // Spherical geometry

  /*
   * radial_proj
   *
   * Given functions f1, f2, f3 and time t, radially project the point
   * (f1(t), f2(t), f3(t)) to the unit sphere (no check for passing
   * through origin...)
   */
  static triple
  proj_to_sphere(double f1(double t), double f2(double t), double f3(double t),
		 double t, const int sphere_proj_type)
  {
    double c1 = f1(t);
    double c2 = f2(t);
    double c3 = f3(t);
    if (sphere_proj_type == RADIAL)
      return (1/sqrt(c1*c1+c2*c2+c3*c3))*P(c1, c2, c3);

    else if (sphere_proj_type == STEREO_N && c3 == 0)
      return (1/(c1*c1+c2*c2+1))*P(2*c1, 2*c2,  c1*c1+c2*c2-1);

    else if (sphere_proj_type == STEREO_S && c3 == 0)
      return (1/(c1*c1+c2*c2+1))*P(2*c1, 2*c2, -c1*c1-c2*c2+1);

    else // Return origin on erroneous projection type (should never occur)
      return P(0,0,0);
  }

  // triple-valued function argument
  static triple
  proj_to_sphere(triple phi(double), double t, const int sphere_proj_type)
  {
    if (sphere_proj_type == RADIAL)
      return (1/raw_len(phi(t)))*phi(t);

    else // Return origin on erroneous projection type
      return P(0,0,0);
  }

  /*
   * seek_horizon
   *
   * Approximates point where projection of a path to the unit sphere
   * disappears over the horizon (a.k.a. the great circle orthogonal to the
   * viewpt).
   * Algorithm: Start at point known to be visible, take small steps
   * towards outside point, stop when point disappears.
   */
  static triple 
  seek_horizon(double f1(double), double f2(double), double f3(double),
	       double t, double step, int hidden, const int sphere_proj_type)
  {
    triple temp = proj_to_sphere(f1, f2, f3, t, sphere_proj_type);
    camera = P(viewpt1, viewpt2, viewpt3);

    while (hidden*(temp|camera) >= 0)
      {
	t += (EPIX_SEEK_SIZE)*step; 
	temp = proj_to_sphere(f1, f2, f3, t, sphere_proj_type);
      }

    return temp;
  }

  // triple-valued function argument
  static triple 
  seek_horizon(triple phi(double), double t, double step, int hidden, 
	       const int sphere_proj_type)
  {
    triple temp = proj_to_sphere(phi, t, sphere_proj_type);
    camera = P(viewpt1, viewpt2, viewpt3);

    while (hidden*(temp|camera) >= 0)
      {
	t += (EPIX_SEEK_SIZE)*step; 
	temp = proj_to_sphere(phi, t, sphere_proj_type);
      }

    return temp;
  }

  /*
   * draw_sphereplot (a thinly-disguised clipplot:) plots a curve by
   * keeping track of the state (front/back of sphere) of pairs of
   * adjacent points. The parameter hidden determines what portion of
   * the path is shown: 1 -> front, 0 -> all, -1 -> back.
   * 
   * (back, front)  --> Start new path segment (seek back to find edge)
   * (front, front)   --> Continue existing path
   * (front, back)  --> End current path segment (seek forward to find edge)
   * (back, back) --> Print nothing, test next point
   * 
   */

  static void
  draw_sphereplot(double f1(double), double f2(double), double f3(double),
		  double t_min, double t_max, int num_pts, int hidden,
		  const int sphere_proj_type)
  {
    triple curr_point, prev_point;
    int curr_flag=0, prev_flag=0; // Visibility flags

    int pt_count=0; // Points printed in path segment, to format output
    int pr_flag=0; // Whether any points have been printed
    double t = 0;
    const double step = (t_max - t_min)/num_pts;
  
    camera = P(viewpt1, viewpt2, viewpt3);
 
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*step;
	curr_point = proj_to_sphere(f1, f2, f3, t, sphere_proj_type);

	if (hidden*(curr_point|camera) >= 0) // visibility test
	  curr_flag=1;
	else
	  curr_flag=0;
      
	// Four cases: Previous is in/out, current is in/out.
      
	// Start new path component
	if (curr_flag == 1 && prev_flag == 0)
	  {
	    if (t == t_min) // print first point
	      {
		start_path();
		print(curr_point);
		pt_count = 1;
	      }
	    else // print 2 points: seek-back and current
	      {
		if (pr_flag == 0)
		  start_path();

		else
		  {
		    fprintf(stdout, "\n%%%%"); // New sub-stanza
		    start_path();
		  }

		// Seek back to edge of bounding box
		print(seek_horizon(f1, f2, f3, t, -step, 
				   hidden, sphere_proj_type));
		print(curr_point);
		pt_count=2;
	      }
	    pr_flag=1;
	    prev_flag=1;
	    prev_point=curr_point;
	  }
      
	// Continue path
	else if (curr_flag == 1 && prev_flag == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(curr_point);
	    prev_flag=1;
	    prev_point=curr_point;
	  
	    ++pt_count;
	  }
      
	// End current path
	else if (curr_flag == 0 && prev_flag == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    /* 
	     * Hardwired constant (0.01): Skip back 1+e path steps, then
	     * seek forward. Acceptably handles the case in which
	     * previous + seek_step is outside the bounding box.
	     */
	    print(seek_horizon(f1, f2, f3, t - (1+(0.01)*EPIX_SEEK_SIZE)*step, 
			       step, hidden, sphere_proj_type));
	    prev_flag=0;
	    prev_point=curr_point;
	    pt_count=0;
	  }
      
	// (curr_flag == 0 && prev_flag == 0), keep searching...
	else 
	  {
	    prev_flag=0;
	    prev_point=curr_point;
	  }
      }
  }

  // Radial projection from origin to the unit sphere
  void
  plot_R(double f1(double), double f2(double), double f3(double), 
	 double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% plot_R:");  
    draw_sphereplot(f1, f2, f3, t_min, t_max, num_pts, 0, RADIAL);
    end_stanza();
  }
  void
  frontplot_R(double f1(double), double f2(double), double f3(double), 
	      double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% frontplot_R:");  
    draw_sphereplot(f1, f2, f3, t_min, t_max, num_pts, 1, RADIAL);
    end_stanza();
  }
  void
  backplot_R(double f1(double), double f2(double), double f3(double), 
	     double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% backplot_R:");  
    draw_sphereplot(f1, f2, f3, t_min, t_max, num_pts, -1, RADIAL);
    end_stanza();
  }

  // Stereographic projection from north pole...
  void
  plot_N(double f1(double), double f2(double),
	 double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% plot_N:");  
    draw_sphereplot(f1, f2, zero, t_min, t_max, num_pts, 0, STEREO_N);
    end_stanza();
  }
  void
  frontplot_N(double f1(double), double f2(double),
	      double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% frontplot_N:");  
    draw_sphereplot(f1, f2, zero, t_min, t_max, num_pts, 1, STEREO_N);
    end_stanza();
  }
  void
  backplot_N(double f1(double), double f2(double),
	     double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% backplot_N:");  
    draw_sphereplot(f1, f2, zero, t_min, t_max, num_pts, -1, STEREO_N);
    end_stanza();
  }

  // and south pole
  void
  plot_S(double f1(double), double f2(double),
	 double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% plot_S:");  
    draw_sphereplot(f1, f2, zero, t_min, t_max, num_pts, 0, STEREO_S);
    end_stanza();
  }
  void
  frontplot_S(double f1(double), double f2(double),
	      double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% frontplot_S:");  
    draw_sphereplot(f1, f2, zero, t_min, t_max, num_pts, 1, STEREO_S);
    end_stanza();
  }
  void
  backplot_S(double f1(double), double f2(double),
	     double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% backplot_S:");  
    draw_sphereplot(f1, f2, zero, t_min, t_max, num_pts, -1, STEREO_S);
    end_stanza();
  }

  // pair- and triple-valued plot argument
  static void
  draw_sphereplot(triple Phi(double), double t_min, double t_max, 
		  int num_pts, int hidden, const int sphere_proj_type)
  {
    triple curr_point, prev_point;
    int curr_flag=0, prev_flag=0; // Visibility flags

    int pt_count=0; // Points printed in path segment, to format output
    int pr_flag=0; // Whether any points have been printed
    double t = 0;
    const double step = (t_max - t_min)/num_pts;
  
    camera = P(viewpt1, viewpt2, viewpt3);
 
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*step;
	curr_point = proj_to_sphere(Phi, t, sphere_proj_type);

	if (hidden*(curr_point|camera) >= 0) // visibility test
	  curr_flag=1;
	else
	  curr_flag=0;
      
	// Four cases: Previous is in/out, current is in/out.
      
	// Start new path component
	if (curr_flag == 1 && prev_flag == 0)
	  {
	    if (t == t_min) // print first point
	      {
		start_path();
		print(curr_point);
		pt_count = 1;
	      }
	    else // print 2 points: seek-back and current
	      {
		if (pr_flag == 0)
		  start_path();

		else
		  {
		    fprintf(stdout, "\n%%%%"); // New sub-stanza
		    start_path();
		  }

		// Seek back to edge of bounding box
		print(seek_horizon(Phi, t, -step, hidden, sphere_proj_type));
		print(curr_point);
		pt_count=2;
	      }
	    pr_flag=1;
	    prev_flag=1;
	    prev_point=curr_point;
	  }
      
	// Continue path
	else if (curr_flag == 1 && prev_flag == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(curr_point);
	    prev_flag=1;
	    prev_point=curr_point;
	  
	    ++pt_count;
	  }
      
	// End current path
	else if (curr_flag == 0 && prev_flag == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    /* 
	     * Hardwired constant (0.01): Skip back 1+e path steps, then
	     * seek forward. Acceptably handles the case in which
	     * previous + seek_step is outside the bounding box.
	     */
	    print(seek_horizon(Phi, t - (1+(0.01)*EPIX_SEEK_SIZE)*step, 
			       step, hidden, sphere_proj_type));
	    prev_flag=0;
	    prev_point=curr_point;
	    pt_count=0;
	  }
      
	// (curr_flag == 0 && prev_flag == 0), keep searching...
	else 
	  {
	    prev_flag=0;
	    prev_point=curr_point;
	  }
      }
  }

  // Radial projection from origin to the unit sphere
  void
  plot_R(triple phi(double), double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% plot_R:");  
    draw_sphereplot(phi, t_min, t_max, num_pts, 0, RADIAL);
    end_stanza();
  }
  void
  frontplot_R(triple phi(double), double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% frontplot_R:");  
    draw_sphereplot(phi, t_min, t_max, num_pts, 1, RADIAL);
    end_stanza();
  }
  void
  backplot_R(triple phi(double), double t_min, double t_max, int num_pts)
  {
    fprintf(stdout, "\n%%%% backplot_R:");  
    draw_sphereplot(phi, t_min, t_max, num_pts, -1, RADIAL);
    end_stanza();
  }

  // Hyperbolic geometry
  
  // Hyperbolic lines in upper half plane

  void 
  draw_hyperbolic_line(pair tail, pair head)
  {
    double x;
    pair jump = head - tail;
    pair current;
    double a = tail.x1, b = tail.x2, c = head.x1, d = head.x2;
    int i, n;

    if (tail.x2 < 0 || head.x2 < 0)
      fprintf(stdout, "\n%%%% Error: Point(s) not in upper half-plane");

    // Position of center of circle is numerically unstable near a=c.
    else if ( truncate(fabs(jump.x1)) == 0 ) {

      n = (int) ceil(p2t(M_PI*fabs( c2p(jump).x2 )/20)); // ad hoc scale factor
      //v_scale(M_PI*fabs(d - b))/20.0));
      if (n < 1)
	n=1; // print at least 2 points

      start_path();
      for (i=0; i <= n; ++i) 
	{
	  current = tail + i*(1.0/n)*(pair(1,0)&jump);
	  print(current);
	  line_break(i, n);
	}
    }    

    else {
      x = (0.5)*(hypot(c, d) - hypot(a, b))/(c-a); // center of circle

      draw_arc(P(x,0), hypot(c-x, d), 
	       atan2(d, c-x), atan2(b, a-x));
    }
  }

  void 
  hyperbolic_line(pair tail, pair head)
  {
    epix_comment("hyperbolic line in the upper half plane");
    draw_hyperbolic_line(tail, head);
    end_stanza();
  }

  /* 
   * Lines in Poincare disk model.
   *
   * Consider the "positive" portion of the standard hyperboloid of two 
   * sheets: x^2 + y^2 + 1 = z^2, z>0, and consider copies of the unit
   * disk in the planes z=0 (D0) and z=1 (D1). The Klein model of the disk
   * is gotten by stereographic projection from the origin to D1, while the
   * Poincare model is gotten by stereographic projection from (0,0,-1) to
   * D0. Appropriate compositions of these projection maps are hyperbolic
   * isometries. The algorithm for drawing lines in the disk model is to
   * find the images of the endpoints in the Klein model, draw the line
   * between them, and map this line back to the Poincare model. Because
   * the isometry is "square-root-like" in the radial direction at the
   * unit circle, the points on the Klein line are spaced quadratically
   * close together at the endpoints of the segment (the variable "s") so
   * their images will be roughly equally-spaced in the Poincare model.
   * There is no visual harm if one or both endpoints are far from the
   * circle, and the result is acceptable if both points are on or near the
   * circle. The number of points to draw is determined both by the true
   * distance between the endpoints and by how close they are to the circle.
   */
  static pair poincare_klein(pair p)
  {
    double denom=1+pow(raw_len(p),2); // p=(u,v), denom = 1 + |p|^2
    p *= (2.0/denom);
    return p;
  }
  static pair klein_poincare(pair p)
  {
    double denom=1+sqrt(1-pow(raw_len(p),2)); // 1 + sqrt(1 - |p|^2)
    p *= (1.0/denom);
    return p;
  }

  void 
  draw_disk_line(pair tail, pair head)
  {
    int i;
    double n; // 2 <= n+1 = number of points on curve
    pair current;

    // Euclidean length between endpoints
    double length = raw_len(head - tail);

    // Roughly twice number of true points between head and tail
    double length_scale = 2*arc_scale(length);

    // Draw more points if head and/or tail are close to unit circle
    double length_weight = (1 + raw_len(head) + raw_len(tail));

    if (1 < raw_len(tail) || 1 < raw_len(head))
      fprintf(stdout, "\n%%%% Error: One or both points not in unit disk");

    // Roughly prop. to true length, weighted by closeness to boundary
    n = ceil(0.1*length_weight*length_scale);

    start_path();
    for (i=0; i <= (int) n; ++i) 
      {
	// Space points quadratically closely near endpoints
	double s = 0.5*(1+std::cos(M_PI*i/n)); // s in [0,1]
	
	current = (s*poincare_klein(tail)) + ((1-s)*poincare_klein(head));
	print(klein_poincare(current));
	
	line_break(i, (int) n);
      }
  }

  void 
  disk_line(pair tail, pair head)
  {
    epix_comment("hyperbolic line in the unit disk");
    draw_disk_line(tail, head);
    end_stanza();
  }

} /* end of namespace */

