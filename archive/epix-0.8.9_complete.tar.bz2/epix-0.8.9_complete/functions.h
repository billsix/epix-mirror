/*
 * functions.h
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.9rc5
 * Last Change: February 10, 2003
 *
 */

#ifndef _EPIX_FUNCTIONS
#define _EPIX_FUNCTIONS

#include <cmath>

namespace ePiX {

  // ePiX:: trig functions are sensitive to angle units
  double cos(double theta);
  double sin(double theta);
  double tan(double theta); 

  // non-mathematical behavior (i.e. vanishing:) at poles
  double sec(double theta);
  double csc(double theta);
  double cot(double theta);

  // and inverses
  double acos(double arg);
  double asin(double arg);
  double atan(double arg);

  // identity function for angle units
  double angle(double);

  double id (double);

  double proj1 (double, double);
  double proj2 (double, double);

  // utility functions with discontinuities removed
  double sinx (double);
  double sgn (double);
  double recip (double);

  // period-2 extension of absolute value on [-1,1]: \/\/\/
  double cb (double);

  int gcd (int, int);
  double inf (double f(double), double, double);
  double sup (double f(double), double, double);

} /* end of namespace */

#endif /* _EPIX_FUNCTIONS */
