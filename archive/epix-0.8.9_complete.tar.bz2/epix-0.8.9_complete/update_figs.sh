#!/bin/bash
#
# update_figs.sh -- converts ePiX input files for versions 0.8.5--0.8.8 
#   to v0.8.9 syntax.
#
# August 19, 2001, Andrew D. Hwang   ahwang@mathcs.holycross.edu
#
# July 5, 2002: v0.8.5 -- strips "()" from bold and color declarations
#   Potentially modified files are archived or saved with ".old" extension
# July 12: v0.8.5a -- Re-written to fix bug with Solaris' "sed"
#
# February 6, 2003: Reverse changes made in v0.8.5 to avoid (present and
#   potential) conflict with gcc-3.2 STL
#

TARBALL=update_figs.tar.gz

# Conversion function
epix_update() {
    mv -i $1 $1.old
    # the bold line handles endbold and end_bold; fill handles unfill
    sed 's/bold;/bold();/g' $1.old | \
    sed 's/plain;/plain();/g' | \
    sed 's/fill;/fill();/g' | \
    sed 's/solid;/solid();/g' | \
    sed 's/dashed;/dashed();/g' | \
    sed 's/dotted;/dotted();/g' | \
    sed 's/white;/white();/g' | \
    sed 's/black;/black();/g' | \
    sed 's/red;/red();/g' | \
    sed 's/green;/green();/g' | \
    sed 's/blue;/blue();/g' | \
    sed 's/cyan;/cyan();/g' | \
    sed 's/magenta;/magenta();/g' | \
    sed 's/yellow;/yellow();/g' > $1
}

if [ $# -gt 0 ]; then # process files on the command line
    echo "Processing"
    for file in $@
    do
	echo "$file"
	epix_update $file
    done 

    echo "done"

    exit 0

else # no files specified; process all .xp, .c, .cc, and .C files

    echo "This operation is potentially destructive."
    echo -n "Create backup? [yes/no/quit] "
    read ANSWER

    while [ "$ANSWER" != "yes" -a "$ANSWER" != "no" -a "$ANSWER" != "quit" ]
    do
	echo -n "Please answer yes, no, or quit: "
	read ANSWER
    done

    echo

    case "$ANSWER" in

	quit)
	echo "Operation cancelled"
	exit 0
	;;

	no)
	echo "No backup created -- original files have \".old\" suffix"
	echo "Running this script again may delete these files."
	;;

	yes)
	if [ ! -f $TARBALL ]; then
	    tar -cf - *.xp *.c *.cc *.C 2> /dev/null | gzip -9 > $TARBALL
	    echo "All \".xp\", \".c\", \".cc\", \".C\" files saved to $TARBALL"
	else
	    echo "$TARBALL exists; please (re)move and run this script again"
	    exit 1;
	fi
	;;

	*)
	echo "Internal error -- perhaps I've been tampered...?"
	exit 1
	;;
    esac

    echo "Processing "
    for file in $(ls *.xp *.c *.cc *.C 2> /dev/null)
    do
	epix_update $file

	if [ "$ANSWER" = "yes" ]; then
	rm -f $file.old
	fi
    done 

    echo "done"
    
    exit 0
fi
