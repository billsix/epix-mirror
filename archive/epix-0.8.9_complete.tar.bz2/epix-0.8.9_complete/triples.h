/* 
 * triples.h -- ePiX triple:: class and mathematical operators
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.9rc5
 * Last Change: February 10, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_TRIPLES
#define _EPIX_TRIPLES

#include "pairs.h"
#include "functions.h"

namespace ePiX {

  class triple 
    {
    public:
      double x1;
      double x2;
      double x3;

      // void constructor
      triple(void) {}

      // Cartesian constructor
      triple(double x1, double x2, double x3);

      // copy
      triple(const triple& old);

      // destructor
      ~triple() {}

      // increment operators
      triple& operator += (const triple&);
      triple& operator -= (const triple&);
      triple& operator *= (const double&);

      // complex multiplication and division
      triple& operator *= (const triple&);
      triple& operator /= (const triple&);
    }; /* end of class */

  /* triple creation */
  triple P(double, double, double); 

  // spherical constructor
  inline triple sph(double r, double t, double phi) 
    {
      return P(r*(ePiX::cos(t))*(ePiX::cos(phi)), 
	       r*(ePiX::sin(t))*(ePiX::cos(phi)), 
	       r*(ePiX::sin(phi)));
    }

  const triple E_1 = P(1,0,0);
  const triple E_2 = P(0,1,0);
  const triple E_3 = P(0,0,1);

  pair V(triple); // Project <triple> according to current viewpoint

  int  operator == (const triple&, const triple&);
  triple operator - (const triple&);
  triple operator + (const triple&, const triple&);
  triple operator - (const triple&, const triple&);

  // cross product
  triple operator * (const triple&, const triple&);

  // scalar multiplication
  triple operator * (const double&, const triple&);

  // dot product
  double operator |(const triple&, const triple&);
  // componentwise product (a,b,c)&(x,y,z) = (ax,by,cz)
  triple operator &(const triple&, const triple&);

} /* end of namespace */

#endif /* _EPIX_TRIPLES */
