/*
 * geometry.h 
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.9rc1
 * Last Change: January 30, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#ifndef _EPIX_GEOMETRY
#define _EPIX_GEOMETRY

#include <cstdlib>

#include "pairs.h"
#include "triples.h"

namespace ePiX {

  // Radial projection from origin to unit sphere
  void plot_R      (double f1(double), double f2(double), double f3(double), 
		    double t_min, double t_max, int num_pts);
  void frontplot_R (double f1(double), double f2(double), double f3(double), 
		    double t_min, double t_max, int num_pts);
  void backplot_R  (double f1(double), double f2(double), double f3(double), 
		    double t_min, double t_max, int num_pts);

  // triple-valued plot argument
  void plot_R      (triple phi(double), 
		    double t_min, double t_max, int num_pts);
  void frontplot_R (triple phi(double), 
		    double t_min, double t_max, int num_pts);
  void backplot_R  (triple phi(double), 
		    double t_min, double t_max, int num_pts);

  // Stereographic projection from the north pole...
  void plot_N      (double f1(double), double f2(double),
		    double t_min, double t_max, int num_pts);
  void frontplot_N (double f1(double), double f2(double),
		    double t_min, double t_max, int num_pts);
  void backplot_N  (double f1(double), double f2(double),
		    double t_min, double t_max, int num_pts);

  // and the south
  void plot_S      (double f1(double), double f2(double),
		    double t_min, double t_max, int num_pts);
  void frontplot_S (double f1(double), double f2(double),
		    double t_min, double t_max, int num_pts);
  void backplot_S  (double f1(double), double f2(double),
		    double t_min, double t_max, int num_pts);

  // Hyperbolic lines
  void draw_hyperbolic_line (pair, pair);
  void hyperbolic_line (pair, pair);

  void draw_disk_line (pair, pair);
  void disk_line (pair, pair);

} /* end of namespace */

#endif /* _EPIX_GEOMETRY */
