/* 
 * plots.cc: Plots of user-defined functions
 *
 * Includes plane and space curves, polar plots, plotting data from files,
 * derivatives and integrals, solutions and time slices of ODEs, plane meshes.
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.9rc5
 * Last Change: February 10, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <math.h>

#include "globals.h"
#include "plots.h"
#include "output.h"
#include "objects.h"

namespace ePiX {

  extern epix_path_style EPIX_PATH_STYLE;

  static int bold_flag; // kludge to fill arrowheads in boldvector_field

  // the zero function
  static double 
  zero (double t)
  {
    return 0;
  }

  // Functions for adaptive plotting
  
  // Classical Newtonian increment
  static inline double delta(double f(double), double t, double dt)
    {
      return f(t + dt) - f(t);
    }

  static double arclength(double f1(double), double f2(double),
			  double t_min, double t_max, int n)
  {
    double sum = 0;
    double dt = (t_max - t_min)/(n*EPIX_ITERATIONS);

    for (int i=0; i < n*EPIX_ITERATIONS; ++i)
      sum += hypot(delta(f1, t_min + i*dt, dt), delta(f2, t_min + i*dt, dt));

    return sum;
  }

  static inline pair 
  plot_pt(double f1(double), double f2(double), double t)
  {
    return pair(f1(t), f2(t));
  }

  // pair-valued plot argument
  static inline double length_elt(pair f(double), double t, double dt)
  {
    return raw_len(f(t + dt) - f(t));
  }

  static double arclength(pair f(double), double t_min, double t_max, int n)
  {
    double sum = 0;
    double dt = (t_max - t_min)/(n*EPIX_ITERATIONS);

    for (int i=0; i < n*EPIX_ITERATIONS; ++i)
      sum += length_elt(f, t_min + i*dt, dt);

    return sum;
  }

  // Adaptive plotting
  void
  draw_adapt_plot(double f1(double), double f2(double),
		  double t_min, double t_max, int n)
  {
    double sum = 0;
    int pt_count = 0;
    const double dt = (t_max - t_min)/(n*EPIX_ITERATIONS);
    double step = (1.0/n)*arclength(f1, f2, t_min, t_max, n);
    int step_count = 0;

    start_path(); // pt_count already = 1
    print(plot_pt(f1, f2, t_min));

    for (int i=0; i <= n*EPIX_ITERATIONS; ++i)
      {
	sum += hypot(delta(f1, t_min + i*dt, dt), delta(f2, t_min + i*dt, dt));
	++step_count;

	if (step <= sum || EPIX_ITERATIONS <= step_count) 
	  {
	    line_break(pt_count++, n*EPIX_ITERATIONS);
	    print(plot_pt(f1, f2, t_min + i*dt));

	    sum -= step;
	    step_count = 0;
	  }
      }
  }
	
  void
  adplot(double f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("adaptive plot");
    draw_adapt_plot(id, f, t_min, t_max, num_pts);
    end_stanza();
  }
  void
  adplot(double f1(double), double f2(double), 
	 double t_min, double t_max, int num_pts)
  {
    epix_comment("adaptive parametric plot");
    draw_adapt_plot(f1, f2, t_min, t_max, num_pts);
    end_stanza();
  }

  // for pair-valued plot argument
  void
  draw_adapt_plot(pair f(double), double t_min, double t_max, int n)
  {
    double sum = 0;
    int pt_count = 0;
    const double dt = (t_max - t_min)/(n*EPIX_ITERATIONS);
    double step = (1.0/n)*arclength(f, t_min, t_max, n);
    int step_count = 0;
    double time;

    start_path(); // pt_count already = 1
    print(f(t_min));

    for (int i=0; i <= n*EPIX_ITERATIONS; ++i)
      {
	time = t_min + i*dt;
	sum += length_elt(f, time, dt);
	++step_count;

	if (step <= sum || EPIX_ITERATIONS <= step_count) 
	  {
	    line_break(pt_count++, n*EPIX_ITERATIONS);
	    print(f(time));

	    sum -= step;
	    step_count = 0;
	  }
      }
  }
	
  void
  adplot(pair f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("adaptive parametric plot");
    draw_adapt_plot(f, t_min, t_max, num_pts);
    end_stanza();
  }

  // Ordinary graph plotting
  void
  draw_plot(double f(double), double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(plot_pt(id, f, t));

	line_break(i, num_pts);
      }
  }

  void
  plot(double f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("graph plot");
    draw_plot(f, t_min, t_max, num_pts);
    end_stanza();
  }

  // Planar parametric plotting
  void
  draw_plot(double f1(double), double f2(double),
	    double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;
    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(plot_pt(f1, f2, t));

	line_break(i, num_pts);
      }
  }
  void
  plot(double f1(double), double f2(double), 
       double t_min, double t_max, int num_pts)
  {
    epix_comment("parametric plane curve");
    draw_plot(f1, f2, t_min, t_max, num_pts);
    end_stanza();
  }

  void
  draw_plot(pair f(double), double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(f(t));

	line_break(i, num_pts);
      }
  }
  void
  plot(pair f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("parametric plane curve");
    draw_plot(f, t_min, t_max, num_pts);
    end_stanza();
  }

  // Space curve plotting
  void
  draw_plot(double f1(double), double u2(double), double f3(double),
	    double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(V(f1(t), u2(t), f3(t)));

	line_break(i, num_pts);
      }
  }

  void
  plot(double f1(double), double f2(double), double f3(double),
       double t_min, double t_max, int num_pts)
  {
    epix_comment("parametric space curve");
    draw_plot(f1, f2, f3, t_min, t_max, num_pts);
    end_stanza();
  }

  // triple plot argument
  void
  draw_plot(triple f(double), double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(f(t));
      
	line_break(i, num_pts);
      }
  }
    
  void
  plot(triple f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("parametric space curve");
    draw_plot(f, t_min, t_max, num_pts);
    end_stanza();
  }

  // project a space curve to a plane through the origin
  void
  draw_shadowplot(double f1(double), double f2(double), double f3(double), 
		  triple normal, double t_min, double t_max, int num_pts)
  {
    triple unit_normal;
    if (raw_len(normal) != 0)
      unit_normal = (1/raw_len(normal))*normal;
    double t;
    const double dt = (t_max - t_min)/num_pts;
    triple curr_pt;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	curr_pt = P(f1(t), f2(t), f3(t));
	print(curr_pt - (curr_pt|unit_normal)*unit_normal);
      
	line_break(i, num_pts);
      }
  }
  void
  shadow(double f1(double), double f2(double), double f3(double), triple normal, 
	 double t_min, double t_max, int num_pts)
  {
    epix_comment("parametric space curve, projected to a plane");
    draw_shadowplot(f1, f2, f3, normal, t_min, t_max, num_pts);
    end_stanza();
  }

  // triple-valued plot argument
  void
  draw_shadowplot(triple f(double), triple normal, 
		  double t_min, double t_max, int num_pts)
  {
    triple unit_normal;
    if (raw_len(normal) != 0)
      unit_normal = (1/raw_len(normal))*normal;
    double t;
    const double dt = (t_max - t_min)/num_pts;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(f(t) - (f(t)|unit_normal)*unit_normal);
      
	line_break(i, num_pts);
      }
  }
   
  void
  shadow(triple f(double), triple normal, 
	 double t_min, double t_max, int num_pts)
  {
    epix_comment("parametric space curve, projected to a plane");
    draw_shadowplot(f, normal, t_min, t_max, num_pts);
    end_stanza();
  }

  void
  draw_polarplot(double r(double), double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;
    const double t0 = t_min;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t0 + i*dt;
	print(polar(r(t), t));

	line_break(i, num_pts);
      }
  }

  void
  polarplot(double r(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("polar plot");
    draw_polarplot(r, t_min, t_max, num_pts);
    end_stanza();
  }

  /* 
   * plot one curve in a family:
   * sliceplot1: t -> [f1(s0,t), f2(s0,t)]
   * sliceplot2: s -> [f1(s,t0), f2(s,t0)]
   */
  void
  draw_sliceplot1(double f1(double, double), double f2(double, double), 
		  double t_min, double t_max, double s0, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(P(f1(s0,t), f2(s0,t)));

	line_break(i, num_pts);
      }
  }

  void
  draw_sliceplot2(double f1(double, double), double f2(double, double), 
		  double s_min, double s_max, double t0, int num_pts)
  {
    double s;
    const double ds = (s_max - s_min)/num_pts;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	s = s_min + i*ds;
	print(P(f1(s,t0), f2(s,t0)));

	line_break(i, num_pts);
      }
  }

  void
  sliceplot1 (double f1(double, double), double f2(double, double), 
	      double t_min, double t_max, double s0, int num_pts)
  {
    epix_comment("graph from a family, first variable constant");
    draw_sliceplot1(f1, f2, t_min, t_max, s0, num_pts);
    end_stanza();
  }
  void
  sliceplot2 (double f1(double, double), double f2(double, double), 
	      double s_min, double s_max, double t0, int num_pts)
  {
    epix_comment("graph from a family, second variable constant");
    draw_sliceplot2(f1, f2, s_min, s_max, t0, num_pts);
    end_stanza();
  }

  void
  draw_multiplot1 (double f1(double, double), double f2(double, double), 
		   pair lowleft, pair upright, struct mesh netsize,
		   int num_pts)
  {
    int i, N1 = netsize.n1;
    double s;

    const double s_min=lowleft.x1;
    const double s_max=upright.x1;
    const double ds = (s_max - s_min)/N1;

    const double t_min=lowleft.x2;
    const double t_max=upright.x2;
  
    for (i=0; i <= N1; ++i)
      {
	s = s_min + i*ds;
	draw_sliceplot1(f1, f2, t_min, t_max, s, num_pts);
	if (i < N1)
	  fprintf (stdout, "\n%%%%");
      }

    end_stanza();
  }
  void
  draw_multiplot2 (double f1(double, double), double f2(double, double), 
		   pair lowleft, pair upright, struct mesh netsize,
		   int num_pts)
  {
    int i, N2 = netsize.n2;
    double t;

    const double s_min=lowleft.x1;
    const double s_max=upright.x1;
    const double t_min=lowleft.x2;
    const double t_max=upright.x2;
    const double dt = (t_max - t_min)/N2;

    for (i=0; i <= N2; ++i)
      {
	t = t_min + i*dt;
	draw_sliceplot2(f1, f2, s_min, s_max, t, num_pts);
	if (i < N2)
	  fprintf (stdout, "\n%%%%");
      }

    end_stanza();
  }

  void
  multiplot1 (double f1(double, double), double f2(double, double), 
	      pair lowleft, pair upright, struct mesh netsize,
	      int num_pts)
  {
    epix_comment("graphs from a family, first variable constant");
    draw_multiplot1 (f1, f2, lowleft, upright, netsize, num_pts);
  }
  void
  multiplot2 (double f1(double, double), double f2(double, double), 
	      pair lowleft, pair upright, struct mesh netsize,
	      int num_pts)
  {
    epix_comment("graphs from a family, second variable constant");
    draw_multiplot2 (f1, f2, lowleft, upright, netsize, num_pts);
  }

  // pair-valued plot arguments
  void
  draw_sliceplot1(pair f(double, double),
		  double t_min, double t_max, double s0, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(f(s0,t));

	line_break(i, num_pts);
      }
  }
  void
  draw_sliceplot2(pair f(double, double), 
		  double s_min, double s_max, double t0, int num_pts)
  {
    double s;
    const double ds = (s_max - s_min)/num_pts;

    start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	s = s_min + i*ds;
	print(f(s,t0));

	line_break(i, num_pts);
      }
  }

  void
  sliceplot1 (pair f(double, double), 
	      double t_min, double t_max, double s0, int num_pts)
  {
    epix_comment("graph from a family, first variable constant");
    draw_sliceplot1(f, t_min, t_max, s0, num_pts);
    end_stanza();
  }
  void
  sliceplot2 (pair f(double, double), 
	      double s_min, double s_max, double t0, int num_pts)
  {
    epix_comment("graph from a family, second variable constant");
    draw_sliceplot2(f, s_min, s_max, t0, num_pts);
    end_stanza();
  }

  void
  draw_multiplot1 (pair f(double, double), pair lowleft, pair upright, 
		   struct mesh netsize, int num_pts)
  {
    int i, N1 = netsize.n1;
    double s;

    const double s_min=lowleft.x1;
    const double s_max=upright.x1;
    const double ds = (s_max - s_min)/N1;

    const double t_min=lowleft.x2;
    const double t_max=upright.x2;
  
    for (i=0; i <= N1; ++i)
      {
	s = s_min + i*ds;
	draw_sliceplot1(f, t_min, t_max, s, num_pts);
	if (i < N1)
	  fprintf (stdout, "\n%%%%");
      }

    end_stanza();
  }
  void
  draw_multiplot2 (pair f(double, double), pair lowleft, pair upright, 
		   struct mesh netsize, int num_pts)
  {
    int i, N2 = netsize.n2;
    double t;

    const double s_min=lowleft.x1;
    const double s_max=upright.x1;
    const double t_min=lowleft.x2;
    const double t_max=upright.x2;
    const double dt = (t_max - t_min)/N2;

    for (i=0; i <= N2; ++i)
      {
	t = t_min + i*dt;
	draw_sliceplot2(f, s_min, s_max, t, num_pts);
	if (i < N2)
	  fprintf (stdout, "\n%%%%");
      }

    end_stanza();
  }

  void
  multiplot1 (pair f(double, double), pair lowleft, pair upright, 
	      struct mesh netsize, int num_pts)
  {
    epix_comment("graphs from a family, first variable constant");
    draw_multiplot1 (f, lowleft, upright, netsize, num_pts);
  }
  void
  multiplot2 (pair f(double, double), pair lowleft, pair upright, 
	      struct mesh netsize, int num_pts)
  {
    epix_comment("graphs from a family, second variable constant");
    draw_multiplot2 (f, lowleft, upright, netsize, num_pts);
  }

  // Plotting functions that truncate plots at bounding box

  /*
   * edge-seek
   *
   * Approximates point where plot goes outside global bounding box.
   * Algorithm: Start at point known to be inside, take small steps
   * towards outside point, stop when point goes outside.
   */
  static
  pair edge_seek(double f1(double), double f2(double), double f3(double),
		 double t, double step)
  {
    pair temp = V(f1(t), f2(t), f3(t));

    while (x_min <= temp.x1 && temp.x1 <= x_max && 
	   y_min <= temp.x2 && temp.x2 <= y_max)
      {
	t += (EPIX_SEEK_SIZE)*step; 
	temp = V(f1(t), f2(t), f3(t));
      }
    return temp; // pair(f1(t), f2(t));
  }
  // pair-valued argument
  static
  pair edge_seek(pair f(double), double t, double step)
  {
    pair temp = f(t);

    while (x_min <= temp.x1 && temp.x1 <= x_max && 
	   y_min <= temp.x2 && temp.x2 <= y_max)
      {
	t += (EPIX_SEEK_SIZE)*step; 
	temp = f(t);
      }
    return temp; // pair(f1(t), f2(t));
  }
  // triple-valued argument
  static
  pair edge_seek(triple f(double), double t, double step)
  {
    pair temp = V(f(t).x1, f(t).x2, f(t).x3);

    while (x_min <= temp.x1 && temp.x1 <= x_max && 
	   y_min <= temp.x2 && temp.x2 <= y_max)
      {
	t += (EPIX_SEEK_SIZE)*step; 
	temp = V(f(t).x1, f(t).x2, f(t).x3);
      }
    return temp; // pair(f1(t), f2(t));
  }

  /*
   * clipplot and its variants plot a curve by keeping track of the
   * state (in/out of bounding region) of pairs of adjacent points. The
   * <previous> point is initially outside the bounding region. 
   * Subsequently, if (previous, current) = 
   * (out, in)  --> Start new path segment (seek back to find edge)
   * (in, in)   --> Continue existing path
   * (in, out)  --> End current path segment (seek forward to find edge)
   * (out, out) --> Print nothing, test next point
   *
   * 
   */
  void
  draw_clipplot(double f1(double), double f2(double), double f3(double),
		double t_min, double t_max, int num_pts)
  {
    pair curr, prev;
    int current=1, previous=0; // In/out of bounding box

    int pt_count=0; // Points printed in path segment, to format output
    int pr_flag=0; // Whether any points have been printed
    double t = 0;
    const double step = (t_max - t_min)/num_pts;
  
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*step;
	curr = V(f1(t), f2(t), f3(t));

	if (x_min <= curr.x1 && curr.x1 <= x_max && \
	    y_min <= curr.x2 && curr.x2 <= y_max)
	  current=1;
	else
	  current=0;
      
	// Four cases: Previous is in/out, current is in/out.
      
	// Start new path component
	if (current == 1 && previous == 0)
	  {
	    if (t == t_min) // print first point
	      {
		start_path();
		print(curr);
		pt_count = 1;
	      }
	    else // print 2 points: seek-back and current
	      {
		if (pr_flag == 0)
		  start_path();

		else
		  {
		    fprintf(stdout, "\n%%%%"); // New sub-stanza
		    start_path();
		  }

		// Seek back to edge of bounding box
		print(edge_seek(f1, f2, f3, t, -step));
		print(curr);
		pt_count=2;
	      }
	    pr_flag=1;
	    previous=1;
	    prev=curr;
	  }
      
	// Continue path
	else if (current == 1 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(curr);
	    previous=1;
	    prev=curr;
	  
	    ++pt_count;
	  }
      
	// End current path
	else if (current == 0 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    /* 
	     * Skip back 1+e path steps, then seek forward. Acceptably
	     * handles the case in which previous + seek_step is
	     * outside the bounding box.
	     */
	    print(edge_seek(f1, f2, f3, t-(1+(0.01)*EPIX_SEEK_SIZE)*step, step));
	    previous=0;
	    prev=curr;
	    pt_count=0;
	  }
      
	// (current == 0 && previous == 0), keep searching...
	else 
	  {
	    previous=0;
	    prev=curr;
	  }
      }
  }

  // Ordinary plot of function of one variable
  void
  clipplot(double f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("clipped graph");
    draw_clipplot(id, f, zero, t_min, t_max, num_pts);
    end_stanza();
  }

  // Parametric plane curves

  void
  clipplot(double f1(double), double f2(double), 
	   double t_min, double t_max, int num_pts)
  {
    epix_comment("clipped plane curve");  
    draw_clipplot(f1, f2, zero, t_min, t_max, num_pts);
    end_stanza();
  }

  // Parametric space curves
  void
  clipplot(double f1(double), double f2(double), double f3(double),
	   double t_min, double t_max, int num_pts)
  {
    epix_comment("clipped space curve");
    draw_clipplot(f1, f2, f3, t_min, t_max, num_pts);
    end_stanza();
  }

  // pair-valued plot argument
  void
  draw_clipplot(pair f(double), double t_min, double t_max, int num_pts)
  {
    pair curr, prev;
    int current=1, previous=0; // In/out of bounding box

    int pt_count=0; // Points printed in path segment, to format output
    int pr_flag=0; // Whether any points have been printed
    double t = 0;
    const double step = (t_max - t_min)/num_pts;
  
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*step;
	curr = f(t);

	if (x_min <= curr.x1 && curr.x1 <= x_max && \
	    y_min <= curr.x2 && curr.x2 <= y_max)
	  current=1;
	else
	  current=0;
      
	// Four cases: Previous is in/out, current is in/out.
      
	// Start new path component
	if (current == 1 && previous == 0)
	  {
	    if (t == t_min) // print first point
	      {
		start_path();
		print(curr);
		pt_count = 1;
	      }
	    else // print 2 points: seek-back and current
	      {
		if (pr_flag == 0)
		  start_path();

		else
		  {
		    fprintf(stdout, "\n%%%%"); // New sub-stanza
		    start_path();
		  }

		// Seek back to edge of bounding box
		print(edge_seek(f, t, -step));
		print(curr);
		pt_count=2;
	      }
	    pr_flag=1;
	    previous=1;
	    prev=curr;
	  }
      
	// Continue path
	else if (current == 1 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(curr);
	    previous=1;
	    prev=curr;
	  
	    ++pt_count;
	  }
      
	// End current path
	else if (current == 0 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(edge_seek(f, t-(1+(0.01)*EPIX_SEEK_SIZE)*step, step));
	    previous=0;
	    prev=curr;
	    pt_count=0;
	  }
      
	// (current == 0 && previous == 0), keep searching...
	else 
	  {
	    previous=0;
	    prev=curr;
	  }
      }
  }

  // Parametric plane curves

  void
  clipplot(pair f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("clipped plane curve");  
    draw_clipplot(f, t_min, t_max, num_pts);
    end_stanza();
  }

  // triple-valued plot argument
  void
  draw_clipplot(triple f(double), double t_min, double t_max, int num_pts)
  {
    pair curr, prev;
    int current=1, previous=0;

    int pt_count=0; 
    int pr_flag=0;
    double t = 0;
    const double step = (t_max - t_min)/num_pts;
  
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*step;
	curr = V(f(t).x1, f(t).x2, f(t).x3);

	if (x_min <= curr.x1 && curr.x1 <= x_max && \
	    y_min <= curr.x2 && curr.x2 <= y_max)
	  current=1;
	else
	  current=0;
      
	// Four cases: Previous is in/out, current is in/out.
      
	// Start new path component
	if (current == 1 && previous == 0)
	  {
	    if (t == t_min) // print first point
	      {
		start_path();
		print(curr);
		pt_count = 1;
	      }
	    else // print 2 points: seek-back and current
	      {
		if (pr_flag == 0)
		  start_path();

		else
		  {
		    fprintf(stdout, "\n%%%%"); // New sub-stanza
		    start_path();
		  }

		// Seek back to edge of bounding box
		print(edge_seek(f, t, -step));
		print(curr);
		pt_count=2;
	      }
	    pr_flag=1;
	    previous=1;
	    prev=curr;
	  }
      
	// Continue path
	else if (current == 1 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(curr);
	    previous=1;
	    prev=curr;
	  
	    ++pt_count;
	  }
      
	// End current path
	else if (current == 0 && previous == 1)
	  {
	    line_break(pt_count - 1, num_pts);
	    print(edge_seek(f, t-(1+(0.01)*EPIX_SEEK_SIZE)*step, step));
	    previous=0;
	    prev=curr;
	    pt_count=0;
	  }
      
	// (current == 0 && previous == 0), keep searching...
	else 
	  {
	    previous=0;
	    prev=curr;
	  }
      }
  }
  // Parametric space curves
  void
  clipplot(triple f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("clipped space curve");
    draw_clipplot(f, t_min, t_max, num_pts);
    end_stanza();
  }

  // Data plotting from file

    /*
     * Input file consists of lines containing two double-precision
     * floating point numbers separated by whitespace. Lines starting
     * with '%' are discarded, as are lines not matching the format
     * string "%g %g \n".
     */
  void
  data_plot(const char *data, const int epix_mark_type)
  {
    double x, y;
    FILE *input;
    char line[EPIX_FILE_WIDTH+1];
    int lineno = 0;
    int pt_count = 0; // Number of points printed in PATH
    int lines = 0;    // Printable lines found in data file

    input = fopen(data, "r");

    if (input != NULL) { // No error opening data file
      fprintf(stdout, "\n%%%% data_plot: File %s \n%%%%", data);

      if (epix_mark_type == PATH)
	{
	  // Count lines in input file for line breaking of output
	  while (fgets(line, EPIX_FILE_WIDTH, input) != NULL) {
	    if (line[0] == '%')
	      ;
	    else if (sscanf(line, "%lg %lg", &x, &y) == 2) 
	      ++lines;
	  }
	  rewind(input);

	  start_path();
	}
    
      while (fgets(line, EPIX_FILE_WIDTH, input) != NULL) {
	++lineno;
	if (line[0] == '%') // '%' starts comment line
	  ;

	else if (sscanf(line, "%lg %lg", &x, &y) == 2) 
	  {
	    marker(P(x, y), epix_mark_type);
	    if (epix_mark_type == PATH)
	      {
		++pt_count;
		line_break(pt_count, lines);
	      }
	  }

	else 
	  {
	    fprintf(stdout, "\n%%%% Ignoring line %d of file %s", lineno, data);
	    ++epix_lines_printed;
	  }
      } // while()
      fclose(input);
    } // if()
  
    else 
      fprintf(stdout, "\n%%%% Couldn't open file %s", data);
  
    end_stanza();
  }
  
  // Calculus plots: derivatives and definite integrals

  // Difference quotient of f at t
  static inline double deriv(double f(double), double t, double dt)
  {
    return (f(t + 0.5*dt) - f(t - 0.5*dt))/dt;
  }
  // pair-valued
  static inline pair deriv(pair f(double), double t, double dt)
  {
    return (1.0/dt)*(f(t + 0.5*dt) - f(t-0.5*dt));
  }

  static inline double integrand(double f(double), double t, double dt)
  {
    // Simpson's rule
    return (1.0/6)*(f(t) + 4*f(t+0.5*dt)+f(t + dt))*dt; 
  }

  // Print list of ordered pairs
  void
  draw_deriv(double f(double), double a, double b, int num_pts)
  {
    /*
     * Algorithm: Partition into intervals of length dt=(b-a)/N;
     *  Evaluate f'(t) for t=a, a+0.5*dt, ..., b-0.5*dt, b.
     */
    double t = a;
    const double dt = (b-a)/(num_pts*EPIX_ITERATIONS);

    start_path();

    // f'(a)
    print(P(t, delta(f, t, dt)/dt));
    t += 0.5*dt;

    for (int i=1; i <= num_pts; ++i)
      {
	print(P(t, deriv(f, t, dt)));
	line_break(i, num_pts);
	t += dt*EPIX_ITERATIONS;
      }
    // f'(b)
    t += 0.5*dt;
    print(P(t, deriv(f, t - 0.5*dt, dt)));
  }

  void
  plot_deriv(double f(double t), double a, double b, int num_pts)
  {
    epix_comment("derivative plot");
    draw_deriv(f, a, b, num_pts);
    end_stanza();
  }

  // tuples of real-valued plot arguments
  void tan_line(double f1(double t), double f2(double t), double t0)
  {
    const double dt = 1.0/(EPIX_ITERATIONS);
    pair dir = P(deriv(f1, t0, dt), deriv(f2, t0, dt));
    draw_Line(plot_pt(f1, f2, t0), plot_pt(f1, f2, t0)+dir, 1);
  }	      
  void tan_line(double f(double t), double t0)
  {
    const double dt = 1.0/(EPIX_ITERATIONS);
    pair dir = P(1, deriv(f, t0, dt));
    draw_Line(plot_pt(id, f, t0), plot_pt(id, f, t0)+dir, 1);
  }
  void envelope(double f1(double t), double f2(double t), 
		double t_min, double t_max, int num_pts)
  {
    const double dt = (t_max - t_min)/(num_pts*EPIX_ITERATIONS);
    double t=t_min;
    pair dir;

    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*EPIX_ITERATIONS*dt;
	dir = P(deriv(f1, t, dt), deriv(f2, t, dt));
	draw_Line(plot_pt(f1, f2, t), plot_pt(f1, f2, t) + dir, 1);
      }
  }	      
  void envelope(double f(double t), double t_min, double t_max, int num_pts)
  {
    const double dt = (t_max - t_min)/(num_pts*EPIX_ITERATIONS);
    double t=t_min;
    pair dir;

    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*EPIX_ITERATIONS*dt;
	dir = P(1, deriv(f, t, dt));
	draw_Line(plot_pt(id, f, t), plot_pt(id, f, t) + dir, 1);
      }
  }	      

  // pair-valued plot argument
  void tan_line(pair f(double t), double t0)
  {
    const double dt = 1.0/(EPIX_ITERATIONS);
    pair dir = deriv(f, t0, dt);
    draw_Line(f(t0), f(t0)+dir, 1);
  }
  void envelope(pair f(double t), double t_min, double t_max, int num_pts)
  {
    const double dt = (t_max - t_min)/(num_pts*EPIX_ITERATIONS);
    double t=t_min;
    pair dir;

    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*EPIX_ITERATIONS*dt;
	dir = deriv(f, t, dt);
	draw_Line(f(t), f(t) + dir, 1);
      }
  }	      

  // Tangent field along parametrized path
  void
  tan_field(double f1(double), double f2(double), double t_min,
	    double t_max, double num_pts)
  {
    double t=t_min;
    const double dt=(t_max - t_min)/(num_pts*EPIX_ITERATIONS);
    const double delta_t=(t_max - t_min)/num_pts;

    epix_comment("tangent field along a plane path");

    for (int i=0; i <= num_pts; ++i, t+=EPIX_ITERATIONS*dt)
      {
	draw_arrow(plot_pt(f1, f2, t), plot_pt(f1, f2, t)
		   + delta_t * P(deriv(f1, t, dt), deriv(f2, t, dt)));

	if (i < num_pts )
	  fprintf(stdout, "\n%%%%");
      }
    end_stanza();
  }

  void
  boldtan_field(double f1(double), double f2(double), double t_min,
		double t_max, double num_pts)
  {
    double t=t_min;
    const double dt=(t_max - t_min)/(num_pts*EPIX_ITERATIONS);
    const double delta_t=(t_max - t_min)/num_pts;

    epix_comment("bold tangent field along a plane path");

    for (int i=0; i <= num_pts; ++i, t+=EPIX_ITERATIONS*dt)
      {
	draw_boldarrow(plot_pt(f1, f2, t), 
		       plot_pt(f1, f2, t) + delta_t*P(deriv(f1, t, dt), deriv(f2, t, dt)));

	if (i < num_pts )
	  fprintf(stdout, "\n%%%%");
      }
    end_stanza();
  }

  // pair-valued plot argument
  void
  tan_field(pair f(double), double t_min, double t_max, double num_pts)
  {
    double t=t_min;
    const double dt=(t_max - t_min)/(num_pts*EPIX_ITERATIONS);
    const double delta_t=(t_max - t_min)/num_pts;

    epix_comment("tangent field along a plane path");

    for (int i=0; i <= num_pts; ++i, t+=EPIX_ITERATIONS*dt)
      {
	draw_arrow(f(t), f(t) + (delta_t*deriv(f, t, dt)));

	if (i < num_pts )
	  fprintf(stdout, "\n%%%%");
      }
    end_stanza();
  }

  void
  boldtan_field(pair f(double), double t_min, double t_max, double num_pts)
  {
    double t=t_min;
    const double dt=(t_max - t_min)/(num_pts*EPIX_ITERATIONS);
    const double delta_t=(t_max - t_min)/num_pts;

    epix_comment("bold tangent field along a plane path");

    for (int i=0; i <= num_pts; ++i, t+=EPIX_ITERATIONS*dt)
      {
	draw_boldarrow(f(t), f(t) + (delta_t*deriv(f, t, dt)));

	if (i < num_pts )
	  fprintf(stdout, "\n%%%%");
      }
    end_stanza();
  }

  // Definite integrals
  void
  draw_int(double f(double), double a, double b, int num_pts)
  {
    // Integrand is (1.0/6)*(f(t) + 4*f(t+0.5*dt) + f(t+dt))*dt
    double t = a, sum = 0; 
    int pt_count=0;
    const double dt = (b-a)/(num_pts*EPIX_ITERATIONS);

    start_path();
    for (int i=0; i <= num_pts*EPIX_ITERATIONS; ++i)
      {
	if (i%EPIX_ITERATIONS == 0)
	  {
	    print(pair(t, sum));
	    ++pt_count;
	    line_break(pt_count, num_pts);
	  }
	sum += integrand(f, t, dt);
	t += dt;
      }
  }
  void
  plot_int(double f(double), double a, double b, int num_pts)
  {
    epix_comment("definite integral plot");
    draw_int(f, a, b, num_pts);
    end_stanza();
  }

  // Integral with lower limit != end of plot interval
  void
  draw_int(double f(double), double x0, double a, double b, int num_pts)
  {
    double t = x0, sum = 0; 
    int pt_count=0;
    const double dt = (b-a)/(num_pts*EPIX_ITERATIONS);

    /* 
     * Calculate the "constant of integration" c by starting at x0,
     * stepping to a. (Simple, but sometimes inefficient.)
     */
    const double step = (a - x0)/EPIX_ITERATIONS;
    double c = 0;

    for (int i=0; i <= EPIX_ITERATIONS; ++i)
      c += integrand(f, x0+i*step, step);

    t = a; // reset left endpoint

    start_path();
    for (int i=0; i <= num_pts*EPIX_ITERATIONS; ++i)
      {
	if (i%EPIX_ITERATIONS == 0)
	  {
	    print(pair(t, sum+c));
	    ++pt_count;
	    line_break(pt_count, num_pts);
	  }
	sum += integrand(f, t, dt);
	t += dt;
      }
  }

  void
  plot_int(double f(double), double x0, double a, double b, int num_pts)
  {
    epix_comment("definite integral plot");
    draw_int(f, x0, a, b, num_pts);
    end_stanza();
  }

  // ODE plots -- slope, dart, and vector fields, solutions of ODEs
  static void
  draw_field(double f1(double, double), double f2(double, double),
	     pair p, pair q, int n1, int n2, const int epix_field_type)
  {
    // p = lower left corner, q = upper right corner, (n1, n2) = grid size
    double x1;
    double x2;
    const double dx1 = (q.x1 - p.x1)/n1;
    const double dx2 = (q.x2 - p.x2)/n2;
    double len_pict; // vector length in LaTeX units
    double minimum; // 40% of shorter grid length in Cartesian

    pair base; // basepoint
    pair vect; // displacement vector

    for (int i1 = 0; i1 <= n1; ++i1)
      {
	x1 = p.x1 + i1*dx1;
	for (int i2 = 0; i2 <= n2; ++i2)
	  {
	    x2 = p.x2 + i2*dx2;
	    base = P(x1, x2);

	    vect = P(f1(x1, x2), f2(x1, x2));

	    // Plotting the zero vector
	    if (truncate(raw_len(vect)) == 0)
	      {
		// Formerly a 2pt \circle*, which broke color handling
		fprintf(stdout, "\n\\put");
		print(base);
		fprintf(stdout, "{\\kern -0.25pt \\rule[-0.25pt]{0.5pt}{0.5pt}}");
	      }
	    // VECTOR fields plotted to scale
	    else if (epix_field_type == VECTOR)
	      {
		if (bold_flag)
		  draw_boldarrow(base, base + vect);
		else
		  draw_arrow(base, base + vect);
	      }

	    else // DART or ARROW fields scaled to constant length
	      {
		pair temp = c2s(vect);
		pair dX = c2s(pair(dx1, dx2));
		len_pict = raw_len(temp);
		// Hardwired constant 0.4: Segment length 80% of shorter grid length
		minimum = (dX.x1 > dX.x2) ? 0.4*dX.x2 : 0.4*dX.x1;
		vect *= (minimum/len_pict);
	    
		if (epix_field_type == SLOPE)
		  draw_line(base - vect, base + vect, 1, 0);
		else if (epix_field_type == DART)
		  draw_dart(base - vect, base + vect);
		else // unknown type...
		  ;	    
	      }
	  }
      }
  }

  void
  draw_slope_field(double f1(double, double), double f2(double, double),
		   pair p, pair q, int n1, int n2)
  {
    draw_field(f1, f2, p, q, n1, n2, SLOPE);
  }
  void
  draw_dart_field(double f1(double, double), double f2(double, double),
		  pair p, pair q, int n1, int n2)
  {
    draw_field(f1, f2, p, q, n1, n2, DART);
  }
  void
  draw_vector_field(double f1(double, double), double f2(double, double),
		    pair p, pair q, int n1, int n2)
  {
    draw_field(f1, f2, p, q, n1, n2, VECTOR);
  }

  void
  slope_field(double f1(double, double), double f2(double, double),
	      pair p, pair q, int n1, int n2)
  {
    epix_comment("slope field");
    draw_slope_field(f1, f2, p, q, n1, n2);
    end_stanza();
  }
  void
  boldslope_field(double f1(double, double), double f2(double, double),
		  pair p, pair q, int n1, int n2)
  {
    epix_comment("bold slope field");
    bold();
    draw_slope_field(f1, f2, p, q, n1, n2);
    plain();
    end_stanza();
  }

  void
  dart_field(double f1(double, double), double f2(double, double),
	     pair p, pair q, int n1, int n2)
  {
    epix_comment("dart field");
    draw_dart_field(f1, f2, p, q, n1, n2);
    end_stanza();
  }
  void
  bolddart_field(double f1(double, double), double f2(double, double),
		 pair p, pair q, int n1, int n2)
  {
    epix_comment("bold dart field");
    bold();
    draw_dart_field(f1, f2, p, q, n1, n2);
    plain();
    end_stanza();
  }

  void
  vector_field(double f1(double, double), double f2(double, double),
	       pair p, pair q, int n1, int n2)
  {
    epix_comment("vector field");
    draw_vector_field(f1, f2, p, q, n1, n2);
    end_stanza();
  }
  void
  boldvector_field(double f1(double, double), double f2(double, double),
		   pair p, pair q, int n1, int n2)
  {
    epix_comment("bold vector field");
    bold();
    bold_flag=1;
    draw_vector_field(f1, f2, p, q, n1, n2);
    plain();
    end_stanza();
  }

  // pair-valued vector fields
  static void
  draw_field(pair F(double, double), pair p, pair q, 
	     int n1, int n2, const int epix_field_type)
  {
    // p = lower left corner, q = upper right corner, (n1, n2) = grid size
    double x1;
    double x2;
    const double dx1 = (q.x1 - p.x1)/n1;
    const double dx2 = (q.x2 - p.x2)/n2;
    double len_pict; // vector length in LaTeX units
    double minimum; // 40% of shorter grid length in Cartesian

    pair base; // basepoint
    pair vect; // displacement vector

    for (int i1 = 0; i1 <= n1; ++i1)
      {
	x1 = p.x1 + i1*dx1;
	for (int i2 = 0; i2 <= n2; ++i2)
	  {
	    x2 = p.x2 + i2*dx2;
	    base = P(x1, x2);
	    vect = F(x1, x2);

	    // Plotting the zero vector
	    if (truncate(raw_len(vect)) == 0)
	      {
		fprintf(stdout, "\n\\put");
		print(base);
		fprintf(stdout, "{\\kern -0.25pt \\rule[-0.25pt]{0.5pt}{0.5pt}}");
	      }
	    // VECTOR fields plotted to scale
	    else if (epix_field_type == VECTOR)
	      {
		if (bold_flag)
		  draw_boldarrow(base, base + vect);
		else
		  draw_arrow(base, base + vect);
	      }

	    else // DART or ARROW fields scaled to constant length
	      {
		pair temp = c2s(vect);
		pair dX = c2s(pair(dx1, dx2));
		len_pict = raw_len(temp);
		// Hardwired constant 0.4: Segment length 80% of shorter grid length
		minimum = (dX.x1 > dX.x2) ? 0.4*dX.x2 : 0.4*dX.x1;
		vect *= (minimum/len_pict);
	    
		if (epix_field_type == SLOPE)
		  draw_line(base - vect, base + vect, 1, 0);
		else if (epix_field_type == DART)
		  draw_dart(base - vect, base + vect);
		else // unknown type...
		  ;	    
	      }
	  }
      }
  }

  void
  draw_slope_field(pair F(double, double), pair p, pair q, int n1, int n2)
  {
    draw_field(F, p, q, n1, n2, SLOPE);
  }
  void
  draw_dart_field(pair F(double, double), pair p, pair q, int n1, int n2)
  {
    draw_field(F, p, q, n1, n2, DART);
  }
  void
  draw_vector_field(pair F(double, double), pair p, pair q, int n1, int n2)
  {
    draw_field(F, p, q, n1, n2, VECTOR);
  }

  void
  slope_field(pair F(double, double), pair p, pair q, int n1, int n2)
  {
    epix_comment("slope field");
    draw_slope_field(F, p, q, n1, n2);
    end_stanza();
  }
  void
  boldslope_field(pair F(double, double),	pair p, pair q, int n1, int n2)
  {
    epix_comment("bold slope field");
    bold();
    draw_slope_field(F, p, q, n1, n2);
    plain();
    end_stanza();
  }

  void
  dart_field(pair F(double, double), pair p, pair q, int n1, int n2)
  {
    epix_comment("dart field");
    draw_dart_field(F, p, q, n1, n2);
    end_stanza();
  }
  void
  bolddart_field(pair F(double, double), pair p, pair q, int n1, int n2)
  {
    epix_comment("bold dart field");
    bold();
    draw_dart_field(F, p, q, n1, n2);
    plain();
    end_stanza();
  }

  void
  vector_field(pair F(double, double), pair p, pair q, int n1, int n2)
  {
    epix_comment("vector field");
    draw_vector_field(F, p, q, n1, n2);
    end_stanza();
  }
  void
  boldvector_field(pair F(double, double), pair p, pair q, int n1, int n2)
  {
    epix_comment("bold vector field");
    bold();
    bold_flag=1;
    draw_vector_field(F, p, q, n1, n2);
    plain();
    end_stanza();
  }

  // Solutions of ODEs
  void
  draw_ode_plot(double f1(double, double), double f2(double, double),
		pair start, double t_max, int num_pts)
  {
    int i=0;
    int pt_count = 0;
    pair curr = start;

    if (x_min <= curr.x1 && curr.x1 <= x_max &&
	y_min <= curr.x2 && curr.x2 <= y_max)
      start_path();
    else
      fprintf(stdout, "\n%%%% Initial point outside bounding box");

    while(x_min <= curr.x1 && curr.x1 <= x_max &&
	  y_min <= curr.x2 && curr.x2 <= y_max &&
	  i <= num_pts*EPIX_ITERATIONS)
      {
	if (i%EPIX_ITERATIONS == 0)
	  {
	    print(curr);
	    ++pt_count;
	    line_break(pt_count, num_pts);
	  }

	++i;

	// Euler's method (adequate, faster than Runge-Kutta)
	curr += (t_max/(num_pts*EPIX_ITERATIONS)) 
	  * pair(f1(curr.x1, curr.x2), f2(curr.x1, curr.x2));
      }
  
    print(curr);
  }

  void
  ode_plot(double f1(double, double), double f2(double, double),
	   pair start, double t_max, int num_pts)
  {
    epix_comment("solution curve to a planar ODE");
    draw_ode_plot(f1, f2, start, t_max, num_pts);
    end_stanza();
  }

  // pair-valued vector field
  void
  draw_ode_plot(pair F(double, double), pair start, double t_max, int num_pts)
  {
    int i=0;
    int pt_count = 0;
    pair curr = start;
    const double dt = (t_max/(num_pts*EPIX_ITERATIONS));

    if (x_min <= curr.x1 && curr.x1 <= x_max &&
	y_min <= curr.x2 && curr.x2 <= y_max)
      start_path();
    else
      fprintf(stdout, "\n%%%% Initial point outside bounding box");

    while(x_min <= curr.x1 && curr.x1 <= x_max &&
	  y_min <= curr.x2 && curr.x2 <= y_max &&
	  i <= num_pts*EPIX_ITERATIONS)
      {
	if (i%EPIX_ITERATIONS == 0)
	  {
	    print(curr);
	    ++pt_count;
	    line_break(pt_count, num_pts);
	  }

	++i;

	// Euler's method
	curr += dt*F(curr.x1, curr.x2);
      }
    print(curr);
  }

  void
  ode_plot(pair F(double, double), pair start, double t_max, int num_pts)
  {
    epix_comment("solution curve to a planar ODE");
    draw_ode_plot(F, start, t_max, num_pts);
    end_stanza();
  }

  /*
   * flow_plot draws the image of a set of points under a planar flow.
   * The initial set is the image of the path f:[0,1] -> R^2, and the 
   * flow is followed in <steps> increments up to time t_max.
   */
  static void
  print_points(pair* data, int num_pts)
  {
    for (int i = 0; i <= num_pts; ++i)
      {
	print(data[i]);
	line_break(i, num_pts);
      }
  }
  static triple
  color_black(double t)
  {
    return P(0,0,0);
  }

  void 
  draw_flow_plot(double f1(double, double), double f2(double, double),
		 pair f(double), triple color(double t), 
		 double t_max, int steps, int num_pts)
  {
    pair curr[num_pts + 1]; // locations of points on path segments
    triple current_color;
    const double dt = t_max/(steps*EPIX_ITERATIONS);

    // initialize path segment
    for (int i = 0; i <= num_pts; ++i)
      curr[i] = f(i*1.0/num_pts);

    for (int tick=0; tick <= steps*EPIX_ITERATIONS; ++tick)
      {
	if ((tick%EPIX_ITERATIONS) == 0)
	  {
	    current_color = color(tick*1.0/(steps*EPIX_ITERATIONS));
	    rgb(current_color.x1, current_color.x2, current_color.x3);

	    start_path();
	    print_points(curr, num_pts);
	    fprintf (stdout, "\n%%%%");
	  }

	// Euler's method
	for (int i = 0; i <= num_pts; ++i)
	  curr[i] += dt*P(f1(curr[i].x1, curr[i].x2), 
			  f2(curr[i].x1, curr[i].x2)); 
      }
  }

  void
  flow_plot(double f1(double, double), double f2(double, double),
	    pair f(double), triple color(double t), 
	    double t_max, int steps, int num_pts)
  {
    epix_comment("time slice of a planar flow");
    draw_flow_plot(f1, f2, f, color, t_max, steps, num_pts);
    end_stanza();
  }

  void
  flow_plot(double f1(double, double), double f2(double, double),
	    pair f(double), double t_max, int steps, int num_pts)
  {
    epix_comment("time slice of a planar flow");
    draw_flow_plot(f1, f2, f, color_black, t_max, steps, num_pts);
    end_stanza();
  }

  // pair-valued vector field
  void 
  draw_flow_plot(pair F(double, double), pair f(double), triple color(double t), 
		 double t_max, int steps, int num_pts)
  {
    pair curr[num_pts + 1]; // locations of points on path segments
    triple current_color;
    const double dt = t_max/(steps*EPIX_ITERATIONS);

    // initialize path segment
    for (int i = 0; i <= num_pts; ++i)
      curr[i] = f(i*1.0/num_pts);

    for (int tick=0; tick <= steps*EPIX_ITERATIONS; ++tick)
      {
	if ((tick%EPIX_ITERATIONS) == 0)
	  {
	    current_color = color(tick*1.0/(steps*EPIX_ITERATIONS));
	    rgb(current_color.x1, current_color.x2, current_color.x3);

	    start_path();
	    print_points(curr, num_pts);
	    fprintf (stdout, "\n%%%%");
	  }

	// Euler's method
	for (int i = 0; i <= num_pts; ++i)
	  curr[i] += dt*F(curr[i].x1, curr[i].x2);
      }
  }

  void
  flow_plot(pair F(double, double), pair f(double), triple color(double t), 
	    double t_max, int steps, int num_pts)
  {
    epix_comment("time slice of a planar flow");
    draw_flow_plot(F, f, color, t_max, steps, num_pts);
    end_stanza();
  }

  void
  flow_plot(pair F(double, double), pair f(double), 
	    double t_max, int steps, int num_pts)
  {
    epix_comment("time slice of a planar flow");
    draw_flow_plot(F, f, color_black, t_max, steps, num_pts);
    end_stanza();
  }

  // Jay Belanger's shaded plot routines -- December 1, 2002

  static void
  draw_blackplot(double f(double), double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    fprintf (stdout, "\n\\blacken\\path"); //start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(plot_pt(id, f, t));

	line_break(i, num_pts);
      }
    print(plot_pt(id, zero, t_max));
    print(plot_pt(id, zero, t_min));
    print(plot_pt(id, f, t_min));
  }

  static void
  draw_blackplot(double f(double), double g(double), double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    fprintf (stdout, "\n\\blacken\\path"); //start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(plot_pt(id, f, t));

	line_break(i, num_pts);
      }
    print(plot_pt(id, g, t_max));
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_max - i*dt;
	print(plot_pt(id, g, t));
	line_break(i, num_pts);
      }
    print(plot_pt(id, f, t_min));
  }

  void
  blackplot(double f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("black graph plot");
    draw_blackplot(f, t_min, t_max, num_pts);
    end_stanza();
  }

  void
  blackplot(double f(double), double g(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("black graph plot");
    draw_blackplot(f, g, t_min, t_max, num_pts);
    end_stanza();
  }

  static void
  draw_whiteplot(double f(double), double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    fprintf (stdout, "\n\\whiten\\path"); //start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(plot_pt(id, f, t));

	line_break(i, num_pts);
      }
    print(plot_pt(id, zero, t_max));
    print(plot_pt(id, zero, t_min));
    print(plot_pt(id, f, t_min));
  }

  static void
  draw_whiteplot(double f(double), double g(double), double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    fprintf (stdout, "\n\\whiten\\path"); //start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(plot_pt(id, f, t));

	line_break(i, num_pts);
      }
    print(plot_pt(id, g, t_max));
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_max - i*dt;
	print(plot_pt(id, g, t));
	line_break(i, num_pts);
      }
    print(plot_pt(id, f, t_min));
  }

  void
  whiteplot(double f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("white graph plot");
    draw_whiteplot(f, t_min, t_max, num_pts);
    end_stanza();
  }

  void
  whiteplot(double f(double), double g(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("white graph plot");
    draw_whiteplot(f, g, t_min, t_max, num_pts);
    end_stanza();
  }

  static void
  draw_shadeplot(double f(double), double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    fprintf (stdout, "\n\\shade\\path"); //start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(plot_pt(id, f, t));

	line_break(i, num_pts);
      }
    print(plot_pt(id, zero, t_max));
    print(plot_pt(id, zero, t_min));
    print(plot_pt(id, f, t_min));
  }

  static void
  draw_shadeplot(double f(double), double g(double), 
		 double t_min, double t_max, int num_pts)
  {
    double t;
    const double dt = (t_max - t_min)/num_pts;

    fprintf (stdout, "\n\\shade\\path"); //start_path();
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_min + i*dt;
	print(plot_pt(id, f, t));

	line_break(i, num_pts);
      }
    print(plot_pt(id, g, t_max));
    for (int i=0; i <= num_pts; ++i)
      {
	t = t_max - i*dt;
	print(plot_pt(id, g, t));
	line_break(i, num_pts);
      }
    print(plot_pt(id, f, t_min));
  }

  void
  shadeplot(double f(double), double t_min, double t_max, int num_pts)
  {
    epix_comment("shaded graph plot");
    draw_shadeplot(f, t_min, t_max, num_pts);
    end_stanza();
  }

  void
  shadeplot(double f(double), double g(double), 
	    double t_min, double t_max, int num_pts)
  {
    epix_comment("shaded graph plot");
    draw_shadeplot(f, g, t_min, t_max, num_pts);
    end_stanza();
  }

} /* end of namespace */
