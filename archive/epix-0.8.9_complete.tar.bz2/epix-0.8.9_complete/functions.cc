/* 
 * functions.cc -- non-standard mathematical functions
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.9rc5
 * Last Change: February 10, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <cstdlib>
#include <cmath>

#include "globals.h"

namespace ePiX {

  extern double epix_angle_units;

  static double inv (double x)
  {
    if (fabs(x) > EPIX_DBL_INFTY) 
      return 0;
    else 
      return 1/x;
  }
  // trig functions with angle units
  double cos(double theta) { return std::cos(epix_angle_units*theta); }
  double sin(double theta) { return std::sin(epix_angle_units*theta); }
  double tan(double theta) { return std::tan(epix_angle_units*theta); }

  // non-mathematical behavior (i.e. vanishing:) at poles
  double sec(double theta) { return inv(std::cos(epix_angle_units*theta)); }
  double csc(double theta) { return inv(std::sin(epix_angle_units*theta)); }
  double cot(double theta) { return inv(std::tan(epix_angle_units*theta)); }

  // and inverses
  double acos(double arg) { return std::acos(arg)/epix_angle_units; }
  double asin(double arg) { return std::asin(arg)/epix_angle_units; }
  double atan(double arg) { return std::atan(arg)/epix_angle_units; }

  // identity function for angle units
  double angle(double t) { return epix_angle_units*t; }

  /* identity and coordinate projections */
  double id (double x) { return x; }

  double proj1 (double x, double y) { return x; }
  double proj2 (double x, double y) { return y; }

  // reciprocal, with 1/0=0
  double recip (double x)
  {
    if (x != 0)
      return 1/x;
    else
      return 0;
  }

  // sin(x)/x
  double sinx (double x)
  {
    if (x != 0)
      return ePiX::sin(x)/angle(x);
    else
      return 1;
  }

  // signum, x/|x|, defined to be 0 at 0
  double sgn (double x)
  {
    if (x > 0)
      return 1;
    else if (x < 0)
      return -1;
    else
      return 0;
  }

  // Charlie Brown: Period-2 extension of |x| on [-1,1] /\/\/\/\/\/
  double cb (double x)
  {
    x = fabs(x); // cb is even

    while (x > 1)
      x += -2;

    return fabs(x); // cb extends |x|
  }

  // N.B.: gcd(0,i) = |i|
  int gcd (int i, int j)
  {
    int temp;

    i=abs(i);
    j=abs(j);

    if (i==0 || j==0) // (1,0) and (0,1) coprime, others not
      return i+j;

    else {
      if (j < i) // swap them
	{
	  temp = j;
	  j=i;
	  i=temp;
	}
      // Euclidean algorithm
      while ((temp = j%i)) // i does not evenly divide j
	{
	  j=i;
	  i=temp;
	}
    
      return i;
    }
  }

  // inf and sup of f on [a,b]
  double inf (double f(double), double a, double b)
  {
    const int N = (int) ceil(fabs(b-a)); // N >= 1 unless a=b
    double y = f(a);
    double dx = (b-a)/(N*EPIX_ITERATIONS);

    for (int i=1; i <= N*EPIX_ITERATIONS; ++i)
      if (f(a + i*dx) < y)
	y = f(a + i*dx);

    return y;
  }

  double sup (double f(double), double a, double b)
  {
    const int N = (int) ceil(fabs(b-a)); // N >= 1 unless a=b
    double y = f(a);
    double dx = (b-a)/(N*EPIX_ITERATIONS);

    for (int i=1; i <= N*EPIX_ITERATIONS; ++i)
      if (f(a + i*dx) > y)
	y = f(a + i*dx);

    return y;
  }

} /* end of namespace */
