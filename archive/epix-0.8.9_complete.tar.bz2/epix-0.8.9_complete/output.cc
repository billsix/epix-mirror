/* 
 * output.cc -- output file formatting routines
 *
 * This file is part of ePiX, a preprocessor for creating high-quality 
 * line figures in LaTeX 
 *
 * Version 0.8.9rc3
 * Last Change: February 06, 2003
 */

/* 
 * Copyright (C) 2001, 2002, 2003
 * Andrew D. Hwang <ahwang@mathcs.holycross.edu>
 * Department of Mathematics and Computer Science
 * College of the Holy Cross
 * Worcester, MA, 01610-2395, USA
 */

/*
 * ePiX is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ePiX is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ePiX; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <cstdio>

#define _EPIX_COMPILE_OUTPUT

#include "globals.h"
#include "pairs.h"
#include "output.h"

namespace ePiX {

  extern const char *epix_version;

  double epix_stretch_factor=1.0;
  double epix_angle_units=1.0;

  double h_size, v_size, h_offset, v_offset;
  double viewpt1, viewpt2, viewpt3;
  double x_min, x_max, y_min, y_max, x_size, y_size;
  double pic_size;
  char *pic_unit;

  epix_path_style EPIX_PATH_STYLE;

  int epix_begin_count=0; // number of calls to begin()

  /*
   * Output control; count line_breaks, terminate with fatal error if
   * more than EPIX_MAX_LINES are printed. 
   */
  int epix_lines_printed = 0;

  // Sectioning Functions

  // Print standard ePiX picture header
  void begin(void)
  {
    solid(); // initialize EPIX_PATH_STYLE
    if (epix_begin_count == 0)
      fprintf (stdout, "%%%% ePiX-%s\n", epix_version);
    ++epix_begin_count;

    fprintf (stdout, "%%%%");
    fprintf (stdout, "\n%%%%   Cartesian bounding box: [%g,%g] x [%g,%g]",
	     x_min, x_max, y_min, y_max);
    fprintf (stdout, "\n%%%%   Actual size: %g%s x %g%s",
	     h_size*pic_size, pic_unit, v_size*pic_size, pic_unit);
    fprintf (stdout, "\n%%%%   Figure offset: %s by %g%s, %s by %g%s",
	     (h_offset >= 0) ? "right" : "left", fabs(h_offset)*pic_size, pic_unit, 
	     (v_offset >= 0) ? "up"    : "down", fabs(v_offset)*pic_size, pic_unit);
    fprintf (stdout, "\n%%%%");
    fprintf (stdout, "\n\\setlength{\\unitlength}{%g%s}", pic_size, pic_unit);
    fprintf (stdout, "\n\\begin{picture}(%g,%g)(%g,%g)", \
	     h_size, v_size, -h_offset, -v_offset);
    end_stanza();
  }

  void end() { fprintf (stdout, "\n\\end{picture}\n"); }

  // Print Cartesian pair/triple in LaTeX coordinates
  void print(pair p)
  {
    pair out = c2p(p);
    fprintf (stdout, "(%g,%g)", out.x1, out.x2);
  }
  void print(triple p)
  {
    pair out = c2p(V(p.x1, p.x2, p.x3));
    fprintf (stdout, "(%g,%g)", out.x1, out.x2);
  }
  // Print pair without conversion
  void raw_print(pair p)
  {
    fprintf (stdout, "(%g,%g)", truncate(p.x1), truncate(p.x2));
  }

  void
  stretch(double t)
  {
    epix_stretch_factor = t;
  }

  void radians(void)
  {
    epix_angle_units = 1.0;
  }
  void degrees(void)
  {
    epix_angle_units = M_PI/180;
  }
  void revolutions(void)
  {
    epix_angle_units = 2*M_PI;
  }

  // Path style declarations
  void
  pen(char *pen_width) // valid LaTeX length, e.g. "0.01in"
  {
    fprintf (stdout, "\n\\allinethickness{%s}%%", pen_width);
  }

  void 
  pen(double width) // true points
  {
    fprintf (stdout, "\n\\allinethickness{%gpt}%%", width);
  }

  void start_path(void)
  {
    fprintf (stdout, "\n");

    if (EPIX_PATH_STYLE == SOLID)
      fprintf (stdout, "\\path");

    else if (EPIX_PATH_STYLE == DASHED)
      fprintf (stdout, "\\dashline{%.3f}", 
	       t2p(epix_stretch_factor*EPIX_DASH_LENGTH));

    else if (EPIX_PATH_STYLE == DOTTED)
      fprintf (stdout, "\\dottedline{%.3f}", 
	       t2p(epix_stretch_factor*EPIX_DOT_SEP));

    else // defensive measure...
      fprintf (stdout, "\\path");
  }

  // Unified comment function
  void epix_comment(char *type)
  {
    fprintf(stdout, "\n%%%% %s:\n%%%%", type);
  } 

  // End current stanza of .eepic file
  void end_stanza(void)
  {
    int i=0;
    // Stanza separator of width EPIX_FILE_WIDTH
    fprintf (stdout, "\n%%%%\n%%%%");
    for (i=0; i<= EPIX_FILE_WIDTH - 4; ++i)
      fprintf (stdout, "-");
    fprintf (stdout, "%%%%");

    output();
  }

  void fatal_error(void)
  {
    int i;
    fprintf (stdout, "\n%%%%\n");
    for (i=0; i <= EPIX_FILE_WIDTH; ++i)
      fprintf (stdout, "%%");

    fprintf (stdout, "\n%%%%      ");
    fprintf (stdout, "That's more than %d lines. I suspect an error...", 
	     EPIX_MAX_LINES);
    fprintf (stdout, "     %%%%\n");

    for (i=0; i <= EPIX_FILE_WIDTH; ++i)
      fprintf (stdout, "%%");
    end();
    exit(1);
  }

  void output(void)
  {
    if (epix_lines_printed > EPIX_MAX_LINES)
      fatal_error();
  }

  void line_break(int i, int num_pts)
  {
    // Print only 3 points on first line of dashed/dotted path
    if (EPIX_PATH_STYLE == DASHED || EPIX_PATH_STYLE == DOTTED)
      ++i;
  
    if ((i+1) % EPIX_PAIRS_PER_LINE == 0 && i < num_pts)
      {
	fprintf (stdout, "\n  ");
	++epix_lines_printed;
	output();
      }
  }

  // Variable color handling, requires "color" package

  // Force double to [0,1]
  static double 
  clip_to_unit(double t)
  {
    if (t < 0)
      return 0;
    else if (t > 1)
      return 1;
    else
      return t;
  }

  // Red-Blue-Green color model
  void
  rgb(double r, double g, double b)
  {
    r = clip_to_unit(r);
    g = clip_to_unit(g);
    b = clip_to_unit(b);
    fprintf (stdout, "\n\\color[rgb]{%.2f,%.2f,%.2f}", r, g, b);
  }

  // Cyan-Magenta-Yellow-Black color model, better for printing
  void
  cmyk(double c, double m, double y, double k)
  {
    c = clip_to_unit(c);
    m = clip_to_unit(m);
    y = clip_to_unit(y);
    k = clip_to_unit(k);
    fprintf (stdout, "\n\\color[cmyk]{%.2f,%.2f,%.2f,%.2f}", c, m, y, k);
  }

  // Changing the shading

  void gray(double x)
  {
    if (x<0) x=0;
    if (x>1) x=1;

    fprintf(stdout, "\n\\special{sh %g}%%%%", x);
  }

} /* end of namespace */
