/*
 * output.h -- ePiX file-formatting output routines
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.4
 * Last Change: June 29, 2002
 *
 */

#ifndef _EPIX_OUTPUT
#define _EPIX_OUTPUT

#ifdef _EPIX_COMPILE
#include "lengths.h"
#endif

/* Sectioning Functions */

/* Begin/end picture */
void begin(void);
void end(void);

/* Print Cartesian pair in form (p.x1,p.x2) */
void print(pair);
void raw_print(pair);

/* Path style declarations */
void start_path(const int);
void fill(void);

void end_stanza(void);
void fatal_error(void);
void output(void);
void line_break(int, int, int);

extern int lines_printed;

/* Misc Styles and output formatting */
void pen(char *);
void pen(double);
void stretch(double);
void bold(void);
void endbold(void);
void end_bold(void);

/*
 * Color handling
 *
 * ePiX provides both "pstricks" style colors (only six choices),
 * which are used in "\begin-\end" style environments, and "color"
 * style colors (c*10^6 choices, c>1), which are declarations rather
 * than delimited environments. In other words, you can make part of
 * an ePiX file print red in at least two ways:
 *   red();
 *   <epix commands>
 *   end_red();
 *
 *   rgb(1,0,0);
 *   <epix commands>
 *   black();
 *
 * rgb and cmyk colors are specified (respectively) by 3 or 4 floats,
 * the densities of the corresponding primary colors. If these densities
 * are specified outside the unit interval [0,1], they will be truncated,
 * e.g., rgb(2, -1, 0.3) = rgb(1, 0, 0.3).
 */

/* variable color handling -- requires LaTeX "color" package */
// red-green-blue
void rgb(double r, double g, double b); 
// cyan-magenta-yellow-black
void cmyk(double c, double m, double y, double k);
void black(void);

/* constant color handling -- requires LaTeX "pstricks" package */
void red(void);
void end_red(void);
void blue(void);
void end_blue(void);
void green(void);
void end_green(void);
void cyan(void);
void end_cyan(void);
void magenta(void);
void end_magenta(void);
void yellow(void);
void end_yellow(void);


void fill(void);
void unfill(void);
void shade(void);

/* Obsolete path style declarations */
void path(void);
void dashed(void);
void dotted(void);

#endif /* _EPIX_OUTPUT */
