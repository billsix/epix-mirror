/*
 * globals.h -- ePiX top-level header file
 *
 * ePiX: A lightweight LaTeX pre-processor to generate mathematically 
 * accurate eepic files from user-friendly C source files. ePiX is
 * implemented as a C/C++ library and a shell script, and requires a C++ 
 * compiler for ordinary use. The GNU compiler is strongly preferred.
 *
 * Feedback about this program (bug reports, suggestions for features,
 * etc.) is welcome. If you find this program useful, please consider
 * making a contribution to the Free Software Foundation; see
 * http://www.fsf.org
 *
 * Version 0.8.4
 * Last Change: June 25, 2002
 *
 * Copyright (C) 2001--2, Andrew D. Hwang   <ahwang@mathcs.holycross.edu>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 * 
 */

#ifndef _EPIX
#define _EPIX

#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#ifdef _EPIX_COMPILE /* Ignore this during normal use */
#ifdef _VERSION
const char *version="0.8.4"; 
#endif
#endif

/* 
 * To find hard-wired constants in the source code, do
 *
 *             grep "Magic number" *.cc
 */

/* Tweakable constants  */

#define NUM_PTS 40 /* Number of points in half-ellipses, splines */
#define FILE_WIDTH 70 /* Width of output file, in characters */
#define DIAM 4 /* Diameter of circles and spots in true pt */
#define ARROWHEAD_WIDTH 1.5 /* Half-width of arrowheads in true pt */
#define ARROWHEAD_RATIO 5.5 /* Aspect ratio of arrowheads */

/* 
 * Determines accuracy of truncation in clipplot et. al.
 * smaller -> better accuracy, longer run
 */
#define SEEK_SIZE 0.01 

/*
 * In calculus plotting, determines the size of the increment dt
 * and the number of increments per point printed
 * larger -> better accuracy, longer run
 */
#define ITERATIONS 1000 

/* Path styles and data plot markers */
enum path_style {PLAIN, DASHED, DOTTED, BOLD};

enum mark_type {PATH, CIRC, SPOT, RING, DOT, DDOT, PLUS, OPLUS, TIMES, OTIMES,
		DIAMOND, UP, DOWN, BOX, BBOX};

// coordinate axis tick marks
enum tick_type {TICK_NULL, H_AXIS, V_AXIS};

// "vector field"-type objects
enum field_type {SLOPE, DART, VECTOR};

/* Deprecated constants */

#define PAIRS_PER_LINE 4 /* Number of pairs per line in output file */
#define MAX_LINES 20000 /* Fatal error if this many lines printed */
/*
 * Output control; count line_breaks, terminate with fatal error if
 * more than MAX_LINES are printed. 
 */
#ifndef _INCLUDE
int lines_printed = 0;
#endif

/* Buggy dash/dot separation specifiers */
#define DASH_LENGTH 5.0 /* Dash length/dot separation in true pt */
#define DOT_SEP 40.0

/* 
 * ePiX depicts the rectangle [x_min, x_max] x [y_min, y_max] in a LaTeX
 * figure occupying (h_offset, v_offset) + [0, h_size] x [0, v_size]. If
 * appropriate, orthogonal projection to the plane normal to <viewpoint>
 * is performed. The call unitlength("0.5cm") causes the LaTeX picture
 * unit to be 0.5cm, and sets pic_size=0.5, *pic_unit="cm".
 */

/* 
 * <Size> and <offset> of picture in PICTURE coordinates. Sizes 
 * define space in document alotted by LaTeX. Offsets shift the
 * origin from the CENTER of the picture; positive offsets shift
 * RIGHT and UP (contrast LaTeX behavior).
 */
extern double h_size, v_size, h_offset, v_offset; // zero offset by default

/*
 * Components of normal vector for 3-d plotting. When set to (0,0,a3),
 * ePiX draws the standard x-y plane in standard orientation. Otherwise
 * ePiX does orthogonal projection to the plane normal to <viewpoint>,
 * keeping the z-axis vertical. Because projection is orthogonal, overall
 * scale in <viewpoint> is immaterial (aside from round-off).
 */
extern double viewpt1, viewpt2, viewpt3; // default viewpoint (0,0,0)

/*
 * Bounding box of picture in CARTESIAN coordinates.
 * Output is scaled so that Cartesian bounding box exactly
 * fills picture box (see h_scale, v_scale).
 */
extern double x_min, x_max, y_min, y_max;
/* Cartesian width and height of bounding box */
extern double x_size, y_size;

/*
 * Picture length units
 *
 * <pic_unit> is one of the following valid LaTeX length units: 
 *    cm, in, mm, pc, or pt.
 * <pic_size> is a double that (with pic_unit) specifies unitlength
 */
extern double pic_size; // e.g., 1
extern char *pic_unit;  // e.g., "pt" 

void unitlength (const char *);

#endif /* _EPIX */
