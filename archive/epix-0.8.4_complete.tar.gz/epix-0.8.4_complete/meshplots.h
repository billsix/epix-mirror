/*
 * meshplots.h
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.8.3
 * Last Change: June 14, 2002
 *
 */

#ifndef _EPIX_MESH
#define _EPIX_MESH

#ifdef _EPIX_COMPILE
#include "output.h"
#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                        meshplots.cc                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Parametric surfaces */
void wiremesh(double f1(double, double), double f2(double, double), 
	      double f3(double, double), pair p1, pair p2, mesh N,
	      mesh num_pts);
void dashwiremesh(double f1(double, double), double f2(double, double), 
		  double f3(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts);
void dotwiremesh(double f1(double, double), double f2(double, double), 
		 double f3(double, double), pair p1, pair p2, mesh N,
		 mesh num_pts);
void boldwiremesh(double f1(double, double), double f2(double, double), 
		  double f3(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts);

/* Graphs of functions of two real variables */
void wiremesh(double f(double, double), pair p1, pair p2, mesh N,
	      mesh num_pts);
void dashwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts);
void dotwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		 mesh num_pts);
void boldwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts);

#endif /* _EPIX_MESH */
