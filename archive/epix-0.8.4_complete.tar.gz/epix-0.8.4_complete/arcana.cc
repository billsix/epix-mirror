/* 
 * arcana.cc
 *
 * Functions not likely to be of general interest:
 *   plot_profile -- Implementation of the momentum construction
 *   std_F -- Routine for visualizing linear maps of the plane
 *
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.7.x
 * Last Change: May 29, 2002
 */

#define _EPIX_COMPILE

#include "arcana.h"
/*
extern double h_size, v_size, h_offset, v_offset;
extern double viewpt1, viewpt2, viewpt3;
extern double x_min, x_max, y_min, y_max, x_size, y_size;
extern double pic_size;
extern char *pic_unit;
*/
static double dt;

/* Difference quotient of f at t */
static double 
deriv(double f(double), double t, double dt)
{
  return (f(t + 0.5*dt) - f(t - 0.5*dt))/dt;
}

/* Convert a momentum profile to a geometric profile */

void 
draw_profile(double f(double), double a, double b, 
	     int num_pts, const int path_style)
{
  double x=x_min;
  double t=a;
  int i=0, pt_count=0;

  dt = (b-a)/(num_pts*ITERATIONS);

  start_path(path_style);
  print(pair(x, sqrt(f(t))));
  ++pt_count;
  t += 0.5*dt;
  x += dt*sqrt((4-deriv(f, t, dt)*deriv(f, t, dt))/(4*f(t)));

  while (0 <= f(t) && f(t) <= y_max && x <= x_max
	 && fabs(deriv(f, t, dt)) <= 2 && pt_count <= num_pts)
    {
      if ( i%ITERATIONS == 0 )
	{
	  print(pair(x, sqrt(f(t))));
	  ++pt_count;
	  line_break(pt_count, num_pts, path_style);
	}

      x += dt*sqrt((4-deriv(f, t, dt)*deriv(f, t, dt))/(4*f(t)));
      t += dt;
      ++i;
    }
  
  /* Next point printed is slightly wrong; x incremented, t not */
  print(pair(x, sqrt(f(t-dt))));
}

void 
plot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("plot_profile");
  draw_profile(f, a, b, num_pts, PLAIN);
  end_stanza();
}

void 
dashplot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("dashplot_profile");
  draw_profile(f, a, b, num_pts, DASHED);
  end_stanza();
}

void 
dotplot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("dotplot_profile");
  draw_profile(f, a, b, num_pts, DOTTED);
  end_stanza();
}

void 
boldplot_profile(double f(double), double a, double b, int num_pts)
{
  comment_plot("boldplot_profile");
  bold();
  draw_profile(f, a, b, num_pts, BOLD);
  endbold();
  end_stanza();
}

/* Plane linear transformations */

// 2x2 matrix multiplication [a1 a2][in] = [out]
pair 
transf(pair a1, pair a2, pair in)
{
  pair out;

  out.x1 = a1.x1*in.x1 + a2.x1*in.x2;
  out.x2 = a1.x2*in.x1 + a2.x2*in.x2;

  return out;
}

pair 
reflect(double theta, pair in)
{
  double a = cos(2*theta);
  double b = sin(2*theta);
  pair out;

  /*
   * Columns of reflection matrix are P(a,b), P(b,-a)
   */
  out=transf(P(a,b), P(b,-a), in);

  return out; 
}

void 
std_F(pair a1, pair a2)
{
  pair p1, p2, p3, p4, p5, p6, p7, p8, p9, p10;
  pair q1, q2, q3, q4, q5, q6, q7, q8, q9, q10;
  pair c1, c2, c3, c4;

  double r=1.0/6.0;

  // Vertices of standard F
  p1 = P(r,   0.75*r);
  p2 = P(2*r, 0.75*r);
  p3 = P(2*r, 2.25*r);
  p4 = P(4*r, 2.25*r);
  p5 = P(4*r, 3.25*r);
  p6 = P(2*r, 3.25*r);
  p7 = P(2*r, 4.25*r);
  p8 = P(5*r, 4.25*r);
  p9 = P(5*r, 5.25*r);
  p10= P(r,   5.25*r);

  // Vertices of transformed F
  q1 = transf(a1, a2, p1);
  q2 = transf(a1, a2, p2);
  q3 = transf(a1, a2, p3);
  q4 = transf(a1, a2, p4);
  q5 = transf(a1, a2, p5);
  q6 = transf(a1, a2, p6);
  q7 = transf(a1, a2, p7);
  q8 = transf(a1, a2, p8);
  q9 = transf(a1, a2, p9);
  q10= transf(a1, a2, p10);

  // Vertices of parallelogram
  c1 = transf(a1, a2, P(0,0));
  c2 = transf(a1, a2, P(1,0));
  c3 = transf(a1, a2, P(1,1));
  c4 = transf(a1, a2, P(0,1));

  fprintf (stdout, "\n%%%% Standard F: (%g,%g), (%g,%g)", 
	   a1.x1, a1.x2, a2.x1, a2.x2);
  fprintf (stdout, "\n%%%%");

  // Boundary of parallelogram
  fprintf (stdout, "\n\\path");
  print(c1);
  print(c2);
  print(c3);
  print(c4);
  print(c1);

  dot(P(0,0));

  // The actual F
  fprintf (stdout, "\n\\blacken\\path");
  print(q1);
  print(q2);
  print(q3);
  print(q4);
  print(q5);
  print(q6);
  print(q7);
  print(q8);
  print(q9);
  print(q10);
  print(q1);

  end_stanza();
}

/*
 * fractal generation
 *
 * The basic recursion unit is a piecewise-linear path whose segments
 * are parallel to spokes on a wheel, labelled modulo <spokes>.
 * Recursively up to <depth>, each segment is replaced by a copy of the
 * recursion unit, scaled and rotated in order to join p to q.
 *
 * Kludge: pre_seed[0] = spokes, pre_seed[1] = length of seed;
 *
 * Sample data for _/\_ standard Koch snowflake:
 * const int seed[] = {6, 4, 0, 1, -1, 0};
 */

static int 
get_spokes(const int *pre_seed)
{
  return pre_seed[0];
}

static int 
get_length(const int *pre_seed)
{
  return pre_seed[1];
}

static pair
get_scale(int spokes, int length, const int *seed)
{
  pair sum = P(0,0);

  for (int i=0; i< length; ++i)
    sum += cis(2*M_PI*seed[i]/spokes);

  return sum;
}

void 
fractal(pair p, pair q, int depth, const int *pre_seed)
{
  int spokes = get_spokes(pre_seed);
  int seed_length = get_length(pre_seed);

  // Kludge to extract seed from pre_seed
  int seed[seed_length];
  for (int i=0; i<seed_length; ++i)
    seed[i] = pre_seed[i+2];

  // Unit-length steps in <seed> sequence add up to <scale>
  pair scale = get_scale(spokes, seed_length, seed);

  // Number of points in final fractal
  int length = 1+(int)pow(seed_length, depth); 
  int direction[length]; // stepping information

  pair location = p; // coordinates of current point
  pair step; // increment between successive points

  for(int i=0; i<length; ++i) // initialize direction[]
    direction[i]=0;

  /* 
   * direction[] starts out [0, 1, -1, 0, ..., 0] (seed_length^depth entries)
   * then take repeated "Kronecker sum" with seed = [0, 1, -1, 0]
   */

  for(int i=0; i<seed_length; ++i)
    direction[i]=seed[i];

  for(int i=1; i<depth; ++i) // recursively fill direction array
    {
      for(int j=0; j < pow(seed_length,i); ++j)
	{
	  for(int k=seed_length-1; 0 < k; --k)
	    direction[k*(int)pow(seed_length,i) + j] = direction[j] + seed[k];
	}
    }

  printf("\n\\path");
  print(location);
      
  for(int i=0; i<length; ++i)
    {
      /* Magic number: Split output into 200-point blocks (TeX memory) */
      if(i < length-1)
	{
	  if (i%200 == 0 && 0 < i)
	    {
	      printf("\n\\path");
	      print(location); // New path segment -- repeat point
	    }
	  else 
	    line_break(i, length, PLAIN);

	  step = polar(pow(raw_len(scale),-depth),
		       (2*M_PI/spokes)*direction[i])*(q-p);
	  step /= scale;
	  location += step;      
	  print(location);
	}
    }
  end_stanza();
}

