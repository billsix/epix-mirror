/*
 * plots.h 
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.7.x
 * Last Change: May 27, 2002
 */

#ifndef _EPIX_PLOTS
#define _EPIX_PLOTS

#ifdef _EPIX_COMPILE
#include "objects.h"
#include "functions.h"
#endif

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *          Plots of user-specified functions -- plots.c         *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* Adaptive plotting */
void
draw_adapt_plot (double f1(double), double f2(double),
		 double, double, int, const int);

void
adplot (double f(double), double, double, int);

void
dashadplot (double f(double), double, double, int);

void
dotadplot (double f(double), double, double, int);

void
boldadplot (double f(double), double, double, int);


/* Graph y=f(t), bounds on t, and number of points to plot. */
void
comment_plot (char *);

void
draw_plot (double f(double), double, double, int, const int);

void
plot (double f(double), double, double, int);

void
dashplot (double f(double), double, double, int);

void
dotplot (double f(double), double, double, int);

void
boldplot (double f(double), double, double, int);

/* Parametric plot [x(t), y(t)] */
void
draw_paramplot (double x(double), double y(double),
		double, double, int, const int);

void
paramplot (double x(double), double y(double),
	   double, double, int);

void
dashparamplot (double x(double), double y(double),
	       double, double, int);

void
dotparamplot (double x(double), double y(double),
	      double, double, int);

void
boldparamplot (double x(double), double y(double),
	       double, double, int);

/* Space curve plot [u1(t), u2(t), u3], projected by <viewpoint> */
void
draw_plot3d (double u1(double), double u2(double), double u3(double),
	     double, double, int, const int);

void
plot3d (double u1(double), double u2(double), double u3(double),
	double, double, int);

void
dashplot3d (double u1(double), double u2(double), double u3(double),
	    double, double, int);

void
dotplot3d (double u1(double), double u2(double), double u3(double),
	   double, double, int);

void
boldplot3d (double u1(double), double u2(double), double u3(double),
	    double, double, int);

/* Overloaded names for parametric/space plots */
void
plot (double x(double), double y(double), double, double, int);

void
dashplot (double x(double), double y(double), double, double, int);

void
dotplot (double x(double), double y(double), double, double, int);

void
boldplot (double x(double), double y(double), double, double, int);

void
plot (double u1(double), double u2(double), double u3(double),
      double, double, int);

void
dashplot (double u1(double), double u2(double), double u3(double),
	  double, double, int);

void
dotplot (double u1(double), double u2(double), double u3(double),
	 double, double, int);

void
boldplot (double u1(double), double u2(double), double u3(double),
	  double, double, int);


/* Polar plot r=r(t) */
void
draw_polarplot (double r(double), double, double, int, const int);

void
polarplot (double r(double), double, double, int);

void
dashpolarplot (double r(double), double, double, int);

void
dotpolarplot (double r(double), double, double, int);

void
boldpolarplot (double r(double), double, double, int);

/* Plotting families of curves */
void
draw_sliceplot1(double f1(double, double), double f2(double, double), 
		double, double, double, int, const int);
void
draw_sliceplot2(double f1(double, double), double f2(double, double), 
		double, double, double, int, const int);

void
sliceplot1 (double f1(double, double), double f2(double, double), 
	    double, double, double, int);
void
sliceplot2 (double f1(double, double), double f2(double, double), 
	    double, double, double, int);

void
dashsliceplot1 (double f1(double, double), double f2(double, double), 
		double, double, double, int);
void
dashsliceplot2 (double f1(double, double), double f2(double, double), 
		double, double, double, int);

void
dotsliceplot1 (double f1(double, double), double f2(double, double), 
	       double, double, double, int);
void
dotsliceplot2 (double f1(double, double), double f2(double, double), 
	       double, double, double, int);

void
boldsliceplot1 (double f1(double, double), double f2(double, double), 
		double, double, double, int);
void
boldsliceplot2 (double f1(double, double), double f2(double, double), 
		double, double, double, int);

void
multiplot1 (double f1(double, double), double f2(double, double), 
	    pair, pair, mesh, int);
void
multiplot2 (double f1(double, double), double f2(double, double), 
	    pair, pair, mesh, int);

void
dashmultiplot1 (double f1(double, double), double f2(double, double), 
		pair, pair, mesh, int);
void
dashmultiplot2 (double f1(double, double), double f2(double, double), 
		pair, pair, mesh, int);

void
dotmultiplot1 (double f1(double, double), double f2(double, double), 
	       pair, pair, mesh, int);
void
dotmultiplot2 (double f1(double, double), double f2(double, double), 
	       pair, pair, mesh, int);

void
boldmultiplot1 (double f1(double, double), double f2(double, double), 
		pair, pair, mesh, int);
void
boldmultiplot2 (double f1(double, double), double f2(double, double), 
		pair, pair, mesh, int);


/* Truncated plotting */

/* 
 * pair edge_seek (double f1(), double f2(), double f3(), double, double);
 * declared static in plots.cc; clipplot takes *three* function arguments
 */

void
draw_clipplot (double f1(double), double f2(double), double f3(double),
	       double, double, int, const int);

void
clipplot (double f(double), double, double, int);

void
dashclipplot (double f(double), double, double, int);

void
dotclipplot (double f(double), double, double, int);

void
boldclipplot (double f(double), double, double, int);

/* Clipped parametric plotting */
void
clipparamplot (double f1(double), double f2(double), double, double, int);

void
dashparamclipplot (double f1(double), double f2(double), double, double, int);

void
dotparamclipplot (double f1(double), double f2(double), double, double, int);

void
boldparamclipplot (double f1(double), double f2(double), double, double, int);

/* Overloaded parametric plotting */
void
clipplot (double f1(double), double f2(double), double, double, int);

void
dashclipplot (double f1(double), double f2(double), double, double, int);

void
dotclipplot (double f1(double), double f2(double), double, double, int);

void
boldclipplot (double f1(double), double f2(double), double, double, int);

/* cliiplot3d */
void
clipplot(double f1(double), double f2(double), double f3(double),
	 double t_min, double t_max, int num_pts);
void
dashclipplot(double f1(double), double f2(double), double f3(double),
	     double t_min, double t_max, int num_pts);
void
dotclipplot(double f1(double), double f2(double), double f3(double),
	    double t_min, double t_max, int num_pts);
void
boldclipplot(double f1(double), double f2(double), double f3(double),
	     double t_min, double t_max, int num_pts);

/* Data plotting from file */
void
marker (pair, const int);

void
data_plot (const char *, const int);

/* Derivatives and integrals */

// double deriv(double f(double), double, double);
void
draw_deriv (double f(double), double, double, int, const int);

void
plot_deriv (double f(double t), double, double, int);

void
dashplot_deriv (double f(double t), double, double, int);

void
dotplot_deriv (double f(double t), double, double, int);

void
boldplot_deriv (double f(double t), double, double, int);

void
tan_field (double f1(double), double f2(double), double, double, double);

void
boldtan_field (double f1(double), double f2(double), double, double, double);

// double integrand(double f(double), double, double);
void
draw_int (double f(double), double, double, int, const int);

void
plot_int (double f(double), double, double, int);

void
dashplot_int (double f(double), double, double, int);

void
dotplot_int (double f(double), double, double, int);

void
boldplot_int (double f(double), double, double, int);

/* Slope, dart, and vector fields */
void
draw_slope_field (double f1(double, double), double f2(double, double),
		  pair, pair, int, int);

void
slope_field (double f1(double, double), double f2(double, double),
	     pair, pair, int, int);

void
boldslope_field (double f1(double, double), double f2(double, double),
		 pair, pair, int, int);

void
draw_dart_field (double f1(double, double), double f2(double, double),
		 pair, pair, int, int);

void
dart_field (double f1(double, double), double f2(double, double),
	    pair, pair, int, int);

void
bolddart_field (double f1(double, double), double f2(double, double),
		pair, pair, int, int);

void
draw_vector_field (double f1(double, double), double f2(double, double),
		   pair, pair, int, int, const int);

void
vector_field (double f1(double, double), double f2(double, double),
	      pair, pair, int, int);

void
boldvector_field (double f1(double, double), double f2(double, double),
		  pair, pair, int, int);

/* ODE plotting */
void
draw_ode_plot (double f1(double, double), double f2(double, double),
	       pair, double, int, const int);

void
ode_plot (double f1(double, double), double f2(double, double),
	  pair, double, int);

void
dashode_plot (double f1(double, double), double f2(double, double),
	      pair, double, int);

void
dotode_plot (double f1(double, double), double f2(double, double),
	     pair, double, int);

void
boldode_plot (double f1(double, double), double f2(double, double),
	      pair, double, int);

#endif /* _EPIX_PLOTS */
