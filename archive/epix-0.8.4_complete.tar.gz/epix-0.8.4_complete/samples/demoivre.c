/* demoivre.c -- July 22, 2001 */

#include "epix.h"

main()
{
  int n=24;
  pair pow = e_1; // (1,0)
  pair z = e_1 + (M_PI/n)*e_2;

  bounding_box(P(-1.5,0), P(1,1.25));
  picture(P(200,100));
  unitlength("1pt");
  offset(P(75,0));

  begin();
  
  for(int i=0; i<n; ++i)
    {
      line(P(0,0), z*pow);
      line(pow, z*pow);
      pow *= z;
    }
  red();
  boldtriangle(P(0, 0), e_1, z);
  end_red();
  label(z, P(2, -4), "$\\alpha=1+\\frac{i\\pi}{n}$");

  label(pow, P(-14,-4), "$\\alpha^n$");

  end();
}

