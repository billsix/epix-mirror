/* 
 * weierstrass.c -- A Weierstrass nowhere-differentiable function
 *
 * August 16, 2001
 */
#include "epix.h"
#define N 8 // Number of summands

/* "cb" is the Charlie Brown function, see functions.c */

double weierstrass(double t)
{
  int i;
  double y=0;
  for(i=0; i < N; ++i)
    y += pow(2,-i)*cb(pow(2,i)*t);

  return y;
}

main() {

  bounding_box(P(-2, -0.5), P(2, 1.5));
  picture(P(300, 150));
  unitlength("0.01in");
  //  offset(P(150,0));
  offset(P(150,-150));

  begin();

  h_axis(P(x_min,0), P(x_max,0), 8);
  v_axis(P(0,y_min), P(0,y_max), 4);
  h_axis_labels(P(x_min,0), P(x_max,0), x_size, P(-8,-14));
  
  boldplot(weierstrass, x_min, x_max, pow(2,N));

  blue();
  plot(cb, x_min - 0.25, x_max+0.25, 4*x_size + 2);
  end_blue();

  red();
  boldplot(weierstrass, 0.5, 1.5, pow(2,N-2));
  end_red();

  end();
}

