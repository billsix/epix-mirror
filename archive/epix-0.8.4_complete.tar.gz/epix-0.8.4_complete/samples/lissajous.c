/* 
 * lissajous.c -- Tangent vector field plots along a curve
 *
 * May 29, 2002
 */

#include "epix.h"

double f1(double t) {
  return sin(3*M_PI*t+0.5);
}
double f2(double t) {
  return sin(4*M_PI*t+0.5);
}

main() {

  bounding_box(P(-1,-1), P(1,1));
  picture(P(300, 300));
  unitlength("0.01in");
  offset(P(150,0));

  begin();

  grid(P(x_min,y_min), P(x_max,y_max), 4*x_size, 4*y_size);
  boldline(P(x_min, 0), P(x_max, 0));
  boldline(P(0, y_min), P(0, y_max));

  red();
  paramplot(f1, f2, 0, 2, 200);
  end_red();
  blue();
  tan_field(f1, f2, 0, 2, 81);
  end_blue();

  //  h_axis_masklabels(P(x_min, 0), P(x_max, 0), x_size, P(-16, -2));
  v_axis_masklabels(P(0, y_min), P(0, y_max), 2*y_size, P(-15, -3));

  end();
}

