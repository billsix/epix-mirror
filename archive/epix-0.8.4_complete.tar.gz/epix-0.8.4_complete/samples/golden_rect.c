/* sample1.c, March 28, 2002
 * 
 * Golden Rectangle
 */

#include "epix.h"

main() 
{
  double a = (1+sqrt(5))/2;

  bounding_box(P(0,0), P(a,1));
  picture(P(100*(1+a), 100*a));
  unitlength("0.0125in");

  offset(P(100,0));

  begin();

  line(P(1,0), P(1,1));
  dashline(P(0.5,0), P(0.5,1));
  line(P(0.5,0), P(1,1));

  arc(P(0.5,0), a-0.5, 0, atan(2));
  boldrect(P(0,0), P(a, 1));

  end();
}

