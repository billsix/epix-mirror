/* geomsum.c -- July 16, 2001 */

#include "epix.h"

main() 
{
  double t;

  unitlength("1.5pt");
  bounding_box(P(0,0), P(1,1));
  picture(P(128,128));
  offset(P(96,0));

  begin();   

  for(int i=0; i<8; ++i)
    {
      t = pow(0.5, i+1); // 2^-(i+1)
      line(P(1-t, 1-2*t), P(1-t, 1));
      line(P(1-t, 1-t), P(1, 1-t)); 
    }
  boldrect(P(x_min, y_min), P(x_max, y_max));

  end();
}
