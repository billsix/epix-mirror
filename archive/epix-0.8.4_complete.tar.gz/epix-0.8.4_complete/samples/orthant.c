/* orthant.c, March 28, 2002
 * 
 * Fake 3-D sphere
 */

#include "epix.h"

main() 
{
  double r=1/sqrt(3);

  bounding_box(P(-1, -1), P(1,1));
  picture(P(160, 160));
  unitlength("1pt");

  offset(P(100, -50));

  begin();

  ellipse(P(0,0), P(1,1));
  
  /* Center, radius, rotation angle in degrees */
  red();
  boldellipse_half(P(0,0), P(r, 1),  30); 
  dashellipse_half(P(0,0), P(r, 1), 210);
  end_red();

  boldellipse_half(P(0,0), P(r,1),  -90);
  dashellipse_half(P(0,0), P(r,1),   90);

  boldellipse_half(P(0,0), P(r, 1), 150);
  dashellipse_half(P(0,0), P(r, 1), -30);

  arrow(P(0,0), P(0,1.2));
  boldarrow(P(0,0), P(-0.6*sqrt(3), -0.6));
  arrow(P(0,0), P(0.6*sqrt(3), -0.6));

  end();
}
