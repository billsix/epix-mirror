/* slopefield.c -- March 29, 2002
 *
 * Slope field and ode plotting
 */

#include "epix.h"

double f1(double s, double t)
{
  return 0.1*s - t/(0.01+s*s+t*t);
}
double f2(double s, double t)
{
  return 0.025*t + s/(0.01+s*s+t*t);
}

main() {
  int i=0;

  unitlength("1pt");
  bounding_box(P(-4, -3), P(2,2));
  picture(P(234, 195));
  offset(P(120, -30));

  begin();

  dart_field(f1, f2, P(x_min, y_min), P(x_max, y_max), 4*x_size, 4*y_size);

  for (int i=0; i<7; ++i)
    {
      rgb(0.25 - 0.05*i, 1 - 0.1*i, 0.2*i);
      boldode_plot(f1, f2, P(-0.9-0.025*i,0), 20, 200);
    }
  end();
}

