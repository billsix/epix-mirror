/*
 * functions.cc -- non-standard functions
 *
 *
 * Andrew D. Hwang            <ahwang@mathcs.holycross.edu>
 *
 * Version 0.7.x
 * Last Change: May 28, 2002
 */

#include <math.h>
#define _INCLUDE
#include "globals.h"

/* identity and coordinate projections */
double
id (double x)
{
  return x;
}

double
proj1 (double x, double y)
{
  return x;
}
double
proj2 (double x, double y)
{
  return y;
}

/* sin(x)/x */
double
sinx (double x)
{
  if (x != 0)
    return sin(x)/x;
  else
    return 1;
}

/* reciprocal */
double
recip (double x)
{
  if (x != 0)
    return 1/x;
  else
    return 0;
}

/* signum */
double
sgn (double x)
{
  if (x != 0)
    return x/fabs(x);
  else
    return 0;
}

/* Charlie Brown: Period-2 extension of |x| on [-1,1] /\/\/\/\/\/ */
double
cb (double x)
{
  x = fabs(x); // cb is even

  while (x > 1)
    x += -2;

  return fabs(x); // cb extends |x|
}

/* Integer-valued functions of integer variables */

int abs (int i)
{
  if (i<0)
    i = -i;
  return i;
}

/* N.B.: gcd(0,i) = |i| */
int gcd (int i, int j)
{
  int temp;

  i=abs(i);
  j=abs(j);

  if (i==0 || j==0) // (1,0) and (0,1) coprime, others not
    return i+j;

  else {
    if (j < i) // swap them
      {
	temp = j;
	j=i;
	i=temp;
      }
    /* Euclidean algorithm */    
    while ((temp = j%i)) // i does not evenly divide j
      {
	j=i;
	i=temp;
      }
    
    return i;
  }
}

/* inf and sup of f on [a,b] */
double
inf (double f(double), double a, double b)
{
  int i = 0;
  int N = (int) ceil(fabs(b-a)); // N >= 1 unless a=b
  double y = f(a);
  double dx = (b-a)/(N*ITERATIONS);

  for (i=1; i <= N*ITERATIONS; ++i)
    if (f(a + i*dx) < y)
      y = f(a + i*dx);

  return y;
}

double
sup (double f(double), double a, double b)
{
  int i = 0;
  int N = (int) ceil(fabs(b-a)); // N >= 1 unless a=b
  double y = f(a);
  double dx = (b-a)/(N*ITERATIONS);

  for (i=1; i <= N*ITERATIONS; ++i)
    if (f(a + i*dx) > y)
      y = f(a + i*dx);

  return y;
}
