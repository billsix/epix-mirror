/* p-twist.c -- Knot primitives */
#include "epix.h"

main()
{
  unitlength("1pt");
  bounding_box(P(0,0), P(3,1));
  picture(P(150,50));

  begin();
  dashrect(P(0,0), P(1,1));
  dashrect(P(2,0), P(3,1));

  label(P(0,0), P(-30, 2), "$(a,b)$");
  label(P(1,1), P(-10,6), "$(c,d)$");

  p_twist(P(0,0), P(1,1));
  p_twist(P(2,1), P(3,0));

  label(P(2,1), P(-20,6), "$(a,b)$");
  label(P(3,0), P(2,2), "$(c,d)$");

  label(P(-1.5,0.5), P(0,0), "{\\tt p\\underline{ }twist}");

  end();
}
