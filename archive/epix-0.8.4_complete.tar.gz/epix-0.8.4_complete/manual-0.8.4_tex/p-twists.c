/* p-twists.c -- Knot primitives */
#include "epix.h"

main()
{
  unitlength("1pt");
  bounding_box(P(0,0), P(3,1));
  picture(P(150,50));

  begin();
  dashrect(P(0,1), P(3,0));

  label(P(0,1), P(-30, -14), "$(0,1)$");
  label(P(3,0), P(4,0), "$(3,0)$");

  boldtwists(P(0,1), P(3,0), -5);

  label(P(0,0), P(-16,-14), "{\\tt boldtwists(P(0,1), P(3,0), -5);}");

  end();
}
