/* semicirc.c -- A rectangle inscribed in a semi-circle */

#include "epix.h"

double w = 0.6;

main()
{
  unitlength("1in");
  bounding_box(P(-1, 0), P(1, 1));
  picture(P(2.5, 1.25));
  offset(P(0,0.125));

  begin();

  line(P(x_min, 0), P(x_max, 0));
  line(P(0, y_min), P(0, y_max));

  ellipse_top(P(0,0), P(1,1));

  boldrect(P(-w,0), P(w, sqrt(1-w*w)));

  label(P(0.5, sqrt(0.75)), P(2,4), "$y=\\sqrt{1-x^2}$");
  h_axis_labels(P(x_min,0), P(x_max,0), x_size, P(-12, -12));

  end();
}
