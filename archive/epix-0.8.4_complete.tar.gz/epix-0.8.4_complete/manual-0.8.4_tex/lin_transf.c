/*
 * lin_transf.c -- The standard F
 *
 * February 12, 2002
 */
#include <epix.h>

main()
{
  bounding_box(P(-1,-1), P(2,2));
  unitlength("1pt");
  picture(P(150,150));
  offset(P(0,40));

  begin();
  std_F(P(1,-1), P(0,1));
  label(P(1,1), P(0,0), "$\\left[\\begin{matrix}\\phantom{-}1&0\\\\ -1&1\\end{matrix}\\right]$");
  end();

  offset(P(40,40));
  begin();
  std_F(P(0,-1), P(-1,0));
  label(P(0,1), P(0,0), "$\\left[\\begin{matrix}\\phantom{-}0&-1\\\\ -1&\\phantom{-}0\\end{matrix}\\right]$");
  end();
}
  

