/* parabola.c -- The parabola from the reference manual */
#include "epix.h"

double f(double t) {
  return t*t; 
}

main()
{
  unitlength("1mm");
  picture(P(100, 50));
  bounding_box(P(-1, 0), P(1,1));

  begin();

  /* Graph f for t in [-1,1] using 20 steps */ 
  plot(f, -1, 1, 20);  

  end();
}
