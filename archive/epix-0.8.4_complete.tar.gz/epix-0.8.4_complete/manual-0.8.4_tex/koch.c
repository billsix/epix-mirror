/* 
 * koch.c -- Simple fractal "curve" generation. 
 *
 * June 6, 2002
 */

#include <epix.h>

// const int koch_seed[] = {6, 4, 0, 1, -1, 0};
const int seed[] = {4, 8, 0, 1, 0, 3, 3, 0, 1, 0};

main() 
{
  bounding_box(P(0,0), P(4, 0.5));
  picture(P(360, 45));
  unitlength("1pt");
  offset(P(0,22.5));

  begin();   

  for (int i=1; i <= 4; ++i)
    fractal(P(i-1,0), P(i,0), i, seed);

  end();
}

