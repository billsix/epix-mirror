/* sine.c -- The graph y = sin x on [-3,3] */
#include "epix.h"
double x0 = M_PI_2; // \pi/2 to 20 decimals

main()
{
  unitlength("1pt");
  picture(P(300, 100));
  bounding_box(P(-3, -1), P(3,1));

  begin();

  h_axis(P(x_min, 0), P(x_max, 0), x_size);
  v_axis(P(0, y_min), P(0, y_max), y_size);

  plot(sin, x_min, -x0, 30);
  plot(sin, x0, x_max, 30);

  dashline(P(x0,0), P(x0, sin(x0)));

  label(P(x0, 0), P(-3, -12), "$\\frac{\\pi}{2}$");
  h_axis_masklabels(P(x_min,0), P(x_max,0), x_size, P(-14,-12));

  boldplot(sin, -x0, x0, 60);

  end();
}
