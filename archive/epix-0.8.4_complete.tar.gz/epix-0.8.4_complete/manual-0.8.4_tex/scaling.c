/* 
 * scaling.c
 */

#include "epix.h"

main()
{
  unitlength("1pt");
  bounding_box(P(0,-0.125), P(5, 1));
  picture(P(300, 60));
  offset(P(0,5));

  begin();

  rect(P(0,0), P(1.5, 0.75));
  rect(P(3,0), P(5, 0.875));

  dot(P(0,0));
  dot(P(1.5, 0.75));

  dot(P(3,0));
  dot(P(5,0.875));

  arrow(P(1.75, 0.25), P(2.75,0.25));
  label(P(2, 0.25), P(0,4), "{\\tt ePiX}");

  label(P(0,0), P(2,4), 
	"\\scriptsize$(x_\\mathrm{min},y_\\mathrm{min})$");
  label(P(1.5, 0.75), P(-50,-8), 
	"\\scriptsize$(x_\\mathrm{max},y_\\mathrm{max})$");
  label(P(0,0), P(-20,-12), "Cartesian bounding box");

  label(P(3,0), P(2,4), "\\scriptsize$(0,0)$");
  label(P(5, 0.875), P(-46, -8), 
	"\\scriptsize$(h_\\mathrm{size},v_\\mathrm{size})$");
  label(P(3,0), P(16, -12), "\\LaTeX\\ picture box");
  end();
}
