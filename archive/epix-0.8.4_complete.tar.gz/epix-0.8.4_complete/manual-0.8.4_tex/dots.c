/* dots.c -- Dot primitives */
#include "epix.h"

main()
{
  unitlength("1pt");
  bounding_box(P(0,0), P(4,1));
  picture(P(48,12));
  offset(P(10,2));

  begin();

  spot(P(0,0));
  dot(P(1,0));
  ddot(P(2,0));

  line(P(2.5,0), P(4.75,0));

  circ(P(3,0));
  ring(P(4,0), 6);

  end();
}
