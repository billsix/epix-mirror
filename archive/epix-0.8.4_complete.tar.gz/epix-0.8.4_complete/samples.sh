#!/bin/bash
#
# samples.sh: (un)install/test sample files
#
# This script is NOT INTENDED TO BE RUN MANUALLY!!
#
#   Options: --install, --uninstall, --test
#   Assumes EPIX_ROOTDIR is set to install directory from Makefile
#
# June 29, 2002  Andrew D. Hwang,  ahwang@mathcs.holycross.edu
#

if [ "$EPIX_ROOTDIR" = "" ]
then 
    echo "samples.sh: Please do not run this script manually!" && exit 1
fi

TARBALL=epix_samples.tar
SAMPLEDIR=share/epix
SAMPLE_PARENT=share

# Mimic run of epix on sample file, using newly-compiled library
ePiX() {
FILEROOT=${1%%".c"}

$CXX $CFLAGS $1 -o $FILEROOT.exe -I. -L. -lm -lepixtest 

if [ -x "$FILEROOT.exe" ] 
then ./$FILEROOT.exe > $FILEROOT.eepic
fi

if [ -f "$FILEROOT.eepic" ] 
then
    echo -n "." # Progress meter :)
    rm -f $FILEROOT.exe
    return 0;

else 
    echo "failed, exiting"
    rm -f $FILEROOT.exe libepixtest.a 2>/dev/null
    exit 1;
fi
}
# end of ePiX()

case "$1" in

    --install)
	if [ ! -d $EPIX_ROOTDIR/$SAMPLEDIR ] # pre-install script has failed...
	then echo "$0: Can't find directory $EPIX_ROOTDIR/$SAMPLEDIR"
	exit 1;
	fi

	cd samples && tar -cf $TARBALL *.c sample.* makefigs template
	mv $TARBALL $EPIX_ROOTDIR/$SAMPLEDIR/$TARBALL

	cd $EPIX_ROOTDIR/$SAMPLEDIR && tar -xf $TARBALL 
	chown $USER.$USER * && chmod go+rX *
	;;

    --uninstall)
	# Delete $INSTALL/share/epix; Makefile handles the rest
	cd $EPIX_ROOTDIR/$SAMPLE_PARENT 
	if [ -d epix ]; then rm -Rf epix; fi
	;;

    --test)
	CXX="g++"
	CFLAGS="-w"

	if [ -d samples ] 
	then cd ./samples
	else echo "samples.sh: Directory \"samples\" does not exist" && exit 1;
	fi

	# Now we're in samples
	cp -p ../libepix.a libepixtest.a
	cp -p ../epix.h epix.h

	echo -n "Creating .eepic files  "
	for FILE in *.c ; do ePiX $FILE ; done # N.B. Shell function ePiX
	echo " done"

	# Clean up
	rm -f libepixtest.a epix.h

	echo; echo "Testing laps..."

	../laps sample.tex 1>/dev/null

	if [ -f "sample.ps" ] 
	then echo; echo "ePiX test: success"
	     mv -f sample.dvi  sample.ps ..
	     rm -f sample.log *.eepic
	     echo "You may now preview sample.dvi or sample.ps"; exit 0;
	else echo; echo "failed"; exit 1;
	fi
	;;

    *)
	echo "$0: Unknown option $1" && exit 1
	;;
esac

exit 0
