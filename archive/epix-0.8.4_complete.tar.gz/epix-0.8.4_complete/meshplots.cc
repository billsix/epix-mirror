/* 
 * meshplot.cc -- Wire mesh plotting
 *
 * Andrew D. Hwang                      <ahwang@mathcs.holycross.edu>
 *
 * Version: 0.8.3
 * Last Change: June 14, 2002
 */

#define _EPIX_COMPILE
#include "meshplots.h"
#include "functions.h"

/* 
 * Wiremesh plotting -- no hidden line removal
 */
static void 
draw_wiremesh(double f1(double u1, double u2),
	      double f2(double u1, double u2),
	      double f3(double u1, double u2),
	      pair p1, pair p2, mesh N, mesh num_pts, const int path_style)
{
  // Fineness of plotted mesh
  double step_u1 = (p2.x1 - p1.x1)/N.n1;
  double step_u2 = (p2.x2 - p1.x2)/N.n2;
  // Number of points plotted in each direction
  double du1 = (p2.x1 - p1.x1)/num_pts.n1;
  double du2 = (p2.x2 - p1.x2)/num_pts.n2;

  for (int i = 0; i <= N.n1; ++i)
    {
      double temp1 = p1.x1 + i*step_u1;
      fprintf (stdout, "\n%%%%  x1 = %g", temp1);
      start_path(path_style);
      for (int j = 0; j <= num_pts.n2; ++j)
      {
	double temp2 = p1.x2 + j*du2;
	print(V(f1(temp1, temp2), f2(temp1, temp2), f3(temp1, temp2)));
	line_break(j, num_pts.n2, path_style);
      }
      fprintf (stdout, "\n%%%%");
    }

  for (int j = 0; j <= N.n2; ++j)
    {
      double temp2 = p1.x2 + j*step_u2;
      fprintf (stdout, "\n%%%%  x2 = %g", temp2);
      start_path(path_style);
      for (int i = 0; i <= num_pts.n1; ++i)
      {
	double temp1 = p1.x1 + i*du1;
	print(V(f1(temp1, temp2), f2(temp1, temp2), f3(temp1, temp2)));
	line_break(i, num_pts.n1, path_style);
      }
    }
}

void wiremesh(double f1(double, double), double f2(double, double), 
	      double f3(double, double), pair p1, pair p2, mesh N,
	      mesh num_pts)
{
  fprintf (stdout, "\n%%%% wiremesh:");
  draw_wiremesh(f1, f2, f3, p1, p2, N, num_pts, PLAIN);
  end_stanza();
} 
void dashwiremesh(double f1(double, double), double f2(double, double), 
		 double f3(double, double), pair p1, pair p2, mesh N,
		 mesh num_pts)
{
  fprintf (stdout, "\n%%%% dashwiremesh:");
  draw_wiremesh(f1, f2, f3, p1, p2, N, num_pts, DASHED);
  end_stanza();
} 
void dotwiremesh(double f1(double, double), double f2(double, double), 
		 double f3(double, double), pair p1, pair p2, mesh N,
		 mesh num_pts)
{
  fprintf (stdout, "\n%%%% dotwiremesh:");
  draw_wiremesh(f1, f2, f3, p1, p2, N, num_pts, DOTTED);
  end_stanza();
} 
void boldwiremesh(double f1(double, double), double f2(double, double), 
		  double f3(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts)
{
  fprintf (stdout, "\n%%%% boldwiremesh:");
  bold();
  draw_wiremesh(f1, f2, f3, p1, p2, N, num_pts, BOLD);
  end_bold();
  end_stanza();
} 

/* Wire mesh plot of function of two real variables */
void wiremesh(double f(double, double), pair p1, pair p2, mesh N,
	      mesh num_pts)
{
  fprintf (stdout, "\n%%%% wiremesh:");
  draw_wiremesh(proj1, proj2, f, p1, p2, N, num_pts, PLAIN);
  end_stanza();
} 
void dashwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts)
{
  fprintf (stdout, "\n%%%% dashwiremesh:");
  draw_wiremesh(proj1, proj2, f, p1, p2, N, num_pts, DASHED);
  end_stanza();
} 
void dotwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		 mesh num_pts)
{
  fprintf (stdout, "\n%%%% dotwiremesh:");
  draw_wiremesh(proj1, proj2, f, p1, p2, N, num_pts, DOTTED);
  end_stanza();
} 
void boldwiremesh(double f(double, double), pair p1, pair p2, mesh N,
		  mesh num_pts)
{
  fprintf (stdout, "\n%%%% boldwiremesh:");
  bold();
  draw_wiremesh(proj1, proj2, f, p1, p2, N, num_pts, BOLD);
  end_bold();
  end_stanza();
} 

/*
 * meshplot draws the graph over a rectangle of a function of two real 
 * variables. The algorithm is to start at the front (as determined by
 * the current viewpoint) and "clipplot" sections of the graph, where
 * the plotting criterion is whether or not the point has been occluded
 * by earlier parts of the graph. The process is the repeated side to
 * side, again with "nearness" determined by the viewpoint. This algorithm
 * unfortunately does not generalize to arbitrary parametrized surfaces.
 */

/*
 * mesh_edge1_seek; // moving in x1 direction
 * mesh_edge2_seek; // moving in x2 direction
 *
 * Approximates point where plot goes behind existing plot.
 * Algorithm: Start at point known to be visible, take small steps
 * towards occluded point, stop when point disappears.
 */

static
pair mesh_edge1_seek(double f(double, double), 
		     double t1, double t2, double step)
{
  /*
   * Establish an orthonormal frame; current viewpoint is E3, while
   * E1 is parallel to (x1,x2) plane by default. N.B. E1 vs. E_1...
   */
  triple right;
  if (hypot(viewpt1, viewpt2) == 0 && viewpt3 >= 0)
    {
      right = E_1; // (1,0,0)
      viewpt3 = 1;
    }
  else if (hypot(viewpt1, viewpt2) == 0)
    {
      right = -E_1; // (-1,0,0)
      viewpt3 = -1;
    }
  else
    right = P(-viewpt2, viewpt1, 0);

  triple viewpt = P(viewpt1, viewpt2, viewpt3);

  triple E3 = (1.0/raw_len(viewpt))*viewpt;
  triple E1 = (1.0/raw_len(right))*right;
  triple E2 = E3*E1; // cross product

  pair temp = V(t1, t2, f(t1, t2));

  while (0 /* temp has not been occluded */)
    {
      t1 += (SEEK_SIZE)*step; 
      temp = V(t1, t2, f(t1, t2));
    }
  return temp;
}
